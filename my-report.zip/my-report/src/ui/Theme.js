import { createMuiTheme } from '@material-ui/core/styles';
import OpenSansFont from '../fonts/Open Sans/OpenSans-Regular.ttf';
const openSans = {
    fontFamily: 'Raleway Arial',
    fontStyle: 'normal',
    fontDisplay: 'swap',
    fontWeight: 400,
    src: `
      local('Open Sans'),
      local('OpenSans-Regular'),
      url(${OpenSansFont}) format('ttf')
    `,
    unicodeRange:
      'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF',
  };


const gicBlack = "#000000";
const gicWhite = "#FFFFFF";
const gicGreen = "#85BC24";

const gicLightGrey = "#C9C9C9";
const  gicRegGrey = "#75787A";
const gicDarkGrey = "#52555A";

const gicRed = "#E32213";
const gicOrange = "#F39000";

const gicLightGreen = '#C8DE9F';



export default createMuiTheme({
    palette: {
        common: {
            black: `${gicBlack}`,
            white: `${gicWhite}`,
            green: `${gicGreen}`,
            red: `${gicRed}`,
            orange: `${gicOrange}`,
            grey: `${gicLightGrey}`,
            darkGrey: `${gicRegGrey}`,
            darkGreyBold: `${gicDarkGrey}`
        },
        primary: {
            main: `${gicBlack}`,
        },
        secondary: {
            main: `${gicGreen}`,
        }
    },
    typography: {
        htmlFontSize: 16,
        fontFamily: [
            'openSans',
            'Helvetica Neue',
            'Arial',
            'sans-serif',
            'Apple Color Emoji',
            'Segoe UI Emoji',
            'Segoe UI Symbol',
          ].join(','),
        gic_h1:{
            fontSize: "3.4rem",
            fontWeight: "700",
            textTransform: "none",
        },
        gic_h2:{
            fontSize: "3.2rem",
            fontWeight: "700",
            textTransform: "none",
        },

        gic_h3:{
            fontSize: "2rem",
            fontWeight: "700",
            textTransform: "none",
        },
        gic_h4:{
            fontSize: "1.6rem",
            fontWeight: "700",
            textTransform: "none",
        },
        gic_h5:{
            fontSize: "1.6rem",
            fontWeight: "400",
            textTransform: "none",
        },
        gic_h6:{
            fontSize: "1.6rem",
            fontWeight: "400",
            textTransform: "none",
        },
        body1:{
            fontSize: "1.6rem",
            fontWeight: "400",
            textTransform: "none",
        },
        body2:{
            fontSize: "1.6rem",
            fontWeight: "400",
            textTransform: "none",
        },
        heading_font: {
            fontSize: '20px',
            color: '#52555A',
            opacity: 1,
            fontWeight: 700
        }
    }


});