import React from 'react';
import { makeStyles } from '@material-ui/styles';
import banner from '../../Images/banner.png';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import pieChart from '../../Images/piechart.svg';
import barChart from '../../Images/barchart.svg';



const useStyles = makeStyles(theme => ({
  bannerImgContainer: {
    maxHeight: 385,
    width: '100%'
  },
  bannerImg:{
    objectFit: 'cover',
    width: '98%',
    maxHeight: 385,
    borderRadius: 10,
  },
  gic_h3: {
    ...theme.typography.gic_h3,
    marginBottom: 1,
    fontWeight: '700',
    color: theme.palette.common.green,
    position: 'absolute',
    padding: '52px 42px 42px 42px',
    fontSize: '24px'
  },
  gic_h4: {
    ...theme.typography.gic_h4,
    marginBottom: 1,
    position: 'absolute',
    padding: '60px 32px',
    color: theme.palette.common.grey,
    maxWidth: '60%'
  },
  gic_h5: {
    position: "fixed",
    top: '40%',
    left: '15%'
  },
  cardGrid:{
  position:"absolute",
  top: "30rem",
  width: "58%",
  margin: "0 25px"
  },
  cardContainer:{
    maxWidth: "250px",
    maxHeight: "118px",
    whiteSpace: "nowrap",
    background: '#FFFFFF 0% 0% no-repeat padding-box',
    borderRadius: '8px',
    opacity: 1,
  },
  cardContent:{
    display: "flex"
  },
  iconContainer:{
    marginLeft: "auto",
    marginTop: "-20px"
  },
  salesValue:{
    ...theme.typography.gic_h3,
    color: '#52555A',
    opacity: 1,
    fontSize: '34px'
  },
  valueContainer:{
    marginTop:"-8px"
  }

}))

export default function Banner(props) {
  const classes = useStyles();

  return (
   <React.Fragment>
   <div className={classes.bannerImgContainer}>
   <Typography className={classes.gic_h3} component={'div'}>
    Welcome!
    <div>{props.userName}</div>
 </Typography>
 {/* <Typography className={classes.gic_h4} component={'div'}>
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

  </Typography> */}
  {/* <span className={classes.gic_h5}><SimpleCard></SimpleCard></span> */}
  <Grid container className={classes.cardGrid}  spacing={2}>
  <Grid item xs={12} sm={4}>
  <Card className={classes.cardContainer}>
  <CardHeader subheader="YTD Sales" />

  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
      {props.target ? props.formatNumber(props.target.ytdSales) : null}
      </Typography>
    </span>{" "}
    <span className={classes.iconContainer}>
      <img alt="pie chart image" src={pieChart}/>
    </span>
  </CardContent>
</Card>
  </Grid>
  <Grid item xs={12} sm={4}>
  <Card className={classes.cardContainer}>
  <CardHeader subheader="Sales Target" />

  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
      {props.target ? props.formatNumber(props.target.salesTarget) : null}
      </Typography>
    </span>{" "}
    <span className={classes.iconContainer}>
      <img alt="bar chart image" src={barChart}/>
    </span>
  </CardContent>
</Card>
  </Grid>
  </Grid>


 <img alt="banner image" src={banner} className={classes.bannerImg}/>
   </div>
   </React.Fragment>
  );
}
export { Banner };