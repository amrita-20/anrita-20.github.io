import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import SvgIcon from '@material-ui/core/SvgIcon';
import HomeIcon from '@material-ui/icons/Home';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import SimpleCard from '../Card/Card';
import Banner from '../Banner/Banner';
import DetailsBanner from '../DetailsBanner/DetailsBanner';
import ReactCharts from '../Charts/Charts';
import ReactTable from '../ReactTable/ReactTable';
import BasicTable from '../../_components/Table/Table';
import FilterMenu from '../Filter/Filter';
import EventNoteOutlined from '@material-ui/icons/EventNoteOutlined';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import pieChart from '../../Images/piechart.svg';
import barChart from '../../Images/barchart.svg';
import Backdrop from '@material-ui/core/Backdrop';
import CircularProgress from '@material-ui/core/CircularProgress';
import { useDispatch, useSelector } from 'react-redux';
import AccountTable from '../AccountTable/AccountTable';
import { authHeader } from '../../_helpers';
import Comment from '../Comment/Comment';
import { Paper } from '@material-ui/core';
import DialogTitle from '@material-ui/core/DialogTitle';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
}

function SalesIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d="M11.024,3.055A9.028,9.028,0,1,0,21,13.03H11.024Z" />
    </SvgIcon>
  );
}
function DetailsIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d="M9.286,5.143H7.143A2.143,2.143,0,0,0,5,7.286V20.143a2.143,2.143,0,0,0,2.143,2.143H17.857A2.143,2.143,0,0,0,20,20.143V7.286a2.143,2.143,0,0,0-2.143-2.143H15.714m-6.429,0a2.143,2.143,0,0,0,2.143,2.143h2.143a2.143,2.143,0,0,0,2.143-2.143m-6.429,0A2.143,2.143,0,0,1,11.429,3h2.143a2.143,2.143,0,0,1,2.143,2.143m-3.214,7.5h3.214M12.5,16.929h3.214M9.286,12.643H9.3m-.011,4.286H9.3" />
    </SvgIcon>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
	root: {
		flexGrow: 1,
		marginTop: '2rem'
	},
	tabsContainer: {
		flexGrow: 1,
		display: 'flex',
		height: 'auto'
	},
	tabs: {
		marginTop: '11rem',
		minWidth: 160,
		textAlign: 'left',
		display: 'inline'
	},
	default_tab: {
		width: 264,
		display: 'inline-block',
		backgroundColor: theme.palette.common.white,
		...theme.typography.gic_h6,
		textAlign: 'left',
		'&:hover': {
			outline: 'none'
		},
		'&:active': {
			outline: 'none'
		}
	},
	active_tab: {
		background: '#C8DE9F 0% 0% no-repeat padding-box',
		textAlign: 'left',
		opacity: 0.26,
		...theme.typography.gic_h6,
		fontWeight: 700,

		'&:active': {
			outline: 'none',
			fontWeight: 700
		},
		'&:hover': {
			outline: 'none',
			...theme.typography.gic_h6,
			fontWeight: 700
		}
	},
	imageIcon: {
		height: '100%'
	},

	tabPanelContainer: {
		marginTop: '6rem',
		width: '100%',
		...theme.typography.gic_h3,
		background: '#F4F4F4 0% 0% no-repeat padding-box',
		opacity: 1
	},
	basicTableContainer: {
		marginTop: '3rem',
		borderRadius: '8px'
	},
	centerBlock: {
		minWidth: '100%'
	},
	filterGridItem: {
		marginLeft: 'auto'
	},
	filterGridContainer: {
		position: 'absolute',
		right: '1%',
		margin: '15px',
		borderRadius: '8px'
	},
	basicTable: {
		padding: '5px 0'
	},
	cardContent: {
		display: 'flex'
	},
	cardContainer: {
		height: 140
	},
	cardContainer1: {
		background: '#9FDCFF 0% 0% no-repeat padding-box',
		borderRadius: '8px',
		opacity: 0.7,
		height: 140
	},
	iconContainer: {
		marginLeft: 'auto',
		marginTop: '-20px'
	},
	salesValue: {
		...theme.typography.gic_h3,
		color: '#345484D',
		fontSize: 34,
		opacity: 1
	},
	valueContainer: {
		marginTop: '-8px'
	},
	indicator: {
		height: '5px',
		margin: 15,
		marginBottom: 0,
		width: 38
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 1,
		color: '#fff'
	},
	tabIcons: {
		paddingRight: 20
	},
	posts: {
		...theme.typography.gic_h4,
		fontSize: 12,
		fontWeight: 400
	},
	commentComponents: {
		maxHeight: 385,
		minHeight: 385,
		overflowY: 'scroll',

		'&::-webkit-scrollbar': {
			width: '0.4em',
			backgroundColor: theme.palette.common.grey
		},
		'&::-webkit-scrollbar-track': {
			webkitBoxShadow: 'inset 0 0 6px rgba(0,0,0,0.00)',
			opacity: 0.26
		},
		'&::-webkit-scrollbar-thumb': {
			backgroundColor: theme.palette.common.green,
			opacity: 0.26,
			borderRadius: 4
		},
		'&::-webkit-scrollbar-corner': {
			backgroundColor: theme.palette.common.orange
		}
	},
	commentsFilter: {
		padding: 0,
		marginLeft: 'auto',
		'&::input': {
			fontSize: 12
		}
	},
	commentPaper: {
		borderBottomLeftRadius: 0,
		borderBottomRightRadius: 0,
		padding: 10
	},
	addCommentsIcon: {
		color: theme.palette.common.green,
		height: '36px !important',
		width: '36px !important',
		fontWeight: 200,
		border: `1px solid ${theme.palette.common.green}`,
		borderRadius: 4,
		margin: 'auto',
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		cursor: 'pointer'
	},
	addIcon: {
		fontSize: 37
	},
	sharePost: {
		backgroundColor: theme.palette.common.green,
		color: theme.palette.common.white
	},
	textArea: {
		minWidth: 400,
		borderRadius: 4,
		overflow: 'hidden',
		border: '2px solid #C9C9C9'
	},
	closeIconButton: {
		marginLeft: 'auto',
		cssFloat: 'right !important'
	},
	newPost: {
		paddingTop: 16
	},
	dialogActions: {
		padding: 24,
		marginRight: 'auto'
	},

	'@global': {
		'.MuiTab-wrapper': {
			display: 'inline',
			paddingLeft: '16%'
		},
		'.MuiSvgIcon-root': {
			marginRight: 10,
			height: 25,
			width: 21
		},
		'.MuiOutlinedInput-input': {
			padding: 14
		},
		'.MuiAutocomplete-endAdornment': {
			right: '0 !important'
		},
		'.MuiAutocomplete-hasPopupIcon.MuiAutocomplete-hasClearIcon .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"]': {
			padding: 0
		},
		'.MuiAutocomplete-option[data-focus="true"]': {
			backgroundColor: 'rgba(133, 188, 36, 0.26)'
		}
	}
}));

export default function VerticalTabs(props) {
	const dispatch = useDispatch();
	const cardDetails = props.dashboardData.getTotalSalesTarget.breakup;
	const nsrCardDetails = props.dashboardData.getYtdNsr.breakup;
	let initialChartData = [];
	const accChartData = [...props.dashboardData.getAccWiseSalesTarget];
	initialChartData = accChartData.filter((curr) => curr.serviceLine === 'DCM');
	const classes = useStyles();
	const [value, setValue] = React.useState(0);
	const [rowValue, setRowValue] = React.useState(null);
	const [appState, setAppState] = React.useState({
		loading: false,
		repos: null
	});
	const [chartData, setChartData] = React.useState(props.dashboardData.getAccWiseSalesTarget);
	const [selectedServiceLine, setSelectedServiceLine] = React.useState('DCM');
  const [selectedStatus, setSelectedStatus] = React.useState('ALL');
  const [postDetails, setPostDetails] = React.useState(
    props.dashboardData.getPostDetails
  );


	let userDetails = JSON.parse(localStorage.getItem('user'));

	// const roleBasedDetails = userDetails.role ? userDetails.role.type : '';
	let roleBasedFlag = true;
	if (userDetails.user.role.type === 'l_1_leader' || userDetails.user.role.type === 'l_2_leader') {
		roleBasedFlag = true;
	} else {
		roleBasedFlag = false;
	}

	const handleChange = (event, newValue) => {
		setValue(newValue);
	};
	const indicator = <hr className={classes.indicator} style={{ backgroundColor: '#85BC24' }}></hr>;
	const indicatorForInPursuit = <hr className={classes.indicator} style={{ backgroundColor: '#FABF68' }}></hr>;
	const indicatorForSold = <hr className={classes.indicator} style={{ backgroundColor: '#85BC24' }}></hr>;
	const indicatorForLost = <hr className={classes.indicator} style={{ backgroundColor: '#E32213' }}></hr>;

	const filterSalesChartByServiceLine = (serviceline) => {
		let updatedServiceline = serviceline;
		if (serviceline === 'ALL L2') {
			updatedServiceline = 'DCM';
		}
		const accountSales = [...props.dashboardData.getAccWiseSalesTarget];
		const filteredAccountSales = accountSales.filter(
			(accountSale) => accountSale.serviceLine === updatedServiceline
		);
		const filteredChartData = () => {
			switch (selectedStatus) {
				case 'ALL':
					return filteredAccountSales;
					break;
				case 'Lost':
					return filteredAccountSales.map((accountSale) => {
						return { ...accountSale, soldSales: 0, inPursuitSales: 0 };
					});
					break;
				case 'In Pursuit':
					return filteredAccountSales.map((accountSale) => {
						return { ...accountSale, soldSales: 0, lostSales: 0 };
					});
					break;
				case 'Sold':
					return filteredAccountSales.map((accountSale) => {
						return { ...accountSale, inPursuitSales: 0, lostSales: 0 };
					});
					break;
			}
		};
		setSelectedServiceLine(updatedServiceline);
		setChartData(filteredChartData);
	};

	const filterSalesChartByStatus = (status) => {
		const accountSales = [...props.dashboardData.getAccWiseSalesTarget];
		const filteredAccountSales = accountSales.filter(
			(accountSale) => accountSale.serviceLine === selectedServiceLine
		);
		switch (status) {
			case 'ALL':
				setChartData(filteredAccountSales);
				break;
			case 'Lost':
				setChartData(
					filteredAccountSales.map((accountSale) => {
						return { ...accountSale, soldSales: 0, inPursuitSales: 0 };
					})
				);
				break;
			case 'In Pursuit':
				setChartData(
					filteredAccountSales.map((accountSale) => {
						return { ...accountSale, soldSales: 0, lostSales: 0 };
					})
				);
				break;
			case 'Sold':
				setChartData(
					filteredAccountSales.map((accountSale) => {
						return { ...accountSale, inPursuitSales: 0, lostSales: 0 };
					})
				);
				break;
		}
		setSelectedStatus(status);
	};

	const filterNSRChartByServiceLine = (serviceLine) => {
		var accountNSR = [...props.dashboardData.getAccountNsr];
		var filteredAccountNSR = accountNSR.filter((accountNSR) => accountNSR.serviceLine === serviceLine);
		setChartData(filteredAccountNSR);
	};

	const baseUrl = 'https://gic-reporting.herokuapp.com';
	const getRowDetails = (rowDetails) => {
		setAppState({ loading: true });
		setRowValue(rowDetails);

		const requestOptions = {
			method: 'GET',
			headers: authHeader()
		};

		fetch(`${baseUrl}/sales-data/account-details?accountName=${rowDetails.accountName}`, requestOptions)
			.then((res) => res.json())
			.then((repos) => {
				setAppState({ loading: false, repos: repos });
			});

		// console.log("row details gos hererrerererer", rowDetails)
		// dispatch({ type: "DASHBOARD_UPDATEFILTERLIST", accountId } );
		// dispatch(dashBoardActions.getAccountDetails(rowDetails.accountName));
		handleChange(null, 2);
	};

	function numDifferentiation(value) {
		let val = Math.abs(value);
		if (val >= 10000000) {
			val = (val / 10000000).toFixed(2) + ' cr';
		} else if (val >= 100000) {
			val = (val / 100000).toFixed(2) + ' lac';
		}
		return val;
	}
	const [open, setOpen] = React.useState(false);

	const handleClickOpen = () => {
		setOpen(true);
	};
	const handleClose = () => {
		setOpen(false);
	};
	return (
		<div className={classes.tabsContainer}>
			<Tabs
				orientation="vertical"
				variant="scrollable"
				value={value}
				onChange={handleChange}
				aria-label="Vertical tabs example"
				className={classes.tabs}
			>
				<Tab
					label="Home"
					className={value === 0 ? classes.active_tab : classes.default_tab}
					icon={<HomeIcon />}
					{...a11yProps(0)}
				/>
				<Tab
					label="Sales Breakup"
					className={value === 1 ? classes.active_tab : classes.default_tab}
					icon={<SalesIcon />}
					{...a11yProps(3)}
				/>
				<Tab
					label="Details"
					style={{ display: 'none' }}
					className={value === 2 ? classes.active_tab : classes.default_tab}
					icon={<EventNoteOutlined />}
					{...a11yProps(2)}
				/>
				<Tab
					label="Home - NSR"
					className={value === 3 ? classes.active_tab : classes.default_tab}
					icon={<HomeIcon />}
					{...a11yProps(3)}
				/>
			</Tabs>
			<TabPanel value={value} index={0} className={classes.tabPanelContainer}>
				<div className={classes.root}>
					<Grid container spacing={3}>
						{roleBasedFlag ? (
							<Grid item xs={12} sm={7} className={classes.bannerContainer}>
								<Banner
									target={props.dashboardData.getTotalSalesTarget}
									userName={userDetails.user.firstName}
									formatNumber={numDifferentiation}
									roles={roleBasedFlag}
								/>
							</Grid>
						) : (
							<Grid item xs={12} sm={2} className={classes.bannerContainer}>
								<Banner
									target={props.dashboardData.getTotalSalesTarget}
									userName={userDetails.user.firstName}
									formatNumber={numDifferentiation}
									roles={roleBasedFlag}
								/>
							</Grid>
						)}
						{cardDetails && roleBasedFlag ? (
							<Grid item xs={12} sm={2}>
								{cardDetails.map((data) => (
									<SimpleCard sale={data} formatNumber={numDifferentiation} />
								))}
							</Grid>
						) : null}

						<Grid item xs={12} sm={3} className={classes.commentComponents}>
							<Paper className={classes.commentPaper}>
								<Grid container>
									<Grid item sm={4} className={classes.posts}>
										Posts
									</Grid>
									<Grid item sm={6} className={classes.commentsFilter}>
										<FilterMenu
											filterLabel="Filter"
											filterPlaceholder="Latest"
											filterValue={commentFilterList}
											getFilteredChartVal={filterSalesChartByServiceLine}
											className={classes.commentsFilter}
										/>
									</Grid>
									<Grid item sm={2}>
										<div className={classes.addCommentsIcon} onClick={handleClickOpen}>
											<span className={classes.addIcon}>+</span>
										</div>
									</Grid>
								</Grid>
							</Paper>
							 {/* {postDetails.length > 0
                ? postDetails.map((post) => <Comment post={post} />)
                : */}
               {props.dashboardData.getPostDetails.map((post) => (
                    <Comment post={post} />
                  ))}
              {/* <Comment />
							<Comment />
							<Comment />
							<Comment /> */}
							<Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={open}>
								<DialogTitle>
									<Grid container>
										<Grid item sm={11} className={classes.newPost}>
											<b>New Post</b>
										</Grid>
										<Grid item sm={1}>
											<IconButton
												aria-label="close"
												className={classes.closeIconButton}
												onClick={handleClose}
											>
												<CloseIcon />
											</IconButton>
										</Grid>
									</Grid>
								</DialogTitle>
								<DialogContent>
									<TextareaAutosize
										rowsMin={5}
										placeholder="Enter Comment"
										className={classes.textArea}
									/>
								</DialogContent>
								<DialogActions className={classes.dialogActions}>
									<Button variant="outlined" onClick={handleClose}>
										Cancel
									</Button>
									<Button variant="contained" onClick={savePost} className={classes.sharePost}>
										Share Post
									</Button>
								</DialogActions>
							</Dialog>
						</Grid>
					</Grid>

					<Grid container spacing={2} className={classes.filterGridContainer}>
						<Grid item xs={12} sm={2} className={classes.filterGridItem}>
							<FilterMenu
								filterLabel="Filter"
								filterPlaceholder="Line of business"
								getFilteredChartVal={filterSalesChartByServiceLine}
								filterValue={filterList}
								selectOptions={props.selectOptions}
							/>
						</Grid>
						{roleBasedFlag ? (
							<Grid item xs={12} sm={2}>
								<FilterMenu
									filterLabel="Filter"
									filterPlaceholder="Status"
									filterValue={statusFilterList}
									getFilteredChartVal={filterSalesChartByStatus}
								/>
							</Grid>
						) : null}
					</Grid>
					<Grid container>
						<Grid item xs={12}>
							<ReactCharts
								chartData={chartData.length > 0 ? chartData : props.dashboardData.getAccWiseSalesTarget}
							/>
						</Grid>
					</Grid>
					{!props.dashboardData.getAccWiseSalesTarget.length && (
						<Backdrop className={classes.backdrop} open={open}>
							<CircularProgress color="inherit" />
						</Backdrop>
					)}
					{roleBasedFlag ? (
						<Grid container className={classes.basicTableContainer} spacing={2}>
							<Grid item xs={12} sm={3}>
								<BasicTable data={props.dashboardData.getTop5Wins} heading={'Top 5 Wins'} />
							</Grid>
							<Grid item xs={12} sm={3}>
								<BasicTable data={props.dashboardData.getTop5Losses} heading={'Top 5 Losses'} />
							</Grid>
							<Grid item xs={12} sm={3}>
								<BasicTable
									data={props.dashboardData.getAccountWithMove}
									heading={'Account with Significant Movement'}
								/>
							</Grid>
							<Grid item xs={12} sm={3}>
								<BasicTable
									data={props.dashboardData.getAccountWithNoMove}
									heading={'Account with No Movement'}
								/>
							</Grid>
						</Grid>
					) : null}
				</div>
			</TabPanel>
			<TabPanel value={value} index={1} className={classes.tabPanelContainer}>
				Sales Break Up
				<ReactTable salesBreakup={props.dashboardData.getSalesBreakUp} getRowDetails={getRowDetails} />
			</TabPanel>
			<TabPanel value={value} index={2} className={classes.tabPanelContainer}>
				<Grid container spacing={3}>
					<Grid item xs={12} sm={12}>
						<DetailsBanner
							accountName={rowValue ? rowValue.accountName : ''}
							logoUrl={appState.repos ? appState.repos.data.logoUrl : ''}
						/>
					</Grid>
				</Grid>

				<Grid container spacing={2}>
					<Grid item xs={12} sm={3}>
						<Card className={classes.cardContainer}>
							<Typography component="div">{/* {indicator} */}</Typography>
							<CardHeader subheader="YTD Sales" />
							<CardContent className={classes.cardContent}>
								<span className={classes.valueContainer}>
									<Typography className={classes.salesValue} component="p">
										{rowValue ? numDifferentiation(rowValue.salesTarget) : null}
									</Typography>
								</span>{' '}
								<span className={classes.iconContainer}>
									<img alt="pie chart image" src={pieChart} />
								</span>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={3}>
						<Card className={classes.cardContainer}>
							<Typography component="p">{/* {indicator} */}</Typography>
							<CardHeader subheader="Sales Target" />

							<CardContent className={classes.cardContent}>
								<span className={classes.valueContainer}>
									<Typography className={classes.salesValue} component="p">
										{rowValue ? numDifferentiation(rowValue.ytdNsr) : null}
									</Typography>
								</span>{' '}
								<span className={classes.iconContainer}>
									<img alt="bar chart image" src={barChart} />
								</span>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={2}>
						<Card className={classes.cardContainer1}>
							<Typography component="p">{indicatorForInPursuit}</Typography>
							<CardHeader subheader="In Pursuit" />
							<CardContent className={classes.cardContent}>
								<span className={classes.valueContainer}>
									<Typography className={classes.salesValue} component="p">
										{rowValue ? rowValue.inPursuitCount : null}
									</Typography>
								</span>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={2}>
						<Card className={classes.cardContainer1}>
							<Typography component="p">{indicatorForSold}</Typography>
							<CardHeader subheader="Sold" />
							<CardContent className={classes.cardContent}>
								<span className={classes.valueContainer}>
									<Typography className={classes.salesValue} component="p">
										{rowValue ? rowValue.salesCount : null}
									</Typography>
								</span>
							</CardContent>
						</Card>
					</Grid>
					<Grid item xs={12} sm={2}>
						<Card className={classes.cardContainer1}>
							<Typography component="p">{indicatorForLost}</Typography>
							<CardHeader subheader="Lost" />
							<CardContent className={classes.cardContent}>
								<span className={classes.valueContainer}>
									<Typography className={classes.salesValue} component="p">
										{rowValue ? rowValue.lostCount : null}
									</Typography>
								</span>
							</CardContent>
						</Card>
					</Grid>
				</Grid>
				{appState.repos ? <AccountTable accountDetails={appState.repos.data.opportunities} /> : null}
				{appState.loading && (
					<Backdrop className={classes.backdrop} open={open}>
						<CircularProgress color="inherit" />
					</Backdrop>
				)}
				{/* <AccountTable accountDetails = {props.dashboardData.getSalesBreakUp} /> */}
			</TabPanel>
			<TabPanel value={value} index={3} className={classes.tabPanelContainer}>
				<div className={classes.root}>
					<Grid container spacing={3}>
						{roleBasedFlag ? (
							<Grid item xs={12} sm={9} className={classes.bannerContainer}>
								<Banner
									target={props.dashboardData.getYtdNsr}
									userName={userDetails.user.firstName}
									formatNumber={numDifferentiation}
								/>
							</Grid>
						) : (
							<Grid item xs={12} sm={12} className={classes.bannerContainer}>
								<Banner
									target={props.dashboardData.getYtdNsr}
									userName={userDetails.user.firstName}
									formatNumber={numDifferentiation}
								/>
							</Grid>
						)}
						{nsrCardDetails && roleBasedFlag ? (
							<Grid item xs={12} sm={3}>
								{nsrCardDetails.map((data) => (
									<SimpleCard sale={data} formatNumber={numDifferentiation} />
								))}
							</Grid>
						) : null}
					</Grid>
					<Grid container spacing={2} className={classes.filterGridContainer}>
						<Grid item xs={12} sm={2} className={classes.filterGridItem}>
							<FilterMenu
								filterLabel="Filter"
								filterPlaceholder="Line of business"
								getFilteredChartVal={filterNSRChartByServiceLine}
								filterValue={filterList}
								selectOptions={props.selectOptions}
							/>
						</Grid>
					</Grid>
					<Grid container>
						<Grid item xs={12}>
							<ReactCharts
								nsrChartData={chartData.length > 0 ? chartData : props.dashboardData.getAccountNsr}
							/>
						</Grid>
					</Grid>
					{!props.dashboardData.getAccountNsr.length && (
						<Backdrop className={classes.backdrop} open={open}>
							<CircularProgress color="inherit" />
						</Backdrop>
					)}
				</div>
			</TabPanel>
		</div>
	);
}
export { VerticalTabs };

const filterList = ["ALL L2", "AM & C", "CSAD", "DC"];

const statusFilterList = ["ALL", "Lost", "Sold", "In Pursuit"];

const commentFilterList = ["Most Liked", "Most Commented", "Latest"];

const lobList = [
  { title: "ALL L2", value: "DCM" },
  { title: "AM & C", value: "AM & C" },
  { title: "CSAD", value: "CSAD" },
  { title: "DC", value: "DC" },
];

const statusList = [
  { title: "ALL", value: "ALL" },
  { title: "Lost", value: "Lost" },
  { title: "Sold", value: "Sold" },
  { title: "In Pursuit", value: "In Pursuit" },
];
