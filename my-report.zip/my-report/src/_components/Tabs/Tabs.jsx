import React from "react";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from '@material-ui/core/Typography';
import SvgIcon from "@material-ui/core/SvgIcon";
import HomeIcon from "@material-ui/icons/Home";
import Box from "@material-ui/core/Box";
import Grid from "@material-ui/core/Grid";
import SimpleCard from "../Card/Card";
import Banner from "../Banner/Banner";
import DetailsBanner from "../DetailsBanner/DetailsBanner";
import ReactCharts from "../Charts/Charts";
import ReactTable from "../ReactTable/ReactTable";
import BasicTable from "../../_components/Table/Table";
import FilterMenu from "../Filter/Filter";
import EventNoteOutlined from "@material-ui/icons/EventNoteOutlined";
import Card from "@material-ui/core/Card";
import CardHeader from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import pieChart from '../../Images/piechart.svg';
import barChart from '../../Images/barchart.svg';
import Backdrop from '@material-ui/core/Backdrop';
import CircularProgress from "@material-ui/core/CircularProgress";
import { useDispatch, useSelector } from "react-redux";
import { dashBoardActions } from "../../_actions";
import AccountTable from "../AccountTable/AccountTable";
import { authHeader } from '../../_helpers';

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
}

function SalesIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d="M11.024,3.055A9.028,9.028,0,1,0,21,13.03H11.024Z" />
    </SvgIcon>
  );
}
function DetailsIcon(props) {
  return (
    <SvgIcon {...props}>
      <path d="M9.286,5.143H7.143A2.143,2.143,0,0,0,5,7.286V20.143a2.143,2.143,0,0,0,2.143,2.143H17.857A2.143,2.143,0,0,0,20,20.143V7.286a2.143,2.143,0,0,0-2.143-2.143H15.714m-6.429,0a2.143,2.143,0,0,0,2.143,2.143h2.143a2.143,2.143,0,0,0,2.143-2.143m-6.429,0A2.143,2.143,0,0,1,11.429,3h2.143a2.143,2.143,0,0,1,2.143,2.143m-3.214,7.5h3.214M12.5,16.929h3.214M9.286,12.643H9.3m-.011,4.286H9.3" />
    </SvgIcon>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    marginTop: '2rem'
  },
  tabsContainer: {
    flexGrow: 1,
    display: "flex",
    height: "auto",
  },
  tabs: {
    marginTop: "11rem",
    minWidth: 160,
    textAlign: "left",
    display: "inline"
  },
  default_tab: {
    width: 264,
    display: 'inline-block',
    backgroundColor: theme.palette.common.white,
    ...theme.typography.gic_h6,
    textAlign: 'left',
    "&:hover": {
      outline: "none",
    },
    "&:active": {
      outline: "none",
    },
  },
  active_tab: {
    background: '#C8DE9F 0% 0% no-repeat padding-box',
    textAlign: 'left',
    opacity: 0.26,
    ...theme.typography.gic_h6,
    fontWeight: 700,

    "&:active": {
      outline: "none",
      fontWeight: 700
    },
    "&:hover": {
      outline: "none",
      ...theme.typography.gic_h6,
      fontWeight: 700
    },
  },
  imageIcon: {
    height: "100%",
  },

  tabPanelContainer: {
    marginTop: "6rem",
    width: "100%",
    ...theme.typography.gic_h3,
    background: '#F4F4F4 0% 0% no-repeat padding-box',
    opacity: 1
  },
  basicTableContainer: {
    marginTop: "3rem",
    borderRadius: '8px'
  },
  centerBlock: {
    minWidth: "100%",
  },
  filterGridItem:{
    marginLeft: "auto"
  },
      filterGridContainer:{
        position: "absolute",
        right: "3%",
        margin: "12px",
        borderRadius: '8px'
      },
      basicTable:{
        padding: '5px 0'
      },
      cardContent:{
        display: "flex",
      },
      cardContainer: {
        height: 140,
      },
      iconContainer:{
        marginLeft: "auto",
        marginTop: "-20px"
      },
      salesValue:{
        ...theme.typography.gic_h3,
        color: '#345484D',
        fontSize: 34,
        opacity: 1
      },
      valueContainer:{
        marginTop:"-8px"
      },
      indicator: {
        height: '5px',
        margin: 15,
        marginBottom: 0,
        width: 38
      },
      backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
      },
      tabIcons:{
        paddingRight: 20,
      },
      
  '@global': {
    '.MuiTab-wrapper': {
      display: 'inline',
      paddingLeft: '16%'
    },
    '.MuiSvgIcon-root':{
      marginRight: 10,
      height: 25,
      width: 21,
    }
  },
}));


export default function VerticalTabs(props) {
  const dashboardAccountDetails = useSelector((state) => state.dashboard.getAccountDetails);
  console.log("account details  hdhfhfhfh", props.dashboardData.getAccountDetails)
  const dispatch = useDispatch();
  const cardDetails = props.dashboardData.getTotalSalesTarget.breakup;
  console.log("props.dashboardData.initialFilterData-->", props.dashboardData.initialFilterData);
  let initialChartData = [];
  const accChartData = [...props.dashboardData.getAccWiseSalesTarget];
  initialChartData = accChartData.filter((curr)=>
    curr.serviceLine === 'DCM'
  )
  console.log('initial chart val--', initialChartData)
  console.log("card details ----", cardDetails);
  const classes = useStyles();
  const [value, setValue] = React.useState(0);
  const [rowValue, setRowValue] = React.useState(null);
  const [appState, setAppState] = React.useState({
    loading: false,
    repos: null,
  });
  // const [chartVal, setChartVal] = React.useState(props.dashboardData.getAccWiseSalesTarget);

  let userDetails = JSON.parse(localStorage.getItem('user'));
  console.log("user details-amrtita----", userDetails)

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const indicator = <hr className={classes.indicator} style={{ backgroundColor: '#85BC24'}}></hr>;
  const indicatorForInPursuit = <hr className={classes.indicator} style={{ backgroundColor: '#FABF68'}}></hr>;
  const indicatorForSold = <hr className={classes.indicator} style={{ backgroundColor: '#85BC24'}}></hr>;
  const indicatorForLost = <hr className={classes.indicator} style={{ backgroundColor: '#E32213'}}></hr>;

  // let filteredChartData = [];
  // const accChartData = [...props.dashboardData.getAccWiseSalesTarget];
  // filteredChartData = accChartData.filter((curr)=>
  //   curr.serviceLine === 'DCM'
  // )

  const getFilteredChartVal = (serviceline, selected) => {
    // console.log("inside getfilter method",   selected)
    let updatedServiceline = serviceline;
    if(serviceline === 'ALL L2'){
      updatedServiceline = 'DCM'
    }
    const accChartData = [...props.dashboardData.getAccWiseSalesTarget];
    const filteredChartData = accChartData.filter((curr)=>
      curr.serviceLine === updatedServiceline
    )
    // setChartVal(filteredChartData)
  }
  const baseUrl = 'https://gic-reporting.herokuapp.com'
  const getRowDetails = (rowDetails) => {
    setAppState({ loading: true });
    setRowValue(rowDetails)

    const requestOptions = {
      method: 'GET',
      headers: authHeader()
  };

  fetch(`${baseUrl}/sales-data/account-details?accountName=${rowDetails.accountName}`, requestOptions)
  .then((res) => res.json())
  .then((repos) => {
    setAppState({ loading: false, repos: repos });
  });

   // console.log("row details gos hererrerererer", rowDetails)
    // dispatch({ type: "DASHBOARD_UPDATEFILTERLIST", accountId } );
   // dispatch(dashBoardActions.getAccountDetails(rowDetails.accountName));
    handleChange(null, 2);
  }

  function numDifferentiation(value) {
    let val = Math.abs(value)
    if (val >= 10000000) {
      val = (val / 10000000).toFixed(2) + ' cr';
    } else if (val >= 100000) {
      val = (val / 100000).toFixed(2) + ' lac';
    }
    return val;
  }

  return (
    <div className={classes.tabsContainer}>
      <Tabs
        orientation="vertical"
        variant="scrollable"
        value={value}
        onChange={handleChange}
        aria-label="Vertical tabs example"
        className={classes.tabs}
      >
        <Tab
          label="Home"
          className={value === 0 ? classes.active_tab : classes.default_tab}
          icon={<HomeIcon />}
          {...a11yProps(0)}
        />
        <Tab
          label="Sales Breakup"
          className={value === 1 ? classes.active_tab : classes.default_tab}
          icon={<SalesIcon />}


          {...a11yProps(3)}
        />
        <Tab
          label="Details"
          className={value === 2 ? classes.active_tab : classes.default_tab}
          icon={<EventNoteOutlined />}
          {...a11yProps(2)}
        />
      </Tabs>
      <TabPanel value={value} index={0} className={classes.tabPanelContainer}>
        <div className={classes.root}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={9} className={classes.bannerContainer}>
              <Banner target={props.dashboardData.getTotalSalesTarget} userName = {userDetails.user.firstName} formatNumber = {numDifferentiation} />
            </Grid>
            {cardDetails ? (
              <Grid item xs={12} sm={3}>
                {cardDetails.map((data) => (
                  <SimpleCard sale={data} formatNumber = {numDifferentiation} />
                ))}
              </Grid>
            ) : null}
          </Grid>
          <Grid container spacing={2} className={classes.filterGridContainer}>
            <Grid item xs={12} sm={2} className={classes.filterGridItem}>
              <FilterMenu
                filterLabel="Filter"
                filterPlaceholder="Line of business"
                getFilteredChartVal = {getFilteredChartVal}
                filterValue={lobList}
                initialFilterData ={props.dashboardData.initialFilterData}
                selectOptions = {props.selectOptions}
              />
            </Grid>
            <Grid item xs={12} sm={2}>
              <FilterMenu
                filterLabel="Filter"
                filterPlaceholder="Status"
                filterValue={statusList}
              />
            </Grid>
          </Grid>
          <Grid container>
            <Grid item xs={12}>
              <ReactCharts chartData={props.dashboardData}/>
            </Grid>
          </Grid>
          {!props.dashboardData.getAccWiseSalesTarget.length &&  <Backdrop className={classes.backdrop} open={open} >
          <CircularProgress color="inherit" />
        </Backdrop>}
          <Grid container className={classes.basicTableContainer} spacing={2}>
            <Grid item xs={12} sm={3}>
              <BasicTable
                data={props.dashboardData.getTop5Wins}
                heading={"Top 5 Wins"}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <BasicTable
                data={props.dashboardData.getTop5Losses}
                heading={"Top 5 Losses"}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <BasicTable
                data={props.dashboardData.getAccountWithMove}
                heading={"Account with Significant Movement"}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <BasicTable
                data={props.dashboardData.getAccountWithNoMove}
                heading={"Account with No Movement"}
              />
            </Grid>
          </Grid>
        </div>
      </TabPanel>
      <TabPanel value={value} index={1} className={classes.tabPanelContainer}>
        Sales Break Up
        <ReactTable salesBreakup={props.dashboardData.getSalesBreakUp} getRowDetails = {getRowDetails} />
      </TabPanel>
      <TabPanel value={value} index={2} className={classes.tabPanelContainer}>
        <Grid container spacing={3}>
        <Grid item xs={12} sm={12}>
          <DetailsBanner accountName = {rowValue ? rowValue.accountName : ''}  logoUrl = {appState.repos ? appState.repos.data.logoUrl: ''}/>
        </Grid>
          </Grid>


  <Grid container spacing={2}>
  <Grid item xs={12} sm={3}>
  <Card className={classes.cardContainer}>
  <Typography component="div">
  {/* {indicator} */}
   </Typography>
  <CardHeader subheader="YTD Sales" />
  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
     {rowValue ? numDifferentiation(rowValue.salesTarget) : null}
      </Typography>
    </span>{" "}
    <span className={classes.iconContainer}>
      <img alt="pie chart image" src={pieChart}/>
    </span>
  </CardContent>
</Card>
  </Grid>
  <Grid item xs={12} sm={3}>
  <Card className={classes.cardContainer}>
  <Typography component="p">
  {/* {indicator} */}
   </Typography>
  <CardHeader subheader="Sales Target" />

  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
                  {rowValue ? numDifferentiation(rowValue.ytdNsr) : null}
      </Typography>
    </span>{" "}
    <span className={classes.iconContainer}>
      <img alt="bar chart image" src={barChart}/>
    </span>
  </CardContent>
</Card>
  </Grid>
  <Grid item xs={12} sm={2}>
  <Card className={classes.cardContainer}>
  <Typography component="p">
  {indicatorForInPursuit}
   </Typography>
  <CardHeader subheader="In Pursuit" />
  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
      {rowValue ? rowValue.inPursuitCount : null}
      </Typography>
    </span>

  </CardContent>
</Card>
  </Grid>
  <Grid item xs={12} sm={2}>
  <Card className={classes.cardContainer}>
  <Typography component="p">
  {indicatorForSold}
   </Typography>
  <CardHeader subheader="Sold" />
  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
      {rowValue ? rowValue.salesCount : null}
      </Typography>
    </span>

  </CardContent>
</Card>
  </Grid>
  <Grid item xs={12} sm={2}>
  <Card className={classes.cardContainer}>
  <Typography component="p">
     {indicatorForLost}
      </Typography>
  <CardHeader subheader="Lost" />
  <CardContent className={classes.cardContent}>
    <span className={classes.valueContainer}>
      <Typography className={classes.salesValue} component="p">
     {rowValue ? rowValue.lostCount : null}
      </Typography>
    </span>

  </CardContent>
</Card>
  </Grid>


  </Grid>
 {appState.repos ? <AccountTable accountDetails={appState.repos.data.opportunities} /> : null}
 {appState.loading &&  <Backdrop className={classes.backdrop} open={open} >
          <CircularProgress color="inherit" />
        </Backdrop>}
  {/* <AccountTable accountDetails = {props.dashboardData.getSalesBreakUp} /> */}


      </TabPanel>
    </div>
  );
}
export { VerticalTabs };

const lobList = [
  { title: "ALL L2", value: "DCM"},
  { title: "AM & C", value: "AM & C" },
  { title: "CSAD", value: "CSAD" },
  { title: "DC", value: "DC" },
];

const statusList = [
  { title: "ALL", value: "ALL" },
  { title: "Lost", value: "Lost" },
  { title: "Sold", value: "Sold" },
  { title: "In Pursuit", value: "In Pursuit" },
];
