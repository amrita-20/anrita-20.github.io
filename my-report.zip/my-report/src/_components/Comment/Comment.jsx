import React from 'react';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import ThumbUpOutlinedIcon from '@material-ui/icons/ThumbUpOutlined';
import IconButton from '@material-ui/core/IconButton';
import SendIcon from '@material-ui/icons/Send';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';

const useStyles = makeStyles((theme) => ({
	commentContainer: {
		width: '100%',
		padding: 15,
		borderRadius: 0
	},

	gic_h6: {
		...theme.typography.gic_h6,
		color: theme.palette.common.grey,
		fontSize: 8
	},
	commentor: {
		...theme.typography.gic_h4,
		fontSize: 12
	},
	description: {
		...theme.typography.gic_h6,
		fontSize: 12
	},
	thumbsUpIcon: {
		color: theme.palette.common.green,
		cursor: 'pointer',
		height: '15px !important',
		width: '15px !important',
		marginTop: -10
	},
	likes: {
		...theme.typography.gic_h6,
		fontSize: 12
	},
	comments: {
		...theme.typography.gic_h6,
		fontSize: 12,
		color: theme.palette.common.green
	},
	commentBox: {
		padding: 10
	}
}));

export default function Comment(props) {
	const classes = useStyles();

	return (
		<React.Fragment>
			<Card className={classes.commentContainer}>
				<Typography className={classes.gic_h4} color="textSecondary" gutterBottom>
					<span className={classes.commentor}>{props.post.createdBy}</span>{' '}
					<span className={classes.gic_h6}>5 min ago</span>
				</Typography>
				<Typography className={classes.description} gutterBottom>
					{props.post.message}
				</Typography>
				<Grid container>
					<Grid item sm={1}>
						<ThumbUpOutlinedIcon className={classes.thumbsUpIcon} />
					</Grid>
					<Grid item sm={4}>
						<Typography className={classes.likes}>{props.post.noOfLikes}</Typography>
					</Grid>
					<Grid item sm={7}>
						<Typography className={classes.comments}>View all {props.post.noOfComments} comments.</Typography>
					</Grid>
				</Grid>
				<FormControl className={clsx(classes.margin, classes.textField)}>
					<OutlinedInput
						type="text"
						placeholder="Add Comments"
						endAdornment={
							<InputAdornment position="end">
								<IconButton>
									<SendIcon />
								</IconButton>
							</InputAdornment>
						}
					/>
				</FormControl>
			</Card>
		</React.Fragment>
	);
}
export { Comment };
