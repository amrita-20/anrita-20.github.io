import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import uniqid from'uniqid';
import { useDispatch, useSelector } from "react-redux";
import { dashBoardActions } from "../../_actions";

const columns = [
    { id: 'accountName', label: 'GIC Accounts', minWidth: 100 },
    { id: 'numOfOpportunities', label: 'No. of Opportunities', minWidth: 100 },
    { id: 'ytdSales', label: 'YTD Sales', minWidth: 100 },
    { id: 'salesTarget', label: 'Sales Target', minWidth: 100 },
    { id: 'salesCount', label: 'Sales(Count)', minWidth: 100 },
    { id: 'inPursuitCount', label: 'In Pursuit(Count)', minWidth: 100 },
    { id: 'lostCount', label: 'Lost(Count)', minWidth: 100 },
    { id: 'ytdNsr', label: 'YTD NSR', minWidth: 100 },
];



const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    ...theme.typography.gic_h6,
  },
  container: {
    marginTop: 16
  },
  tableCellContainer:{
    ...theme.typography.gic_h4,
  },
  tableBodyCell:{
    ...theme.typography.gic_h6,
    color: theme.palette.common.gicDarkGrey,
  },
  tableArrow: {
    top: 214,
    left: 1369,
    width: 7,
    height: 13,
    transform: 'matrix(0, -1, 1, 0, 0, 0)',
    border: '1px solid #75787A',
    opacity: 1,
  }
}));

export default function ReactTable(props) {
  const dispatch = useDispatch();
  const classes = useStyles();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(8);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    setPage(0);
  };

  const getRowDetails = (row) => {
   // dispatch(dashBoardActions.getAccountDetails(row.accountName));
    props.getRowDetails(row);
  }

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow >
              {columns.map((column) => (
                <TableCell
                  key={column.id + uniqid()}
                  align={column.align}
                  className={classes.tableCellContainer}
                  style={{ minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {props.salesBreakup.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
              return (
                <>
                <TableRow style = {{cursor: 'pointer'}} onClick = {() => getRowDetails(row)} hover role="checkbox" tabIndex={-1} key={row.code+  uniqid()}>
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <TableCell className={classes.tableBodyCell} key={column.id +  uniqid()} align={column.align}>
                        {column.format && typeof value === 'number' ? column.format(value) : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
                </>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[8, 15, 100]}
        className={classes.tableBodyCell}
        component="div"
        count={props.salesBreakup.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onChangePage={handleChangePage}
        onChangeRowsPerPage={handleChangeRowsPerPage}
      />
    </Paper>
  );
}

export { ReactTable };