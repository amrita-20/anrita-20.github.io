import React from 'react';
import { makeStyles } from '@material-ui/styles';
import banner from '../../Images/black-background.svg';
import rectangle from '../../Images/Rectangle 21563.svg';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(theme => ({
  bannerImgContainer: {
    maxHeight: 216,
    width: '100%',
    position: "relative",
    textAlign: "center",
    marginBottom: 20
  },
  bannerImg:{
    objectFit: 'cover',
    width: '100%',
    maxHeight: 216,
    borderRadius: 10,
    top: 10,
    left: 10,
    zIndex: 1
  },
  rectangleImg: {
    position: 'absolute',
    top: 25,
    bottom: 25,
    right: 25,
    zIndex: 2,
    height: '80%'
  },
  gic_h3: {
    ...theme.typography.gic_h3,
    fontSize: 32,
    marginBottom: 1,
    fontWeight: '700',
    color: theme.palette.common.green,
    position: 'absolute',
    textAlign: 'left',
    top: '30%',
    left: '3%',
    opacity: '1',
  },
  gic_h4: {
    ...theme.typography.gic_h4,
    marginBottom: 1,
    position: 'absolute',
    color: theme.palette.common.grey,
    textAlign: 'left',
    top: '67%',
    left: '4.8%',
    maxWidth: '60%'
  },
  gic_h5: {
    position: "fixed",
    top: '40%',
    left: '15%'
  },
  cardGrid:{
  position:"absolute",
  top: "32rem",
  width: "65%",
  margin: "0 25px"
  },
  cardContainer:{
    maxWidth: "250px",
    maxHeight: "100px",
    whiteSpace: "nowrap"
  },
  cardContent:{
    display: "flex"
  },
  iconContainer:{
    marginLeft: "auto",
    marginTop: "-20px"
  },
  salesValue:{
    ...theme.typography.gic_h3,
  },
  valueContainer:{
    marginTop:"-8px"
  }

}))

export default function DetailsBanner(props) {
  const classes = useStyles();
  const imgUrl = `http://6b5b6cb34a27.ngrok.io${props.logoUrl}`


  return (
   <React.Fragment>
   <div className={classes.bannerImgContainer}>
   <Typography className={classes.gic_h3} component={'div'}>
 {props.accountName}
 </Typography>


 <img alt="details banner image" src={banner} className={classes.bannerImg}/>
 <img alt="rectangle image" src={imgUrl} className={classes.rectangleImg}/>
   </div>


   </React.Fragment>
  );
}
export { DetailsBanner };