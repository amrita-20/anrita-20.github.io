import * as React from "react";
import Paper from "@material-ui/core/Paper";

import {
  Chart,
  ArgumentAxis,
  ValueAxis,
  BarSeries,
  Legend,
} from "@devexpress/dx-react-chart-material-ui";
import { withStyles } from "@material-ui/core/styles";
import { Stack, Animation } from "@devexpress/dx-react-chart";

import { olimpicMedals as data } from "./demo-data/data-vizualization";

const legendStyles = () => ({
  root: {
    display: "flex",
    margin: "auto",
    flexDirection: "row",
  },
});
const legendRootBase = ({ classes, ...restProps }) => (
  <Legend.Root {...restProps} className={classes.root} />
);
const Root = withStyles(legendStyles, { name: "LegendRoot" })(legendRootBase);
const legendLabelStyles = () => ({
  label: {
    whiteSpace: "nowrap",
  },
});
const legendLabelBase = ({ classes, ...restProps }) => (
  <Legend.Label className={classes.label} {...restProps} />
);
const Label = withStyles(legendLabelStyles, { name: "LegendLabel" })(
  legendLabelBase
);

export default class ReactCharts extends React.PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      data,
    };
  }

  render() {
    const { data: chartData } = this.state;
    const titleStyle = {
      fontSize: "20px",
      color: "#52555A",
      opacity: 1,
      fontWeight: 700,
      padding: "25px 10px 15px 20px",
    };

    return (
      <Paper>
        {this.props.chartData ? (
          <Chart data={this.props.chartData}>
            <ArgumentAxis />
            <ValueAxis />

            <BarSeries
              name="InPursuit Sales"
              valueField="inPursuitSales"
              argumentField="account"
              color="#FABF68"
              barWidth={0.3}
            />

            <BarSeries
              name="Sold Sales"
              valueField="soldSales"
              argumentField="account"
              color="#85BC24"
              barWidth={0.3}
            />

            <BarSeries
              name="Lost Sales"
              valueField="lostSales"
              argumentField="account"
              color="#E32213"
              barWidth={0.3}
            />

            <Animation />
            <h5 style={titleStyle}>GIC Accounts Sales</h5>
            <Legend
              position="bottom"
              rootComponent={Root}
              labelComponent={Label}
            />

            <Stack />
          </Chart>
        ) : (
          <Chart data={this.props.nsrChartData}>
            <ArgumentAxis />
            <ValueAxis />

            <BarSeries
              name="NSR Value"
              valueField="ytdNsr"
              argumentField="account"
              color="#85BC24"
              barWidth={0.1}
            />

            <Animation />
            <h5 style={titleStyle}>GIC Accounts NSR</h5>
            <Legend
              position="bottom"
              rootComponent={Root}
              labelComponent={Label}
            />

            <Stack />
          </Chart>
        )}
      </Paper>
    );
  }
}
