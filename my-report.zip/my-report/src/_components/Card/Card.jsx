import React from 'react';
import { makeStyles } from '@material-ui/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles((theme) => ({
	cardContainer: {
		marginBottom: '3.1rem',
		maxHeight: 106,
		background: '#9FDCFF 0% 0% no-repeat padding-box',
		borderRadius: '8px',
		opacity: 0.7
	},
	indicator: {
		height: '5px',
		margin: 0,
		marginBottom: 5
	},
	title: {
		fontSize: 14
	},
	gic_h3: {
		...theme.typography.gic_h3,
		marginBottom: 1,
		fontSize: '30px',
		color: '#45484D',
		opacity: 1
	},
	gic_h6: {
		...theme.typography.gic_h6,
		whiteSpace: 'nowrap',
		textOverflow: 'ellipsis',
		marginBottom: 1,
		color: '#45484D',
		fontSize: '16px'
	}
}));

export default function SimpleCard(props) {
	const classes = useStyles();
	let indicatorColor = null;
	if (props.sale.percent > 0 && props.sale.percent <= 34) {
		indicatorColor = '#E32213';
	} else if (props.sale.percent > 34 && props.sale.percent <= 66) {
		indicatorColor = '#FABF68';
	} else if (props.sale.percent > 66 && props.sale.percent <= 100) {
		indicatorColor = '#85BC24"';
	}

	const indicator = (
		<hr
			className={classes.indicator}
			style={{ width: `${props.sale.percent}%`, backgroundColor: indicatorColor }}
		></hr>
	);

	return (
		<Card className={classes.cardContainer}>
			<CardContent>
				<Typography className={classes.gic_h6} component={'div'} color="textSecondary" gutterBottom>
					{indicator}
					{props.sale.percent}% {props.sale.nsr ? 'YTD NSR' : 'YTD Sales'} {props.sale.serviceLine}
				</Typography>
				<Typography className={classes.gic_h3} component={'div'}>
					{props.sale ? props.formatNumber(props.sale.sales ? props.sale.sales : props.sale.nsr) : null}
				</Typography>
			</CardContent>
		</Card>
	);
}
export { SimpleCard };
