import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import uniqid from'uniqid';
import { useDispatch, useSelector } from "react-redux";

const columns = [
    { id: 'opportunityName', label: 'Apportunity Name/ID', minWidth: 100 },
    { id: 'entity', label: 'Entity Name', minWidth: 100 },
    { id: 'ytdSales', label: 'YTD Sales', minWidth: 100 },
    { id: 'serviceLine', label: 'Service Line', minWidth: 100 },
    { id: 'opportunityOwner', label: 'Owner', minWidth: 100 },
    { id: 'opportunityLeader', label: 'Leader', minWidth: 100 },
    { id: 'opportunityPartner', label: 'Partner', minWidth: 100 },
];



const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    ...theme.typography.gic_h6,
  },
  container: {
    maxHeight: 400,
    marginTop: 16
  },
  tableCellContainer:{
    ...theme.typography.gic_h4,
  },
  tableBodyCell:{
    ...theme.typography.gic_h6,
    color: theme.palette.common.gicDarkGrey,
  }
}));

export default function AccountTable(props) {
  const dashboardAccountDetails = useSelector((state) => state.dashboard.getAccountDetails);
  const classes = useStyles();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    setPage(0);
  };

  // const getRowDetails = (accountId) => {
  //   console.log("inside row details table", accountId)
  //   props.getRowDetails(accountId);
  // }

  return (
    <Paper className={classes.root}>
      <TableContainer className={classes.container}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow >
              {columns.map((column) => (
                <TableCell
                  key={column.id + uniqid()}
                  align={column.align}
                  className={classes.tableCellContainer}
                  style={{ minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {props.accountDetails.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
              return (
                <TableRow  hover role="checkbox" tabIndex={-1} key={row.code+  uniqid()}>
                  {columns.map((column) => {
                    const value = row[column.id];
                    return (
                      <TableCell className={classes.tableBodyCell} key={column.id +  uniqid()} align={column.align}>
                        {column.format && typeof value === 'number' ? column.format(value) : value}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 15, 100]}
        className={classes.tableBodyCell}
        component="div"
        count={props.accountDetails.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onChangePage={handleChangePage}
        onChangeRowsPerPage={handleChangeRowsPerPage}
      />
    </Paper>
  );
}

export { AccountTable };