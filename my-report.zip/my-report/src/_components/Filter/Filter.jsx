import React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';

export default function FilterMenu(props) {
  const [value, setValue] = React.useState(props.filterValue[0]);
  const [inputValue, setInputValue] = React.useState('');

  return (
    <div>

      <Autocomplete
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
        inputValue={inputValue}
        onInputChange={(event, newInputValue) => {
          setInputValue(newInputValue);
          props.getFilteredChartVal(newInputValue)
        }}
        id="controllable-states-demo"
        options={props.filterValue}
        style={{ width: "100%" }}
        renderInput={(params) => <TextField {...params} label={props.filterLabe} variant="outlined" />}
      />
    </div>
  );
}