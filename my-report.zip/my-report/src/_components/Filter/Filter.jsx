/* eslint-disable no-use-before-define */

import React from 'react';
import {
  Chart,
  ArgumentAxis,
  ValueAxis,
  BarSeries,
  Legend,
} from '@devexpress/dx-react-chart-material-ui';
import { useDispatch, useSelector } from "react-redux";
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize="large" />;
const checkedIcon = <CheckBoxIcon fontSize="large" />;

export default function FilterMenu(props) {

  const dispatch = useDispatch();

  console.log("Vinay-->FilterMenu --> props", props);

  // const getMyOptions = (option, value) => {
  //   console.log("Vinay--> getMyOptions",option, value );
  //   return (option === value);
  // }

  const changeOption = (event, value) => {
    console.log("change options here----", event, value);
    dispatch({ type: "DASHBOARD_UPDATEFILTERLIST", value } );
    
    props.getFilteredChartVal(event.currentTarget.textContent)
    // const chartData = [...props.chartData];
    // const filteredChartData = chartData.filter((curr)=>
    //   curr.serviceLine === event.currentTarget.textContent
    // )
  }
  // const onChangeCheckbox = (event, selected) =>{
  //   console.log("Vinay--> onChangeCheckbox-->", event, selected);

  // }
  return (
    <Autocomplete
      multiple
      id="checkboxes-tags"
      size="small"
      limitTags={2}
      defaultValue = {props.initialFilterData || []}
      options={props.filterValue}
      disableCloseOnSelect
      getOptionLabel={(option) => option.title}
      // getOptionSelected = {(option, value) => getMyOptions(option, value)}

      onChange={(event, value) => changeOption(event,value)}
      renderOption={(option, { selected }) => (
        <React.Fragment>
          <Checkbox
            icon={icon}
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
          />
          {option.title}
        </React.Fragment>
      )}
      style={{ width: "100%" }}
      renderInput={(params) => {
        console.log("Vinay--> Params", params);
        return(
        <TextField {...params} variant="outlined" label={props.filterLabel} placeholder={props.filterPlaceholder} />
      )}}
    />
  );
}

