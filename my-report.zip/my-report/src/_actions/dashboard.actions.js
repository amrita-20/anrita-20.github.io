import { dashboardConstants } from '../_constants';
import { dashboardServices } from '../_services';
// import { alertActions } from './';
// import { history } from '../_helpers';

export const dashBoardActions = {

    getTop5Wins,
    getTop5Losses,
    getAccountWithNoMove,
    getAccountWithMove,
    getTotalSalesTarget,
    getAccWiseSalesTarget,
    getSalesBreakUp,
    getAccountDetails,
    getYtdNsr,
    getAccountNsr,
    getPostDetails,
    savePostDetails,
    getComments
};

function getTop5Wins() {
    return dispatch => {
        dispatch(request());

        dashboardServices.top5Wins()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOP5WINS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOP5WINS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOP5WINS_FAILURE, error } }
}

function getTop5Losses() {
    return dispatch => {
        dispatch(request());

        dashboardServices.top5Losses()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOP5LOSSES_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOP5LOSSES_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOP5LOSSES_FAILURE, error } }
}

function getAccountWithNoMove() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountWithNoMove()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_FAILURE, error } }
}

function getAccountWithMove() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountWithMove()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTWITHMOVE_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTWITHMOVE_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTWITHMOVE_FAILURE, error } }
}

function getTotalSalesTarget() {
    return dispatch => {
        dispatch(request());

        dashboardServices.totalSalesTarget()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOTALSALESTARGET_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOTALSALESTARGET_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOTALSALESTARGET_FAILURE, error } }
}

function getAccWiseSalesTarget() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accWiseSalesTarget()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCWISESALESTARGET_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCWISESALESTARGET_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCWISESALESTARGET_FAILURE, error } }
}
function getSalesBreakUp() {
    return dispatch => {
        dispatch(request());

        dashboardServices.salesBreakUp()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETSALESBREAKUP_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETSALESBREAKUP_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETSALESBREAKUP_FAILURE, error } }
}
function getAccountDetails(accountId) {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountDetails(accountId)
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTDETAILS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTDETAILS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTDETAILS_FAILURE, error } }
}

function getYtdNsr() {
    return dispatch => {
        dispatch(request());

        dashboardServices.ytdNsr()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETYTDNSR_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETYTDNSR_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETYTDNSR_FAILURE, error } }
}

function getAccountNsr() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountNsr()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTNSR_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTNSR_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTNSR_FAILURE, error } }
}

function getPostDetails() {
    return dispatch => {
        dispatch(request());

        dashboardServices.postDetails()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETPOSTDETAILS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETPOSTDETAILS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETPOSTDETAILS_FAILURE, error } }
}

function getComments() {
    return dispatch => {
        dispatch(request());

        dashboardServices.getComments()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETCOMMENTS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETCOMMENTS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETCOMMENTS_FAILURE, error } }
}

function savePostDetails(posts) {
    return dispatch => {
        dispatch(request());

        dashboardServices.savePost(posts)
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.SAVEPOST_REQUEST } }
    function success(data) { return { type: dashboardConstants.SAVEPOST_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.SAVEPOST_FAILURE, error } }
}


