import { dashboardConstants } from '../_constants';
import { dashboardServices } from '../_services';
// import { alertActions } from './';
// import { history } from '../_helpers';

export const dashBoardActions = {

    getTop5Wins,
    getTop5Losses,
    getAccountWithNoMove,
    getAccountWithMove,
    getTotalSalesTarget,
    getAccWiseSalesTarget,
    getSalesBreakUp,
    getAccountDetails
};

function getTop5Wins() {
    return dispatch => {
        dispatch(request());

        dashboardServices.top5Wins()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOP5WINS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOP5WINS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOP5WINS_FAILURE, error } }
}

function getTop5Losses() {
    return dispatch => {
        dispatch(request());

        dashboardServices.top5Losses()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOP5LOSSES_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOP5LOSSES_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOP5LOSSES_FAILURE, error } }
}

function getAccountWithNoMove() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountWithNoMove()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTWITHNOMOVE_FAILURE, error } }
}

function getAccountWithMove() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountWithMove()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTWITHMOVE_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTWITHMOVE_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTWITHMOVE_FAILURE, error } }
}

function getTotalSalesTarget() {
    return dispatch => {
        dispatch(request());

        dashboardServices.totalSalesTarget()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETTOTALSALESTARGET_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETTOTALSALESTARGET_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETTOTALSALESTARGET_FAILURE, error } }
}

function getAccWiseSalesTarget() {
    return dispatch => {
        dispatch(request());

        dashboardServices.accWiseSalesTarget()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCWISESALESTARGET_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCWISESALESTARGET_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCWISESALESTARGET_FAILURE, error } }
}
function getSalesBreakUp() {
    return dispatch => {
        dispatch(request());

        dashboardServices.salesBreakUp()
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETSALESBREAKUP_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETSALESBREAKUP_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETSALESBREAKUP_FAILURE, error } }
}
function getAccountDetails(accountId) {
    return dispatch => {
        dispatch(request());

        dashboardServices.accountDetails(accountId)
            .then(
                data => dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: dashboardConstants.GETACCOUNTDETAILS_REQUEST } }
    function success(data) { return { type: dashboardConstants.GETACCOUNTDETAILS_SUCCESS, data } }
    function failure(error) { return { type: dashboardConstants.GETACCOUNTDETAILS_FAILURE, error } }
}


