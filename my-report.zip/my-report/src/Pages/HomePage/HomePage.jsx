import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { userActions, dashBoardActions } from "../../_actions";
// import BasicTable from '../../_components/Table/Table';
// import Charts from '../../_components/ApexCharts/ApexCharts';
// import ReactCharts from '../../_components/Charts/Charts';
// import SideDrawer from '../../_components/SideDrawer/SideDrawer'
// import ReactTable from '../../_components/ReactTable/ReactTable';
import VerticalTabs from "../../_components/Tabs/Tabs";
// import axios from "axios";
// import { batch } from 'react-redux'

function HomePage() {
  const users = useSelector((state) => state.users);
  const dashboard = useSelector((state) => state.dashboard);
  const user = useSelector((state) => state.authentication.user);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(userActions.getAll());
    dispatch(dashBoardActions.getTop5Wins());
    dispatch(dashBoardActions.getTop5Losses());
    dispatch(dashBoardActions.getAccountWithNoMove());
    dispatch(dashBoardActions.getAccountWithMove());
    dispatch(dashBoardActions.getTotalSalesTarget());
    dispatch(dashBoardActions.getAccWiseSalesTarget());
    dispatch(dashBoardActions.getSalesBreakUp());

    // batch(() => {
    //     dispatch(userActions.getAll())
    //     dispatch(dashBoardActions.getTop5Wins())
    // })
  }, []);

  function handleDeleteUser(id) {
    dispatch(userActions.delete(id));
  }

  return (
    <React.Fragment>
      <VerticalTabs dashboardData={dashboard} />
      {/* <h1>Hi {user.firstName}!</h1>
                <SideDrawer/> */}
      {/* <ReactCharts/>
                <Charts/> */}
      {/* <br/>
                <div class="row">
                    <div class="col-sm-4">
                        <BasicTable className="center-block" data={top5Wins} heading={"Top 5 Wins"}/>
                    </div>
                    <div class="col-sm-4">
                         <BasicTable className="center-block" data={top5Losses} heading={"Top 5 Losses"}/>
                    </div>
                    <div class="col-sm-4">
                         <BasicTable className="center-block" data={row3} heading={"No Movement"}/>
                    </div>
                </div> */}
      {/* <ReactTable/> */}

      {
        /* <h3>All registered users:</h3>
                {users.loading && <em>Loading users...</em>}
                {users.error && <span className="text-danger">ERROR: {users.error}</span>}
                {users.items &&
                    <ul>
                        {users.items.map((user, index) =>
                            <li key={user.id}>
                                {user.firstName + ' ' + user.lastName}
                                {
                                    user.deleting ? <em> - Deleting...</em>
                                    : user.deleteError ? <span className="text-danger"> - ERROR: {user.deleteError}</span>
                                    : <span> - <a onClick={() => handleDeleteUser(user.id)} className="text-primary">Delete</a></span>
                                }
                            </li>
                        )}
                    </ul>
                }*/
        <p>
          <Link to="/login">Logout</Link>
        </p>
      }
    </React.Fragment>
  );
}

export { HomePage };
