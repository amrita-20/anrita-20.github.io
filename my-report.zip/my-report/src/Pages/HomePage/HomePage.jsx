import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { userActions, dashBoardActions } from "../../_actions";
import VerticalTabs from "../../_components/Tabs/Tabs";

function HomePage() {
  const users = useSelector((state) => state.users);
  let dashboard = useSelector((state) => state.dashboard);
  const user = useSelector((state) => state.authentication.user);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(userActions.getAll());
    dispatch(dashBoardActions.getTop5Wins());
    dispatch(dashBoardActions.getTop5Losses());
    dispatch(dashBoardActions.getAccountWithNoMove());
    dispatch(dashBoardActions.getAccountWithMove());
    dispatch(dashBoardActions.getTotalSalesTarget());
    dispatch(dashBoardActions.getAccWiseSalesTarget());
    dispatch(dashBoardActions.getSalesBreakUp());
    dispatch(dashBoardActions.getYtdNsr());
    dispatch(dashBoardActions.getAccountNsr());
    dispatch(dashBoardActions.getPostDetails());
  }, []);

  function handleDeleteUser(id) {
    dispatch(userActions.delete(id));
  }

  const clearDashboardData = () => {
    dashboard = null;
    window.location.href = '/login'
  }

  return (
    <React.Fragment>
      <VerticalTabs dashboardData={dashboard} />
      {
        // <p>
        //   <Link to="/login">Logout</Link>
        // </p>
        <button onClick={clearDashboardData}>Logout</button>
      }
    </React.Fragment>
  );
}

export { HomePage };
