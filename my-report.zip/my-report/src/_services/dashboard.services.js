import config from 'config';
import { authHeader } from '../_helpers';

export const dashboardServices = {
    top5Wins,
    top5Losses,
    accountWithNoMove,
    accountWithMove,
    totalSalesTarget,
    accWiseSalesTarget,
    salesBreakUp,
    accountDetails,
    accountsWithNoMovement,
    accountsWithSignificantMovement,
    ytdNsr,
    accountNsr,
    postDetails,
    savePost,
    getComments
};

const heroBaseUrl = 'https://gic-reporting.herokuapp.com';

const ngBaseUrl = 'http://6b5b6cb34a27.ngrok.io';

const baseUrl = heroBaseUrl;

function top5Wins() {

    console.log("response in services top5Wins-->",  authHeader());

    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };
    console.log("Vinay--> requestOptions", requestOptions);

    return fetch(`${baseUrl}/sales-data/top-wins`, requestOptions).then(handleResponse);
}
function top5Losses() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/top-losses`, requestOptions).then(handleResponse);
}
function accountWithNoMove() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/no-movement-accounts`, requestOptions).then(handleResponse);
}

function accountWithMove() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/significant-movement-accounts`, requestOptions).then(handleResponse);
}

function totalSalesTarget() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/ytd-sales`, requestOptions).then(handleResponse);
}
function accWiseSalesTarget() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/account-sales`, requestOptions).then(handleResponse);
}
function salesBreakUp() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/sales-breakup`, requestOptions).then(handleResponse);
}

function accountDetails(accountId) {
    const requestOptions = {
        method: 'GET',
        async: false,
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/account-details?accountName=${accountId}`, requestOptions).then(handleResponse);
}

function accountsWithNoMovement() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/no-movement-accounts`, requestOptions).then(handleResponse);
}

function accountsWithSignificantMovement() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/sales-data/significant-movement-accounts`, requestOptions).then(handleResponse);
}
function ytdNsr() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/nsr-data/ytd-nsr`, requestOptions).then(handleResponse);
}
function accountNsr() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/nsr-data/account-nsr`, requestOptions).then(handleResponse);
}

function postDetails() {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/get-posts`, requestOptions).then(handleResponse);
}

function getComments(postId) {
    const requestOptions = {
        method: 'GET',
        headers: authHeader()
    };

    return fetch(`${baseUrl}/get-comments?postId=${postId}`, requestOptions).then(handleResponse);
}


function savePost(posts) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(posts)
    };

    return fetch(`${config.apiUrl}/save-post`, requestOptions).then(handleResponse);
}
function handleResponse(response) {
    return response.text().then(text => {
        const data = text && JSON.parse(text);
        console.log("My response data-->", data);
        if (!response.ok) {
            if (response.status === 401) {
                // auto logout if 401 response returned from api
                logout();
                location.reload(true);
            }

            const error = (data && data.message) || response.statusText;
            return Promise.reject(error);
        }

        return data;
    });
}