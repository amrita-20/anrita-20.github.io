import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import "core-js/stable";
import "regenerator-runtime/runtime";
import { store } from './_helpers';
import { App } from './App';
import '@devexpress/dx-react-chart-bootstrap4/dist/dx-react-chart-bootstrap4.css';
import '@devexpress/dx-react-grid-bootstrap4/dist/dx-react-grid-bootstrap4.css';

// // setup fake backend
// import { configureFakeBackend } from './_helpers';
// configureFakeBackend();

render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('app')
);