import React, { useEffect } from 'react';
import { ThemeProvider } from '@material-ui/styles';
import { Router, Route, Switch, Redirect } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import theme from '../ui/Theme';
import { history } from '../_helpers';
import { alertActions } from '../_actions';
import { PrivateRoute } from '../_components';
import { HomePage } from '../Pages/HomePage';
import { LoginPage } from '../Pages/LoginPage';
import { RegisterPage } from '../Pages/RegisterPage';
import { Header } from '../_components/Header';

function App() {
    const alert = useSelector(state => state.alert);
    const dispatch = useDispatch();

    useEffect(() => {
        history.listen((location, action) => {
            // clear alert on location change
            dispatch(alertActions.clear());
        });
    }, []);

    return (
        <React.Fragment>
        <ThemeProvider theme={theme}>
        <Header/>
       
        {/* <div className="jumbotron"> */}
            {/* <div className="container"> */}
                {/* <div className="col-md-12 offset-md-0"> */}
                    {alert.message &&
                        <div className={`alert ${alert.type}`}>{alert.message}</div>
                    }
                    <Router history={history}>
                        <Switch>
                            <PrivateRoute exact path="/" component={HomePage} />
                            <Route path="/login" component={LoginPage} />
                            <Route path="/register" component={RegisterPage} />
                            <Redirect from="*" to="/" />
                        </Switch>
                    </Router>
                {/* </div>
            </div>
        </div> */}
        </ThemeProvider>
      </React.Fragment>
        
    );
}

export { App };