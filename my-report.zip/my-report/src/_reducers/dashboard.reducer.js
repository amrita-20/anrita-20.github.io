<<<<<<< HEAD
import {
    dashboardConstants
} from '../_constants';
 const _ = require ('lodash');
=======
import { dashboardConstants } from "../_constants";
>>>>>>> d34964fa63ca8a9e01e14966648c6853912c8bd9

let user = JSON.parse(localStorage.getItem("user"));
const initialState = {
<<<<<<< HEAD
    getTop5Wins: [],
    getTop5Losses: [],
    getAccountWithNoMove: [],
    getAccountWithMove: [],
    getTotalSalesTarget: {},
    getAccWiseSalesTarget: [],
    getSalesBreakUp: [],
    getAccountDetails: [],
    loading: false,
    initialFilterData: [{title: "ALL L2", value: "DCM"}]
}

export function dashboard(state = initialState, action) {
    switch (action.type) {
        case dashboardConstants.GETTOP5WINS_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETTOP5WINS_SUCCESS:

            return {
                ...state,
                getTop5Wins: action.data.data
            };
        case dashboardConstants.GETTOP5WINS_FAILURE:

            return {
                ...state,
                error: action.error
            };
        case dashboardConstants.GETTOP5LOSSES_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETTOP5LOSSES_SUCCESS:

            return {
                ...state,
                getTop5Losses: action.data.data
            };
        case dashboardConstants.GETTOP5LOSSES_FAILURE:

            return {
                ...state,
                error: action.error
            };
        case dashboardConstants.GETACCOUNTWITHNOMOVE_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETACCOUNTWITHNOMOVE_SUCCESS:

            return {
                ...state,
                getAccountWithNoMove: action.data.data
            };
        case dashboardConstants.GETACCOUNTWITHNOMOVE_FAILURE:

            return {
                ...state,
                error: action.error
            };
        case dashboardConstants.GETACCOUNTWITHMOVE_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETACCOUNTWITHMOVE_SUCCESS:

            return {
                ...state,
                getAccountWithMove: action.data.data
            };
        case dashboardConstants.GETACCOUNTWITHMOVE_FAILURE:

            return {
                ...state,
                error: action.error
            };
        case dashboardConstants.GETTOTALSALESTARGET_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETTOTALSALESTARGET_SUCCESS:

            return {
                ...state,
                getTotalSalesTarget: action.data.data
            };
        case dashboardConstants.GETTOTALSALESTARGET_FAILURE:

            return {
                ...state,
                error: action.error
            };

        case dashboardConstants.GETACCWISESALESTARGET_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETACCWISESALESTARGET_SUCCESS:

            return {
                ...state,
                getAccWiseSalesTarget: action.data.data
            };
        case dashboardConstants.GETACCWISESALESTARGET_FAILURE:

            return {
                ...state,
                error: action.error
            };

        case dashboardConstants.GETSALESBREAKUP_REQUEST:
            return {
                ...state,
                loading: true

            };
        case dashboardConstants.GETSALESBREAKUP_SUCCESS:

            return {
                ...state,
                getSalesBreakUp: action.data.data
            };
        case dashboardConstants.GETSALESBREAKUP_FAILURE:

            return {
                ...state,
                error: action.error
            };

        case "DASHBOARD_UPDATEFILTERLIST" :
        // console.log("testing reducer-->",_.filter(action.value, state.getAccWiseSalesTarget));
        console.log("testing reducer-->",JSON.stringify(state.getAccWiseSalesTarget));

        return {
            ...state,
            initialFilterData: action.value


        }
        default:
            return state
    }
}
=======
  getTop5Wins: [],
  getTop5Losses: [],
  getAccountWithNoMove: [],
  getAccountWithMove: [],
  getTotalSalesTarget: {},
  getAccWiseSalesTarget: [],
  getSalesBreakUp: [],
  getAccountDetails: {},
  loading: false,
  initialFilterData: [],
};

export function dashboard(state = initialState, action) {
  switch (action.type) {
    case dashboardConstants.GETTOP5WINS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOP5WINS_SUCCESS:
      return {
        ...state,
        getTop5Wins: action.data.data,
      };
    case dashboardConstants.GETTOP5WINS_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETTOP5LOSSES_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOP5LOSSES_SUCCESS:
      return {
        ...state,
        getTop5Losses: action.data.data,
      };
    case dashboardConstants.GETTOP5LOSSES_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_SUCCESS:
      return {
        ...state,
        getAccountWithNoMove: action.data.data,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_SUCCESS:
      return {
        ...state,
        getAccountWithMove: action.data.data,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETTOTALSALESTARGET_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOTALSALESTARGET_SUCCESS:
      return {
        ...state,
        getTotalSalesTarget: action.data.data,
      };
    case dashboardConstants.GETTOTALSALESTARGET_FAILURE:
      return {
        ...state,
        error: action.error,
      };

    case dashboardConstants.GETACCWISESALESTARGET_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCWISESALESTARGET_SUCCESS:
      return {
        ...state,
        getAccWiseSalesTarget: action.data.data,
      };
    case dashboardConstants.GETACCWISESALESTARGET_FAILURE:
      return {
        ...state,
        error: action.error,
      };

    case dashboardConstants.GETSALESBREAKUP_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETSALESBREAKUP_SUCCESS:
      return {
        ...state,
        getSalesBreakUp: action.data.data,
      };
    case dashboardConstants.GETSALESBREAKUP_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTDETAILS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTDETAILS_SUCCESS:
      return {
        ...state,
        getAccountDetails: action.data.data,
      };
    case dashboardConstants.GETACCOUNTDETAILS_FAILURE:
      return {
        ...state,
        error: action.error,
      };

    case "DASHBOARD_UPDATEFILTERLIST":
      return {
        ...state,
        initialFilterData: action.value,
      };
    default:
      return state;
  }
}
>>>>>>> d34964fa63ca8a9e01e14966648c6853912c8bd9
