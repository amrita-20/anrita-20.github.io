import { dashboardConstants } from "../_constants";

let user = JSON.parse(localStorage.getItem("user"));
const initialState = {
  getTop5Wins: [],
  getTop5Losses: [],
  getAccountWithNoMove: [],
  getAccountWithMove: [],
  getTotalSalesTarget: {},
  getAccWiseSalesTarget: [],
  getSalesBreakUp: [],
  getAccountDetails: {},
  loading: false,
  initialFilterData: [],
  getYtdNsr: {},
  getAccountNsr: [],
  getPostDetails: [],
  getCommentDetails: []
};

export function dashboard(state = initialState, action) {
  switch (action.type) {
    case dashboardConstants.GETTOP5WINS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOP5WINS_SUCCESS:
      return {
        ...state,
        getTop5Wins: action.data.data,
      };
    case dashboardConstants.GETTOP5WINS_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETTOP5LOSSES_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOP5LOSSES_SUCCESS:
      return {
        ...state,
        getTop5Losses: action.data.data,
      };
    case dashboardConstants.GETTOP5LOSSES_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_SUCCESS:
      return {
        ...state,
        getAccountWithNoMove: action.data.data,
      };
    case dashboardConstants.GETACCOUNTWITHNOMOVE_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_SUCCESS:
      return {
        ...state,
        getAccountWithMove: action.data.data,
      };
    case dashboardConstants.GETACCOUNTWITHMOVE_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETTOTALSALESTARGET_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETTOTALSALESTARGET_SUCCESS:
      return {
        ...state,
        getTotalSalesTarget: action.data.data,
      };
    case dashboardConstants.GETTOTALSALESTARGET_FAILURE:
      return {
        ...state,
        error: action.error,
      };

    case dashboardConstants.GETACCWISESALESTARGET_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCWISESALESTARGET_SUCCESS:
      return {
        ...state,
        getAccWiseSalesTarget: action.data.data,
      };
    case dashboardConstants.GETACCWISESALESTARGET_FAILURE:
      return {
        ...state,
        error: action.error,
      };

    case dashboardConstants.GETSALESBREAKUP_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETSALESBREAKUP_SUCCESS:
      return {
        ...state,
        getSalesBreakUp: action.data.data,
      };
    case dashboardConstants.GETSALESBREAKUP_FAILURE:
      return {
        ...state,
        error: action.error,
      };
    case dashboardConstants.GETACCOUNTDETAILS_REQUEST:
      return {
        ...state,
        loading: true,
      };
    case dashboardConstants.GETACCOUNTDETAILS_SUCCESS:
      return {
        ...state,
        getAccountDetails: action.data.data,
      };
    case dashboardConstants.GETACCOUNTDETAILS_FAILURE:
      return {
        ...state,
        error: action.error,
      };
      case dashboardConstants.GETYTDNSR_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case dashboardConstants.GETYTDNSR_SUCCESS:
        return {
          ...state,
          getYtdNsr: action.data.data,
        };
      case dashboardConstants.GETYTDNSR_FAILURE:
        return {
          ...state,
          error: action.error,
        };
        case dashboardConstants.GETACCOUNTNSR_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case dashboardConstants.GETACCOUNTNSR_SUCCESS:
        return {
          ...state,
          getAccountNsr: action.data.data,
        };
      case dashboardConstants.GETACCOUNTNSR_FAILURE:
        return {
          ...state,
          error: action.error,
        };

    case "DASHBOARD_UPDATEFILTERLIST":
      return {
        ...state,
        initialFilterData: action.value,
      };

      case dashboardConstants.GETPOSTDETAILS_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case dashboardConstants.GETPOSTDETAILS_SUCCESS:
        return {
          ...state,
          getPostDetails: action.data.data,
        };
      case dashboardConstants.GETPOSTDETAILS_FAILURE:
        return {
          ...state,
          error: action.error,
        };

        case dashboardConstants.GETCOMMENTS_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case dashboardConstants.GETCOMMENTS_SUCCESS:
          return {
            ...state,
            getCommentDetails: action.data.data,
          };
        case dashboardConstants.GETCOMMENTS_FAILURE:
          return {
            ...state,
            error: action.error,
          };

    default:
      return state;
  }
}
