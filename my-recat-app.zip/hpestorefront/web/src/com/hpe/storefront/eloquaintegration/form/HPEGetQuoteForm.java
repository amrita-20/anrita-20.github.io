/**
 *
 */
package com.hpe.storefront.eloquaintegration.form;

/**
 * @author PO375901
 *
 */
public class HPEGetQuoteForm
{
	private String C_FirstName;
	private String C_LastName;
	private String C_EmailAddress;
	private String C_BusPhone;
	private String C_MobilePhone;
	private String C_Company;
	private String C_Country;
	private String C_City;
	private String stateProv;
	private String C_Estimated_Budget1;
	private String C_Lead_Currency1;
	private String C_Email_Opt_In1;
	private String C_Phone_Opt_in1;
	private String mobileOptIn1;
	private String titleCode;
	private Boolean decisionMaker;
	private Boolean hpeContact;
	private String quoteNumber;
	private String C_AttentionTo;
	private String productName;
	private String productIds;
	/**
	 * @return the productIds
	 */
	public String getProductIds()
	{
		return productIds;
	}

	/**
	 * @param productIds
	 *           the productIds to set
	 */
	public void setProductIds(final String productIds)
	{
		this.productIds = productIds;
	}

	/**
	 * @return the productName
	 */
	public String getProductName()
	{
		return productName;
	}

	/**
	 * @param productName
	 *           the productName to set
	 */
	public void setProductName(final String productName)
	{
		this.productName = productName;
	}

	/**
	 * @return the hpeContact
	 */
	public Boolean getHpeContact()
	{
		return hpeContact;
	}

	/**
	 * @param hpeContact
	 *           the hpeContact to set
	 */
	public void setHpeContact(final Boolean hpeContact)
	{
		this.hpeContact = hpeContact;
	}

	/**
	 * @return the decisionMaker
	 */
	public Boolean getDecisionMaker()
	{
		return decisionMaker;
	}

	/**
	 * @param decisionMaker
	 *           the decisionMaker to set
	 */
	public void setDecisionMaker(final Boolean decisionMaker)
	{
		this.decisionMaker = decisionMaker;
	}

	/**
	 * @return the titleCode
	 */
	public String getTitleCode()
	{
		return titleCode;
	}

	/**
	 * @param titleCode
	 *           the titleCode to set
	 */
	public void setTitleCode(final String titleCode)
	{
		this.titleCode = titleCode;
	}

	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * @param password
	 *           the password to set
	 */
	public void setPassword(final String password)
	{
		this.password = password;
	}

	/**
	 * @return the checkpassword
	 */
	public String getCheckpassword()
	{
		return checkpassword;
	}

	/**
	 * @param checkpassword
	 *           the checkpassword to set
	 */
	public void setCheckpassword(final String checkpassword)
	{
		this.checkpassword = checkpassword;
	}

	/**
	 * @return the emailcheck
	 */
	public String getEmailcheck()
	{
		return emailcheck;
	}

	/**
	 * @param emailcheck
	 *           the emailcheck to set
	 */
	public void setEmailcheck(final String emailcheck)
	{
		this.emailcheck = emailcheck;
	}

	private String C_Timeframe_to_Buy1;
	private String C_configID;
	private String C_BOM;
	private String password;
	private String checkpassword;
	private String emailcheck;

	/**
	 * @return the c_FirstName
	 */
	public String getC_FirstName()
	{
		return C_FirstName;
	}

	/**
	 * @param c_FirstName
	 *           the c_FirstName to set
	 */
	public void setC_FirstName(final String c_FirstName)
	{
		C_FirstName = c_FirstName;
	}

	/**
	 * @return the c_LastName
	 */
	public String getC_LastName()
	{
		return C_LastName;
	}

	/**
	 * @param c_LastName
	 *           the c_LastName to set
	 */
	public void setC_LastName(final String c_LastName)
	{
		C_LastName = c_LastName;
	}

	/**
	 * @return the c_EmailAddress
	 */
	public String getC_EmailAddress()
	{
		return C_EmailAddress;
	}

	/**
	 * @param c_EmailAddress
	 *           the c_EmailAddress to set
	 */
	public void setC_EmailAddress(final String c_EmailAddress)
	{
		C_EmailAddress = c_EmailAddress;
	}

	/**
	 * @return the c_BusPhone
	 */
	public String getC_BusPhone()
	{
		return C_BusPhone;
	}

	/**
	 * @param c_BusPhone
	 *           the c_BusPhone to set
	 */
	public void setC_BusPhone(final String c_BusPhone)
	{
		C_BusPhone = c_BusPhone;
	}

	/**
	 * @return the c_MobilePhone
	 */
	public String getC_MobilePhone()
	{
		return C_MobilePhone;
	}

	/**
	 * @param c_MobilePhone
	 *           the c_MobilePhone to set
	 */
	public void setC_MobilePhone(final String c_MobilePhone)
	{
		C_MobilePhone = c_MobilePhone;
	}

	/**
	 * @return the c_Company
	 */
	public String getC_Company()
	{
		return C_Company;
	}

	/**
	 * @param c_Company
	 *           the c_Company to set
	 */
	public void setC_Company(final String c_Company)
	{
		C_Company = c_Company;
	}

	/**
	 * @return the c_Country
	 */
	public String getC_Country()
	{
		return C_Country;
	}

	/**
	 * @param c_Country
	 *           the c_Country to set
	 */
	public void setC_Country(final String c_Country)
	{
		C_Country = c_Country;
	}

	/**
	 * @return the stateProv
	 */
	public String getStateProv()
	{
		return stateProv;
	}

	/**
	 * @param stateProv
	 *           the stateProv to set
	 */
	public void setStateProv(final String stateProv)
	{
		this.stateProv = stateProv;
	}

	/**
	 * @return the c_Estimated_Budget1
	 */
	public String getC_Estimated_Budget1()
	{
		return C_Estimated_Budget1;
	}

	/**
	 * @param c_Estimated_Budget1
	 *           the c_Estimated_Budget1 to set
	 */
	public void setC_Estimated_Budget1(final String c_Estimated_Budget1)
	{
		C_Estimated_Budget1 = c_Estimated_Budget1;
	}

	/**
	 * @return the c_Lead_Currency1
	 */
	public String getC_Lead_Currency1()
	{
		return C_Lead_Currency1;
	}

	/**
	 * @param c_Lead_Currency1
	 *           the c_Lead_Currency1 to set
	 */
	public void setC_Lead_Currency1(final String c_Lead_Currency1)
	{
		C_Lead_Currency1 = c_Lead_Currency1;
	}

	/**
	 * @return the c_Email_Opt_In1
	 */
	public String getC_Email_Opt_In1()
	{
		return C_Email_Opt_In1;
	}

	/**
	 * @param c_Email_Opt_In1
	 *           the c_Email_Opt_In1 to set
	 */
	public void setC_Email_Opt_In1(final String c_Email_Opt_In1)
	{
		C_Email_Opt_In1 = c_Email_Opt_In1;
	}

	/**
	 * @return the c_Phone_Opt_in1
	 */
	public String getC_Phone_Opt_in1()
	{
		return C_Phone_Opt_in1;
	}

	/**
	 * @param c_Phone_Opt_in1
	 *           the c_Phone_Opt_in1 to set
	 */
	public void setC_Phone_Opt_in1(final String c_Phone_Opt_in1)
	{
		C_Phone_Opt_in1 = c_Phone_Opt_in1;
	}

	/**
	 * @return the mobileOptIn1
	 */
	public String getMobileOptIn1()
	{
		return mobileOptIn1;
	}

	/**
	 * @param mobileOptIn1
	 *           the mobileOptIn1 to set
	 */
	public void setMobileOptIn1(final String mobileOptIn1)
	{
		this.mobileOptIn1 = mobileOptIn1;
	}

	/**
	 * @return the c_Timeframe_to_Buy1
	 */
	public String getC_Timeframe_to_Buy1()
	{
		return C_Timeframe_to_Buy1;
	}

	/**
	 * @param c_Timeframe_to_Buy1
	 *           the c_Timeframe_to_Buy1 to set
	 */
	public void setC_Timeframe_to_Buy1(final String c_Timeframe_to_Buy1)
	{
		C_Timeframe_to_Buy1 = c_Timeframe_to_Buy1;
	}

	/**
	 * @return the c_configID
	 */
	public String getC_configID()
	{
		return C_configID;
	}

	/**
	 * @param c_configID
	 *           the c_configID to set
	 */
	public void setC_configID(final String c_configID)
	{
		C_configID = c_configID;
	}

	/**
	 * @return the c_BOM
	 */
	public String getC_BOM()
	{
		return C_BOM;
	}

	/**
	 * @param c_BOM
	 *           the c_BOM to set
	 */
	public void setC_BOM(final String c_BOM)
	{
		C_BOM = c_BOM;
	}

	/**
	 * @return the c_Business_Need
	 */
	public String getC_Business_Need()
	{
		return C_Business_Need;
	}

	/**
	 * @param c_Business_Need
	 *           the c_Business_Need to set
	 */
	public void setC_Business_Need(final String c_Business_Need)
	{
		C_Business_Need = c_Business_Need;
	}

	/**
	 * @return the mcid
	 */
	public String getMcid()
	{
		return mcid;
	}

	/**
	 * @param mcid
	 *           the mcid to set
	 */
	public void setMcid(final String mcid)
	{
		this.mcid = mcid;
	}

	/**
	 * @return the mcid_tid
	 */
	public String getMcid_tid()
	{
		return mcid_tid;
	}

	/**
	 * @param mcid_tid
	 *           the mcid_tid to set
	 */
	public void setMcid_tid(final String mcid_tid)
	{
		this.mcid_tid = mcid_tid;
	}

	/**
	 * @return the mcid_url
	 */
	public String getMcid_url()
	{
		return mcid_url;
	}

	/**
	 * @param mcid_url
	 *           the mcid_url to set
	 */
	public void setMcid_url(final String mcid_url)
	{
		this.mcid_url = mcid_url;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1()
	{
		return address1;
	}

	/**
	 * @param address1
	 *           the address1 to set
	 */
	public void setAddress1(final String address1)
	{
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2()
	{
		return address2;
	}

	/**
	 * @param address2
	 *           the address2 to set
	 */
	public void setAddress2(final String address2)
	{
		this.address2 = address2;
	}

	/**
	 * @return the zipPostal
	 */
	public String getZipPostal()
	{
		return zipPostal;
	}

	/**
	 * @param zipPostal
	 *           the zipPostal to set
	 */
	public void setZipPostal(final String zipPostal)
	{
		this.zipPostal = zipPostal;
	}

	/**
	 * @return the purchaseRole1
	 */
	public String getPurchaseRole1()
	{
		return purchaseRole1;
	}

	/**
	 * @param purchaseRole1
	 *           the purchaseRole1 to set
	 */
	public void setPurchaseRole1(final String purchaseRole1)
	{
		this.purchaseRole1 = purchaseRole1;
	}

	/**
	 * @return the source_page_URL
	 */
	public String getSource_page_URL()
	{
		return source_page_URL;
	}

	/**
	 * @param source_page_URL
	 *           the source_page_URL to set
	 */
	public void setSource_page_URL(final String source_page_URL)
	{
		this.source_page_URL = source_page_URL;
	}

	/**
	 * @return the c_City
	 */
	public String getC_City()
	{
		return C_City;
	}

	/**
	 * @param c_City
	 *           the c_City to set
	 */
	public void setC_City(final String c_City)
	{
		C_City = c_City;
	}


	/**
	 * @return the quoteNumber
	 */
	public String getQuoteNumber()
	{
		return quoteNumber;
	}

	/**
	 * @param quoteNumber
	 *           the quoteNumber to set
	 */
	public void setQuoteNumber(final String quoteNumber)
	{
		this.quoteNumber = quoteNumber;
	}



	/**
	 * @return the c_AttentionTo
	 */
	public String getC_AttentionTo()
	{
		return C_AttentionTo;
	}

	/**
	 * @param c_AttentionTo
	 *           the c_AttentionTo to set
	 */
	public void setC_AttentionTo(final String c_AttentionTo)
	{
		C_AttentionTo = c_AttentionTo;
	}

	private String C_Business_Need;
	private String mcid;
	private String mcid_tid;
	private String mcid_url;
	private String address1;
	private String address2;
	private String zipPostal;
	private String purchaseRole1;
	private String source_page_URL;



}
