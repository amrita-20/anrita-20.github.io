/**
 *
 */
package com.hpe.storefront.passportintegration.form;

import de.hybris.platform.acceleratorstorefrontcommons.forms.RegisterForm;


/**
 * @author NandhiniMarimuthu
 * @version 1.0
 *
 */
public class HPERegisterForm extends RegisterForm
{
	private String countryName;
	private String company;
	private String address1;
	private String address2;
	private String city;
	private String stateCode;
	private String zipCode;
	private String countryCode;
	private String emailCheck;
	private String attentionTo;
	private String partnerNumber;

	/**
	 * @return the partnerNumber
	 */
	public String getPartnerNumber()
	{
		return partnerNumber;
	}

	/**
	 * @param partnerNumber
	 *           the partnerNumber to set
	 */
	public void setPartnerNumber(final String partnerNumber)
	{
		this.partnerNumber = partnerNumber;
	}

	/**
	 * @return the attentionTo
	 */
	public String getAttentionTo()
	{
		return attentionTo;
	}

	/**
	 * @param attentionTo
	 *           the attentionTo to set
	 */
	public void setAttentionTo(final String attentionTo)
	{
		this.attentionTo = attentionTo;
	}

	/**
	 * @return the countryName
	 */
	public String getCountryName()
	{
		return countryName;
	}

	/**
	 * @param countryName
	 *           the countryName to set
	 */
	public void setCountryName(final String countryName)
	{
		this.countryName = countryName;
	}

	/**
	 * @return the company
	 */
	public String getCompany()
	{
		return company;
	}

	/**
	 * @param company
	 *           the company to set
	 */
	public void setCompany(final String company)
	{
		this.company = company;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1()
	{
		return address1;
	}

	/**
	 * @param address1
	 *           the address1 to set
	 */
	public void setAddress1(final String address1)
	{
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2()
	{
		return address2;
	}

	/**
	 * @param address2
	 *           the address2 to set
	 */
	public void setAddress2(final String address2)
	{
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 * @param city
	 *           the city to set
	 */
	public void setCity(final String city)
	{
		this.city = city;
	}

	/**
	 * @return the stateCode
	 */
	public String getStateCode()
	{
		return stateCode;
	}

	/**
	 * @param stateCode
	 *           the stateCode to set
	 */
	public void setStateCode(final String stateCode)
	{
		this.stateCode = stateCode;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode()
	{
		return zipCode;
	}

	/**
	 * @param zipCode
	 *           the zipCode to set
	 */
	public void setZipCode(final String zipCode)
	{
		this.zipCode = zipCode;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode()
	{
		return countryCode;
	}

	/**
	 * @param countryCode
	 *           the countryCode to set
	 */
	public void setCountryCode(final String countryCode)
	{
		this.countryCode = countryCode;
	}

	/**
	 * @return the emailCheck
	 */
	public String getEmailCheck()
	{
		return emailCheck;
	}

	/**
	 * @param emailCheck
	 *           the emailCheck to set
	 */
	public void setEmailCheck(final String emailCheck)
	{
		this.emailCheck = emailCheck;
	}


}
