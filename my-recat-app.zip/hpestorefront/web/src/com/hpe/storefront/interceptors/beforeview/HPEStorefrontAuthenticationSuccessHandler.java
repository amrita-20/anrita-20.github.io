/**
 *
 */
package com.hpe.storefront.interceptors.beforeview;


import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.security.StorefrontAuthenticationSuccessHandler;
import de.hybris.platform.core.Constants;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.util.Config;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;

import com.hpe.facades.order.HPECartFacade;
import com.hpe.hpepassport.constant.HPEPassportConstant;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.security.cookie.HPESessionCookieGenerator;
import com.hpe.storefront.security.cookie.HPEUserCartNotificationCookieGenerator;

/**
 * Success handler initializing user settings, restoring or merging the cart and ensuring the cart is handled correctly.
 * Cart restoration is stored in the session since the request coming in is that to j_spring_security_check and will be
 * redirected.
 */
public class HPEStorefrontAuthenticationSuccessHandler extends StorefrontAuthenticationSuccessHandler
{

	@Resource(name = "sessionService")
	private SessionService sessionService;
	@Resource(name = "userCartNotificationCookieGenerator")
	private HPEUserCartNotificationCookieGenerator userCartNotificationCookieGenerator;
	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;
	private static final Logger LOG = Logger.getLogger(StorefrontAuthenticationSuccessHandler.class);

	@Resource(name = "hpeSessionCookieGenerator")
	private HPESessionCookieGenerator hpeSessionCookieGenerator;

	@Override
	public void onAuthenticationSuccess(final HttpServletRequest request, final HttpServletResponse response,
			final Authentication authentication) throws IOException, ServletException
	{
		//if redirected from some specific url, need to remove the cachedRequest to force use defaultTargetUrl
		final RequestCache requestCache = new HttpSessionRequestCache();
		final SavedRequest savedRequest = requestCache.getRequest(request, response);
		final String productCode = sessionService.getAttribute("productCodePost");
		final String encodedContextPath = request.getContextPath();
		final String getQuoteFlag = sessionService.getAttribute("getQuoteFlag");

		String getQuoteUrl = "";
		if (getQuoteFlag != null && getQuoteFlag.equals(HPEStorefrontConstant.SINGLE_VARIANT))
		{
			getQuoteUrl = encodedContextPath + Config.getParameter(HPEStorefrontConstant.GET_QUOTE_URL) + productCode;
		}
		else
		{
			getQuoteUrl = encodedContextPath + Config.getParameter(HPEStorefrontConstant.CHANNELCENTRAL_GET_QUOTE_URL);
		}

		if (savedRequest != null)
		{
			for (final String redirectUrlForceDefaultTarget : getListRedirectUrlsForceDefaultTarget())
			{
				if (savedRequest.getRedirectUrl().contains(redirectUrlForceDefaultTarget))
				{
					requestCache.removeRequest(request, response);
					break;
				}
			}
		}
		if (productCode != null && savedRequest == null)
		{
			response.sendRedirect(getQuoteUrl);
		}
		if (sessionService.getAttribute("productCodePost") != null)
		{
			sessionService.removeAttribute("productCodePost");
		}
		getCustomerFacade().loginSuccess();
		setSessionCookies(request, response);

		request.setAttribute(WebConstants.CART_MERGED, Boolean.FALSE);

		// Check if the user is in role admingroup
		if (!isAdminAuthority(authentication))
		{
			getCartRestorationStrategy().restoreCart(request);
			userCartIndicatorCookie(request, response);
			getBruteForceAttackCounter().resetUserCounter(getCustomerFacade().getCurrentCustomerUid());
			getCustomerConsentDataStrategy().populateCustomerConsentDataInSession();
			super.onAuthenticationSuccess(request, response, authentication);
		}
		else
		{
			LOG.warn("Invalidating session for user in the " + Constants.USER.ADMIN_USERGROUP + " group");
			invalidateSession(request, response);
		}
	}

	private void userCartIndicatorCookie(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (hpeCartFacade.hasEntries())
		{
			userCartNotificationCookieGenerator.addCookie(request, response, Boolean.TRUE.toString());
		}
	}

	/* Setting HPP Response in Browser Cookie for SSO / Site Minder */
	private void setSessionCookies(final HttpServletRequest request, final HttpServletResponse response)
	{
		final Object session = JaloSession.getCurrentSession().getAttribute(HPEPassportConstant.SESSIONTOKEN);
		if (session != null)
		{
			final int startSessionToken = 17;
			String sesionValue = session.toString();
			sesionValue = sesionValue.substring(startSessionToken, sesionValue.length() - 2);

			try
			{
				hpeSessionCookieGenerator.addCookie(request, response, sesionValue);
			}
			catch (final Exception ex)
			{
				LOG.error("HPEStorefrontAuthenticationSuccessHandler:::setSessionCookies():::", ex);
			}
		}

	}
}

