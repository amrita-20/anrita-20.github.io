/**
 * HPESeoRobotsFollowBeforeViewHandler
 */
package com.hpe.storefront.interceptors.beforeview;

import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.interceptors.BeforeViewHandler;
import de.hybris.platform.util.Config;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;


public class HPESeoRobotsFollowBeforeViewHandler implements BeforeViewHandler
{

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorstorefrontcommons.interceptors.BeforeViewHandler#beforeView(javax.servlet.http.
	 * HttpServletRequest, javax.servlet.http.HttpServletResponse, org.springframework.web.servlet.ModelAndView)
	 */
	@Override
	public void beforeView(final HttpServletRequest request, final HttpServletResponse response, final ModelAndView modelAndView)
			throws Exception
	{
		// XXX Auto-generated method stub
		final String robotsValue = Config.getParameter("robots.content");
		modelAndView.addObject(ThirdPartyConstants.SeoRobots.META_ROBOTS, robotsValue);

		if (modelAndView.getModel().containsKey("metatags"))
		{
			final MetaElementData metaElement = new MetaElementData();
			metaElement.setName("robots");
			metaElement.setContent((String) modelAndView.getModel().get(ThirdPartyConstants.SeoRobots.META_ROBOTS));
			((List<MetaElementData>) modelAndView.getModel().get("metatags")).add(metaElement);

		}

	}
}
