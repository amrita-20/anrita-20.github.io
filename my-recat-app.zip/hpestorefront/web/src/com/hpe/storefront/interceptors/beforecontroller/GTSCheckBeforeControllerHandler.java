/**
 *
 */
package com.hpe.storefront.interceptors.beforecontroller;

import de.hybris.platform.acceleratorstorefrontcommons.interceptors.BeforeControllerHandler;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.util.Config;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.method.HandlerMethod;

import com.hpe.facades.user.HPEUserFacade;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * @author SR351338
 *
 */
public class GTSCheckBeforeControllerHandler implements BeforeControllerHandler
{

	private static final Logger LOG = Logger.getLogger(GTSCheckBeforeControllerHandler.class);
	private static final String GTS_SUCCESS = "SUCCESS";
	private static final String GTS_EXCEPTION = "EXCEPTION";
	private static final String GTS_FAILED = "FAILED";

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	private static final String GTS_IP_CHECK = "gts.ip.check";

	@Override
	public boolean beforeController(final HttpServletRequest request, final HttpServletResponse response,
			final HandlerMethod handler)
	{
		// XXX Auto-generated method stub
		boolean gtsResponse = false;
		final String gtsIPCheck = "gtsIPCheck";
		final String RemoteMachineIPAddress = "Remote machine IP Address: ";

		final String gtsIpCheck = Config.getString(GTS_IP_CHECK, "false");
		if ("true".equals(gtsIpCheck) && (JaloSession.getCurrentSession().getAttribute(gtsIPCheck) == null))
		{
			final String remoteAddress = hpeStorefrontUtil.remoteAddress(request);

			LOG.debug("***********checkIpCalled**************" + request.getAttribute("checkIpCalled"));
			LOG.debug("*********GTS service call for IP Check**********");
			LOG.debug(RemoteMachineIPAddress + remoteAddress);
			try
			{
				gtsResponse = hpeUserFacade.getGTSResponse(hpeStorefrontUtil.setGTSRequestData(null, null, remoteAddress));
			}
			catch (final Exception e)
			{
				LOG.error("GTSCheckBeforeControllerHandler:::beforeController:::gtsResponse ", e);
				JaloSession.getCurrentSession().setAttribute(gtsIPCheck, GTS_EXCEPTION);

				try
				{
					response.sendRedirect(request.getRequestURI());
					return true;
				}
				catch (final IOException e1)
				{
					LOG.debug(RemoteMachineIPAddress + e1);
				}
			}
			LOG.debug("gtsResponse true or false? " + gtsResponse);
			if (!gtsResponse)
			{
				JaloSession.getCurrentSession().setAttribute("gtsIPCheck", GTS_FAILED);
				LOG.debug("******gtsResponse value in GTSCheckBeforeControllerHandler********* " + gtsResponse);
				try
				{

					response.sendRedirect(request.getRequestURI());
					return true;

				}
				catch (final IOException e)
				{
					LOG.debug(RemoteMachineIPAddress + e);
				}
			}
			else
			{

				JaloSession.getCurrentSession().setAttribute(gtsIPCheck, GTS_SUCCESS);

			}
		}
		return true;
	}
}
