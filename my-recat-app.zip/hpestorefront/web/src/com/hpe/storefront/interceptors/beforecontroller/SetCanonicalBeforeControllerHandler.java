/*
 * This file is written for SEO Purpose
 */
package com.hpe.storefront.interceptors.beforecontroller;

import de.hybris.platform.acceleratorstorefrontcommons.interceptors.BeforeControllerHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.method.HandlerMethod;


/**
 * @author VI20053042
 *
 */
public class SetCanonicalBeforeControllerHandler implements BeforeControllerHandler
{

	@Override
	public boolean beforeController(final HttpServletRequest request, final HttpServletResponse response,
			final HandlerMethod handler) throws Exception
	{
		return true;
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}
}