/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorfacades.ordergridform.OrderGridFormFacade;
import de.hybris.platform.acceleratorfacades.product.data.ReadOnlyOrderGridData;
import de.hybris.platform.acceleratorservices.constants.GeneratedAcceleratorServicesConstants.Enumerations.ImportStatus;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.Breadcrumb;
import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.ResourceBreadcrumbBuilder;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractSearchPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.SaveCartForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.RestoreSaveCartFormValidator;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.SaveCartFormValidator;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.CartFacade;
import de.hybris.platform.commercefacades.order.SaveCartFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartParameterData;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartResultData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.impl.DefaultPriceDataFactory;
import de.hybris.platform.commerceservices.order.CommerceSaveCartException;
import de.hybris.platform.commerceservices.search.pagedata.PageableData;
import de.hybris.platform.commerceservices.search.pagedata.SearchPageData;
import de.hybris.platform.search.restriction.SearchRestrictionService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.storefront.address.form.HPERestoreSavedCartForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * Controller for saved carts page
 */
@Controller
@RequestMapping("/my-account/saved-carts")
public class HPEAccountSavedCartsPageController extends AbstractSearchPageController
{

	private static final Logger LOG = Logger.getLogger(HPEAccountSavedCartsPageController.class);

	private static int count = 0;

	@Resource(name = "accountBreadcrumbBuilder")
	private ResourceBreadcrumbBuilder accountBreadcrumbBuilder;

	@Resource(name = "saveCartFacade")
	private SaveCartFacade saveCartFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "orderGridFormFacade")
	private OrderGridFormFacade orderGridFormFacade;

	@Resource(name = "saveCartFormValidator")
	private SaveCartFormValidator saveCartFormValidator;

	@Resource(name = "cartFacade")
	private CartFacade cartFacade;

	@Resource(name = "restoreSaveCartFormValidator")
	private RestoreSaveCartFormValidator restoreSaveCartFormValidator;

	@Resource(name = "defaultPriceDataFactory")
	private DefaultPriceDataFactory defaultPriceDataFactory;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "searchRestrictionService")
	private SearchRestrictionService searchRestrictionService;



	@RequestMapping(method = RequestMethod.GET)
	@RequireHardLogIn
	public String savedCarts(@RequestParam(value = "page", defaultValue = "0") final int page,
			@RequestParam(value = "show", defaultValue = "Page") final ShowMode showMode,
			@RequestParam(value = "sort", required = false) final String sortCode, final Model model) throws CMSItemNotFoundException
	{
		// Handle paged search results
		final PageableData pageableData = createPageableDataJump(page, 4, sortCode, showMode);
		final SearchPageData<CartData> searchPageData = saveCartFacade.getSavedCartsForCurrentUser(pageableData, null);
		populateModel(model, searchPageData, showMode);

		model.addAttribute(HPEStorefrontConstant.REFRESH_SAVED_CART,
				getSiteConfigService().getBoolean(HPEStorefrontConstant.REFRESH_UPLOADING_SAVED_CART, false));
		model.addAttribute(HPEStorefrontConstant.REFRESH_SAVED_CART_INTERVAL,
				getSiteConfigService().getLong(HPEStorefrontConstant.REFRESH_UPLOADING_SAVED_CART_INTERVAL, 0));

		storeCmsPageInModel(model, getContentPageForLabelOrId(HPEStorefrontConstant.SAVED_CARTS_CMS_PAGE));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(HPEStorefrontConstant.SAVED_CARTS_CMS_PAGE));
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				accountBreadcrumbBuilder.getBreadcrumbs(HPEStorefrontConstant.TEXT_ACCOUNT_SAVED_CARTS));
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);

		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDetail = hpeAnalyticsUtil.getCartDataJsonObjectForAnalytics();
		model.addAttribute(HPEStorefrontConstant.MY_ACCOUNT_DETAIL, cartDetail);
		return getViewForPage(model);
	}

	@RequestMapping(value = "/" + HPEStorefrontConstant.SAVED_CART_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
	@RequireHardLogIn
	public String savedCart(@PathVariable("cartCode") final String cartCode, final Model model,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		String productCode = null;
		final List<OrderEntryData> configEntries = new ArrayList<>();
		final List<ProductOption> options = new ArrayList<>(
				Arrays.asList(ProductOption.BASIC, ProductOption.URL, ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE));

		try
		{
			final CommerceSaveCartParameterData parameter = new CommerceSaveCartParameterData();
			parameter.setCartId(cartCode);
			final CommerceSaveCartResultData resultData = saveCartFacade.getCartForCodeAndCurrentUser(parameter);
			final CartData cartData = resultData.getSavedCartData();
			PriceData priceData = new PriceData();
			BigDecimal totalPrice = BigDecimal.valueOf(0.0);
			for (final OrderEntryData entries : cartData.getEntries())
			{
				totalPrice = totalPrice.add(entries.getTotalPrice().getValue());
				final PriceDataType EntryPriceType = entries.getTotalPrice().getPriceType();
				final String currencyIso = entries.getTotalPrice().getCurrencyIso();
				priceData = defaultPriceDataFactory.create(EntryPriceType, totalPrice, currencyIso);
			}
			model.addAttribute(HPEStorefrontConstant.ENTRY_TOTAL_PRICE, priceData.getFormattedValue());

			// Code to populate BaseProduct Url to Product Name
			if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
			{
				for (final OrderEntryData entry : cartData.getEntries())
				{
					productCode = entry.getProduct().getCode();


					final ProductData productData = getProductData(productCode, options, model);
					getBaseProductData(options, productData, productCode, entry, configEntries);
				}
			}
			cartData.setConfigEntries(configEntries);
			if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
			{
				cartData.getEntries().removeAll(configEntries);
			}

			if (ImportStatus.PROCESSING.equals(cartData.getImportStatus()))
			{
				return HPEStorefrontConstant.REDIRECT_TO_SAVED_CARTS_PAGE;
			}
			if (ImportStatus.PROCESSING.equals(cartData.getImportStatus()))
			{
				return HPEStorefrontConstant.REDIRECT_TO_SAVED_CARTS_PAGE;
			}

			model.addAttribute(HPEStorefrontConstant.SAVED_CART_DATA, cartData);
			model.addAttribute(HPEStorefrontConstant.TOTAL_PRICE, totalPrice);

			final SaveCartForm saveCartForm = new SaveCartForm();
			saveCartForm.setDescription(cartData.getDescription());
			saveCartForm.setName(cartData.getName());
			model.addAttribute(HPEStorefrontConstant.SAVE_CART_FORM, saveCartForm);

			final List<Breadcrumb> breadcrumbs = accountBreadcrumbBuilder.getBreadcrumbs(null);
			breadcrumbs.add(new Breadcrumb(HPEStorefrontConstant.MY_ACCOUNT_SAVED_CARTS_URL, getMessageSource()
					.getMessage(HPEStorefrontConstant.TEXT_ACCOUNT_SAVED_CARTS, null, getI18nService().getCurrentLocale()), null));
			breadcrumbs
					.add(new Breadcrumb("#", getMessageSource()
							.getMessage(HPEStorefrontConstant.TEXT_ACCOUNT_SAVED_CART_SAVED_CART_BREADCRUMB, new Object[]
			{ cartData.getCode() }, "Saved Cart {0}", getI18nService().getCurrentLocale()), null));
			model.addAttribute(WebConstants.BREADCRUMBS_KEY, breadcrumbs);

			// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
			final JSONObject cartDetail = hpeAnalyticsUtil.getCartDataJsonObjectForAnalytics();
			model.addAttribute(HPEStorefrontConstant.MY_ACCOUNT_DETAIL, cartDetail);
		}
		catch (final CommerceSaveCartException e)
		{
			LOG.warn("Attempted to load a saved cart that does not exist or is not visible", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "system.error.page.not.found", null);
			return HPEStorefrontConstant.REDIRECT_TO_SAVED_CARTS_PAGE;
		}
		storeCmsPageInModel(model, getContentPageForLabelOrId(HPEStorefrontConstant.SAVED_CART_DETAILS_CMS_PAGE));
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(HPEStorefrontConstant.SAVED_CART_DETAILS_CMS_PAGE));
		return getViewForPage(model);
	}

	@RequestMapping(value = "/uploadingCarts", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	@RequireHardLogIn
	public List<CartData> getUploadingSavedCarts(@RequestParam("cartCodes") final List<String> cartCodes)
			throws CommerceSaveCartException
	{
		final List<CartData> result = new ArrayList<>();
		for (final String cartCode : cartCodes)
		{
			final CommerceSaveCartParameterData parameter = new CommerceSaveCartParameterData();
			parameter.setCartId(cartCode);

			final CommerceSaveCartResultData resultData = saveCartFacade.getCartForCodeAndCurrentUser(parameter);
			final CartData cartData = resultData.getSavedCartData();

			if (ImportStatus.COMPLETED.equals(cartData.getImportStatus()))
			{
				result.add(cartData);
			}
		}

		return result;
	}

	@RequestMapping(value = "/" + HPEStorefrontConstant.SAVED_CART_CODE_PATH_VARIABLE_PATTERN
			+ "/getReadOnlyProductVariantMatrix", method = RequestMethod.GET)
	@RequireHardLogIn
	public String getProductVariantMatrixForResponsive(@PathVariable("cartCode") final String cartCode,
			@RequestParam("productCode") final String productCode, final Model model, final RedirectAttributes redirectModel)
	{
		try
		{
			final CommerceSaveCartParameterData parameter = new CommerceSaveCartParameterData();
			parameter.setCartId(cartCode);

			final CommerceSaveCartResultData resultData = saveCartFacade.getCartForCodeAndCurrentUser(parameter);
			final CartData cartData = resultData.getSavedCartData();

			final Map<String, ReadOnlyOrderGridData> readOnlyMultiDMap = orderGridFormFacade.getReadOnlyOrderGridForProductInOrder(
					productCode, Arrays.asList(ProductOption.BASIC, ProductOption.CATEGORIES), cartData);
			model.addAttribute(HPEStorefrontConstant.READ_ONLY_MULTI_D_MAP, readOnlyMultiDMap);

			return ControllerConstants.Views.Fragments.Checkout.ReadOnlyExpandedOrderForm;
		}
		catch (final CommerceSaveCartException e)
		{
			LOG.warn("Attempted to load a saved cart that does not exist or is not visible", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "system.error.page.not.found", null);
			return HPEStorefrontConstant.REDIRECT_TO_SAVED_CARTS_PAGE + "/" + cartCode;
		}
	}

	@RequestMapping(value = "/" + HPEStorefrontConstant.SAVED_CART_CODE_PATH_VARIABLE_PATTERN
			+ "/edit", method = RequestMethod.POST)
	@RequireHardLogIn
	public String savedCartEdit(@PathVariable("cartCode") final String cartCode, final SaveCartForm form,
			final BindingResult bindingResult, final RedirectAttributes redirectModel) throws CommerceSaveCartException
	{
		saveCartFormValidator.validate(form, bindingResult);
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, error.getCode());
			}
			redirectModel.addFlashAttribute(HPEStorefrontConstant.SAVE_CART_FORM, form);
		}
		else
		{
			final CommerceSaveCartParameterData commerceSaveCartParameterData = new CommerceSaveCartParameterData();
			commerceSaveCartParameterData.setCartId(cartCode);
			commerceSaveCartParameterData.setName(form.getName());
			commerceSaveCartParameterData.setDescription(form.getDescription());
			commerceSaveCartParameterData.setEnableHooks(false);
			hpeStorefrontUtil.getSavedCart(form, bindingResult, redirectModel, commerceSaveCartParameterData);
		}
		return HPEStorefrontConstant.REDIRECT_TO_SAVED_CARTS_PAGE + "/" + cartCode;
	}

	@RequestMapping(value = "/{cartId}/restore", method = RequestMethod.GET)
	@RequireHardLogIn
	public String restoreSaveCartForId(@PathVariable(value = "cartId") final String cartId, final Model model,
			final RedirectAttributes redirectAttributes) throws CommerceSaveCartException
	{
		final CommerceSaveCartParameterData parameters = new CommerceSaveCartParameterData();
		parameters.setCartId(cartId);
		final CommerceSaveCartResultData commerceSaveCartResultData = saveCartFacade.getCartForCodeAndCurrentUser(parameters);
		final boolean hasSessionCart = cartFacade.hasEntries();
		model.addAttribute(HPEStorefrontConstant.HAS_SESSION_CART, hasSessionCart);
		if (hasSessionCart)
		{
			model.addAttribute(HPEStorefrontConstant.AUTO_GENERATED_NAME, System.currentTimeMillis());
		}
		else
		{
			final CommerceSaveCartParameterData commerceSaveCartParameterData = new CommerceSaveCartParameterData();
			commerceSaveCartParameterData.setCartId(cartId);
			commerceSaveCartParameterData.setEnableHooks(true);
			saveCartFacade.cloneSavedCart(commerceSaveCartParameterData);
			saveCartFacade.restoreSavedCart(commerceSaveCartParameterData);
			model.addAttribute(HPEStorefrontConstant.CART, HPEStorefrontConstant.CART);
		}
		model.addAttribute(commerceSaveCartResultData);
		return ControllerConstants.Views.Fragments.Account.SavedCartRestorePopup;
	}

	@RequireHardLogIn
	@RequestMapping(value = "/{cartId}/restore", method = RequestMethod.POST)
	public @ResponseBody String postRestoreSaveCartForId(@PathVariable(value = "cartId") final String cartId,
			final HPERestoreSavedCartForm restoreSaveCartForm, final BindingResult bindingResult) throws CommerceSaveCartException
	{
		try
		{
			restoreSaveCartFormValidator.validate(restoreSaveCartForm, bindingResult);
			if (bindingResult.hasErrors())
			{
				return getMessageSource().getMessage(bindingResult.getFieldError().getCode(), null,
						getI18nService().getCurrentLocale());
			}

			if (restoreSaveCartForm.getCartName() != null && !restoreSaveCartForm.isPreventSaveActiveCart()
					&& cartFacade.hasEntries())
			{
				final CommerceSaveCartParameterData commerceSaveActiveCart = new CommerceSaveCartParameterData();
				commerceSaveActiveCart.setCartId(cartFacade.getSessionCart().getCode());
				commerceSaveActiveCart.setName(restoreSaveCartForm.getCartName());
				commerceSaveActiveCart.setDescription(restoreSaveCartForm.getDescription());
				commerceSaveActiveCart.setEnableHooks(true);
				saveCartFacade.saveCart(commerceSaveActiveCart);
			}

			final CommerceSaveCartParameterData commerceSaveCartParameterData = new CommerceSaveCartParameterData();
			commerceSaveCartParameterData.setCartId(cartId);
			commerceSaveCartParameterData.setEnableHooks(true);
			if (restoreSaveCartForm.isKeepRestoredCart())
			{
				saveCartFacade.cloneSavedCart(commerceSaveCartParameterData);
			}
			saveCartFacade.restoreSavedCart(commerceSaveCartParameterData);
		}
		catch (final CommerceSaveCartException ex)
		{
			LOG.error("Error while restoring the cart for cartId " + cartId + " because of " + ex);
			return getMessageSource().getMessage("text.restore.savedcart.error", null, getI18nService().getCurrentLocale());
		}
		return String.valueOf(HttpStatus.OK);
	}

	@RequestMapping(value = "/{cartId}/delete", method = RequestMethod.DELETE)
	@ResponseStatus(value = HttpStatus.OK)
	@RequireHardLogIn
	public @ResponseBody String deleteSaveCartForId(@PathVariable(value = "cartId") final String cartId)
			throws CommerceSaveCartException
	{
		try
		{
			final CommerceSaveCartParameterData parameters = new CommerceSaveCartParameterData();
			parameters.setCartId(cartId);
			saveCartFacade.flagForDeletion(cartId);
		}
		catch (final CommerceSaveCartException ex)
		{
			LOG.error("Error while deleting the saved cart with cartId " + cartId + " because of " + ex);
			return getMessageSource().getMessage("text.delete.savedcart.error", null, getI18nService().getCurrentLocale());
		}
		return String.valueOf(HttpStatus.OK);
	}

	@RequestMapping(value = "/multiDeleteCart", method = RequestMethod.GET)
	public String multiDeleteGet(final Model model, final HttpServletRequest request) throws CMSItemNotFoundException
	{
		return ControllerConstants.Views.Pages.MultiDelete.MultiDeletePage;
	}

	@RequestMapping(value = "/multiIdDeleteCart", method = RequestMethod.POST)
	@ResponseStatus(value = HttpStatus.OK)
	@RequireHardLogIn
	public @ResponseBody String deleteMoreThanOneSaveCartForId(@RequestParam(value = "selectedCart") final String cartIdString)
			throws CommerceSaveCartException
	{
		final String cartIdList[] = cartIdString.split(",");

		for (final String cartId : cartIdList)
		{

			try
			{
				final CommerceSaveCartParameterData parameters = new CommerceSaveCartParameterData();
				parameters.setCartId(cartId);
				saveCartFacade.flagForDeletion(cartId);
			}
			catch (final CommerceSaveCartException ex)
			{
				LOG.error("Error while deleting the saved cart with cartId " + cartId + " because of " + ex);
				return getMessageSource().getMessage("text.delete.savedcart.error", null, getI18nService().getCurrentLocale());
			}

		}
		return String.valueOf(HttpStatus.OK);
	}

	public ProductData getProductData(final String productCode, final List<ProductOption> options,final Model model)
	{
		try
		{
			return productFacade.getProductForCodeAndOptions(productCode, options);
		}
		catch (final UnknownIdentifierException e)
		{
			LOG.warn("Product Not found with product code [" + productCode + "]");
			searchRestrictionService.disableSearchRestrictions();
			final ProductData product = productFacade.getProductForCodeAndOptions(productCode, options);
			searchRestrictionService.enableSearchRestrictions();
			model.addAttribute(HPEStorefrontConstant.IS_PRODUCT_AVAILABLE, false);
			GlobalMessages.addMessage(model, GlobalMessages.INFO_MESSAGES_HOLDER, "hpestorefront.savedcart.message",
					new Object[]
					{ product.getName() });


		}
		return null;

	}

	public void getBaseProductData(final List<ProductOption> options, final ProductData productData, final String productCode, final OrderEntryData entry,
			final List<OrderEntryData> configEntries)
	{
		ProductData baseProductData = null;
		if (null != productData && null != productData.getBaseProduct())
		{
			try
			{
				baseProductData = productFacade.getProductForCodeAndOptions(productData.getBaseProduct(), options);
				productData.setBaseProductUrl(baseProductData.getUrl());
			}
			catch (final UnknownIdentifierException e)
			{
				LOG.warn("Product Not found with product code [" + productCode + "]");
			}
		}
		if (null != productData && null != productData.getBaseProduct() && null != entry.getConfigID()
				&& entry.getIsStarterProduct())
		{
			productData.setBaseProductUrl(baseProductData == null ? null : baseProductData.getUrl());
		}
		entry.setProduct(productData);

		if (StringUtils.isNotEmpty(entry.getConfigID()))
		{
			configEntries.add(entry);
		}
	}
		protected PageableData createPageableDataJump(final int pageNumber, final int pageSize, final String sortCode,
			final ShowMode showMode)
	{

		final PageableData pageableData = new PageableData();
		if (count == 0)
		{
			pageableData.setCurrentPage(pageNumber);
		}
		else if (pageNumber == 0 && count > 0)
		{
			pageableData.setCurrentPage(pageNumber);
		}
		else
		{
			pageableData.setCurrentPage(pageNumber - 1);
		}


		count++; //NOSONAR

		pageableData.setSort(sortCode);

		if (ShowMode.All == showMode)
		{
			pageableData.setPageSize(MAX_PAGE_LIMIT);
		}
		else
		{
			pageableData.setPageSize(pageSize);
		}
		return pageableData;
	}
}

