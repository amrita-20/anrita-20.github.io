/**
*
*/
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.HPECategoryPageBannerComponentModel;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;


/**
 * @author NA20006812
 *
 */
@Controller("HPECategoryPageBannerComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.HPECategoryPageBannerComponent)
public class HPECategoryPageBannerComponentController extends AbstractCMSComponentController<HPECategoryPageBannerComponentModel>
{


	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final HPECategoryPageBannerComponentModel component)
	{
		model.addAttribute(HPEStorefrontConstant.MEDIA, component.getMedia());
		model.addAttribute(HPEStorefrontConstant.URL_LINK, component.getUrlLink());
		model.addAttribute(HPEStorefrontConstant.CONTENT, component.getContent());
	}

	@Override
	protected String getView(final HPECategoryPageBannerComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(HPECategoryPageBannerComponentModel._TYPECODE);

	}

}
