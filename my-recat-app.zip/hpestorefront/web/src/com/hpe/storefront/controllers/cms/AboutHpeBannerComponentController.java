/*
*AboutHpeBannerComponentController
*/
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.AboutHpeBannerComponentModel;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 *
 *
 */
@Controller("AboutHpeBannerComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.AboutHpeBannerComponent)
public class AboutHpeBannerComponentController extends AbstractCMSComponentController<AboutHpeBannerComponentModel>
{
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model, final AboutHpeBannerComponentModel component)
	{
		model.addAttribute("media", component.getMedia());
		model.addAttribute("urlLink", component.getUrlLink());
		model.addAttribute("content", component.getContent());
	}

	@Override
	protected String getView(final AboutHpeBannerComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(AboutHpeBannerComponentModel._TYPECODE);

	}

}
