/**
 * @author Suneetha Nandhimandalam
 *
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.multicountry.facades.storesession.impl.MulticountryStoreSessionFacade;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.hpe.constants.HPEIntegrationsConstant;
import com.hpe.facades.country.HPECountryFacade;
import com.hpe.facades.storesession.moxie.data.HPEMoxieLiveChatData;
import com.hpe.storefront.controllers.HPEStorefrontConstant;


/**
 * Controller for home page
 */

public class HPEAbstractPageController extends AbstractPageController
{

	@Resource(name = "storeSessionFacade")
	private MulticountryStoreSessionFacade multicountryStoreSessionFacade;

	@Resource(name = "hpeCountryFacade")
	private HPECountryFacade hpeCountryFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	/**
	 * This method returns HPEMoxieLiveChatData which contains DetectionId,QueueId and TalCustProp based on country.
	 *
	 * @param model
	 * @return HPEMoxieLiveChatData
	 */
	@ModelAttribute(HPEStorefrontConstant.MOXIE)
	public HPEMoxieLiveChatData getMoxieLiveChat(final HttpServletRequest request, final Model model)
	{
		final HPEMoxieLiveChatData moxieData = multicountryStoreSessionFacade.getMoxieLiveChat();
		final String moxieLiveChatUrl = configurationService.getConfiguration()
				.getString(HPEIntegrationsConstant.Moxie_LiveChat_Url);
		model.addAttribute(HPEStorefrontConstant.MOXIE, moxieData);
		model.addAttribute(HPEStorefrontConstant.MOXIE_BASE_URL, moxieLiveChatUrl);

		final HttpSession httpSession = request.getSession();
		httpSession.setAttribute("moxieData", moxieData);
		httpSession.setAttribute("moxieLiveChatUrl", moxieLiveChatUrl);

		return moxieData;
	}


	/**
	 * @return the hpeCountryFacade
	 */
	public HPECountryFacade getHpeCountryFacade()
	{
		return hpeCountryFacade;
	}

	/**
	 * @param hpeCountryFacade
	 *           the hpeCountryFacade to set
	 */
	public void setHpeCountryFacade(final HPECountryFacade hpeCountryFacade)
	{
		this.hpeCountryFacade = hpeCountryFacade;
	}


	/**
	 * @return the multicountryStoreSessionFacade
	 */
	public MulticountryStoreSessionFacade getMulticountryStoreSessionFacade()
	{
		return multicountryStoreSessionFacade;
	}

	/**
	 * @param multicountryStoreSessionFacade
	 *           the multicountryStoreSessionFacade to set
	 */
	public void setMulticountryStoreSessionFacade(final MulticountryStoreSessionFacade multicountryStoreSessionFacade)
	{
		this.multicountryStoreSessionFacade = multicountryStoreSessionFacade;
	}


}
