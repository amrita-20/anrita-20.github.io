/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractSearchPageController.ShowMode;
import de.hybris.platform.core.servicelayer.data.PaginationData;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.OrderDetailsComponentModel;
import com.hpe.facades.order.HPEOrderFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEStorefrontUtil;


@Controller("OrderDetailsComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.OrderDetailsComponent)
public class OrderDetailsComponentController extends AbstractAcceleratorCMSComponentController<OrderDetailsComponentModel>
{

	@Resource(name = "hpeOrderFacade")
	private HPEOrderFacade hpeOrderFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	/**
	 * This method returns orders placed by the logged in user.
	 *
	 * @param model
	 */
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model, final OrderDetailsComponentModel component)
	{

		final PaginationData createPageableData = hpeStorefrontUtil.createPaginationData(HPEStorefrontConstant.PAGE_ZERO,
				configurationService.getConfiguration().getInt(HPEStorefrontConstant.ORDERS_PAGE_SIZE, 3), ShowMode.Page);
		model.addAttribute(HPEStorefrontConstant.ORDERS_SEARCH_PAGE_DATA,
				hpeOrderFacade.getPagedOrderHistoryWithStatuses(createPageableData));
		final Map<String, Integer> filtersForOrder = hpeOrderFacade.getFiltersForOrder();
		final Integer allOrders = filtersForOrder.get(HPEStorefrontConstant.ALL_ORDERS);
		filtersForOrder.remove(HPEStorefrontConstant.ALL_ORDERS);
		model.addAttribute(HPEStorefrontConstant.FILTERS, filtersForOrder);
		model.addAttribute(HPEStorefrontConstant.COUNT, allOrders);
	}



	@Override
	protected String getView(final OrderDetailsComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(OrderDetailsComponentModel._TYPECODE);
	}

}