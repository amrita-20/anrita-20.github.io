/**
 *
 */
package com.hpe.storefront.controllers.occ;

import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.net.MalformedURLException;
import java.net.URL;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.hpe.storefront.security.cookie.CartRestoreCookieGenerator;


/**
 * @author chenna
 *
 */
public class HPEDefaultOccController
{
	private static final Logger LOG = Logger.getLogger(HPEDefaultOccController.class);
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN_VALUE = "*";
	private static final String TOP_DOMAINS = "topDomains";
	private static final String HEADER_REFERER = "Referer";
	@Resource(name = "cartRestoreCookieGenerator")
	private CartRestoreCookieGenerator cartRestoreCookieGenerator;
	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	/**
	 * This method returns guid for anonymous user
	 */
	protected String getAnonymousGuid(final HttpServletRequest request)
	{
		if (request.getCookies() == null)
		{
			return null;
		}

		final String anonymousCartCookieName = cartRestoreCookieGenerator.getCookieName();

		for (final Cookie cookie : request.getCookies())
		{
			if (anonymousCartCookieName.equals(cookie.getName()))
			{
				return cookie.getValue();
			}
		}
		return null;
	}

	/**
	 * This method returns access control allow origin value based on the referer header
	 */
	protected String getAccessControlAllowOrigin(final HttpServletRequest request)
	{
		final String refererUrl = request.getHeader(HEADER_REFERER);
		if (refererUrl == null)
		{
			return ACCESS_CONTROL_ALLOW_ORIGIN_VALUE;
		}

		final URL url = getUrl(refererUrl);
		if (url == null)
		{
			return ACCESS_CONTROL_ALLOW_ORIGIN_VALUE;
		}

		final String topDomains = configurationService.getConfiguration().getString(TOP_DOMAINS);
		final String topDomain = getTopDomainName(url.getHost());
		if (topDomains != null && topDomains.contains(topDomain))
		{
			return url.getProtocol() + "://" + url.getHost();
		}
		return ACCESS_CONTROL_ALLOW_ORIGIN_VALUE;
	}

	private URL getUrl(final String refererUrl)
	{
		URL url = null;
		try
		{
			url = new URL(refererUrl);
		}
		catch (final MalformedURLException ex)
		{
			LOG.error("Error during converting String to URL:", ex);
		}
		return url;
	}

	/**
	 * get top domain from request server name example - itg.buy.hpe.com --> returns hpe.com
	 */
	private String getTopDomainName(final String serverName)
	{
		if (serverName.matches(".*[a-zA-Z].*") && serverName.indexOf('.') >= 0)
		{
			return serverName.replaceAll(".*\\.(?=.*\\.)", "");
		}
		return serverName;
	}
}
