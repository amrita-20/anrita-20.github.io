/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.c2l.LanguageModel;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.HPECategoryPageParagraphComponentModel;
import com.hpe.facades.category.HPECategory;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;


/**
 * @author NA20006812
 *
 */

@Controller("HPECategoryPageParagraphComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.HPECategoryPageParagraphComponent)
public class HPECategoryPageParagraphComponentController
		extends AbstractCMSComponentController<HPECategoryPageParagraphComponentModel>
{
	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;

	@Resource(name = "hpeCategory")
	private HPECategory hpeCategory;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final HPECategoryPageParagraphComponentModel component)
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
		final LanguageModel currentLanguage = hpeCategory.getCurrentLanguage();
		model.addAttribute(HPEStorefrontConstant.CONTENT, component.getContent());
		model.addAttribute(HPEStorefrontConstant.HEADLINE, component.getHeadline());
		model.addAttribute(HPEStorefrontConstant.LINKNAME1, component.getLinkName1());
		model.addAttribute(HPEStorefrontConstant.LINKNAME2, component.getLinkName2());
		if (component.getLink1() != null)
		{
			if (component.getLink1().contains("http"))
			{
				model.addAttribute(HPEStorefrontConstant.LINK1, component.getLink1());
			}
			else
			{
				model.addAttribute(HPEStorefrontConstant.LINK1,
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getLink1());
			}
		}
		else
		{
			model.addAttribute(HPEStorefrontConstant.LINK1,
					"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}

		if (component.getLink2() != null)
		{
			if (component.getLink2().contains("http"))
			{
				model.addAttribute(HPEStorefrontConstant.LINK2, component.getLink2());
			}
			else
			{
				model.addAttribute(HPEStorefrontConstant.LINK2,
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getLink2());
			}
		}
		else
		{
			model.addAttribute(HPEStorefrontConstant.LINK2,
					"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}
	}

	@Override
	protected String getView(final HPECategoryPageParagraphComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(HPECategoryPageParagraphComponentModel._TYPECODE);

	}
}

