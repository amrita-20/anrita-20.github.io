/**
 *
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractRegisterPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.GuestForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.LoginForm;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.registration.HPECustomerFacade;
import com.hpe.facades.registration.data.HPERegisterData;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * New HPEAbstractRegisterPageController Overriding the OOTB Flow
 *
 * @author Nandhini Marimuthu
 * @version 1.0
 */
public class HPEAbstractRegisterPageController extends AbstractRegisterPageController
{

	private static final Logger LOGGER = Logger.getLogger(HPEAbstractRegisterPageController.class);

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "hpeCustomerFacade")
	private HPECustomerFacade hpeCustomerFacade;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;


	protected String processRegisterUserRequest(final String referer, final HPERegisterForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		if (bindingResult.hasErrors())
		{
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return handleRegistrationError(model);
		}

		HPERegisterData data = new HPERegisterData();
		data = hpeStorefrontUtil.convertToHPERegisterData(data, form);

		try
		{
			getHpeCustomerFacade().register(data);

			getAutoLoginStrategy().login(form.getEmail().toLowerCase(), form.getPwd(), request, response);
			hpeStorefrontUtil.setDefaultAddress();
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
					HPEStorefrontConstant.REG_CONFIRMATION);
		}
		catch (final DuplicateUidException e)
		{
			LOGGER.warn("registration failed: ", e);
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			bindingResult.rejectValue(HPEStorefrontConstant.EMAIL, HPEStorefrontConstant.REG_ACCOUNT_EXISTS_ERROR);
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return handleRegistrationError(model);
		}

		// Consent form data
		try
		{
			final ConsentForm consentForm = form.getConsentForm();
			if (consentForm != null && consentForm.getConsentGiven())
			{
				getConsentFacade().giveConsent(consentForm.getConsentTemplateId(), consentForm.getConsentTemplateVersion());
			}
		}
		catch (final Exception e)
		{
			LOGGER.error(
					"HPEAbstractRegisterPageController::processUserRegisterRequest::Error occurred while creating consents during registration",
					e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					HPEStorefrontConstant.CONSENT_FORM_GLOBAL_ERROR);
		}

		// save anonymous-consent cookies as ConsentData
		hpeStorefrontUtil.saveAnonymousConsentCookiesAsConsentData(request);

		customerConsentDataStrategy.populateCustomerConsentDataInSession();

		return REDIRECT_PREFIX + getSuccessRedirect(request, response);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractRegisterPageController#getCmsPage()
	 */
	@Override
	protected AbstractPageModel getCmsPage() throws CMSItemNotFoundException
	{
		// XXX Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractRegisterPageController#
	 * getSuccessRedirect(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response)
	{
		// XXX Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractRegisterPageController#getView()
	 */
	@Override
	protected String getView()
	{
		// XXX Auto-generated method stub
		return null;
	}

	/**
	 * @return the hpeCustomerFacade
	 */
	public HPECustomerFacade getHpeCustomerFacade()
	{
		return hpeCustomerFacade;
	}

	/**
	 * @param hpeCustomerFacade
	 *           the hpeCustomerFacade to set
	 */
	public void setHpeCustomerFacade(final HPECustomerFacade hpeCustomerFacade)
	{
		this.hpeCustomerFacade = hpeCustomerFacade;
	}

}
