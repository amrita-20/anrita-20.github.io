/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractSearchPageController.ShowMode;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.quote.data.QuoteData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.core.servicelayer.data.PaginationData;
import de.hybris.platform.core.servicelayer.data.SearchPageData;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.MyAccountQuoteDetailsComponentModel;
import com.hpe.facades.quote.HPEEloquaFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * @author SU40002511
 *
 */
@Controller("MyAccountQuoteDetailsComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.MyAccountQuoteDetailsComponent)
public class MyAccountQuoteDetailsComponentController
		extends AbstractAcceleratorCMSComponentController<MyAccountQuoteDetailsComponentModel>
{

	@Resource(name = "customerFacade")
	private CustomerFacade customerFacade;

	@Resource(name = "hpeEloquaFacade")
	private HPEEloquaFacade hpeEloquaFacade;


	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;


	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final MyAccountQuoteDetailsComponentModel component)
	{

		final CustomerData currentUser = customerFacade.getCurrentCustomer();
		final String emailAddress = currentUser.getDisplayUid();
		final PaginationData pageableData = hpeStorefrontUtil.createPaginationData(HPEStorefrontConstant.PAGE_ZERO, 5,
				ShowMode.Page);
		final SearchPageData<QuoteData> quoteData = hpeEloquaFacade.getHPEEloquaListforCustomer(emailAddress, pageableData);
		model.addAttribute(HPEStorefrontConstant.QUOTES_SEARCH_PAGE_DATA, quoteData);
	}


	@Override
	protected String getView(final MyAccountQuoteDetailsComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(MyAccountQuoteDetailsComponentModel._TYPECODE);
	}



}
