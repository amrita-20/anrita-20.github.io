/* [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commercefacades.user.data.RegionData;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.store.services.BaseStoreService;
import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hpe.facades.addressdoctor.HPEAddressDoctorIntegrationFacade;
import com.hpe.facades.country.HPECountryFacade;
import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.region.HPERegionFacade;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.facades.util.GTSRequestData;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * Register Controller for mobile. Handles login and register for the account flow.
 */
@Controller
@RequestMapping(value = "/register")
public class HPERegisterPageController extends HPEAbstractRegisterPageController
{
	private static final Logger LOG = Logger.getLogger(HPERegisterPageController.class);
	private static final String TRUE_CONSTANT = "true";
	private static final String GTS_GEOLOCATION_CHECK = "gts.geolocation.check";

	private HttpSessionRequestCache httpSessionRequestCache;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;

	@Resource(name = "hpeAddressDoctorIntegrationFacade")
	private HPEAddressDoctorIntegrationFacade hpeAddressDoctorIntegrationFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;
	
	@Resource
	private MessageSource messageSource;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "baseStoreService")
	private BaseStoreService baseStoreService;

	@Resource(name = "hpeCountryFacade")
	private HPECountryFacade hpeCountryFacade;

	@Resource(name = "hpeRegionFacade")
	private HPERegionFacade hpeRegionFacade;

	@Override
	protected AbstractPageModel getCmsPage() throws CMSItemNotFoundException
	{
		return getContentPageForLabelOrId("register");
	}

	@Override
	protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (httpSessionRequestCache.getRequest(request, response) != null)
		{
			return httpSessionRequestCache.getRequest(request, response).getRedirectUrl();
		}
		return "/";
	}

	@Override
	protected String getView()
	{
		return ControllerConstants.Views.Pages.Account.AccountRegisterPage;
	}

	@Resource(name = "httpSessionRequestCache")
	public void setHttpSessionRequestCache(final HttpSessionRequestCache accHttpSessionRequestCache)
	{
		this.httpSessionRequestCache = accHttpSessionRequestCache;
	}

	/**
	 * Method for displaying country code and list of region code while returning to register page.
	 *
	 * @param model
	 * @return model
	 *
	 **/

	@RequestMapping(method = RequestMethod.GET)
	public String doRegister(Model model) throws CMSItemNotFoundException
	{

		final String countryCode = hpeStorefrontUtil.getCountryCode();
		final List<CountryData> countryList = hpeCountryFacade.findCountriesByCode(countryCode);
		final List<RegionData> finalRegionList = hpeRegionFacade.findRegionforCountry(countryCode);
		finalRegionList.sort(Comparator.comparing(RegionData::getIsocodeShort));
		model = hpeStorefrontUtil.countryListGenerate(model); //NOSONAR
		model.addAttribute(HPEStorefrontConstant.COUNTRY_LIST, countryList);
		model.addAttribute(HPEStorefrontConstant.REGION_LIST, finalRegionList);
		model.addAttribute(HPEStorefrontConstant.ELOQUA,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADDRESS));
		model.addAttribute(HPEStorefrontConstant.ELOQUAREGISTRATIONFORMNAME,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_REGISTER_FORMNAME));
		model.addAttribute(HPEStorefrontConstant.ELOQUASITEID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_SITEID));

		model.addAttribute(HPEStorefrontConstant.ELOQUAAPRIMOACTIVITYID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1));
		model.addAttribute(HPEStorefrontConstant.ELOQUARESPONSETYPE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_RESPONSE_TYPE1));
		model.addAttribute(HPEStorefrontConstant.ELOQUALEADSOURCE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_LEAD_SOURCE___MOST_RECENT1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_ID1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMCLEANEDSTATUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_CLEANED_STATUS1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAFORMSOURCE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_FORM_SOURCE1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAPRIVACYCHANGE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_SOURCE));
		model.addAttribute(HPEStorefrontConstant.ELOQUAMKPCARTSTATUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_MKP_CART_STATUS));
		model.addAttribute(HPEStorefrontConstant.ELOQUAMETHODOPTIN,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_METHOD_OPT_IN));
		model.addAttribute(HPEStorefrontConstant.ELOQUACOOKIEWRITE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_COOKIE_WRITE));
		model.addAttribute(HPEStorefrontConstant.REGISTER, new HPERegisterForm());
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);
		return getDefaultRegistrationPage(model);
	}

	/**
	 * Address Doctor Integration- Method to Get the Address Suggestions from Address Doctor
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return
	 * @throws CMSItemNotFoundException
	 * @throws IOException
	 */
	@RequestMapping(value = "/addressVerification", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String addressDoctor(@ModelAttribute(HPEStorefrontConstant.REGISTER)
	final HPERegisterForm form, final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel) throws CMSItemNotFoundException, IOException
	{
		final HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm.setCountryCode(form.getCountryCode());
		hpeRegisterInputForm.setAddress1(form.getAddress1());
		hpeRegisterInputForm.setAddress2(form.getAddress2());
		hpeRegisterInputForm.setCity(form.getCity());
		hpeRegisterInputForm.setStateCode(form.getStateCode());
		hpeRegisterInputForm.setZipCode(form.getZipCode());
		JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.HPEREGISTERFORM, form);
		//Address Doctor Integration Response
		final String addressDoctorResponse = hpeAddressDoctorIntegrationFacade.hpeAddressDoctorIntegration(hpeRegisterInputForm,
				model);
		if (addressDoctorResponse != null)
		{
			return addressDoctorResponse;
		}
		else
		{
			if (LOG.isDebugEnabled())
			{
				LOG.debug("RegisterPageController...addressDoctor()..Address Doctor Response is Null");
			}
		}
		return addressDoctorResponse;
	}

	/**
	 * Register New User to hpestorefront usingn HPE Passport
	 *
	 * @param bindingResult
	 * @param form
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return redirect to homepage on success.
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 * @exception JsonGenerationException,JsonMappingException,IOException,CMSItemNotFoundException
	 *
	 */
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public ResponseEntity<String> registerUser(@ModelAttribute(HPEStorefrontConstant.REGISTER)
	final HPERegisterForm form, final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel)
	{
		final ObjectMapper mapper = new ObjectMapper();
		final HPERegisterInputForm hpeRegisterInputForm = buildHPERegisterInputForm(form);
		ResponseEntity<String> hpeRegistrationData = null;
		final HPERegisterForm hperegistrationform = (HPERegisterForm) JaloSession.getCurrentSession()
				.getAttribute(HPEStorefrontConstant.HPEREGISTERFORM);
		hperegistrationform.setZipCode(form.getZipCode());
		JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.HPEREGISTERFORM, hperegistrationform);
		final Map<String, String> map = new HashMap();
		String gTsString = null;


		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, "false");

		if (TRUE_CONSTANT.equals(gtsGeoLocationCheck))
		{
			LOG.debug("******GTS call for shipping address check*******");

			final GTSRequestData gtsRequestData = hpeStorefrontUtil.setGTSRequestData(form);
			boolean gtsResponse = Boolean.FALSE;
			try
			{
				JaloSession.getCurrentSession().setAttribute("gtsCheck", Boolean.TRUE);
				gtsResponse = hpeUserFacade.getGTSResponse(gtsRequestData);
			}
			catch (final Exception e)
			{
				map.put(HPEStorefrontConstant.GTS_ERROR, messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING_EXCEPTION,
						null, getI18nService().getCurrentLocale()));
				gTsString = getGTSError(mapper, map);
				LOG.error("HPERegisterPageController:::registerUser:::gtsResponse ", e);
				JaloSession.getCurrentSession().removeAttribute("gtsCheck");
				return new ResponseEntity(gTsString, HttpStatus.BAD_REQUEST);
			}

			LOG.debug("******GTS Response in DeliveryAddressCheckoutStepController*******" + gtsResponse);

			if (!gtsResponse)
			{
				map.put(HPEStorefrontConstant.GTS_ERROR,
						messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING, null, getI18nService().getCurrentLocale()));
				gTsString = getGTSError(mapper, map);
				JaloSession.getCurrentSession().removeAttribute("gtsCheck");
				return new ResponseEntity(gTsString, HttpStatus.BAD_REQUEST);
			}
			else
			{
				form.setPartnerNumber(gtsRequestData.getExpPartNum());

			}
		}
		try
		{
			hpeRegistrationData = hpePassportIntegrationFacade.hpeRegisterUser(hpeRegisterInputForm);

			if (hpeRegistrationData != null && hpeRegistrationData.getBody() != null)
			{
				if (hpeRegistrationData.getStatusCode() == HttpStatus.OK
						&& hpeRegistrationData.getBody().contains(HPEStorefrontConstant.PROFILE_IDENTITY))
				{
					processRegisterUserRequest(null, form, bindingResult, model, request, response, redirectModel);
					return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.BAD_REQUEST);
				}
			}
		}
		catch (final Exception ex)
		{
			LOG.error("Error during HPERegisterPageController - registerUser", ex);
		}
		return new ResponseEntity<>("Invalid Username or Password", HttpStatus.BAD_REQUEST);
	}

	/**
	 * @return the baseStoreService
	 */
	public BaseStoreService getBaseStoreService()
	{
		return baseStoreService;
	}

	/**
	 * @param baseStoreService
	 *           the baseStoreService to set
	 */
	public void setBaseStoreService(final BaseStoreService baseStoreService)
	{
		this.baseStoreService = baseStoreService;
	}

	private String getGTSError(final ObjectMapper mapper, final Map<String, String> map)
	{
		try
		{
			return mapper.writeValueAsString(map);
		}
		catch (final Exception ex)
		{
			LOG.error("Error during HPERegisterPageController - getGTSError", ex);
		}
		return null;
	}

	private HPERegisterInputForm buildHPERegisterInputForm(final HPERegisterForm form)
	{
		final HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm.setConfirmPassword(form.getCheckPwd());
		hpeRegisterInputForm.setEmailAddress(form.getEmail());
		hpeRegisterInputForm.setFirstName(form.getFirstName());
		hpeRegisterInputForm.setLastName(form.getLastName());
		hpeRegisterInputForm.setNewPassword(form.getPwd());
		hpeRegisterInputForm.setUserId(form.getEmail());
		hpeRegisterInputForm.setContactByEmail(form.getEmailCheck());
		hpeRegisterInputForm.setCountryCode(form.getCountryCode());
		return hpeRegisterInputForm;
	}
        @Override
	protected MetaElementData createMetaElement(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}


}
