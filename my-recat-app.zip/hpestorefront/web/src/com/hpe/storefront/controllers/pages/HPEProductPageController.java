/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorfacades.futurestock.FutureStockFacade;
import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractSearchPageController.ShowMode;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.FutureStockForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ReviewForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.ReviewValidator;
import de.hybris.platform.acceleratorstorefrontcommons.util.MetaSanitizerUtil;
import de.hybris.platform.acceleratorstorefrontcommons.util.XSSFilterUtil;
import de.hybris.platform.acceleratorstorefrontcommons.variants.VariantSortStrategy;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSPageService;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.order.data.ConfigurationInfoData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.BaseOptionData;
import de.hybris.platform.commercefacades.product.data.ClassificationData;
import de.hybris.platform.commercefacades.product.data.FeatureData;
import de.hybris.platform.commercefacades.product.data.FeatureValueData;
import de.hybris.platform.commercefacades.product.data.FutureStockData;
import de.hybris.platform.commercefacades.product.data.ImageData;
import de.hybris.platform.commercefacades.product.data.ImageDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.ReviewData;
import de.hybris.platform.commercefacades.search.ProductSearchFacade;
import de.hybris.platform.commercefacades.search.data.SearchFilterQueryData;
import de.hybris.platform.commercefacades.search.data.SearchQueryData;
import de.hybris.platform.commercefacades.search.data.SearchStateData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commerceservices.search.facetdata.ProductSearchPageData;
import de.hybris.platform.commerceservices.search.pagedata.PageableData;
import de.hybris.platform.commerceservices.search.pagedata.SearchPageData;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.configurablebundleservices.model.BundleTemplateModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.order.price.TaxModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.order.TaxService;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.JsonMappingException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.google.common.collect.Maps;
import com.hpe.core.constants.HpeCoreConstants;
import com.hpe.core.product.HPEProductService;
import com.hpe.facades.bundle.HPEBundleFacade;
import com.hpe.facades.product.HPEProductFacade;
import com.hpe.facades.product.data.HPEVideoData;
import com.hpe.facades.product.impl.HPEProductBreadcrumbBuilder;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.GenericUtil;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;


/**
 * Controller for product details page
 */
@Controller
@RequestMapping(value = "/**/p")
public class HPEProductPageController extends AbstractPageController
{

	private static final String SERVICES_M_MS = "Services_M_MS";

	private static final String SEARCH_PAGE_DATA = "searchPageData";

	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(HPEProductPageController.class);


	/**
	 * We use this suffix pattern because of an issue with Spring 3.1 where a Uri value is incorrectly extracted if it
	 * contains one or more '.' characters. Please see https://jira.springsource.org/browse/SPR-6164 for a discussion on
	 * the issue and future resolution.
	 */
	private static final String PRODUCT_CODE_PATH_VARIABLE_PATTERN = "/{productCode:.*}"; //NOSONAR
	private static final String REVIEWS_PATH_VARIABLE_PATTERN = "{numberOfReviews:.*}";

	private static final String FUTURE_STOCK_ENABLED = "storefront.products.futurestock.enabled";
	private static final String STOCK_SERVICE_UNAVAILABLE = "basket.page.viewFuture.unavailable";
	private static final String NOT_MULTISKU_ITEM_ERROR = "basket.page.viewFuture.not.multisku";
	private static final String UPLOAD_DATA_VIDEO = "2018-10-23T21:43:16.833Z";//Added a constant for video upload date as we do not have date object in Image Data object
	private static final String CLASSIFICATION_SEO_META_KEYWORD = "Messaging_MarketingTopicalOutline";
	// Request URL for canonical
	private static final String REQUESTURL = "requestUrl";
	private static final String PRODUCT = "productModel";
	private static final String NO_RESULTS_CMS_PAGE_ID = "searchEmpty";
	private static final String PAGINATION_NUMBER_OF_RESULTS_COUNT = "pagination.number.results.count";
	public static final int MAX_PAGE_LIMIT = 100;
	private static final String SERVICE_PRODUCT_DESC = "serviceProductDescription";
	// Added session service to set the request url for canonical tag
	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "productDataUrlResolver")
	private UrlResolver<ProductData> productDataUrlResolver;

	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "productService")
	private ProductService productService;

	@Resource(name = "hpeProductBreadcrumbBuilder")
	private HPEProductBreadcrumbBuilder hpeProductBreadcrumbBuilder;

	@Resource(name = "cmsPageService")
	private CMSPageService cmsPageService;

	@Resource(name = "variantSortStrategy")
	private VariantSortStrategy variantSortStrategy;

	@Resource(name = "reviewValidator")
	private ReviewValidator reviewValidator;

	@Resource(name = "futureStockFacade")
	private FutureStockFacade futureStockFacade;

	@Resource(name = "hpeProductFacade")
	private HPEProductFacade hpeProductFacade;

	@Resource(name = "hpeProductService")
	private HPEProductService hpeProductService;
	
	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "hpeBundleFacade")
	private HPEBundleFacade hpeBundleFacade;

	@Resource(name = "customerFacade")
	private CustomerFacade customerFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "catalogVersionService")
	private CatalogVersionService catalogVersionService;

	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;

	@Resource(name = "productSearchFacade")
	private ProductSearchFacade<ProductData> productSearchFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "baseStoreService")
	private BaseStoreService baseStoreService;

	/**
	 * @return the cmsSiteService
	 */
	@Override
	public CMSSiteService getCmsSiteService()
	{
		return cmsSiteService;
	}



	/**
	 * @param cmsSiteService
	 *           the cmsSiteService to set
	 */
	public void setCmsSiteService(final CMSSiteService cmsSiteService)
	{
		this.cmsSiteService = cmsSiteService;
	}


	@ModelAttribute("stockAvailableUpperLimit")
	public Long getStockAvailableUpperLimit()
	{
		return configurationService.getConfiguration().getLong(HPEStorefrontConstant.STOCK_AVAILABLE_UPPER_LIMIT);
	}

	@ModelAttribute("stockLimitedAvailableUpperLimit")
	public Long getStockLimitedAvailableUpperLimit()
	{
		return configurationService.getConfiguration().getLong(HPEStorefrontConstant.STOCK_LIMITED_AVAILABLE_UPPER_LIMIT);
	}

	@ModelAttribute("stockAvailableLowerLimit")
	public Long getStockLimitedAvailableLowerLimit()
	{
		return configurationService.getConfiguration().getLong(HPEStorefrontConstant.STOCK_LIMITED_AVAILABLE_LOWER_LIMIT);
	}

	@ModelAttribute("showMoreFacetValueCount")
	public Long getMinimumFacetValuesCount()
	{
		return configurationService.getConfiguration().getLong(HPEStorefrontConstant.SHOWMORE_FACET_VALUE_LIMIT);
	}
	
	@ModelAttribute("vatMessage")
	public String getVatMessage()
	{
			return hpeProductFacade.getVatMessage();
	}
	
	@ModelAttribute("isQuoteEnable")
	public boolean isQuoteEnable()
	{
			return hpeProductFacade.isQuoteEnable();
	}

	@RequestMapping(value = "/showOptions", method = RequestMethod.GET)
	public String getProductOptions(@RequestParam(value = "q", defaultValue = StringUtils.EMPTY) final String searchQuery, //NOSONAR
			@RequestParam(value = "page", defaultValue = "0") final int page, //NOSONAR
			@RequestParam(value = "show", defaultValue = "Page") final ShowMode showMode, //NOSONAR
			@RequestParam(value = "sort", required = false) final String sortCode, //NOSONAR
			@RequestParam(value = "text", required = false) final String searchText, //NOSONAR
			@RequestParam(value = "pageSize", defaultValue = "0") final int pageSize,
			@RequestParam(value = "sourceCode", defaultValue = StringUtils.EMPTY) final String sourceCode, final Model model,
			final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException

	{
		int selectedPageSize = pageSize;
		if (pageSize == 0)
		{
			selectedPageSize = getSearchPageSize();

		}

		final PageableData pageableData = hpeStorefrontUtil.createPageableData(page, selectedPageSize, sortCode, ShowMode.Page);
		pageableData.setHpeGlobalVariantIndexType(true);
		final SearchStateData searchState = new SearchStateData();
		final SearchQueryData searchQueryData = new SearchQueryData();
		searchQueryData.setValue(searchQuery);
		searchState.setQuery(searchQueryData);

		ProductSearchPageData<SearchStateData, ProductData> searchPageData = null;
		try
		{
			final long startTime = System.currentTimeMillis();
			searchPageData = hpeStorefrontUtil.encodeSearchPageData(productSearchFacade.textSearch(searchState, pageableData));
			LOG.debug("HPEProductPageController:::getProductOptions():::Time Taken:::" + (System.currentTimeMillis() - startTime));
			model.addAttribute(SEARCH_PAGE_DATA, searchPageData);
			populateModel(model, searchPageData, ShowMode.Page);

			final Collection<String> pageSizes = GenericUtil.getSearchListPageSizes();

			model.addAttribute(HPEStorefrontConstant.SOURCE_CODE, sourceCode);
			model.addAttribute(HPEStorefrontConstant.PAGE_SIZES, pageSizes);
			model.addAttribute(HPEStorefrontConstant.SELECTED_PAGE_SIZE, selectedPageSize);
			final ProductData productData = productFacade.getProductForCodeAndOptions(sourceCode,
					Arrays.asList(ProductOption.BASIC, ProductOption.PRICE, ProductOption.SUMMARY, ProductOption.DESCRIPTION));
			model.addAttribute(HPEStorefrontConstant.MODEL_PRODUCT_DATA, productData);
		}
		catch (final Exception e) // NOSONAR
		{
			storeCmsPageInModel(model, getContentPageForLabelOrId(NO_RESULTS_CMS_PAGE_ID));
			LOG.error("HPEProductPageController:::Show options for query " + searchQuery + ":::Error Details::: ", e);
		}
		return ControllerConstants.Views.Pages.Product.ShowOptionsTab;
	}

	@RequestMapping(value = "/showServices", method = RequestMethod.GET)
	public String getProductServices(@RequestParam(value = "q", defaultValue = StringUtils.EMPTY) final String searchQuery, //NOSONAR
			@RequestParam(value = "page", defaultValue = "0") final int page, //NOSONAR
			@RequestParam(value = "show", defaultValue = "Page") final ShowMode showMode, //NOSONAR
			@RequestParam(value = "sort", required = false) final String sortCode, //NOSONAR
			@RequestParam(value = "text", required = false) final String searchText, //NOSONAR
			@RequestParam(value = "pageSize", defaultValue = "0") final int pageSize, //NOSONAR
			@RequestParam(value = "sourceCode", defaultValue = StringUtils.EMPTY) final String sourceCode, //NOSONAR
			final Model model, final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException
	{
		int selectedPageSize = pageSize;
		if (pageSize == 0)
		{
			selectedPageSize = getSearchPageSize();
		}

		final PageableData pageableData = hpeStorefrontUtil.createPageableData(page, selectedPageSize, sortCode, ShowMode.Page);
		pageableData.setHpeGlobalVariantIndexType(true);
		final SearchStateData searchState = new SearchStateData();
		final SearchQueryData searchQueryData = new SearchQueryData();
		final SearchFilterQueryData searchFilterQueryData = new SearchFilterQueryData();
		searchFilterQueryData.setKey(HPEStorefrontConstant.SOURCE_SERVICE_REFERENCE);
		searchFilterQueryData.setValues(new HashSet<>(Collections.singletonList(sourceCode)));

		searchQueryData.setFilterQueries(Collections.singletonList(searchFilterQueryData));
		searchQueryData.setValue(StringUtils.isNotEmpty(searchQuery) ? searchQuery : sourceCode);
		searchState.setQuery(searchQueryData);

		ProductSearchPageData<SearchStateData, ProductData> searchPageData = null;
		try
		{
			final long startTime = System.currentTimeMillis();
			searchPageData = hpeStorefrontUtil.encodeSearchPageData(productSearchFacade.textSearch(searchState, pageableData));
			LOG.debug("HPEProductPageController:::getProductServices():::Time Taken:::" + (System.currentTimeMillis() - startTime));
			model.addAttribute(SEARCH_PAGE_DATA, searchPageData);
			populateModel(model, searchPageData, ShowMode.Page);

			final Collection<String> pageSizes = GenericUtil.getSearchListPageSizes();

			model.addAttribute(HPEStorefrontConstant.SOURCE_CODE, sourceCode);
			model.addAttribute(HPEStorefrontConstant.PAGE_SIZES, pageSizes);
			model.addAttribute(HPEStorefrontConstant.SELECTED_PAGE_SIZE, selectedPageSize);
		}
		catch (final Exception e) // NOSONAR
		{
			storeCmsPageInModel(model, getContentPageForLabelOrId(NO_RESULTS_CMS_PAGE_ID));
			LOG.error("HPEProductPageController:::Show services for query " + searchQuery + ":::Error Details::: ", e);
		}
		return ControllerConstants.Views.Pages.Product.ShowServicesTab;
	}


	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
	public String productDetail(@PathVariable("productCode") final String encodedProductCode, // NOSONAR
			@RequestParam(value = "q", defaultValue = StringUtils.EMPTY) final String searchQuery, //NOSONAR
			@RequestParam(value = "page", defaultValue = "0") final int page, //NOSONAR
			@RequestParam(value = "show", defaultValue = "Page") final ShowMode showMode, //NOSONAR
			@RequestParam(value = "sort", required = false) final String sortCode, //NOSONAR
			@RequestParam(value = "text", required = false) final String searchText, //NOSONAR
			@RequestParam(value = "pageSize", defaultValue = "0") final int pageSize, final Model model,
			final HttpServletRequest request, final HttpServletResponse response)
					throws CMSItemNotFoundException, UnsupportedEncodingException

	{
		int selectedPageSize = pageSize;
		if (pageSize == 0)
		{
			selectedPageSize = getSearchPageSize();
		}

		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final ProductModel product = productService.getProductForCode(productCode);
		if (null != product && !hpeProductService.checkIfProductHasValidAssignment(product, null, true))
		{
			storeCmsPageInModel(model, getContentPageForLabelOrId(NO_RESULTS_CMS_PAGE_ID));
			return getViewForPage(model);
		}

		final List<ProductOption> extraOptions = Arrays.asList(ProductOption.VARIANT_MATRIX_BASE, ProductOption.VARIANT_MATRIX_URL,
				ProductOption.VARIANT_MATRIX_MEDIA, ProductOption.VARIANT_FULL);

		// Set the URL for canonical tag to the end.
		sessionService.setAttribute(REQUESTURL, request.getRequestURL());

		ProductData productData = productFacade.getProductForCodeAndOptions(productCode, extraOptions);

		if (null != product)
		{
			hpeProductFacade.setBadgeData(product, productData);
		}

		final String removeHpeRootCategoryInUrl = buildCategoryURLWithoutHpeRootCategory(productData);

		final String redirection = checkRequestUrl(request, response, removeHpeRootCategoryInUrl);
		if (StringUtils.isNotEmpty(redirection))
		{
			return redirection;
		}
		updatePageTitle(productCode, model);
		buildModelWithProductDetails(model);
		JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.PROD_RESULT, null);

		buildModelWithVideoDataDetails(model, request, productCode, extraOptions, productData);

		buildModelWithCustomerDetails(model);
		buildModelWithEloquaDetails(model);
		final String country = hpeStorefrontUtil.getCountryCode();
		if (null != country && !country.equalsIgnoreCase(HPEStorefrontConstant.COUNTRY_USCODE))
		{
			buildModelForGetQuote(model, productCode);
		}
		buildModelWithBundleAndAnalyticsDetails(model, productCode, productData);
		buildModelWithPageableDataDetails(searchQuery, page, sortCode, model, selectedPageSize, productCode);
		model.addAttribute(HPEStorefrontConstant.MAIN_PRODUCT_CODE, productCode);

		final String productLaunchStatus = hpeProductFacade.getHpeProductLaunchStatus(productCode,
				this.getBaseSiteService().getCurrentBaseSite().getStores().get(0));
		productData = (ProductData) model.asMap().get(HPEStorefrontConstant.PRODUCT2);
		productData.setHpeProductStatus(productLaunchStatus);
		model.addAttribute(HPEStorefrontConstant.PRODUCT2, productData);
		model.addAttribute(HpeCoreConstants.COUNTRY, hpeStorefrontUtil.getCountryCode());
		model.addAttribute(HPEStorefrontConstant.US_COUNTRY, HPEStorefrontConstant.COUNTRY_USCODE);
		LOG.debug("HPEProductPageController::::productLaunchStatus::::" + productLaunchStatus);


		return getViewForPage(model);
	}

	/**
	 * @param model
	 * @param productCode
	 * @param productData
	 */
	private void buildModelForGetQuote(final Model model, final String productCode)
	{


		final List<BundleTemplateModel> listOfBundle = hpeBundleFacade.getBundlDetailsWithoutOfferForProduct(productCode);


		final List<ProductModel> checkedProductList = new ArrayList<>();
		for (int i = 0; i < listOfBundle.size(); i++)

		{
			final List<ProductModel> Products = listOfBundle.get(i).getProducts();
			for (final ProductModel item : Products)
			{


				if (hpeProductService.checkIfProductHasValidAssignment(item, null, true))
				{
					checkedProductList.add(item);
				}
			}
			listOfBundle.get(i).setProducts(checkedProductList);

		}
		model.addAttribute(HPEStorefrontConstant.LIST_OF_BUNDLE_WITHOUT_OFFER, listOfBundle);


	}



	private void buildModelWithVideoDataDetails(final Model model, final HttpServletRequest request, final String productCode,
			final List<ProductOption> extraOptions, final ProductData productData) throws CMSItemNotFoundException
	{
		final HPEVideoData hpeVideoData = hpeProductFacade.getBcReferenceId(productCode);
		if (hpeVideoData != null)
		{
			model.addAttribute(HPEStorefrontConstant.VIDEO, hpeVideoData.getBcReferenceId());
		}
		populateProductDetailForDisplay(productCode, model, request, extraOptions, productData);
		try
		{
			generateScriptJson(productData, model, hpeVideoData);
		}
		catch (final JSONException e)
		{
			LOG.error("HPEProductPageController:::productDetail:::generateScriptJson():::", e);
		}
	}

	private void buildModelWithPageableDataDetails(final String searchQuery, final int page, final String sortCode,
			final Model model, final int selectedPageSize, final String productCode) throws CMSItemNotFoundException
	{
		final PageableData pageableData = hpeStorefrontUtil.createPageableData(page, selectedPageSize, sortCode, ShowMode.Page);
		pageableData.setHpeGlobalVariantIndexType(true);
		final SearchStateData searchState = new SearchStateData();
		final SearchQueryData searchQueryData = new SearchQueryData();
		final SearchFilterQueryData searchFilterQueryData = new SearchFilterQueryData();
		searchFilterQueryData.setKey(HPEStorefrontConstant.BASE_PRODUCT_CODE);
		searchFilterQueryData.setValues(new HashSet<>(Collections.singletonList(productCode)));

		searchQueryData.setFilterQueries(Collections.singletonList(searchFilterQueryData));
		searchQueryData.setValue(StringUtils.isNotEmpty(searchQuery) ? searchQuery : productCode);
		searchState.setQuery(searchQueryData);

		ProductSearchPageData<SearchStateData, ProductData> searchPageData = null;
		try
		{
			final long startTime = System.currentTimeMillis();
			searchPageData = hpeStorefrontUtil.encodeSearchPageData(productSearchFacade.textSearch(searchState, pageableData));
			LOG.debug("HPEProductPageController:::searchPageData::Time Taken:::" + (System.currentTimeMillis() - startTime));

			populateStartingAtPrice(productCode, model);
			popubalteServiceAvailable(productCode, model);

			model.addAttribute(SEARCH_PAGE_DATA, searchPageData);
			populateModel(model, searchPageData, ShowMode.Page);

			final Collection<String> pageSizes = GenericUtil.getSearchListPageSizes();

			model.addAttribute(HPEStorefrontConstant.PAGE_SIZES, pageSizes);
			model.addAttribute(HPEStorefrontConstant.SELECTED_PAGE_SIZE, selectedPageSize);
		}
		catch (final Exception e) // NOSONAR
		{
			storeCmsPageInModel(model, getContentPageForLabelOrId(NO_RESULTS_CMS_PAGE_ID));
			LOG.error("HPEProductPageController:::Show options for productCode " + productCode + " :::Error Details:::", e);
		}
	}

	private void popubalteServiceAvailable(final String productCode, final Model model)
	{
		final PageableData pageableData = hpeStorefrontUtil.createPageableData(0, 10, null, ShowMode.Page);
		pageableData.setHpeGlobalVariantIndexType(true);
		final SearchStateData searchState = new SearchStateData();
		final SearchQueryData searchQueryData = new SearchQueryData();
		final SearchFilterQueryData searchFilterQueryData = new SearchFilterQueryData();
		searchFilterQueryData.setKey(HPEStorefrontConstant.SOURCE_SERVICE_REFERENCE);
		searchFilterQueryData.setValues(new HashSet<>(Collections.singletonList(productCode)));

		searchQueryData.setFilterQueries(Collections.singletonList(searchFilterQueryData));
		searchQueryData.setValue(productCode);
		searchState.setQuery(searchQueryData);
		final ProductSearchPageData<SearchStateData, ProductData> servicesSearchPageData = hpeStorefrontUtil
				.encodeSearchPageData(productSearchFacade.textSearch(searchState, pageableData));
		model.addAttribute(HPEStorefrontConstant.PRODUCT_REFERENCE_DATA_LIST,
				(null != servicesSearchPageData) ? servicesSearchPageData.getResults() : ListUtils.EMPTY_LIST);
	}



	private void populateStartingAtPrice(final String productCode, final Model model)
	{
		final PageableData pageableData = hpeStorefrontUtil.createPageableData(0, 10, null, ShowMode.Page);
		final SearchStateData searchState = new SearchStateData();
		final SearchQueryData searchQueryData = new SearchQueryData();
		searchQueryData.setValue(productCode);
		searchState.setQuery(searchQueryData);

		final ProductSearchPageData<SearchStateData, ProductData> baseProdctSearchPageData = hpeStorefrontUtil
				.encodeSearchPageData(productSearchFacade.textSearch(searchState, pageableData));
		if (null != baseProdctSearchPageData && CollectionUtils.isNotEmpty(baseProdctSearchPageData.getResults()))
		{
			final ProductData product = baseProdctSearchPageData.getResults().get(0);
			model.addAttribute(HPEStorefrontConstant.LEAST_PARTNER_PRICE, product.getLeastPartnerPrice());
		}

	}



	private void buildModelWithBundleAndAnalyticsDetails(final Model model, final String productCode,
			final ProductData productData)
	{
		final org.json.JSONObject productjson;
		final List<Object> listOfBundleOffer = hpeBundleFacade.getBundlDetailsForProduct(productCode);
		if (null != listOfBundleOffer && listOfBundleOffer.size() >= 3)
		{
			model.addAttribute(HPEStorefrontConstant.LIST_OF_BUNDLE_OFFER, listOfBundleOffer.get(0));
			model.addAttribute(HPEStorefrontConstant.BUNDLE_PRICE, listOfBundleOffer.get(1));
			model.addAttribute(HPEStorefrontConstant.SHOP_LIST, listOfBundleOffer.get(2));
			productjson = hpeAnalyticsUtil.getProductDataJsonObjectForAnalytics(productData, (List) listOfBundleOffer.get(0));
		}
		else
		{
			productjson = hpeAnalyticsUtil.getProductDataJsonObjectForAnalytics(productData, null);
		}
		model.addAttribute(HPEStorefrontConstant.PRODUCTJSON2, productjson);
		model.addAttribute(HPEStorefrontConstant.CANONICAL, sessionService.getAttribute(REQUESTURL).toString());
		model.addAttribute(HPEStorefrontConstant.PRODUCT_VARIANT_LIST_SIZE,
				hpeProductFacade.getProductVariantListSize(productCode));
	}


	private void buildModelWithEloquaDetails(final Model model)
	{
		model.addAttribute(HPEStorefrontConstant.ELOQUA,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADDRESS));
		model.addAttribute(HPEStorefrontConstant.ELOQUAADDTOCARTFORMNAME,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADD_TO_CART_FORM_NAME));
		model.addAttribute(HPEStorefrontConstant.ELOQUASITEID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_SITEID));
		model.addAttribute(HPEStorefrontConstant.ELOQUAAPRIMOACTIVITYIDADDTOCART, configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_ADD_TO_CART));
		model.addAttribute(HPEStorefrontConstant.ELOQUARESPONSETYPE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_RESPONSE_TYPE1));
		model.addAttribute(HPEStorefrontConstant.ELOQUALEADSOURCE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_LEAD_SOURCE___MOST_RECENT1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_ID1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMCLEANEDSTATUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_CLEANED_STATUS1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAFORMSOURCE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_FORM_SOURCE1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAFORMSOURCEADDTOCART,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_SOURCE_ADD_TO_CART));
		model.addAttribute(HPEStorefrontConstant.ELOQUAMKPCARTSTATUSADDTOCART,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_MKP_CART_STATUS_ADD_TO_CART));
		model.addAttribute(HPEStorefrontConstant.ELOQUAMETHODOPTIN,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_METHOD_OPT_IN));
		model.addAttribute(HPEStorefrontConstant.ELOQUACOOKIEWRITE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_COOKIE_WRITE));
		model.addAttribute(new ReviewForm());
		model.addAttribute(HPEStorefrontConstant.PAGE_TYPE, PageType.PRODUCT.name());
		model.addAttribute(HPEStorefrontConstant.FUTURE_STOCK_ENABLED2,
				Boolean.valueOf(configurationService.getConfiguration().getBoolean(FUTURE_STOCK_ENABLED, false)));
	}

	// SEO PDP URL -- Remove HPE Root Category & Stop Words (and / or)
	private String buildCategoryURLWithoutHpeRootCategory(final ProductData productData)
	{
		String removeHpeRootCategoryInUrl = productDataUrlResolver.resolve(productData);
		if (removeHpeRootCategoryInUrl.toLowerCase().contains("/hpe-root-category"))
		{
			removeHpeRootCategoryInUrl = removeHpeRootCategoryInUrl.replace("/hpe-root-category", "");
		}
		if (removeHpeRootCategoryInUrl.contains("-and-"))
		{
			removeHpeRootCategoryInUrl = removeHpeRootCategoryInUrl.replace("-and-", "-");
		}
		return removeHpeRootCategoryInUrl;
	}

	private void buildModelWithCustomerDetails(final Model model)
	{
		final CustomerData currentUser = customerFacade.getCurrentCustomer();
		if (currentUser == null)
		{
			return;
		}
		if (LOG.isDebugEnabled())
		{
			LOG.debug("HPEProductPageController:::productDetail:::currentUser " + currentUser);
		}
		model.addAttribute(HPEStorefrontConstant.CUSTOMER_EMAIL_ADDRESS, currentUser.getDisplayUid());
		model.addAttribute(HPEStorefrontConstant.CUSTOMER_FIRST_NAME, currentUser.getFirstName());
		model.addAttribute(HPEStorefrontConstant.CUSTOMER_LAST_NAME, currentUser.getLastName());
	}


	private void buildModelWithProductDetails(final Model model)
	{
		final HashMap<String, Object> productResult = (HashMap<String, Object>) JaloSession.getCurrentSession()
				.getAttribute("productResult");
		if (MapUtils.isEmpty(productResult))
		{
			return;
		}
		model.addAttribute(HPEStorefrontConstant.REQUEST_TIME, productResult.get(HPEStorefrontConstant.REQUEST_TIME));
		model.addAttribute(HPEStorefrontConstant.RESPONSE_TIME, productResult.get(HPEStorefrontConstant.RESPONSE_TIME));
		model.addAttribute(HPEStorefrontConstant.PAYLOAD_SIZE, productResult.get(HPEStorefrontConstant.PAYLOAD_SIZE));
		model.addAttribute(HPEStorefrontConstant.PRODUCT_HIERARCHY, productResult.get(HPEStorefrontConstant.PRODUCT_HIERARCHY));

		model.addAttribute(HPEStorefrontConstant.AUTH_START, productResult.get(HPEStorefrontConstant.AUTH_START));
		model.addAttribute(HPEStorefrontConstant.AUTH_END, productResult.get(HPEStorefrontConstant.AUTH_END));
		model.addAttribute(HPEStorefrontConstant.CALL1_START, productResult.get(HPEStorefrontConstant.CALL1_START));
		model.addAttribute(HPEStorefrontConstant.CALL1_END, productResult.get(HPEStorefrontConstant.CALL1_END));
		model.addAttribute(HPEStorefrontConstant.CALL2_START, productResult.get(HPEStorefrontConstant.CALL2_START));
		model.addAttribute(HPEStorefrontConstant.CALL2_END, productResult.get(HPEStorefrontConstant.CALL2_END));
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/orderForm", method = RequestMethod.GET)
	public String productOrderForm(@PathVariable("productCode") final String encodedProductCode, final Model model,
			final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final List<ProductOption> extraOptions = Arrays.asList(ProductOption.VARIANT_MATRIX_BASE,
				ProductOption.VARIANT_MATRIX_PRICE, ProductOption.VARIANT_MATRIX_MEDIA, ProductOption.VARIANT_MATRIX_STOCK,
				ProductOption.URL);

		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode, extraOptions);
		updatePageTitle(productCode, model);

		populateProductDetailForDisplay(productCode, model, request, extraOptions, productData);

		if (!model.containsAttribute(WebConstants.MULTI_DIMENSIONAL_PRODUCT))
		{
			return REDIRECT_PREFIX + productDataUrlResolver.resolve(productData);
		}

		return ControllerConstants.Views.Pages.Product.OrderForm;
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/zoomImages", method = RequestMethod.GET)
	public String showZoomImages(@PathVariable("productCode") final String encodedProductCode,
			@RequestParam(value = "galleryPosition", required = false) final String galleryPosition, final Model model)
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode,
				Collections.singleton(ProductOption.GALLERY));
		final List<Map<String, ImageData>> images = getGalleryImages(productData);
		final ProductModel productModel = productService.getProductForCode(productCode);
		populateProductData(productData, model, productModel);
		if (galleryPosition != null)
		{
			try
			{
				model.addAttribute(HPEStorefrontConstant.ZOOM_IMAGE_URL,
						images.get(Integer.parseInt(galleryPosition)).get(HPEStorefrontConstant.ZOOM).getUrl());
			}
			catch (final Exception e)
			{
				model.addAttribute(HPEStorefrontConstant.ZOOM_IMAGE_URL, "");
				LOG.error("HPEProductPageController:::showZoomImages():::", e);
			}
		}
		return ControllerConstants.Views.Fragments.Product.ZoomImagesPopup;
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/quickView", method = RequestMethod.GET)
	public String showQuickView(@PathVariable("productCode") final String encodedProductCode, final Model model,
			final HttpServletRequest request)
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final ProductModel productModel = productService.getProductForCode(productCode);
		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode,
				Arrays.asList(ProductOption.BASIC, ProductOption.PRICE, ProductOption.SUMMARY, ProductOption.DESCRIPTION,
						ProductOption.CATEGORIES, ProductOption.PROMOTIONS, ProductOption.STOCK, ProductOption.REVIEW,
						ProductOption.VARIANT_FULL, ProductOption.DELIVERY_MODE_AVAILABILITY));

		sortVariantOptionData(productData);
		populateProductData(productData, model, productModel);
		getRequestContextData(request).setProduct(productModel);

		return ControllerConstants.Views.Fragments.Product.QuickViewPopup;
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/review", method =
	{ RequestMethod.GET, RequestMethod.POST })
	public String postReview(@PathVariable("productCode") final String encodedProductCode, final ReviewForm form,
			final BindingResult result, final Model model, final HttpServletRequest request, final RedirectAttributes redirectAttrs)
					throws CMSItemNotFoundException
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		getReviewValidator().validate(form, result);

		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode, null);
		if (result.hasErrors())
		{
			updatePageTitle(productCode, model);
			GlobalMessages.addErrorMessage(model, "review.general.error");
			model.addAttribute(HPEStorefrontConstant.SHOW_REVIEW_FORM, Boolean.TRUE);
			populateProductDetailForDisplay(productCode, model, request, Collections.emptyList(), productData);
			storeCmsPageInModel(model, getPageForProduct(productCode));
			return getViewForPage(model);
		}

		final ReviewData review = new ReviewData();
		review.setHeadline(XSSFilterUtil.filter(form.getHeadline()));
		review.setComment(XSSFilterUtil.filter(form.getComment()));
		review.setRating(form.getRating());
		review.setAlias(XSSFilterUtil.filter(form.getAlias()));
		productFacade.postReview(productCode, review);
		GlobalMessages.addFlashMessage(redirectAttrs, GlobalMessages.CONF_MESSAGES_HOLDER, "review.confirmation.thank.you.title");

		return REDIRECT_PREFIX + productDataUrlResolver.resolve(productData);
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/reviewhtml/"
			+ REVIEWS_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
	public String reviewHtml(@PathVariable("productCode") final String encodedProductCode,
			@PathVariable("numberOfReviews") final String numberOfReviews, final Model model, final HttpServletRequest request)
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final ProductModel productModel = productService.getProductForCode(productCode);
		final List<ReviewData> reviews;
		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode,
				Arrays.asList(ProductOption.BASIC, ProductOption.REVIEW));

		if ("all".equals(numberOfReviews))
		{
			reviews = productFacade.getReviews(productCode);
		}
		else
		{
			final int reviewCount = Math.min(Integer.parseInt(numberOfReviews),
					productData.getNumberOfReviews() == null ? 0 : productData.getNumberOfReviews().intValue());
			reviews = productFacade.getReviews(productCode, Integer.valueOf(reviewCount));
		}

		getRequestContextData(request).setProduct(productModel);
		model.addAttribute(HPEStorefrontConstant.REVIEWS2, reviews);
		model.addAttribute(HPEStorefrontConstant.REVIEWS_TOTAL, productData.getNumberOfReviews());
		model.addAttribute(new ReviewForm());

		return ControllerConstants.Views.Fragments.Product.ReviewsTab;
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/writeReview", method = RequestMethod.GET)
	public String writeReview(@PathVariable("productCode") final String encodedProductCode, final Model model)
			throws CMSItemNotFoundException
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		model.addAttribute(new ReviewForm());
		setUpReviewPage(model, productCode);
		return ControllerConstants.Views.Pages.Product.WriteReview;
	}

	protected void setUpReviewPage(final Model model, final String productCode) throws CMSItemNotFoundException
	{
		String metaKeywords = "";
		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode, null);
		Collection<FeatureData> featuredata = null;
		if (productData.getClassificationGroupMap() != null
				&& productData.getClassificationGroupMap().get(CLASSIFICATION_SEO_META_KEYWORD) != null)
		{
			featuredata = productData.getClassificationGroupMap().get(CLASSIFICATION_SEO_META_KEYWORD).getFeatures();
			metaKeywords = featuredata.iterator().next().getFeatureValues().iterator().next().getValue();
		}
		else
		{
			metaKeywords = "";
		}
		final String metaDescription = MetaSanitizerUtil.sanitizeDescription(productData.getDescription());
		setUpMetaData(model, metaKeywords, metaDescription);
		storeCmsPageInModel(model, getPageForProduct(productCode));
		model.addAttribute(HPEStorefrontConstant.PRODUCT2,
				productFacade.getProductForCodeAndOptions(productCode, Arrays.asList(ProductOption.BASIC)));
		updatePageTitle(productCode, model);
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/writeReview", method = RequestMethod.POST)
	public String writeReview(@PathVariable("productCode") final String encodedProductCode, final ReviewForm form,
			final BindingResult result, final Model model, final HttpServletRequest request, final RedirectAttributes redirectAttrs)
					throws CMSItemNotFoundException
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		getReviewValidator().validate(form, result);

		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode, null);

		if (result.hasErrors())
		{
			GlobalMessages.addErrorMessage(model, "review.general.error");
			populateProductDetailForDisplay(productCode, model, request, Collections.emptyList(), productData);
			setUpReviewPage(model, productCode);
			return ControllerConstants.Views.Pages.Product.WriteReview;
		}

		final ReviewData review = new ReviewData();
		review.setHeadline(XSSFilterUtil.filter(form.getHeadline()));
		review.setComment(XSSFilterUtil.filter(form.getComment()));
		review.setRating(form.getRating());
		review.setAlias(XSSFilterUtil.filter(form.getAlias()));
		productFacade.postReview(productCode, review);
		GlobalMessages.addFlashMessage(redirectAttrs, GlobalMessages.CONF_MESSAGES_HOLDER, "review.confirmation.thank.you.title");

		return REDIRECT_PREFIX + productDataUrlResolver.resolve(productData);
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/futureStock", method = RequestMethod.GET)
	public String productFutureStock(@PathVariable("productCode") final String encodedProductCode, final Model model,
			final HttpServletRequest request, final HttpServletResponse response) throws CMSItemNotFoundException
	{
		final String productCode = decodeWithScheme(encodedProductCode, UTF_8);
		final boolean futureStockEnabled = configurationService.getConfiguration().getBoolean(FUTURE_STOCK_ENABLED, false);

		if (futureStockEnabled)
		{
			final List<FutureStockData> futureStockList = futureStockFacade.getFutureAvailability(productCode);
			if (futureStockList == null)
			{
				GlobalMessages.addErrorMessage(model, STOCK_SERVICE_UNAVAILABLE);
			}
			else if (futureStockList.isEmpty())
			{
				GlobalMessages.addInfoMessage(model, "product.product.details.future.nostock");
			}

			populateProductDetailForDisplay(productCode, model, request, Collections.emptyList(), null);
			model.addAttribute(HPEStorefrontConstant.FUTURE_STOCKS, futureStockList);

			return ControllerConstants.Views.Fragments.Product.FutureStockPopup;
		}
		else
		{
			return ControllerConstants.Views.Pages.Error.ErrorNotFoundPage;
		}
	}

	@ResponseBody
	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/grid/skusFutureStock", method =
	{ RequestMethod.POST }, produces = MediaType.APPLICATION_JSON_VALUE)
	public final Map<String, Object> productSkusFutureStock(final FutureStockForm form, final Model model)
	{
		final String productCode = form.getProductCode();
		final List<String> skus = form.getSkus();
		final boolean futureStockEnabled = configurationService.getConfiguration().getBoolean(FUTURE_STOCK_ENABLED, false);

		Map<String, Object> result = new HashMap<>();
		if (futureStockEnabled && CollectionUtils.isNotEmpty(skus) && StringUtils.isNotBlank(productCode))
		{
			final Map<String, List<FutureStockData>> futureStockData = futureStockFacade
					.getFutureAvailabilityForSelectedVariants(productCode, skus);

			if (futureStockData == null)
			{
				// future availability service is down, we show this to the user
				result = Maps.newHashMap();
				final String errorMessage = getMessageSource().getMessage(NOT_MULTISKU_ITEM_ERROR, null,
						getI18nService().getCurrentLocale());
				result.put(NOT_MULTISKU_ITEM_ERROR, errorMessage);
			}
			else
			{
				for (final Map.Entry<String, List<FutureStockData>> entry : futureStockData.entrySet())
				{
					result.put(entry.getKey(), entry.getValue());
				}
			}
		}
		return result;
	}

	@ExceptionHandler(UnknownIdentifierException.class)
	public String handleUnknownIdentifierException(final UnknownIdentifierException exception, final HttpServletRequest request)
	{
		request.setAttribute("message", exception.getMessage());
		return FORWARD_PREFIX + "/404";
	}

	protected void updatePageTitle(final String productCode, final Model model)
	{
		final CMSSiteModel currentSite = getCmsSiteService().getCurrentSite();
		final String pageTitle = getPageTitleResolver().resolveProductPageTitle(productCode);
		if (pageTitle.contains("|"))
		{
			final String pageTitleSplit[] = pageTitle.split("\\|");
			storeContentPageTitleInModel(model, pageTitleSplit[0] + " | " + currentSite.getName());
		}
		else
		{
			storeContentPageTitleInModel(model, getPageTitleResolver().resolveProductPageTitle(productCode));
		}
	}

	protected void populateProductDetailForDisplay(final String productCode, final Model model, final HttpServletRequest request,
			final List<ProductOption> extraOptions, final ProductData productData) throws CMSItemNotFoundException
	{
		final ProductModel productModel = productService.getProductForCode(productCode);

		long startTime = System.currentTimeMillis();

		getRequestContextData(request).setProduct(productModel);

		sessionService.setAttribute(PRODUCT, productModel);

		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.VARIANT_FIRST_VARIANT, ProductOption.BASIC,
				ProductOption.URL, ProductOption.PRICE, ProductOption.SUMMARY, ProductOption.DESCRIPTION, ProductOption.GALLERY,
				ProductOption.CATEGORIES, ProductOption.REVIEW, ProductOption.PROMOTIONS, ProductOption.CLASSIFICATION,
				ProductOption.VARIANT_FULL, ProductOption.STOCK, ProductOption.VOLUME_PRICES, ProductOption.PRICE_RANGE,
				ProductOption.DELIVERY_MODE_AVAILABILITY));

		options.addAll(extraOptions);

		startTime = System.currentTimeMillis();
		final ProductData hpeProductData = productFacade.getProductForCodeAndOptions(productCode, options);
		LOG.info("HPEProductPageController:::productData Time = " + (System.currentTimeMillis() - startTime));
		// Populating the Badge data for Product
		startTime = System.currentTimeMillis();
		hpeProductFacade.setBadgeData(productModel, hpeProductData);
		LOG.info("HPEProductPageController:::badgeData Time = " + (System.currentTimeMillis() - startTime));
		buildDescriptionForServiceProducts(hpeProductData, model);
		sortVariantOptionData(hpeProductData);
		storeCmsPageInModel(model, getPageForProduct(productCode));
		populateProductData(hpeProductData, model, productModel);
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, hpeProductBreadcrumbBuilder.getBreadcrumbs(productCode));

		if (CollectionUtils.isNotEmpty(hpeProductData.getVariantMatrix()))
		{
			model.addAttribute(WebConstants.MULTI_DIMENSIONAL_PRODUCT,
					Boolean.valueOf(CollectionUtils.isNotEmpty(hpeProductData.getVariantMatrix())));
		}

		final String metaKeywords = buildMetaKeywordsWithFeatureData(hpeProductData);

		buildModelWithEmptyFeatures(model, hpeProductData);
		buildModelWithEmptyResources(model, hpeProductData);

		final String metaDescription = MetaSanitizerUtil.sanitizeDescription(hpeProductData.getDescription());
		setUpMetaData(model, metaKeywords, metaDescription);
	}


	private void buildDescriptionForServiceProducts(final ProductData hpeProductData, final Model model)
	{

		final String classficationClassCode = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_SERVICE_CLASS_CODE, SERVICES_M_MS);
		final Map<String, ClassificationData> classificationGroupMap = hpeProductData.getClassificationGroupMap();
		if (MapUtils.isNotEmpty(classificationGroupMap))
		{
			final Map<String, ClassificationData> techSpecifications = classificationGroupMap.entrySet().stream()
					.filter(eachEntry -> eachEntry.getKey().contains(classficationClassCode))
					.collect(Collectors.toMap(eachEntry -> eachEntry.getKey(), eachEntry -> eachEntry.getValue()));
			if (MapUtils.isNotEmpty(techSpecifications) && techSpecifications.entrySet().iterator().hasNext())
			{
				buildFeatureValueData(model, techSpecifications);
			}
		}
	}

	private void buildFeatureValueData(final Model model, final Map<String, ClassificationData> techSpecifications)
	{
		Entry<String, ClassificationData> entry;
		entry = techSpecifications.entrySet().iterator().next();
		final ClassificationData classificationData = entry.getValue();
		final Collection<FeatureData> features = classificationData.getFeatures();
		final String featureAttributeName = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_ATTR_NAME, SERVICES_M_MS);
		final StringBuilder description = new StringBuilder();
		for (final FeatureData featureData : features)
		{
			if (StringUtils.containsIgnoreCase(featureData.getName(), featureAttributeName))
			{
				final Collection<FeatureValueData> featureValues = featureData.getFeatureValues();
				for (final FeatureValueData featureValueData : featureValues)
				{
					description.append(featureValueData.getValue() + " ");
				}
			}
		}
		LOG.debug("HPEProductPageController:::buildFeatureValueData():::Service product description ::: " + description);
		model.addAttribute(SERVICE_PRODUCT_DESC, description.toString());
	}

	private void buildModelWithEmptyResources(final Model model, final ProductData hpeProductData)
	{
		final Map<String, ClassificationData> classificationData = hpeProductData.getClassificationGroupMap();
		if (classificationData == null)
		{
			return;
		}
		if (classificationData.get("Additional_Resources_QuickSpecs_Links") == null
				&& classificationData.get("Additional_Resources_Related_Links") == null
				&& classificationData.get("Additional_Resources_Right_Rail_Links") == null)
		{
			model.addAttribute(HPEStorefrontConstant.EMPTY_RESOURCES, true);
		}
	}


	private void buildModelWithEmptyFeatures(final Model model, final ProductData hpeProductData)
	{
		final Map<String, ClassificationData> classificationData = hpeProductData.getClassificationGroupMap();
		if (classificationData == null || classificationData.get("Messaging_What_is_new") != null)
		{
			return;
		}
		if (classificationData.get("Messaging_Features") == null && classificationData.get("Messaging_Footnotes") == null
				&& classificationData.get(SERVICES_M_MS) == null)
		{
			model.addAttribute(HPEStorefrontConstant.EMPTY_FEATURES, true);
		}
	}


	private String buildMetaKeywordsWithFeatureData(final ProductData hpeProductData)
	{
		String metaKeywords = "";
		Collection<FeatureData> featuredata = null;
		if (hpeProductData.getClassificationGroupMap() != null
				&& hpeProductData.getClassificationGroupMap().get(CLASSIFICATION_SEO_META_KEYWORD) != null)
		{
			featuredata = hpeProductData.getClassificationGroupMap().get(CLASSIFICATION_SEO_META_KEYWORD).getFeatures();
			for (final FeatureData featureData2 : featuredata)
			{
				LOG.debug("--INSIDE FOR LOOP TO FETCH THE SEO KEYWORK CHECK" + featureData2.getName());
				if ("03.Metadata Key Word Search".equalsIgnoreCase(featureData2.getName()))
				{
					metaKeywords = featureData2.getFeatureValues().iterator().next().getValue();
					LOG.debug("--META KEYWORD VALUE--CONGIUGRED" + metaKeywords);
				}
			}
		}
		return metaKeywords;
	}


	protected void populateProductData(final ProductData productData, final Model model, final ProductModel productModel)
	{
		hpeProductFacade.getHpeProductStatus(productData);

		final long startTime = System.currentTimeMillis();
		LOG.info("HPEProductPageController:::populateProductData():::" + (System.currentTimeMillis() - startTime));
		model.addAttribute(HPEStorefrontConstant.GALLERY_IMAGES, getGalleryImages(productData));
		model.addAttribute(HPEStorefrontConstant.PRODUCT2, productData);
		if (productData.getConfigurable())
		{
			final List<ConfigurationInfoData> configurations = productFacade.getConfiguratorSettingsForCode(productData.getCode());
			if (CollectionUtils.isNotEmpty(configurations))
			{
				model.addAttribute(HPEStorefrontConstant.CONFIGURATOR_TYPE, configurations.get(0).getConfiguratorType());
			}
		}

	}

	protected void sortVariantOptionData(final ProductData productData)
	{
		if (CollectionUtils.isNotEmpty(productData.getBaseOptions()))
		{
			for (final BaseOptionData baseOptionData : productData.getBaseOptions())
			{
				if (CollectionUtils.isNotEmpty(baseOptionData.getOptions()))
				{
					Collections.sort(baseOptionData.getOptions(), variantSortStrategy);
				}
			}
		}

		if (CollectionUtils.isNotEmpty(productData.getVariantOptions()))
		{
			Collections.sort(productData.getVariantOptions(), variantSortStrategy);
		}
	}

	protected List<Map<String, ImageData>> getGalleryImages(final ProductData productData)
	{
		final List<Map<String, ImageData>> galleryImages = new ArrayList<>();
		if (CollectionUtils.isEmpty(productData.getImages()))
		{
			return galleryImages;
		}
		final List<ImageData> images = new ArrayList<>();
		for (final ImageData image : productData.getImages())
		{
			if (ImageDataType.GALLERY.equals(image.getImageType()))
			{
				images.add(image);
			}
		}
		Collections.sort(images, new Comparator<ImageData>() //NOSONAR
		{
			@Override
			public int compare(final ImageData image1, final ImageData image2)
			{
				return image1.getGalleryIndex().compareTo(image2.getGalleryIndex());
			}
		});

		if (CollectionUtils.isNotEmpty(images))
		{
			addFormatsToGalleryImages(galleryImages, images);
		}
		return galleryImages;
	}

	protected void addFormatsToGalleryImages(final List<Map<String, ImageData>> galleryImages, final List<ImageData> images)
	{
		int currentIndex = images.get(0).getGalleryIndex().intValue();
		Map<String, ImageData> formats = new HashMap<>();
		for (final ImageData image : images)
		{
			if (currentIndex != image.getGalleryIndex().intValue())
			{
				galleryImages.add(formats);
				formats = new HashMap<>();
				currentIndex = image.getGalleryIndex().intValue();
			}
			formats.put(image.getFormat(), image);
		}
		if (!formats.isEmpty())
		{
			galleryImages.add(formats);
		}
	}

	protected ReviewValidator getReviewValidator()
	{
		return reviewValidator;
	}

	protected AbstractPageModel getPageForProduct(final String productCode) throws CMSItemNotFoundException
	{
		final ProductModel productModel = productService.getProductForCode(productCode);
		return cmsPageService.getPageForProduct(productModel);
	}

	@RequestMapping(value = PRODUCT_CODE_PATH_VARIABLE_PATTERN + "/customizeItem", method = RequestMethod.GET)
	public @ResponseBody String channelCentralProductConfiguration(@RequestParam("variantCode") final String variantCode,
			@RequestParam(value = "shopName", required = false) final String shopName, final Model model)
					throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException
	{
		final String[] productVariantCode = variantCode.split(",");
		LOG.debug("HPEProductPageController :: channelCentralProductConfig()=" + productVariantCode[0] + "-----" + shopName);
		return hpeProductFacade.getChannelCentralConfiguration(productVariantCode[0], shopName, hpeStorefrontUtil.getCountryCode());
	}

	@RequestMapping(value = "/classification", method = RequestMethod.GET)
	public @ResponseBody Map<String, String> getClassificationDetails(@RequestParam("variantCode") final String variantCode,
			final Model model)
	{
		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.CLASSIFICATION));
		final ProductData hpeProductData = productFacade.getProductForCodeAndOptions(variantCode, options);
		final Map<String, ClassificationData> classificationGroupMap = hpeProductData.getClassificationGroupMap();
		if (MapUtils.isEmpty(classificationGroupMap) || CollectionUtils.isEmpty(classificationGroupMap.keySet()))
		{
			return null;
		}
		final Map<String, String> classificationAttributes = new LinkedHashMap<>();
		final String classficationClassCode = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_CLASS_CODE, "_TS");
		for (final String classificationClass : classificationGroupMap.keySet())
		{
			if (classificationClass.contains(classficationClassCode))
			{
				buildClassificationAttributes(classificationGroupMap, classificationAttributes, classificationClass);
			}
		}
		logClassificationAttributes(classificationAttributes);
		return classificationAttributes;
	}

	private void logClassificationAttributes(final Map<String, String> classificationAttributes)
	{
		if (LOG.isDebugEnabled())
		{
			for (final Entry<String, String> eachEntry : classificationAttributes.entrySet())
			{
				LOG.debug("HPEProductPageController:::logClassificationAttributes():::Key:::" + eachEntry.getKey() + ":::Value:::"
						+ eachEntry.getValue());
			}
		}
	}

	private void buildClassificationAttributes(final Map<String, ClassificationData> classificationGroupMap,
			final Map<String, String> classificationAttributes, final String classificationClass)
	{
		ClassificationData classificationData;
		classificationData = classificationGroupMap.get(classificationClass);
		final Collection<FeatureData> features = classificationData.getFeatures();
		if (CollectionUtils.isEmpty(features))
		{
			return;
		}
		for (final FeatureData featureData : features)
		{
			final List<FeatureValueData> featureValues = (List<FeatureValueData>) featureData.getFeatureValues();
			if (CollectionUtils.isNotEmpty(featureValues))
			{
				final String featureName = featureData.getName();
				if (StringUtils.isEmpty(featureName))
				{
					continue;
				}
				if (StringUtils.isNotEmpty(StringUtils.substringAfter(featureName, ".")))
				{
					final String name = StringUtils.substringAfter(featureName, ".");
					LOG.debug("feature name " + name);
					classificationAttributes.put(name, featureValues.get(0).getValue());
				}
				else if (!StringUtils.contains(featureName, "."))
				{
					LOG.debug("feature name " + featureName);
					classificationAttributes.put(featureName, featureValues.get(0).getValue());
				}
			}
		}
	}

	@Override
	protected void setUpMetaData(final Model model, final String metaKeywords, final String metaDescription)
	{
		final List<MetaElementData> metadata = new LinkedList<>();
		final ProductModel product = sessionService.getAttribute(PRODUCT);
		metadata.add(createMetaElement("keywords", metaKeywords));
		metadata.add(
				createMetaElement("description", product.getDescription() + ' ' + getCmsSiteService().getCurrentSite().getName()));
		metadata.add(createMetaElementProperty("og:url", sessionService.getAttribute(REQUESTURL).toString()));
		metadata.add(createMetaElementProperty("og:type", "Website"));
		metadata.add(createMetaElementProperty("og:description", product.getDescription()));
		metadata.add(createMetaElementProperty("og:title",
				getPageTitleResolver().resolveProductPageTitle(product.getCode().replace('|', '-'))));
		metadata.add(createMetaElementProperty("og:image", (product.getPicture() != null) ? product.getPicture().getURL() : ""));
		model.addAttribute(HPEStorefrontConstant.METATAGS, metadata);
	}

	protected MetaElementData createMetaElementProperty(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}

	//Method to find script tag for video as a part of SEO implementation
	public void generateScriptJson(final ProductData productData, final Model model, final HPEVideoData hpeVideoData)
			throws JSONException
	{
		String message = null;
		JSONObject formDetailsResult = new JSONObject();
		final JSONArray jsonArray = new JSONArray();
		if (CollectionUtils.isNotEmpty(productData.getImages()))
		{
			for (final ImageData image : productData.getImages())
			{
				if (ImageDataType.GALLERY.equals(image.getImageType()))
				{
					LOG.debug("--generateScriptJson() method--");
					formDetailsResult = createJSONScript(productData, image);
				}
				jsonArray.add(formDetailsResult);
			}
			message = jsonArray.toString();
		}
		else
		{
			message = "";
		}
		model.addAttribute(HPEStorefrontConstant.SCRIPTVIDEO, message.trim());
	}

	public JSONObject createJSONScript(final ProductData productData, final ImageData image) throws JSONException
	{
		final JSONObject formDetailsJson = new JSONObject();
		LOG.debug("------In createJSONScript-----------");
		if (image.getBcReferenceId() != null)
		{
			LOG.debug("------In createJSONScript bcreferecne  ID is not null-----------");
			formDetailsJson.put("name:", productData.getName());
			formDetailsJson.put("@id:", image.getBcReferenceId());
			formDetailsJson.put("@type:", image.getImageType());
			formDetailsJson.put("description:", productData.getImages().iterator().next().getAltText() != null
					? productData.getImages().iterator().next().getAltText() : "");
			formDetailsJson.put("@context:", "http://schema.org/");
			formDetailsJson.put("uploadDate:", UPLOAD_DATA_VIDEO);
			formDetailsJson.put("duration:", UPLOAD_DATA_VIDEO);
			formDetailsJson.put("embedURL:",
					"http://players.brightcove.net/4119874060001/b05b72e2-39ab-4441-8e06-e6a07a32d71d_default/index.html?videoId\\u003dref:d69557c1-1c30-4b83-93bb-8300ab7489a8");
			formDetailsJson.put("thumbnailURL:", image.getUrl());
		}
		LOG.debug("------In createJSONScript-----------" + formDetailsJson);
		return formDetailsJson;

	}

	protected void populateModel(final Model model, final SearchPageData<?> searchPageData, final ShowMode showMode)
	{
		final int numberPagesShown = getSiteConfigService().getInt(PAGINATION_NUMBER_OF_RESULTS_COUNT, 5);

		model.addAttribute("numberPagesShown", Integer.valueOf(numberPagesShown));
		model.addAttribute(SEARCH_PAGE_DATA, searchPageData);
		model.addAttribute("isShowAllAllowed", calculateShowAll(searchPageData, showMode));
		model.addAttribute("isShowPageAllowed", calculateShowPaged(searchPageData, showMode));
	}

	protected Boolean calculateShowAll(final SearchPageData<?> searchPageData, final ShowMode showMode)
	{
		return Boolean.valueOf((showMode != ShowMode.All && //
				searchPageData.getPagination().getTotalNumberOfResults() > searchPageData.getPagination().getPageSize())
				&& isShowAllAllowed(searchPageData));
	}

	protected boolean isShowAllAllowed(final SearchPageData<?> searchPageData)
	{
		return searchPageData.getPagination().getNumberOfPages() > 1
				&& searchPageData.getPagination().getTotalNumberOfResults() < MAX_PAGE_LIMIT;
	}

	protected Boolean calculateShowPaged(final SearchPageData<?> searchPageData, final ShowMode showMode)
	{
		return Boolean.valueOf(showMode == ShowMode.All && (searchPageData.getPagination().getNumberOfPages() > 1
				|| searchPageData.getPagination().getPageSize() == getMaxSearchPageSize()));
	}

	protected int getMaxSearchPageSize()
	{
		return MAX_PAGE_LIMIT;
	}

	protected int getSearchPageSize()
	{
		return getSiteConfigService().getInt("storefront.search.pageSize", 0);
	}

}
