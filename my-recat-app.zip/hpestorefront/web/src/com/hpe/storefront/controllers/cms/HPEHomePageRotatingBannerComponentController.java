/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.c2l.LanguageModel;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.HPEHomePageRotatingBannerComponentModel;
import com.hpe.facades.category.HPECategory;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 * @author AM20013064
 *
 */
@Controller("HPEHomePageRotatingBannerComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.HPEHomePageRotatingBannerComponent)
public class HPEHomePageRotatingBannerComponentController
		extends AbstractCMSComponentController<HPEHomePageRotatingBannerComponentModel>
{
	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;

	@Resource(name = "hpeCategory")
	private HPECategory hpeCategory;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final HPEHomePageRotatingBannerComponentModel component)
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
		final LanguageModel currentLanguage = hpeCategory.getCurrentLanguage();
		model.addAttribute("media", component.getMedia());
		model.addAttribute("content", component.getContent());
		model.addAttribute("headline", component.getHeadline());
		model.addAttribute("linkName", component.getLinkName());
		if (component.getUrlLink() != null)
		{
			if (component.getUrlLink().contains("http"))
			{
				model.addAttribute("urlLink", component.getUrlLink());
			}
			else
			{
				model.addAttribute("urlLink",
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getUrlLink());
			}
		}
		else
		{
			model.addAttribute("urlLink", "/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}
		model.addAttribute("linkName1", component.getLinkName1());
		if (component.getUrlLink1() != null)
		{
			if (component.getUrlLink1().contains("http"))
			{
				model.addAttribute("urlLink1", component.getUrlLink1());
			}
			else
			{
				model.addAttribute("urlLink1",
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getUrlLink1());
			}
		}
		else
		{
			model.addAttribute("urlLink1", "/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}
	}

	@Override
	protected String getView(final HPEHomePageRotatingBannerComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(HPEHomePageRotatingBannerComponentModel._TYPECODE);

	}

}
