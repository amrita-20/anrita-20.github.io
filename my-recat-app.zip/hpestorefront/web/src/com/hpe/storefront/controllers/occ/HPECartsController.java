/**
 *
 */
package com.hpe.storefront.controllers.occ;

import de.hybris.platform.commercefacades.user.UserFacade;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hpe.facades.occ.HPECartsFacade;
import com.hpe.storefront.security.cookie.HPELoggedInUserNotificationCookieGenerator;


/**
 * @author chenna
 *
 */
@RestController
@RequestMapping(value = "/mycart")
public class HPECartsController extends HPEDefaultOccController
{
	private static final Logger LOG = Logger.getLogger(HPECartsController.class);
	private static final String CART_NOT_FOUND = "Cart Not Found";
	private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
	private static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
	@Resource(name = "hpeCartsFacade")
	private HPECartsFacade hpeCartsFacade;
	@Resource(name = "loggedInUserNotificationCookieGenerator")
	private HPELoggedInUserNotificationCookieGenerator loggedInUserNotificationCookieGenerator;
	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@GetMapping
	public String getCartDetails(final HttpServletRequest request, final HttpServletResponse response)
	{

		ResponseEntity<String> cartResponse = null;
		response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, getAccessControlAllowOrigin(request));
		response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");

		if (userFacade.isAnonymousUser())
		{
			loggedInUserNotificationCookieGenerator.removeCookie(request, response);
		}
		try
		{
			cartResponse = hpeCartsFacade.getCartDetails(getAnonymousGuid(request));
		}
		catch (final Exception ex)
		{
			LOG.error("HPECartsController:::getCartDetails::: Not able to retrive any cart information", ex);
			return CART_NOT_FOUND;
		}
		if (cartResponse == null)
		{
			return CART_NOT_FOUND;
		}
		return cartResponse.getBody();
	}
}