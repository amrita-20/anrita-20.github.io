/**
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorfacades.cart.action.CartEntryAction;
import de.hybris.platform.acceleratorfacades.cart.action.CartEntryActionFacade;
import de.hybris.platform.acceleratorfacades.csv.CsvFacade;
import de.hybris.platform.acceleratorfacades.flow.impl.SessionOverrideCheckoutFlowFacade;
import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorservices.enums.CheckoutFlowEnum;
import de.hybris.platform.acceleratorservices.enums.CheckoutPciOptionEnum;
import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.breadcrumb.ResourceBreadcrumbBuilder;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractCartPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.SaveCartForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.UpdateQuantityForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.VoucherForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.SaveCartFormValidator;
import de.hybris.platform.acceleratorstorefrontcommons.util.XSSFilterUtil;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.EntryGroupData;
import de.hybris.platform.commercefacades.order.SaveCartFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.CartModificationData;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartParameterData;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartResultData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.quote.data.QuoteData;
import de.hybris.platform.commercefacades.voucher.VoucherFacade;
import de.hybris.platform.commercefacades.voucher.exceptions.VoucherOperationException;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.order.CommerceSaveCartException;
import de.hybris.platform.configurablebundleservices.bundle.BundleTemplateService;
import de.hybris.platform.configurablebundleservices.model.BundleTemplateModel;
import de.hybris.platform.core.enums.QuoteState;
import de.hybris.platform.enumeration.EnumerationService;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.search.restriction.SearchRestrictionService;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.site.BaseSiteService;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.core.constants.HpeCoreConstants;
import com.hpe.facades.order.HPECartFacade;
import com.hpe.facades.util.HPEFacadeGenericUtil;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.security.cookie.HPEUserCartNotificationCookieGenerator;
import com.hpe.storefront.util.HPEAnalyticsUtil;

/**
 * Controller for cart page
 */
@Controller
@RequestMapping(value = "/cart")
public class HPECartPageController extends AbstractCartPageController
{
	public static final Logger LOG = Logger.getLogger(HPECartPageController.class);

	public static final String SHOW_CHECKOUT_STRATEGY_OPTIONS = "storefront.show.checkout.flows";
	@Resource(name = "simpleBreadcrumbBuilder")
	private ResourceBreadcrumbBuilder resourceBreadcrumbBuilder;

	@Resource(name = "enumerationService")
	private EnumerationService enumerationService;

	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "saveCartFacade")
	private SaveCartFacade saveCartFacade;

	@Resource(name = "saveCartFormValidator")
	private SaveCartFormValidator saveCartFormValidator;

	@Resource(name = "csvFacade")
	private CsvFacade csvFacade;

	@Resource(name = "voucherFacade")
	private VoucherFacade voucherFacade;

	@Resource(name = "baseSiteService")
	private BaseSiteService baseSiteService;

	@Resource(name = "cartEntryActionFacade")
	private CartEntryActionFacade cartEntryActionFacade;

	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;

	@Resource(name = "bundleTemplateService")
	private BundleTemplateService bundleTemplateService;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource
	private MessageSource messageSource;

	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "userCartNotificationCookieGenerator")
	private HPEUserCartNotificationCookieGenerator userCartNotificationCookieGenerator;

	@Resource(name = "searchRestrictionService")
	private SearchRestrictionService searchRestrictionService;

	@Resource(name = "hpeFacadeGenericUtil")
	private HPEFacadeGenericUtil hpeFacadeGenericUtil;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@ModelAttribute("showCheckoutStrategies")
	public boolean isCheckoutStrategyVisible()
	{
		return getSiteConfigService().getBoolean(SHOW_CHECKOUT_STRATEGY_OPTIONS, false);
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))//this is how the endsWith method take the paramerter it is java recommendation.
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}

	@RequestMapping(method = RequestMethod.GET)
	public String showCart(final Model model, final RedirectAttributes redirectModel, final HttpServletRequest request,
			final HttpServletResponse response) throws CMSItemNotFoundException
	{
		final List<MetaElementData> metadata = new LinkedList();
		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCartDataJsonObjectForAnalytics();
		model.addAttribute(HPEStorefrontConstant.CART_DATA_JSON_OBJECT, cartDataJsonObject);

		final String metaKeywords = configurationService.getConfiguration().getString(HPEStorefrontConstant.SECO_META_KEYWORD);
		metadata.add(createMetaElementProperty(HPEStorefrontConstant.KEYWORDS, metaKeywords));

		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);

		final String cartUrl = prepareCartUrl(model, redirectModel);
		userCartIndicatorCookie(request, response);
		return cartUrl;
	}

	protected String prepareCartUrl(final Model model, final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		final Optional<String> quoteEditUrl = getQuoteUrl();
		if (quoteEditUrl.isPresent())
		{
			return quoteEditUrl.get();
		}
		else
		{

			checkCartConditionalChecks(model);

			final boolean flag = hpeCartFacade.recalculateCart();
			if (flag)
			{
				LOG.debug(HPEStorefrontConstant.CART_IS_RE_CALCULATED_SUCCESSFULLY);
			}

			prepareDataForPage(model);
			bundleProductConfigEntryList(model);
			hpeFacadeGenericUtil.miraklShopName(model);


			return ControllerConstants.Views.Pages.Cart.CartPage;
		}
	}
/**
 * Mehtod to check cart condtional checks
 * @param model
 */
	public void checkCartConditionalChecks(Model model)
	{
		if(checkUnApprovedProductsInCart(model))
		{
			LOG.debug("Found Un Approved products in Cart");
			
		}else	if(checkCartEntryStock(model))
		{
			LOG.debug("Found Out of stock products in Cart");
			
		}else if(checkShopDisableInCart(model))
		{
			LOG.debug("Found shop disable products in Cart");
			
		}else	if(checkMultiResellerInCart(model))
		{
			LOG.debug("Found Multi reseller products in Cart");
			
		}else	if(checkProductRestrictionProductsInCart(model)){
			
			LOG.debug("Met product restriction condition in Cart");
		}
	}

	/**
	 * Method to verify Multi reseller products in cart
	 *
	 * @param model
	 */
	private boolean checkMultiResellerInCart(final Model model)
	{
		boolean flag = false;
		final boolean restrictMultiReseller = configurationService.getConfiguration()
				.getBoolean(HpeCoreConstants.MULTI_RESELLER_RESTRICTION);

		if (JaloSession.getCurrentSession().getAttribute("sesison_multi_reseller") != null)
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource.getMessage(
					HPEStorefrontConstant.BASKET_MULTIRESELLER_DISABLE_CHECKOUT, null, getI18nService().getCurrentLocale()));
			JaloSession.getCurrentSession().removeAttribute("sesison_multi_reseller");
		}
		else if (restrictMultiReseller && hpeCartFacade.checkMultiResellerInCart())
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource.getMessage(
					HPEStorefrontConstant.BASKET_MULTIRESELLER_DISABLE_CHECKOUT, null, getI18nService().getCurrentLocale()));
			model.addAttribute(HPEStorefrontConstant.CART_MULTIRESELLER, "true");
		}
		return flag;
	}

	/**
	 * Method to check product restriction products in Cart
	 *
	 * @param model
	 */
	private boolean checkProductRestrictionProductsInCart(final Model model)
	{
		boolean flag = false;
		if (JaloSession.getCurrentSession().getAttribute("session_product_restriction") != null)
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource.getMessage(
					HPEStorefrontConstant.BASKET_PRODUCTRESTRICTION_DISABLE_CHECKOUT, null, getI18nService().getCurrentLocale()));
			model.addAttribute(HPEStorefrontConstant.PRDRESTRICTION, "true");
			JaloSession.getCurrentSession().removeAttribute("session_product_restriction");
			model.addAttribute(HPEStorefrontConstant.PRODUCT_RESTRICTION_FLAG, true);
		}
		else if (!hpeCartFacade.checkMustBeSoldWithSystem())
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource.getMessage(
					HPEStorefrontConstant.BASKET_PRODUCTRESTRICTION_DISABLE_CHECKOUT, null, getI18nService().getCurrentLocale()));
			model.addAttribute(HPEStorefrontConstant.PRDRESTRICTION, "true");
		}
		return flag;
	}

	/**
	 * Method to verify out of the stock products in cart
	 *
	 * @param model
	 */
	private boolean checkCartEntryStock(final Model model)
	{
		boolean flag = false;

		final StringBuilder sessionProductOutOfStock = (StringBuilder) JaloSession.getCurrentSession()
				.getAttribute("session_product_outofstock");

		if (JaloSession.getCurrentSession().getAttribute("session_product_outofstock") != null)
		{
			flag = true;

			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE,
					messageSource.getMessage(HPEStorefrontConstant.BASKET_PRODUCT_STOCK_CART, new Object[]
					{ sessionProductOutOfStock.substring(0, sessionProductOutOfStock.length() - 1) }, getI18nService().getCurrentLocale()));

			JaloSession.getCurrentSession().removeAttribute("session_product_outofstock");
		}

		else
		{
			final StringBuilder productsOutOfStock = hpeCartFacade.checkCartEntryStock();

			if (productsOutOfStock != null)
			{
				model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE,
						messageSource.getMessage(HPEStorefrontConstant.BASKET_PRODUCT_STOCK_CART, new Object[]
						{ productsOutOfStock.substring(0, productsOutOfStock.length() - 1) }, getI18nService().getCurrentLocale()));
				flag = true;
			}
		}
		return flag;
	}


	/**
	 * Method to verify out of the stock products in cart
	 *
	 * @param model
	 */
	private boolean checkUnApprovedProductsInCart(final Model model)
	{
		boolean flag = false;

		final StringBuilder sessionUnApprovedProducts = (StringBuilder) JaloSession.getCurrentSession()
				.getAttribute("session_unapproved_products");

		if (JaloSession.getCurrentSession().getAttribute("session_unapproved_products") != null)
		{
			flag = true;

			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE,
					messageSource.getMessage(HPEStorefrontConstant.BASKET_PRODUCT_UNAPPROVED_CHECK, new Object[]
					{ sessionUnApprovedProducts.substring(0, sessionUnApprovedProducts.length() - 1) }, getI18nService().getCurrentLocale()));
			JaloSession.getCurrentSession().removeAttribute("session_unapproved_products");
		}

		else
		{
			final StringBuilder unApprovedProducts = hpeCartFacade.checkProductAvailabilityInCart();

			if (unApprovedProducts != null)
			{
				model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE,
						messageSource.getMessage(HPEStorefrontConstant.BASKET_PRODUCT_UNAPPROVED_CHECK, new Object[]
						{ unApprovedProducts.substring(0, unApprovedProducts.length() - 1) }, getI18nService().getCurrentLocale()));

				flag = true;
			}
		}
		return flag;
	}



	/**
	 * Method to verify Multi reseller products in cart
	 *
	 * @param model
	 */
	private boolean checkShopDisableInCart(final Model model)
	{

		boolean flag = false;

		if (JaloSession.getCurrentSession().getAttribute("session_shop_disable") != null)
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource
					.getMessage(HPEStorefrontConstant.BASKET_SHOPDISABLE_REMOVE_CART, null, getI18nService().getCurrentLocale()));
			JaloSession.getCurrentSession().removeAttribute("session_shop_disable");
		}
		else if (hpeCartFacade.getUpdateCartForShopDisable())
		{
			flag = true;
			model.addAttribute(HPEStorefrontConstant.REMOVE_MESSAGE, messageSource
					.getMessage(HPEStorefrontConstant.BASKET_SHOPDISABLE_REMOVE_CART, null, getI18nService().getCurrentLocale()));
		}
		return flag;
	}


	/**
	 * Method to set the channel central bundle products to config entries of CartData.
	 *
	 * @param model
	 */
	private void bundleProductConfigEntryList(final Model model)
	{
		String productCode = null;
		ProductData productData = null;
		ProductData variantProductData = null;
		final List<OrderEntryData> configEntries = new ArrayList<>();
		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.URL));

		final Map<String, Object> cartMap = model.asMap();
		CartData cartData = (CartData) cartMap.get(HPEStorefrontConstant.CART_DATA);

		if (cartData == null)
		{
			cartData = getCartFacade().getSessionCart();
		}

		if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
		{
			for (final OrderEntryData entry : cartData.getEntries())
			{
				productCode = entry.getProduct().getBaseProduct();
				if (null != productCode)
				{
					try
					{
						productData = productFacade.getProductForCodeAndOptions(productCode, options);
						entry.getProduct().setBaseProductUrl(productData.getUrl());
					}
					catch (final UnknownIdentifierException e)
					{

						LOG.warn("Product Not found with product code [" + productCode + "]");					
					}
				}
				if (null != productCode && null != entry.getConfigID() && entry.getIsStarterProduct() && productData != null)
				{
					entry.getProduct().setBaseProductUrl(productData.getUrl());
				}

				if (StringUtils.isNotEmpty(entry.getConfigID()))
				{
					configEntries.add(entry);
				}
				// Resetting the objects
				productData = variantProductData = null;

			}
		}
		cartData = removeEntriesForConfig(configEntries, cartData);
		hpeFacadeGenericUtil.miraklShopName(model);
		model.addAttribute(HPEStorefrontConstant.CART_DATA, cartData);
	}

	/**
	 * @param productCode
	 * @param variantProductCode
	 * @param productData
	 * @param variantProductData
	 * @param options
	 * @param builder
	 */
	public void modifySearchRestriction(final String productCode, final String variantProductCode, final ProductData productData,
			final ProductData variantProductData, final List<ProductOption> options, final StringBuilder builder)
	{
		LOG.debug("HPECartPageController:modifySearchRestriction :: Entered into method to have a check: productCode: "
				+ productCode + ", variantProductCode :: " + variantProductCode);

		searchRestrictionService.disableSearchRestrictions();

		String productName = "";
		ProductData product = null;
		if (productData == null)
		{
			product = productFacade.getProductForCodeAndOptions(productCode, options);

		}
		else if (variantProductData == null)
		{
			product = productFacade.getProductForCodeAndOptions(variantProductCode, options);
		}

		if (product != null)
		{
			productName = product.getName();
			LOG.debug("HPECartPageController:modifySearchRestriction :: product loaded from DB and productName: " + productName);
		}
		builder.append(productName + ",");
		searchRestrictionService.enableSearchRestrictions();
	}

	/**
	 * @param configEntries
	 * @param cartData
	 * @return
	 */
	private CartData removeEntriesForConfig(final List<OrderEntryData> configEntries, CartData cartData)
	{
		cartData = hpeCartFacade.getConfigEntries(configEntries, cartData);

		if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
		{
			cartData.getEntries().removeAll(configEntries);
		}
		return cartData;
	}

	/**
	 * @param model
	 * @param isProductAvailable
	 * @param isVariantProductAvailable
	 * @param builder
	 */
	public void setProductAvailability(final Model model, final boolean isProductAvailable,
			final boolean isVariantProductAvailable, final StringBuilder builder)
	{
		if(BooleanUtils.isFalse(isProductAvailable))
		{
			model.addAttribute(HPEStorefrontConstant.IS_PRODUCT_AVAILABLE, isProductAvailable);
			model.addAttribute(HPEStorefrontConstant.IS_VARIANT_PRODUCT_AVAILABLE, isVariantProductAvailable);

			final String productNames = builder.toString();
			LOG.debug(
					"HPECartPageController:setProductAvailability: Since Product un availble, setting error message with the builder message :: "
							+ productNames);
			GlobalMessages.addMessage(model, GlobalMessages.INFO_MESSAGES_HOLDER, "hpestorefront.savedcart.message", new Object[]
			{ productNames.substring(0, productNames.length() - 1) });

		}
	}

	protected Optional<String> getQuoteUrl()
	{
		final QuoteData quoteData = getCartFacade().getSessionCart().getQuoteData();

		if (quoteData != null)
		{
			if (QuoteState.BUYER_OFFER.equals(quoteData.getState()))
			{
				return Optional.of(String.format(HPEStorefrontConstant.REDIRECT_QUOTE_VIEW_URL, urlEncode(quoteData.getCode())));
			}
			else
			{
				return Optional.of(String.format(HPEStorefrontConstant.REDIRECT_QUOTE_EDIT_URL, urlEncode(quoteData.getCode())));
			}
		}
		else
		{
			return Optional.empty();
		}
	}

	/**
	 * Handle the '/cart/checkout' request url. This method checks to see if the cart is valid before allowing the
	 * checkout to begin. Note that this method does not require the user to be authenticated and therefore allows us to
	 * validate that the cart is valid without first forcing the user to login. The cart will be checked again once the
	 * user has logged in.
	 *
	 * @return The page to redirect to
	 */
	@RequestMapping(value = "/checkout", method = RequestMethod.GET)
	@RequireHardLogIn
	public String cartCheck(final RedirectAttributes redirectModel) throws CommerceCartModificationException
	{
		SessionOverrideCheckoutFlowFacade.resetSessionOverrides();

		if (!getCartFacade().hasEntries())
		{
			LOG.debug("Missing or empty cart");

			// No session cart or empty session cart. Bounce back to the cart page.
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.error.checkout.empty.cart",
					null);
			return HPEStorefrontConstant.REDIRECT_CART_URL;
		}


		// Redirect to the start of the checkout flow to begin the checkout process
		// We just redirect to the generic '/checkout' page which will actually select the checkout flow
		// to use. The customer is not necessarily logged in on this request, but will be forced to login
		// when they arrive on the '/checkout' page.
		return REDIRECT_PREFIX + "/checkout";
	}

	@RequestMapping(value = "/getProductVariantMatrix", method = RequestMethod.GET)
	public String getProductVariantMatrix(@RequestParam("productCode")
	final String productCode, @RequestParam(value = HPEStorefrontConstant.READ_ONLY, required = false, defaultValue = "false")
	final String readOnly, final Model model)
	{
		final ProductData productData = productFacade.getProductForCodeAndOptions(productCode,
				Arrays.asList(ProductOption.BASIC, ProductOption.CATEGORIES, ProductOption.VARIANT_MATRIX_BASE,
						ProductOption.VARIANT_MATRIX_PRICE, ProductOption.VARIANT_MATRIX_MEDIA, ProductOption.VARIANT_MATRIX_STOCK,
						ProductOption.VARIANT_MATRIX_URL));

		model.addAttribute(HPEStorefrontConstant.PRODUCT, productData);
		model.addAttribute(HPEStorefrontConstant.READ_ONLY, Boolean.valueOf(readOnly));

		return ControllerConstants.Views.Fragments.Cart.ExpandGridInCart;
	}

	// This controller method is used to allow the site to force the visitor through a specified checkout flow.
	// If you only have a static configured checkout flow then you can remove this method.
	@RequestMapping(value = "/checkout/select-flow", method = RequestMethod.GET)
	@RequireHardLogIn
	public String initCheck(final Model model, final RedirectAttributes redirectModel,
			@RequestParam(value = "flow", required = false)
			final String flow, @RequestParam(value = "pci", required = false)
			final String pci) throws CommerceCartModificationException
	{
		SessionOverrideCheckoutFlowFacade.resetSessionOverrides();

		if (!getCartFacade().hasEntries())
		{
			LOG.debug("Missing or empty cart");

			// No session cart or empty session cart. Bounce back to the cart page.
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.error.checkout.empty.cart",
					null);
			return HPEStorefrontConstant.REDIRECT_CART_URL;
		}

		// Override the Checkout Flow setting in the session
		if (StringUtils.isNotBlank(flow))
		{
			final CheckoutFlowEnum checkoutFlow = enumerationService.getEnumerationValue(CheckoutFlowEnum.class,
					StringUtils.upperCase(flow));
			SessionOverrideCheckoutFlowFacade.setSessionOverrideCheckoutFlow(checkoutFlow);
		}

		// Override the Checkout PCI setting in the session
		if (StringUtils.isNotBlank(pci))
		{
			final CheckoutPciOptionEnum checkoutPci = enumerationService.getEnumerationValue(CheckoutPciOptionEnum.class,
					StringUtils.upperCase(pci));
			SessionOverrideCheckoutFlowFacade.setSessionOverrideSubscriptionPciOption(checkoutPci);
		}

		// Redirect to the start of the checkout flow to begin the checkout process
		// We just redirect to the generic '/checkout' page which will actually select the checkout flow
		// to use. The customer is not necessarily logged in on this request, but will be forced to login
		// when they arrive on the '/checkout' page.
		return REDIRECT_PREFIX + "/checkout";
	}

	@RequestMapping(value = "/entrygroups/{groupNumber}", method = RequestMethod.POST)
	public String removeGroup(@PathVariable("groupNumber")
	final Integer groupNumber, final Model model, final RedirectAttributes redirectModel)
	{
		return removeBundle(groupNumber, model, redirectModel);
	}

	/**
	 * @param groupNumber
	 * @param model
	 * @param redirectModel
	 */
	private String removeBundle(final Integer groupNumber, final Model model, final RedirectAttributes redirectModel)
	{
		final CartModificationData cartModification;
		try
		{
			cartModification = hpeCartFacade.removeEntryGroup(groupNumber);
			if (cartModification != null && !StringUtils.isEmpty(cartModification.getStatusMessage()))
			{
				GlobalMessages.addErrorMessage(model, cartModification.getStatusMessage());
			}
		}
		catch (final CommerceCartModificationException e)
		{
			LOG.error(e.getMessage(), e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.error.entrygroup.remove",
					new Object[]
					{ groupNumber });
		}
		return HPEStorefrontConstant.REDIRECT_CART_URL;
	}

	@RequestMapping(value = "/updateBundle", method = RequestMethod.POST)
	public String updateCartBundleQuantities(@RequestParam("groupNumber")
	final int groupNumber, @RequestParam("bundleID")
	final String bundleID, final Model model, @Valid
	final UpdateQuantityForm form, final BindingResult bindingResult, final HttpServletRequest request,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException, CommerceCartModificationException
	{
		final BundleTemplateModel bundleTemplate = bundleTemplateService.getBundleTemplateForCode(bundleID);
		if (null == form.getQuantity() || form.getQuantity() == 0)
		{
			return removeBundle(groupNumber, model, redirectModel);
		}
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				if (HPEStorefrontConstant.TYPE_MISMATCH.equals(error.getCode()))
				{
					GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.BASKET_ERROR_QUANTITY_INVALID);
				}
				else
				{
					GlobalMessages.addErrorMessage(model, error.getDefaultMessage());
				}
			}
		}
		else if (bundleTemplate != null)
		{
			final CartData cartData = getCartFacade().getSessionCart();
			for (final EntryGroupData entryGroupData : cartData.getRootGroups())
			{
				if (null != entryGroupData.getRootGroup().getExternalReferenceId()
						&& entryGroupData.getRootGroup().getExternalReferenceId().equals(bundleTemplate.getId()))
				{
					for (final OrderEntryData entry : entryGroupData.getOrderEntries())
					{
						hpeCartFacade.updateCartEntry(entry.getEntryNumber(), form.getQuantity().longValue());
					}
				}
			}
			return getCartPageRedirectUrl();
		}
		model.addAttribute(HPEStorefrontConstant.QUANTITY, form.getQuantity().longValue());
		return prepareCartUrl(model, redirectModel);
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateCartQuantities(@RequestParam("entryNumber")
	final long entryNumber, final Model model, @Valid
	final UpdateQuantityForm form, final BindingResult bindingResult, final HttpServletRequest request,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException, CommerceCartModificationException
	{
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				if (HPEStorefrontConstant.TYPE_MISMATCH.equals(error.getCode()))
				{
					GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.BASKET_ERROR_QUANTITY_INVALID);
				}
				else
				{
					GlobalMessages.addErrorMessage(model, error.getDefaultMessage());
				}
			}
		}
		else if (getCartFacade().hasEntries())
		{
			updateChannelCenterBundle(entryNumber, form);
			final CartModificationData cartModification = hpeCartFacade.updateCartEntry(entryNumber, form.getQuantity().longValue());
			addFlashMessage(form, request, redirectModel, cartModification);
			bundleProductConfigEntryList(model);

			// Redirect to the cart page on update success so that the browser doesn't re-post again
			return getCartPageRedirectUrl();
		}

		// if could not update cart, display cart/quote page again with error
		return prepareCartUrl(model, redirectModel);
	}

	@Override
	protected void prepareDataForPage(final Model model) throws CMSItemNotFoundException
	{
		super.prepareDataForPage(model);

		if (!model.containsAttribute(HPEStorefrontConstant.VOUCHER_FORM))
		{
			model.addAttribute(HPEStorefrontConstant.VOUCHER_FORM, new VoucherForm());
		}

		// Because DefaultSiteConfigService.getProperty() doesn't set default boolean value for undefined property,
		// this property key was generated to use Config.getBoolean() method
		final String siteQuoteProperty = HPEStorefrontConstant.SITE_QUOTES_ENABLED
				.concat(getBaseSiteService().getCurrentBaseSite().getUid());
		model.addAttribute(HPEStorefrontConstant.SITE_QUOTE_ENABLED,
				configurationService.getConfiguration().getBoolean(siteQuoteProperty, Boolean.FALSE));
		model.addAttribute(HPEStorefrontConstant.PAGE_TYPE, PageType.CART.name());
	}

	protected void addFlashMessage(final UpdateQuantityForm form, final HttpServletRequest request,
			final RedirectAttributes redirectModel, final CartModificationData cartModification)
	{
		if (cartModification.getQuantity() == form.getQuantity().longValue())
		{
			// Success
			if (cartModification.getQuantity() == 0)
			{
				// Success in removing entry
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, "basket.page.message.remove");
			}
			else
			{
				// Success in update quantity
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, "basket.page.message.update");
			}
		}
		else if (cartModification.getQuantity() > 0)
		{
			// Less than successful
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					"basket.page.message.update.reducedNumberOfItemsAdded.lowStock", new Object[]
					{ XSSFilterUtil.filter(cartModification.getEntry().getProduct().getName()),
							Long.valueOf(cartModification.getQuantity()), form.getQuantity(),
							request.getRequestURL().append(cartModification.getEntry().getProduct().getUrl()) });
		}
		else
		{
			// No more stock available
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					"basket.page.message.update.reducedNumberOfItemsAdded.noStock", new Object[]
					{ XSSFilterUtil.filter(cartModification.getEntry().getProduct().getName()),
							request.getRequestURL().append(cartModification.getEntry().getProduct().getUrl()) });
		}
	}

	@SuppressWarnings("boxing")
	@ResponseBody
	@RequestMapping(value = "/updateMultiD", method = RequestMethod.POST)
	public CartData updateCartQuantitiesMultiD(@RequestParam("entryNumber")
	final Integer entryNumber, @RequestParam("productCode")
	final String productCode, final Model model, @Valid
	final UpdateQuantityForm form, final BindingResult bindingResult)
	{
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				if (HPEStorefrontConstant.TYPE_MISMATCH.equals(error.getCode()))
				{
					GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.BASKET_ERROR_QUANTITY_INVALID);
				}
				else
				{
					GlobalMessages.addErrorMessage(model, error.getDefaultMessage());
				}
			}
		}
		else
		{
			try
			{
				final CartModificationData cartModification = getCartFacade()
						.updateCartEntry(getOrderEntryData(form.getQuantity(), productCode, entryNumber));
				if (cartModification.getStatusCode().equals(HPEStorefrontConstant.SUCCESSFUL_MODIFICATION_CODE))
				{
					GlobalMessages.addMessage(model, GlobalMessages.CONF_MESSAGES_HOLDER, cartModification.getStatusMessage(), null);
				}
				else if (!model.containsAttribute(HPEStorefrontConstant.ERROR_MSG_TYPE))
				{
					GlobalMessages.addMessage(model, GlobalMessages.ERROR_MESSAGES_HOLDER, cartModification.getStatusMessage(), null);
				}
			}
			catch (final CommerceCartModificationException ex)
			{
				LOG.warn("Couldn't update product with the entry number: " + entryNumber + ".", ex);
			}
		}
		return getCartFacade().getSessionCart();
	}

	@SuppressWarnings("boxing")
	protected OrderEntryData getOrderEntryData(final long quantity, final String productCode, final Integer entryNumber)
	{
		final OrderEntryData orderEntry = new OrderEntryData();
		orderEntry.setQuantity(quantity);
		orderEntry.setProduct(new ProductData());
		orderEntry.getProduct().setCode(productCode);
		orderEntry.setEntryNumber(entryNumber);
		return orderEntry;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	@RequireHardLogIn
	public String saveCart(final SaveCartForm form, final BindingResult bindingResult, final RedirectAttributes redirectModel)
			throws CommerceSaveCartException
	{
		saveCartFormValidator.validate(form, bindingResult);
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, error.getCode());
			}
			redirectModel.addFlashAttribute(HPEStorefrontConstant.SAVE_CART_FORM, form);
		}
		else
		{
			final CommerceSaveCartParameterData commerceSaveCartParameterData = new CommerceSaveCartParameterData();
			commerceSaveCartParameterData.setName(form.getName());
			commerceSaveCartParameterData.setDescription(form.getDescription());
			commerceSaveCartParameterData.setEnableHooks(true);
			try
			{
				final CommerceSaveCartResultData saveCartData = saveCartFacade.saveCart(commerceSaveCartParameterData);
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, "basket.save.cart.on.success",
						new Object[]
						{ saveCartData.getSavedCartData().getName() });
			}
			catch (final CommerceSaveCartException csce)
			{
				LOG.error(csce.getMessage(), csce);
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.save.cart.on.error",
						new Object[]
						{ form.getName() });
			}
		}
		return HPEStorefrontConstant.REDIRECT_CART_URL;
	}

	@RequestMapping(value = "/export", method = RequestMethod.GET, produces = "text/csv")
	public String exportCsvFile(final HttpServletResponse response, final RedirectAttributes redirectModel) throws IOException
	{
		response.setHeader(HPEStorefrontConstant.CONTENT_DESCRIPTION, "attachment;filename=cart.csv");

		try (final StringWriter writer = new StringWriter())
		{
			try
			{
				final List<String> headers = new ArrayList<>();
				headers.add(getMessageSource().getMessage("basket.export.cart.item.sku", null, getI18nService().getCurrentLocale()));
				headers.add(
						getMessageSource().getMessage("basket.export.cart.item.quantity", null, getI18nService().getCurrentLocale()));
				headers.add(getMessageSource().getMessage("basket.export.cart.item.name", null, getI18nService().getCurrentLocale()));
				headers
						.add(getMessageSource().getMessage("basket.export.cart.item.price", null, getI18nService().getCurrentLocale()));

				final CartData cartData = getCartFacade().getSessionCartWithEntryOrdering(false);
				csvFacade.generateCsvFromCart(headers, true, cartData, writer);

				StreamUtils.copy(writer.toString(), StandardCharsets.UTF_8, response.getOutputStream());
			}
			catch (final IOException e)
			{
				LOG.error(e.getMessage(), e);
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.export.cart.error", null);

				return HPEStorefrontConstant.REDIRECT_CART_URL;
			}
		}

		return null;
	}

	@RequestMapping(value = "/voucher/apply", method = RequestMethod.POST)
	public String applyVoucherAction(@Valid
	final VoucherForm form, final BindingResult bindingResult, final RedirectAttributes redirectAttributes)
	{
		try
		{
			if (bindingResult.hasErrors())
			{
				redirectAttributes.addFlashAttribute(HPEStorefrontConstant.ERROR_MSG,
						getMessageSource().getMessage("text.voucher.apply.invalid.error", null, getI18nService().getCurrentLocale()));
			}
			else
			{
				voucherFacade.applyVoucher(form.getVoucherCode());
				redirectAttributes.addFlashAttribute(HPEStorefrontConstant.SUCCESS_MSG,
						getMessageSource().getMessage("text.voucher.apply.applied.success", new Object[]
						{ form.getVoucherCode() }, getI18nService().getCurrentLocale()));
			}
		}
		catch (final VoucherOperationException e)
		{
			redirectAttributes.addFlashAttribute(HPEStorefrontConstant.VOUCHER_FORM, form);
			redirectAttributes.addFlashAttribute(HPEStorefrontConstant.ERROR_MSG,
					getMessageSource().getMessage(e.getMessage(), null,
							getMessageSource().getMessage("text.voucher.apply.invalid.error", null, getI18nService().getCurrentLocale()),
							getI18nService().getCurrentLocale()));
			if (LOG.isDebugEnabled())
			{
				LOG.debug(e.getMessage(), e);
			}
		}

		return HPEStorefrontConstant.REDIRECT_CART_URL;
	}

	@RequestMapping(value = "/voucher/remove", method = RequestMethod.POST)
	public String removeVoucher(@Valid
	final VoucherForm form, final RedirectAttributes redirectModel)
	{
		try
		{
			voucherFacade.releaseVoucher(form.getVoucherCode());
		}
		catch (final VoucherOperationException e)
		{
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "text.voucher.release.error",
					new Object[]
					{ form.getVoucherCode() });
			if (LOG.isDebugEnabled())
			{
				LOG.debug(e.getMessage(), e);
			}
		}

		return HPEStorefrontConstant.REDIRECT_CART_URL;
	}

	@RequestMapping(value = "/entry/execute/"
			+ HPEStorefrontConstant.ACTION_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.POST)
	public String executeCartEntryAction(@PathVariable(value = "actionCode", required = true)
	final String actionCode, final RedirectAttributes redirectModel, @RequestParam("entryNumbers")
	final Long[] entryNumbers)
	{

		try
		{
			CartEntryAction.valueOf(actionCode);
		}
		catch (final IllegalArgumentException e)
		{
			LOG.error(String.format("Unknown cart entry action %s", actionCode), e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.page.entry.unknownAction");
			return getCartPageRedirectUrl();
		}

		try
		{
			if (actionCode.equalsIgnoreCase(HPEStorefrontConstant.REMOVE))
			{
				for (final Long entryNumber : entryNumbers)
				{
					hpeCartFacade.updateCartEntry(entryNumber, 0);

				}
			}
                if(entryNumbers.length>1){
					hpeCartFacade.normalizeChannelCentralEntries();
				}
		}
		catch (final CommerceCartModificationException ex)
		{
			LOG.warn("Couldn't update product with the entry number", ex);
			return getCartPageRedirectUrl();
		}

		return getCartPageRedirectUrl();
	}

	protected String getCartPageRedirectUrl()
	{
		final QuoteData quoteData = getCartFacade().getSessionCart().getQuoteData();
		return quoteData != null ? String.format(HPEStorefrontConstant.REDIRECT_QUOTE_EDIT_URL, urlEncode(quoteData.getCode()))
				: HPEStorefrontConstant.REDIRECT_CART_URL;
	}

	@Override
	public BaseSiteService getBaseSiteService()
	{
		return baseSiteService;
	}

	public void setBaseSiteService(final BaseSiteService baseSiteService)
	{
		this.baseSiteService = baseSiteService;
	}

	protected MetaElementData createMetaElementProperty(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}

	private void userCartIndicatorCookie(final HttpServletRequest request, final HttpServletResponse response) //NOSONAR
	{
		if (hpeCartFacade.hasEntries())
		{
			userCartNotificationCookieGenerator.addCookie(request, response, Boolean.TRUE.toString());
		}
		else
		{
			userCartNotificationCookieGenerator.removeCookie(request, response);
		}
	}

	private void updateChannelCenterBundle(final long entryNumber, final UpdateQuantityForm form)
			throws CMSItemNotFoundException, CommerceCartModificationException
	{

		if (getCartFacade().getSessionCart().getEntries().get(Math.toIntExact(entryNumber)).getConfigID() != null)
		{
			for (final OrderEntryData entry : getCartFacade().getSessionCart().getEntries())
			{

				if (getCartFacade().getSessionCart().getEntries().get(Math.toIntExact(entryNumber)).getConfigID()
						.equalsIgnoreCase(entry.getConfigID()) && !entry.getIsStarterProduct())
				{
					hpeCartFacade.updateCartEntry(entry.getEntryNumber(), form.getQuantity().longValue() * (entry.getQuantity()
							/ (getCartFacade().getSessionCart().getEntries().get(Math.toIntExact(entryNumber)).getQuantity())));


				}
			}
		}

	}

}

