/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages.checkout.steps;

import static com.hpe.facades.util.PrepareRequestData.RPL_BILLINGADDRESS;

import de.hybris.platform.acceleratorservices.constants.GeneratedAcceleratorServicesConstants.Enumerations.CheckoutPciOptionEnum;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.PlaceOrderForm;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.gts.data.WePayRequestData;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.order.CartService;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.user.UserService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.facades.order.HPECartFacade;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.facades.util.GTSRequestData;
import com.hpe.facades.util.HPEFacadeGenericUtil;
import com.hpe.facades.wepay.HPEWePayAuthorizationFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.security.cookie.HPEUserCartNotificationCookieGenerator;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;
import com.hpe.wepay.service.impl.HPEPaymentAuthorizationResponse;
import com.mirakl.hybris.core.model.ShopModel;
import com.mirakl.hybris.core.shop.services.ShopService;


@Controller
@RequestMapping(value = "/checkout/multi/summary")
public class SummaryCheckoutStepController extends AbstractCheckoutStepController
{
	/**
	 *
	 */
	private static final String GTS_ERROR_EXCEPTION_MESSAGE = "gts.error.exception.message";

	/**
	 *
	 */
	private static final String GTS_ERROR_MESSAGE = "gts.error.message";

	private static final Logger LOGGER = Logger.getLogger(SummaryCheckoutStepController.class);

	private static final String AVALARA_EXTERNALTAX_ENABLED = "avalara.externaltax.enabled";
	private static final String SUMMARY = "summary";
	private static final String GTS_TRANSACTION_CHECK = "gts.transaction.check";
	private static final String PAYMENT_METHOD_CHECKOUTSTEP_URL="/checkout/multi/payment-method/add";
	private static final String PAYMENT_ERROR_MESSAGE="checkout.multi.paymentMethod.paymentservice.failedMsg";
	private static final String PAYMENT_AUTHORIZATION_ERROR="checkout.multi.paymentMethod.paymentservice.approvedstatemsg";
	private static final String GTS_GEOLOCATION_CHECK = "gts.geolocation.check";
	private static final String GTS_GELOLOCATION_CHECK_EXCEPTION=GTS_ERROR_EXCEPTION_MESSAGE;
	private static final String RPL_CHECK_FAIL=GTS_ERROR_MESSAGE;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "hpeFacadeGenericUtil")
	private HPEFacadeGenericUtil hpeFacadeGenericUtil;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "shopService")
	private ShopService shopService;

	@Resource(name = "cartService")
	private CartService cartService;

	@Resource(name = "customerFacade")
	private CustomerFacade customerFacade;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;

	@Resource(name = "hpeWePayFacade")
	private HPEWePayAuthorizationFacade hpeWePayFacade;
	@Resource(name = "userCartNotificationCookieGenerator")
	private HPEUserCartNotificationCookieGenerator userCartNotificationCookieGenerator;

	/**
	 *
	 */
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException, // NOSONAR
			CommerceCartModificationException
	{
		ProductData productData = null;
		ProductData baseProductData = null;
		final List<OrderEntryData> configEntries = new ArrayList<>();
		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.URL,
				ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE, ProductOption.PRICE_RANGE));

		CartData cartData = getCheckoutFacade().getCheckoutCart();
		final String paymentAuthorizationId = cartData.getPaymentAuthorizationId();
		final HPEPaymentAuthorizationResponse response = hpeWePayFacade.checkPaymentAuthorizationService(paymentAuthorizationId);
		final String paymentState = configurationService.getConfiguration().getString("payment.authorization.state");
		if(response==null)
		{
			LOGGER.error("SummaryCheckoutStepController:enterStep:CheckPaymentAuthorizationService currently failed or down for cart "+cartData.getCode());
			GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.ERROR_MESSAGES_HOLDER, PAYMENT_ERROR_MESSAGE);
			return REDIRECT_PREFIX+PAYMENT_METHOD_CHECKOUTSTEP_URL;
		}
		else if (null != response && !response.getState().equalsIgnoreCase(paymentState))
		{
			LOGGER.error("SummaryCheckoutStepController:enterStep:CheckPaymentAuthorizationService state is "+response.getState()+" for cart "+cartData.getCode());
			GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.ERROR_MESSAGES_HOLDER, PAYMENT_AUTHORIZATION_ERROR);
			return REDIRECT_PREFIX+PAYMENT_METHOD_CHECKOUTSTEP_URL;
		}

		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, "false");

		if ("true".equals(gtsGeoLocationCheck))
		{
   		boolean gtsResponse = false;
   		try
   		{
   			gtsResponse = callWePayGTSCheck(cartData, response);
   		}
   		catch (final Exception e)
   		{
   			GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.ERROR_MESSAGES_HOLDER,
   					GTS_GELOLOCATION_CHECK_EXCEPTION);
   			LOGGER.error("SummaryCheckoutStepController:::add:::gtsResponse ", e);
   			return REDIRECT_PREFIX + PAYMENT_METHOD_CHECKOUTSTEP_URL;
   		}
   		LOGGER.debug("******GTS Response in SummaryCheckoutStepController*******" + gtsResponse);
   		if (!gtsResponse)
   		{
   			GlobalMessages.addFlashMessage(redirectAttributes, GlobalMessages.ERROR_MESSAGES_HOLDER, RPL_CHECK_FAIL);
   			LOGGER.info("RPL Check fail ");
   			return REDIRECT_PREFIX + PAYMENT_METHOD_CHECKOUTSTEP_URL;
   		}
		}
		if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
		{
			for (final OrderEntryData entry : cartData.getEntries())
			{
				productData = entry.getProduct();
				if (null != productData.getBaseProduct())
				{
					baseProductData = getProductFacade().getProductForCodeAndOptions(productData.getBaseProduct(), options);
					productData.setBaseProductUrl(baseProductData.getUrl());
				}
				if (null != productData.getBaseProduct() && null != entry.getConfigID() && entry.getIsStarterProduct())
				{
					baseProductData = getProductFacade().getProductForCodeAndOptions(productData.getBaseProduct(), options);
					productData.setBaseProductUrl(baseProductData.getUrl());
				}
				entry.setProduct(productData);

				if (StringUtils.isNotEmpty(entry.getConfigID()))
				{
					configEntries.add(entry);
				}
			}
		}
		cartData = hpeCartFacade.getConfigEntries(configEntries, cartData);
		if (cartData.getEntries() != null && !cartData.getEntries().isEmpty())
		{
			cartData.getEntries().removeAll(configEntries);
		}

		model.addAttribute("cartData", cartData);
		model.addAttribute("allItems", cartData.getEntries());
		model.addAttribute("deliveryAddress", cartData.getDeliveryAddress());
		model.addAttribute("deliveryMode", cartData.getDeliveryMode());
		model.addAttribute("paymentInfo", cartData.getPaymentInfo());
		model.addAttribute("eloquasiteid", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_SITEID));
		model.addAttribute("eloquaresponsetype", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_RESPONSE_TYPE1));
		model.addAttribute("eloquagrmid", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_ID1));
		model.addAttribute("eloquagrmcleanedstatus", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_CLEANED_STATUS1));
		model.addAttribute("eloquaformsource", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_FORM_SOURCE1));
		model.addAttribute("eloquamethodoptin", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_METHOD_OPT_IN));
		model.addAttribute("eloquacookiewrite", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_COOKIE_WRITE));
		model.addAttribute("eloqua", configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADDRESS));
		model.addAttribute("eloquaordercompleteformname",
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ORDER_COMPLETE_FORMNAME));
		model.addAttribute("eloquaaprimoactivityidordercomplete",
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_ORDER_COMPLETE));
		model.addAttribute("eloqualeadsourceordercomplete",
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_LEAD_SOURCE___MOST_RECENT1_ORDER_COMPLETE));
		model.addAttribute("eloquaprivacychangesourceordercomplete",
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_SOURCE_ORDER_COMPLETE));
		model.addAttribute("eloquamkpcartstatusordercomplete",
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_MKP_CART_STATUS_ORDER_COMPLETE));
		model.addAttribute(new PlaceOrderForm());

		final CustomerData currentUser = customerFacade.getCurrentCustomer();
		if (currentUser != null)
		{
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("SummaryCheckoutStepController:::productDetail:::currentUser " + currentUser);
			}
			model.addAttribute("customerEmailAddress", currentUser.getDisplayUid());
			model.addAttribute("customerFirstName", currentUser.getFirstName());
			model.addAttribute("customerLastName", currentUser.getLastName());
		}

		storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				getResourceBreadcrumbBuilder().getBreadcrumbs("checkout.multi.summary.breadcrumb"));

		setCheckoutStepLinksForModel(model, getCheckoutStep());

		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCheckoutJsonObjectForAnalytics();
		model.addAttribute("cartDataJsonObject", cartDataJsonObject);
		hpeFacadeGenericUtil.miraklShopName(model);
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);

		return ControllerConstants.Views.Pages.MultiStepCheckout.CheckoutSummaryPage;
	}

	/**
	 *
	 * @param placeOrderForm
	 * @param model
	 * @param request
	 * @param redirectModel
	 * @return
	 * @throws CMSItemNotFoundException
	 * @throws InvalidCartException
	 * @throws CommerceCartModificationException
	 */
	@RequestMapping(value = "/placeOrder")
	//	@PreValidateQuoteCheckoutStep
	@RequireHardLogIn
	public String placeOrder(@ModelAttribute("placeOrderForm")
	final PlaceOrderForm placeOrderForm, final Model model, final HttpServletRequest request, final HttpServletResponse response,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException, // NOSONAR
			InvalidCartException, CommerceCartModificationException
	{
		final OrderData orderData;

		try
		{
			final String gtsTransactionCheck = configurationService.getConfiguration().getString(GTS_TRANSACTION_CHECK, "false");

			if ("true".equals(gtsTransactionCheck))
			{
				final CartModel cartModel = getCartService().getSessionCart();
				final Set<String> shops = new HashSet();
				final List<ShopModel> shopModels = new ArrayList<>();

				for (final AbstractOrderEntryModel entry : cartModel.getEntries())
				{
					shops.add(entry.getShopId());
				}
				if (!shops.isEmpty())
				{
					for (final String shop : shops)
					{
						final ShopModel shopModel = shopService.getShopForId(shop);
						shopModels.add(shopModel);
					}
				}
				final boolean transactionServiceResponse = hpeUserFacade.getTransactionServiceResponse(shopModels,
						hpeStorefrontUtil.getUID());
				LOGGER.debug("******Transaction call check*******");

				if (!transactionServiceResponse)
				{
					LOGGER.debug("******Transaction Service Response value True or False*******" + transactionServiceResponse);
					//Exception message is been passed but we can not hold it or display it because we are redirecting our site to hp.com which is a internet link not a intranet link hence
					//session varaible will be lost
					GlobalMessages.addErrorMessage(model, GTS_ERROR_MESSAGE);
					return enterStep(model, redirectModel);
				}
			}
			orderData = getCheckoutFacade().placeOrder();
			userCartNotificationCookieGenerator.removeCookie(request, response);
		}
		catch (final SOAPFaultException e)
		{
			LOGGER.error("Failed to place Order due to gts exception", e);
			GlobalMessages.addErrorMessage(model, GTS_ERROR_EXCEPTION_MESSAGE);
			return enterStep(model, redirectModel);
		}
		catch (final Exception e)
		{
			LOGGER.error("Failed to place Order", e);
			GlobalMessages.addErrorMessage(model, GTS_ERROR_EXCEPTION_MESSAGE);
			return enterStep(model, redirectModel);
		}

		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCheckoutJsonObjectForAnalytics();
		redirectModel.addFlashAttribute("cartDataJsonObject", cartDataJsonObject);

		return redirectToOrderConfirmationPage(orderData);
	}

	/**
	 * Validates the order form before to filter out invalid order states
	 *
	 * @param placeOrderForm
	 *           The spring form of the order being submitted
	 * @param model
	 *           A spring Model
	 * @return True if the order form is invalid and false if everything is valid.
	 */
	protected boolean validateOrderForm(final PlaceOrderForm placeOrderForm, final Model model)
	{
		final String securityCode = placeOrderForm.getSecurityCode();
		boolean invalid = false;

		if (getCheckoutFlowFacade().hasNoDeliveryAddress())
		{
			GlobalMessages.addErrorMessage(model, "checkout.deliveryAddress.notSelected");
			invalid = true;
		}

		if (getCheckoutFlowFacade().hasNoDeliveryMode())
		{
			GlobalMessages.addErrorMessage(model, "checkout.deliveryMethod.notSelected");
			invalid = true;
		}

		if (getCheckoutFlowFacade().hasNoPaymentInfo())
		{
			GlobalMessages.addErrorMessage(model, "checkout.paymentMethod.notSelected");
			invalid = true;
		}
		else
		{
			// Only require the Security Code to be entered on the summary page if the SubscriptionPciOption is set to Default.
			if (CheckoutPciOptionEnum.DEFAULT.equals(getCheckoutFlowFacade().getSubscriptionPciOption())
					&& StringUtils.isBlank(securityCode))
			{
				GlobalMessages.addErrorMessage(model, "checkout.paymentMethod.noSecurityCode");
				invalid = true;
			}
		}

		if (!placeOrderForm.isTermsCheck())
		{
			GlobalMessages.addErrorMessage(model, "checkout.error.terms.not.accepted");
			invalid = true;
			return invalid;
		}

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		if (!configurationService.getConfiguration().getBoolean(AVALARA_EXTERNALTAX_ENABLED))
		{
			invalid = false;
			return invalid;
		}

		if (!getCheckoutFacade().containsTaxValues())
		{
			LOGGER.error(String.format(
					"Cart %s does not have any tax values, which means the tax cacluation was not properly done, placement of order can't continue",
					cartData.getCode()));
			GlobalMessages.addErrorMessage(model, "checkout.error.tax.missing");
			invalid = true;
		}

		if (!cartData.isCalculated())
		{
			LOGGER.error(
					String.format("Cart %s has a calculated flag of FALSE, placement of order can't continue", cartData.getCode()));
			GlobalMessages.addErrorMessage(model, "checkout.error.cart.notcalculated");
			invalid = true;
		}

		return invalid;
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String back(final RedirectAttributes redirectAttributes)
	{
		return getCheckoutStep().previousStep();
	}

	@RequestMapping(value = "/next", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String next(final RedirectAttributes redirectAttributes)
	{
		return getCheckoutStep().nextStep();
	}

	protected CheckoutStep getCheckoutStep()
	{
		return getCheckoutStep(SUMMARY);
	}


	/**
	 * @return the hpeUserFacade
	 */
	public HPEUserFacade getHpeUserFacade()
	{
		return hpeUserFacade;
	}

	/**
	 * @param hpeUserFacade
	 *           the hpeUserFacade to set
	 */
	public void setHpeUserFacade(final HPEUserFacade hpeUserFacade)
	{
		this.hpeUserFacade = hpeUserFacade;
	}

	/**
	 * @return the userService
	 */
	public UserService getUserService()
	{
		return userService;
	}

	/**
	 * @param userService
	 *           the userService to set
	 */
	public void setUserService(final UserService userService)
	{
		this.userService = userService;
	}

	/**
	 * @return the cartService
	 */
	public CartService getCartService()
	{
		return cartService;
	}

	/**
	 * @param cartService
	 *           the cartService to set
	 */
	public void setCartService(final CartService cartService)
	{
		this.cartService = cartService;
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}
	private boolean callWePayGTSCheck(final CartData cartData,final HPEPaymentAuthorizationResponse response)
	{
		final AddressData deliveryAddress = cartData.getDeliveryAddress();
		final WePayRequestData data=new WePayRequestData();
		if(null!=deliveryAddress)
		{
			data.setZipCode(deliveryAddress.getPostalCode());
		}
		final String payerEmail = response.getPayer_email();
		data.setPayerEmail(payerEmail);
		final String payerName = response.getPayer_name();
		data.setPayerName(payerName);
		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, "false");
		boolean gtsResponse = false;

		GTSRequestData gtsRequestData=null;
		if ("true".equals(gtsGeoLocationCheck))
		{
			LOGGER.debug("******GTS call for Payment check*******");
				gtsRequestData = hpeStorefrontUtil.setGTSRequestData(data);
				gtsResponse = hpeUserFacade.getGTSResponse(gtsRequestData);

		}
		if(gtsResponse)
		{
			data.setExpPartNum(gtsRequestData.getExpPartNum());
			getSessionService().setAttribute(RPL_BILLINGADDRESS, data);
		}
		return gtsResponse;

	}
}
