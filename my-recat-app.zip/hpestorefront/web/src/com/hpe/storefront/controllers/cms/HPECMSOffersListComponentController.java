/**
 *
 */
package com.hpe.storefront.controllers.cms;

import static org.apache.commons.collections.CollectionUtils.isEmpty;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.VariantOptionData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hpe.core.model.HPECMSOffersListComponentModel;
import com.hpe.facades.product.HPEProductFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.mirakl.hybris.beans.OfferData;
import com.mirakl.hybris.facades.product.OfferFacade;


/**
 * @author DA20002251
 *
 */
@Controller
@RequestMapping(value = ControllerConstants.Actions.Cms.HPECMSOffersListComponent)
public class HPECMSOffersListComponentController extends AbstractAcceleratorCMSComponentController<HPECMSOffersListComponentModel>
{

	@Resource(name = "hpeProductFacade")
	private HPEProductFacade hpeProductFacade;

	@ModelAttribute("vatMessage")
	public String getVatMessage()
	{
		return hpeProductFacade.getVatMessage();
	}


	private static final Logger LOG = Logger.getLogger(HPECMSOffersListComponentController.class);

	protected static final String PRODUCT_ATTRIBUTE = "product";
	protected static final String TOP_OFFER_ATTRIBUTE = "topOffer";
	protected static final String VARIANT_OFFER_ATTRIBUTE = "variantOffers";

	@Resource(name = "offerFacade")
	protected OfferFacade offerFacade;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController#fillModel(javax.
	 * servlet.http.HttpServletRequest, org.springframework.ui.Model,
	 * de.hybris.platform.cms2.model.contents.components.AbstractCMSComponentModel)
	 */
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model, final HPECMSOffersListComponentModel component)
	{
		List<OfferData> variantListOffers = new ArrayList<>();
		final List<Map<String, List<OfferData>>> variantOffers = new ArrayList<Map<String, List<OfferData>>>();
		final ProductData product = (ProductData) request.getAttribute(PRODUCT_ATTRIBUTE);
		final ObjectMapper mapper = new ObjectMapper();
		String variantJsonInString = "";

		final List<VariantOptionData> variants = product.getVariantOptions();
		if (!isEmpty(variants))
		{
			for (final VariantOptionData variant : variants)
			{
				final Map<String, List<OfferData>> variantMap = new HashMap<String, List<OfferData>>();
				variantListOffers = offerFacade.getOffersForProductCode(variant.getCode());
				variantMap.put(variant.getCode(), variantListOffers);
				variantOffers.add(variantMap);
			}
			try
			{
				variantJsonInString = mapper.writeValueAsString(variantOffers);
			}
			catch (final JsonProcessingException e)
			{
				LOG.error(e);
			}
		}
		LOG.debug("HPECMSOffersListComponentController::fillModel::Returning from the Controller with the variantOffers :: "
				+ variantOffers);
		model.addAttribute(VARIANT_OFFER_ATTRIBUTE, variantJsonInString);
	}

	@Override
	protected String getView(final HPECMSOffersListComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(HPECMSOffersListComponentModel._TYPECODE);
	}

}
