/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.misc;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hpe.storefront.controllers.ControllerConstants;


/**
 * Controller for web robots instructions
 */
@Controller
public class RobotsController extends AbstractController
{
	// Number of seconds in one day
	private static final String ONE_DAY = String.valueOf(60 * 60 * 24);
	private static final Logger LOG = Logger.getLogger(RobotsController.class);

	@RequestMapping(value = "/robots.txt", method = RequestMethod.GET)
	public String getRobots(final HttpServletResponse response, final HttpServletRequest httpRequest, final Model model)
	{
		LOG.debug("---RobotsController---getRobots()---");
		response.setHeader("Cache-Control", "public, max-age=" + ONE_DAY);
		final String currentRequestURL = httpRequest.getRequestURL().toString();
		final String absoluteURL = StringUtils.removeEnd(currentRequestURL, "/");//absolute URL from host request dispacter call to httprequest object
		if (absoluteURL.endsWith("robots.txt"))
		{
			final String absoluteURLSiteMap = absoluteURL.substring(0, absoluteURL.length() - 10);
			model.addAttribute("absoluteURL", absoluteURLSiteMap.trim());
		}
		return ControllerConstants.Views.Pages.Misc.MiscRobotsPage;
	}
}
