/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.CategoryPageProductDisplayComponentModel;
import com.hpe.facades.product.HPEProductFacade;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 * @author NA20006812
 *
 */
@Controller("CategoryPageProductDisplayComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.CategoryPageProductDisplayComponent)
public class CategoryPageProductDisplayComponentController
		extends AbstractAcceleratorCMSComponentController<CategoryPageProductDisplayComponentModel>
{
	protected static final List<ProductOption> PRODUCT_OPTIONS = Arrays.asList(ProductOption.BASIC, ProductOption.PRICE,
			ProductOption.SUMMARY, ProductOption.DESCRIPTION, ProductOption.GALLERY, ProductOption.IMAGES,
			ProductOption.VARIANT_MATRIX_BASE, ProductOption.VARIANT_MATRIX_ALL_OPTIONS, ProductOption.VARIANT_FULL);

	@Resource(name = "accProductFacade")
	private ProductFacade productFacade;

	@Resource(name = "hpeProductFacade")
	private HPEProductFacade hpeProductFacade;

	@ModelAttribute("vatMessage")
	public String getVatMessage()
	{
		return hpeProductFacade.getVatMessage();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController#fillModel(javax.
	 * servlet.http.HttpServletRequest, org.springframework.ui.Model,
	 * de.hybris.platform.cms2.model.contents.components.AbstractCMSComponentModel)
	 */
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final CategoryPageProductDisplayComponentModel component)
	{
		// XXX Auto-generated method stub
		final ProductModel product = component.getProduct();

		if (product != null)
		{
			final ProductData productData = hpeProductFacade.getProductForCodeAndOptions(product.getCode(), PRODUCT_OPTIONS);

			//Populating Least Price
			final PriceData leastPrice = hpeProductFacade.getProductLeastPartnerPriceForProduct(product);
			if (null != leastPrice)
			{
				productData.setPrice(leastPrice);
			}

			model.addAttribute("product", productData);

		}
	}

	@Override
	protected String getView(final CategoryPageProductDisplayComponentModel component)
	{
		// XXX Auto-generated method stub
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(CategoryPageProductDisplayComponentModel._TYPECODE);
	}
}

