/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.commercefacades.product.converters.populator.ImagePopulator;
import de.hybris.platform.commercefacades.product.data.ImageData;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.FindYourSolutionSimpleBannerComponentModel;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 * @author AN392930
 *
 */
@Controller("FindYourSolutionSimpleBannerComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.FindYourSolutionSimpleBannerComponent)

public class FindYourSolutionSimpleBannerComponentController
		extends AbstractAcceleratorCMSComponentController<FindYourSolutionSimpleBannerComponentModel>
{
	@Autowired
	private ImagePopulator imagePopulator;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final FindYourSolutionSimpleBannerComponentModel component)
	{

		final ImageData imageData = new ImageData();
		imagePopulator.populate(component.getMedia(), imageData);

		model.addAttribute("solutionMedia", imageData);
		model.addAttribute("urlLink", component.getUrlLink());
		model.addAttribute("title", component.getTitle());
	}

	@Override
	protected String getView(final FindYourSolutionSimpleBannerComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(FindYourSolutionSimpleBannerComponentModel._TYPECODE);
	}
}