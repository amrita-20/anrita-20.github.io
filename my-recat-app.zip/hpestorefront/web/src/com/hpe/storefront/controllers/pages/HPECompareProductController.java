/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hpe.facades.product.HPEProductFacade;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.productcompare.prodids.ProductCompareIDs;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.*;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;


/**
 * Product Compare Controller. Handles products comparison.
 */
@Controller
@RequestMapping(value = "/product")
public class HPECompareProductController extends AbstractPageController
{
	private static final Logger LOG = Logger.getLogger(HPECompareProductController.class);

	private static final String PRODUCT_COMPARE_PAGE = "productComparePage";
	private static final String PLP_COMPARE = "comparePLP";
	private static final String SERVICES_COMPARE = "compareServices";
	private static final String MODELS_COMPARE = "compareModels";
	private static final String OPTIONS_COMPARE = "compareOptions";

	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "hpeProductFacade")
	private HPEProductFacade hpeProductFacade;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	/**
	 *
	 * @param model
	 * @return
	 * @throws CMSItemNotFoundException
	 */
	@RequestMapping(value = "/compareProduct")
	public String getOffers(final Model model) throws CMSItemNotFoundException
	{
		final ContentPageModel productComparePage = getContentPageForLabelOrId(PRODUCT_COMPARE_PAGE);
		storeCmsPageInModel(model, productComparePage);
		setUpMetaDataForContentPage(model, productComparePage);
		final Map compareProducts = getCompareProductsinSession();
		final Map<String, List<Map<String, String>>> compareRows = getCompareRows(compareProducts);
		final JSONObject comparePageJsonObject = hpeAnalyticsUtil.getComparePageDetails(compareProducts);
		model.addAttribute("comparePageJsonObject", comparePageJsonObject);
		model.addAttribute("comparePagelayout", compareProducts);
		model.addAttribute("comparePageTable", compareRows);
		return getViewForPage(model);

	}

	/**
	 * Product Comparison
	 *
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return ResponseBody.
	 * @exception JsonGenerationException,JsonMappingException,IOException,CMSItemNotFoundException
	 *
	 */
	@RequestMapping(value = "/compare", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity hpeProductCompare(final ProductCompareIDs productCompareIDs, final String compareflag,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException
	{
		LOG.debug("Inside Product Compare Controller...");

		if (JaloSession.getCurrentSession().getAttribute(PLP_COMPARE) != null)
		{
			JaloSession.getCurrentSession().removeAttribute(PLP_COMPARE);
			LOG.info(JaloSession.getCurrentSession().getAttribute(PLP_COMPARE));
		}

		if (JaloSession.getCurrentSession().getAttribute(compareflag) != null
				&& JaloSession.getCurrentSession().getAttribute(compareflag) instanceof Map)
		{
			JaloSession.getCurrentSession().removeAttribute("compareflag");
		}

		Map<String, ProductData> compareProducts = null;

		if (JaloSession.getCurrentSession().getAttribute(compareflag) != null
				&& JaloSession.getCurrentSession().getAttribute(compareflag) instanceof Map)
		{
			compareProducts = (Map<String, ProductData>) JaloSession.getCurrentSession().getAttribute(compareflag);

		}
		else
		{

			compareProducts = new HashMap<>();
		}

		final List<ProductOption> productOptions = Arrays.asList(ProductOption.BASIC, ProductOption.SUMMARY,
				ProductOption.DESCRIPTION, ProductOption.GALLERY, ProductOption.IMAGES, ProductOption.CLASSIFICATION,


				ProductOption.VARIANT_MATRIX_BASE, ProductOption.VARIANT_MATRIX_ALL_OPTIONS, ProductOption.VARIANT_FULL);

		final String[] products = productCompareIDs.getProdIds().split(",");

		ProductData productCompData = null;

		final List<ProductData> prodCompDataList = new ArrayList<ProductData>();

		for (final String productCode : products)
		{
			if (!compareProducts.containsKey(productCode))
			{
				productCompData = productFacade.getProductForCodeAndOptions(productCode, productOptions);


				final PriceData leastPrice = hpeProductFacade.getProductLeastPartnerPrice(productCode);
				if (null != leastPrice)
				{
					productCompData.setPrice(leastPrice);
				}
				prodCompDataList.add(productCompData);
				compareProducts.put(productCode, productCompData);
				JaloSession.getCurrentSession().setAttribute(compareflag, compareProducts);
			}
			else
			{

				final ProductData product = compareProducts.get(productCode);
				prodCompDataList.add(product);
			}
		}

		return new ResponseEntity(products, HttpStatus.OK);
	}



	private Map<String, ProductData> getCompareProductsinSession()
	{
		final Map<String, ProductData> compareProducts = new HashMap();

		if (JaloSession.getCurrentSession().getAttribute(MODELS_COMPARE) != null)
		{
			compareProducts.putAll((Map<String, ProductData>) JaloSession.getCurrentSession().getAttribute(MODELS_COMPARE));
			JaloSession.getCurrentSession().removeAttribute(MODELS_COMPARE);

		}
		if (JaloSession.getCurrentSession().getAttribute(PLP_COMPARE) != null)
		{
			compareProducts.putAll((Map<String, ProductData>) JaloSession.getCurrentSession().getAttribute(PLP_COMPARE));
			JaloSession.getCurrentSession().removeAttribute(PLP_COMPARE);
			LOG.info(JaloSession.getCurrentSession().getAttribute(PLP_COMPARE));

		}
		if (JaloSession.getCurrentSession().getAttribute(OPTIONS_COMPARE) != null)
		{
			compareProducts.putAll((Map<String, ProductData>) JaloSession.getCurrentSession().getAttribute(OPTIONS_COMPARE));
			JaloSession.getCurrentSession().removeAttribute(OPTIONS_COMPARE);
		}
		if (JaloSession.getCurrentSession().getAttribute(SERVICES_COMPARE) != null)
		{
			compareProducts.putAll((Map<String, ProductData>) JaloSession.getCurrentSession().getAttribute(SERVICES_COMPARE));
			JaloSession.getCurrentSession().removeAttribute(SERVICES_COMPARE);
		}
		return compareProducts;
	}

	private Map<String, List<Map<String, String>>> getCompareRows(final Map compareProducts)
	{

		final List<String> productList = new ArrayList<>(compareProducts.keySet());
		Map<String, List<Map<String, String>>> classificationAttributes = new HashMap<>();

		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.CLASSIFICATION));
		final String classficationClassCode = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_CLASS_CODE, "_TS");
		final List<String> productLabelList = getProductLabelList(productList, classficationClassCode, options);
		if (!(productLabelList).isEmpty())
		{
			final List<String> productLabelList1 = new ArrayList<>(new HashSet<>(productLabelList));
			classificationAttributes = getClassificationAttributes(productLabelList1, productList);

		}

		return classificationAttributes;

	}





	/**
	 * @param productLabelList1
	 * @param productList
	 * @return
	 */
	private Map<String, List<Map<String, String>>> getClassificationAttributes(final List<String> productLabelList1,
			final List<String> productList)
	{

		Map<String, List<Map<String, String>>> classificationAttributes1 = new HashMap<>();
		final Map<String, List<Map<String, String>>> classificationAttributes2 = new HashMap<>();

		for (final String list1 : productLabelList1)
		{
			classificationAttributes1 = getIntermediateclassificationAttributes(list1, productList);
			classificationAttributes2.put(list1, classificationAttributes1.get(list1));
		}
		return classificationAttributes2;
	}/*
	  *
	  *
	  * /**
	  *
	  * @param list1
	  *
	  * @param productList
	  *
	  * @return
	  */

	private Map<String, List<Map<String, String>>> getIntermediateclassificationAttributes(final String list1,
			final List<String> productList)
	{

		Map<String, List<Map<String, String>>> intermediateclassificationAttributes = new HashMap<>();
		final String classficationClassCode = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_CLASS_CODE, "_TS");
		ClassificationData classificationData;

		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.CLASSIFICATION));
		for (final String list2 : productList)
		{
			final ProductData hpeProductData = productFacade.getProductForCodeAndOptions(list2, options);
			final Map<String, String> compareIntermediateList = new HashMap<>();
			final Map<String, ClassificationData> classificationGroupMap = hpeProductData.getClassificationGroupMap();
			boolean classificationcodecheck = true;
			for (final Map.Entry<String, ClassificationData> classificationClass : classificationGroupMap.entrySet())
			{

				if (classificationClass.getKey().contains(classficationClassCode))
				{
					classificationcodecheck = false;
					classificationData = classificationGroupMap.get(classificationClass.getKey());

					final String fieldData = getClassifiedField(classificationData, list1);

					compareIntermediateList.put(list1, fieldData);
					intermediateclassificationAttributes = getIntermediateClassificationAttributes(list1, compareIntermediateList,
							intermediateclassificationAttributes);

				}


			}
			if (classificationGroupMap.entrySet().isEmpty() || null == classificationGroupMap.entrySet()
					|| classificationcodecheck == true)
			{
				compareIntermediateList.put(list1, "");
				intermediateclassificationAttributes = getIntermediateClassificationAttributes(list1, compareIntermediateList,
						intermediateclassificationAttributes);
			}
		}
		return intermediateclassificationAttributes;
	}

	/**
	 * @param list1
	 * @param compareIntermediateList
	 * @return
	 */
	private Map<String, List<Map<String, String>>> getIntermediateClassificationAttributes(final String list1,
			final Map<String, String> compareIntermediateList,
			final Map<String, List<Map<String, String>>> intermediateclassificationAttributes)
	{
		if (intermediateclassificationAttributes.containsKey(list1))
		{
			final List ll = intermediateclassificationAttributes.get(list1);
			ll.add(compareIntermediateList);
			intermediateclassificationAttributes.put(list1, ll);
		}
		else
		{
			final List<Map<String, String>> compareData = new ArrayList<>();
			compareData.add(compareIntermediateList);
			intermediateclassificationAttributes.put(list1, compareData);
		}

		return intermediateclassificationAttributes;
	}

	/**
	 * @param productList
	 * @param options
	 * @param classficationClassCode
	 * @return
	 */
	private List<String> getProductLabelList(final List<String> productList, final String classficationClassCode,
			final List<ProductOption> options)
	{
		// XXX Auto-generated method stub

		final List<String> productLabel = new ArrayList<>();

		for (final String list : productList)
		{
			final ProductData hpeProductData = productFacade.getProductForCodeAndOptions(list, options);
			final Map<String, ClassificationData> classificationGroupMap = hpeProductData.getClassificationGroupMap();

			if ((null != classificationGroupMap) && (null != classificationGroupMap.keySet())
					&& (!(classificationGroupMap.keySet().isEmpty())))
			{


				productLabel.addAll(getProductLabel(classificationGroupMap, classficationClassCode));


			}
		}

		return productLabel;
	}

	/**
	 * @param classificationGroupMap
	 * @param classficationClassCode
	 * @return
	 */
	private List<String> getProductLabel(final Map<String, ClassificationData> classificationGroupMap,
			final String classficationClassCode)
	{

		ClassificationData classificationData;
		List<String> productLabelMap = new ArrayList<>();


		for (final Map.Entry<String, ClassificationData> classificationClass : classificationGroupMap.entrySet())
		{
			if (classificationClass.getKey().contains(classficationClassCode))
			{


				classificationData = classificationGroupMap.get(classificationClass.getKey());
				final Collection<FeatureData> features = classificationData.getFeatures();
				if (!(features).isEmpty())
				{

					productLabelMap = getProductLabelMap(features);

				}
			}




		}
		return productLabelMap;
	}

	/**
	 * @param features
	 * @return
	 */
	private List<String> getProductLabelMap(final Collection<FeatureData> features)
	{

		final List<String> productLabelMap1 = new ArrayList<>();
		for (final FeatureData featureData : features)

		{
			final List<FeatureValueData> featureValues = (List<FeatureValueData>) featureData.getFeatureValues();
			if (CollectionUtils.isNotEmpty(featureValues))
			{
				final String featureName = featureData.getName();
				final String name = featureName.substring(featureName.indexOf('.') + 1, featureName.length());
				productLabelMap1.add(name);
			}
		}
		return productLabelMap1;
	}

	private String getClassifiedField(final ClassificationData classificationData, final String name)
	{

		String value = "";
		final String classficationClassCode = configurationService.getConfiguration()
				.getString(HPEStorefrontConstant.CLASSIFICATION_CLASS_CODE, "_TS");
		if (classificationData != null && classificationData.getCode().endsWith(classficationClassCode))
		{
			final Collection<FeatureData> features = classificationData.getFeatures();

			for (final FeatureData featureData : features)
			{
				final List<FeatureValueData> featureValues = (List<FeatureValueData>) featureData.getFeatureValues();
				final String featureName = featureData.getName();
				final String featureNameTrim = featureName.substring(featureName.indexOf('.') + 1, featureName.length());
				if (featureNameTrim.equalsIgnoreCase(name) && (featureData.getFeatureValues() != null
						&& !featureData.getFeatureValues().isEmpty() && featureValues.get(0).getValue() != null))
				{

					value = featureValues.get(0).getValue();

					break;


				}


			}
		}
		return value;
	}
}



