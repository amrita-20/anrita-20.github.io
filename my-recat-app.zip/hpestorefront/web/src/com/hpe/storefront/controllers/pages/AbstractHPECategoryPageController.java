/**
 *
 */
package com.hpe.storefront.controllers.pages;


import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorservices.data.RequestContextData;
import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractCategoryPageController;
import de.hybris.platform.acceleratorstorefrontcommons.util.MetaSanitizerUtil;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.cms2.model.pages.CategoryPageModel;
import de.hybris.platform.commercefacades.product.data.CategoryData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.search.data.SearchQueryData;
import de.hybris.platform.commercefacades.search.data.SearchStateData;
import de.hybris.platform.commerceservices.search.facetdata.ProductCategorySearchPageData;
import de.hybris.platform.commerceservices.search.pagedata.PageableData;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.servicelayer.session.SessionService;

import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.ui.Model;

import com.hpe.facades.category.HPECategory;
import com.hpe.facades.populators.HPEPLPGuidedSellingPopulator;
import com.hpe.facades.product.Breadcrumb;
import com.hpe.facades.product.impl.HPESearchBreadcrumbBuilder;
import com.hpe.facades.wishlist.HPEWishlistFacade;
import com.hpe.hpepassport.response.data.HPEMetaElementData;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.GenericUtil;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;


/**
 * @author DA20002251
 *
 */
public class AbstractHPECategoryPageController extends AbstractCategoryPageController
{
	private static final Logger LOGGER = Logger.getLogger(AbstractHPECategoryPageController.class);

	@Resource
	private HPEPLPGuidedSellingPopulator plpGuidedSellingPopulator;

	@Resource(name = "hpeWishlist")
	private HPEWishlistFacade hpeWishlistFacade;

	//Added session service to set the request url for canonical tag
	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "hpeSearchBreadcrumbBuilder")
	private HPESearchBreadcrumbBuilder hpeSearchBreadcrumbBuilder;

	@Resource(name = "defaultHPEUrlResolver")
	private UrlResolver<CategoryModel> defaultHPEUrlResolver;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "messageSource")
	private MessageSource messageSource;

	@Resource
	private I18NService i18NService;


	//Added a generic level attribute to set request URL for canonical ref.
	private static final String REQUESTURL = "requestUrl";

	@Resource(name = "hpeCategory")
	private HPECategory hpeCategory;

	@Override
	public ConfigurationService getConfigurationService()
	{
		return configurationService;
	}

	public void setConfigurationService(final ConfigurationService configurationService)
	{
		this.configurationService = configurationService;
	}

	protected String performSearchAndGetResultsPage(final String categoryCode, final String searchQuery, final int page, // NOSONAR
			final ShowMode showMode, final String sortCode, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final int pageSize, final String textSearch)
					throws UnsupportedEncodingException, JSONException
	{
		sessionService.setAttribute(REQUESTURL, request.getRequestURL());

		final CategoryModel category = getCommerceCategoryService().getCategoryForCode(categoryCode);

		final String redirection = checkRequestUrl(request, response, defaultHPEUrlResolver.resolve(category));
		if (StringUtils.isNotEmpty(redirection))
		{
			return redirection;
		}

		final CategoryPageModel categoryPage = getCategoryPage(category);

		final CategorySearchEvaluator categorySearch = new CategorySearchEvaluator(categoryCode, searchQuery, page, showMode,
				sortCode, categoryPage, pageSize, textSearch);

		ProductCategorySearchPageData<SearchStateData, ProductData, CategoryData> searchPageData = null;
		try
		{
			categorySearch.doSearch();
			searchPageData = categorySearch.getSearchPageData();
		}
		catch (final ConversionException e) // NOSONAR
		{
			LOGGER.info("ConversionException occured");
			searchPageData = createEmptySearchResult(categoryCode);
		}

		final boolean showCategoriesOnly = categorySearch.isShowCategoriesOnly();

		storeCmsPageInModel(model, categorySearch.getCategoryPage());
		storeContinueUrl(request);

		final JSONObject responseDetailsJson = new JSONObject();
		responseDetailsJson.put("guidedSelling", hpeStorefrontUtil.populatePLPSellingData(category));

		populateModel(model, searchPageData, showMode);
		final List<Breadcrumb> breadCrumbs = hpeSearchBreadcrumbBuilder.getBreadcrumbs(categoryCode, searchPageData);
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, breadCrumbs);
		model.addAttribute(HPEStorefrontConstant.SHOW_CAT_ONLY, Boolean.valueOf(showCategoriesOnly));
		model.addAttribute(HPEStorefrontConstant.CAT_NAME, category.getName());
		model.addAttribute(HPEStorefrontConstant.PAGE_TYPE, PageType.CATEGORY.name());
		model.addAttribute(HPEStorefrontConstant.USR_LOCATION, getCustomerLocationService().getUserLocation());
		model.addAttribute(HPEStorefrontConstant.GS_LIST, responseDetailsJson.toString());

		final Collection<String> pageSizes = GenericUtil.getSearchListPageSizes();

		model.addAttribute(HPEStorefrontConstant.PAGE_SIZES, pageSizes);

		int selectedPageSize = 0;

		if (pageSize == 0)
		{
			selectedPageSize = getSearchPageSize();

		}
		else
		{
			selectedPageSize = pageSize;
		}


		model.addAttribute(HPEStorefrontConstant.SELECTED_PAGE_SIZE, selectedPageSize);

		updatePageTitle(category, model);

		final RequestContextData requestContextData = getRequestContextData(request);
		requestContextData.setCategory(category);
		requestContextData.setSearch(searchPageData);

		// Meta robot tag
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.INDEX_FOLLOW);

		final List<String> metaKeywords = hpeCategory.getSeoKeywordForCategory(categoryCode);

		final String metaDescription = MetaSanitizerUtil.sanitizeDescription(category.getDescription());

		setUpMetaData(model, metaKeywords, metaDescription, category);
		// Added request url for canonical tag
		model.addAttribute("canonical", sessionService.getAttribute(REQUESTURL).toString());

		final org.json.JSONObject productListJsonObject = hpeAnalyticsUtil.getProductListJsonObjectForAnalytics(searchPageData,
				breadCrumbs);
		model.addAttribute(HPEStorefrontConstant.PRODUCT_LIST_JSON_OBJECT, productListJsonObject);

		return getViewPage(categorySearch.getCategoryPage());

	}

	protected void setUpMetaData(final Model model, final List<String> metaKeywords, final String metaDescription,
			final CategoryModel category)
	{
		final List<MetaElementData> metadata = new LinkedList<>();
		if (!metaKeywords.isEmpty())
		{
			metadata.add(createMetaElementPropertyList(HPEStorefrontConstant.KEYWORDS, metaKeywords));
		}
		else
		{
			metadata.add(createMetaElementProperty(HPEStorefrontConstant.KEYWORDS, category.getName()));
		}
		if (!metaDescription.isEmpty())
		{
			metadata.add(createMetaElement(HPEStorefrontConstant.DESCRIPTION,
					metaDescription + ' ' + getCmsSiteService().getCurrentSite().getName()));
			metadata.add(createMetaElementProperty("og:description",
					metaDescription + ' ' + getCmsSiteService().getCurrentSite().getName()));
		}
		else
		{
			metadata.add(createMetaElement(HPEStorefrontConstant.DESCRIPTION,
					messageSource.getMessage(HPEStorefrontConstant.CATEGORY_DESCRIPTION, null, i18NService.getCurrentLocale())
							.replace("<h1>", category.getName()) + ' ' + getCmsSiteService().getCurrentSite().getName()));
			metadata.add(createMetaElementProperty("og:description",
					messageSource.getMessage(HPEStorefrontConstant.CATEGORY_DESCRIPTION, null, i18NService.getCurrentLocale())
							.replace("<h1>", category.getName()) + ' ' + getCmsSiteService().getCurrentSite().getName()));
		}
		//added for <meta tag attribute>
		metadata.add(createMetaElementProperty("og:url", sessionService.getAttribute(REQUESTURL).toString()));
		metadata.add(createMetaElementProperty("og:type", "Website"));
		metadata.add(
				createMetaElementProperty("og:title", getPageTitleResolver().resolveCategoryPageTitle(category).replace('|', '-')));
		try
		{
			if (category.getCategories().get(0).getProducts().get(0).getPicture() != null)
			{
				metadata.add(createMetaElementProperty("og:image", (category.getPicture() != null) ? category.getPicture().getURL()
						: category.getCategories().get(0).getProducts().get(0).getPicture().getUrl()));
			}
		}
		catch (final Exception e)//NOSONAR
		{
			LOGGER.debug("No category first product image - " + e);
			metadata.add(
					createMetaElementProperty("og:image", (category.getPicture() != null) ? category.getPicture().getURL() : null));
		}

		model.addAttribute("metatags", metadata);
	}

	protected MetaElementData createMetaElementProperty(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}

	protected MetaElementData createMetaElementPropertyList(final String name, final List<String> metaKeywords)
	{
		final HPEMetaElementData element = new HPEMetaElementData();
		element.setName(name);
		element.setHpeContent(metaKeywords);
		return element;
	}

	public class CategorySearchEvaluator extends AbstractCategoryPageController.CategorySearchEvaluator

	{

		/**
		 * @param categoryCode
		 * @param searchQuery
		 * @param page
		 * @param showMode
		 * @param sortCode
		 * @param categoryPage
		 */
		private final String categoryCode;
		private final SearchQueryData searchQueryData = new SearchQueryData();
		private final int page;
		private final ShowMode showMode;
		private final String sortCode;
		private CategoryPageModel categoryPage;
		private ProductCategorySearchPageData<SearchStateData, ProductData, CategoryData> searchPageData;
		private boolean showCategoriesOnly;// NOSONAR
		private final int pageSize;
		private final String textSearch;

		public CategorySearchEvaluator(final String categoryCode, final String searchQuery, final int page, final ShowMode showMode,
				final String sortCode, final CategoryPageModel categoryPage, final int pageSize, final String textSearch)//NO SONAR
		{
			super(categoryCode, searchQuery, page, showMode, sortCode, categoryPage);
			this.categoryCode = categoryCode;
			this.searchQueryData.setValue(searchQuery);
			this.page = page;
			this.showMode = showMode;
			this.sortCode = sortCode;
			this.categoryPage = categoryPage;
			this.pageSize = pageSize;
			this.textSearch = textSearch;
		}

		/**
		 * @return the searchPageData
		 */
		@Override
		public ProductCategorySearchPageData<SearchStateData, ProductData, CategoryData> getSearchPageData()
		{
			return searchPageData;
		}

		@Override
		public void doSearch()// NOSONAR
		{
			PageableData pageableData = null;
			showCategoriesOnly = false;// NOSONAR
			final SearchStateData searchState = new SearchStateData();
			if (categoryPage == null || !categoryHasDefaultPage(categoryPage))
			{
				// Load the default category page
				categoryPage = getDefaultCategoryPage();
			}
			/* Set the Search Query Data only when it is not empty */

			if (StringUtils.isNotEmpty(textSearch)) //when text search value is not empty
			{
				if (searchQueryData.getValue().isEmpty()) //check to see if search query data facet one is emty or not
				{
					searchQueryData.setValue(textSearch); //if empty then facet is not selected assign text search to searchquery data
					searchState.setQuery(searchQueryData); //set the data to search state
				}
				else//if facet is selected then assign it to search state on text search data result
				{
					searchState.setQuery(searchQueryData);
				}
			}
			else if (searchQueryData.getValue() == null) //first time when user click on category data will be null
			{
				// Direct category link without filtering
				searchPageData = getProductSearchFacade().categorySearch(categoryCode);
				if (categoryPage != null)
				{
					showCategoriesOnly = !categoryHasDefaultPage(categoryPage)
							&& CollectionUtils.isNotEmpty(searchPageData.getSubCategories());// NOSONAR
				}
			}
			else //if user select facet.
			{
				searchState.setQuery(searchQueryData);
			}

			if (pageSize == 0)
			{
				pageableData = createPageableData(page, getSearchPageSize(), sortCode, showMode);
			}
			else
			{
				pageableData = createPageableData(page, pageSize, sortCode, showMode);
			}
			searchPageData = getProductSearchFacade().categorySearch(categoryCode, searchState, pageableData);
			//Encode SearchPageData
			searchPageData = (ProductCategorySearchPageData) encodeSearchPageData(searchPageData);
			//Check for hpe root category
			for (final ProductData product : searchPageData.getResults())
			{
				if (product.getUrl().toLowerCase().contains("/hpe-root-category"))
				{
					product.setUrl(product.getUrl().toLowerCase().replace("/hpe-root-category", ""));
				}
				product.setBookmarkFlag(hpeWishlistFacade.isBookmarked(product.getCode()));
			}
		}
	}
}
