/**
 *  This class returns true / false based on the user store login
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.commercefacades.user.UserFacade;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/storelogin")
public class HPEUserLoginController
{
	private static final String USER_LOGGED_IN = "hybris-store-logged-in";

	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Boolean> isUserLoggedIn(final HttpServletRequest request, final HttpServletResponse response)
	{
		final Map<String, Boolean> responseMap = new HashMap<>();
		if (userFacade.isAnonymousUser())
		{
			responseMap.put(USER_LOGGED_IN, Boolean.FALSE);
		}
		else
		{
			responseMap.put(USER_LOGGED_IN, Boolean.TRUE);
		}
		return responseMap;
	}
}
