/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateQuoteCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.validation.ValidationResults;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.GuestForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.LoginForm;
import de.hybris.platform.acceleratorstorefrontcommons.security.AutoLoginStrategy;
import de.hybris.platform.acceleratorstorefrontcommons.strategy.CustomerConsentDataStrategy;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.commercefacades.address.data.AddressVerificationResult;
import de.hybris.platform.commercefacades.consent.ConsentFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commerceservices.address.AddressVerificationDecision;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hpe.core.constants.HpeCoreConstants;
import com.hpe.facades.addressdoctor.HPEAddressDoctorIntegrationFacade;
import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.order.HPECartFacade;
import com.hpe.facades.registration.HPECustomerFacade;
import com.hpe.facades.registration.data.HPERegisterData;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.facades.util.GTSRequestData;
import com.hpe.facades.util.HPEFacadeGenericUtil;
import com.hpe.hpepassport.constant.HPEPassportConstant;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.address.form.HpeAddressForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;
import com.hpe.storefront.util.HpeAddressDataUtil;

import net.sourceforge.pmd.util.StringUtil;


@Controller
@RequestMapping(value = "/checkout/multi/delivery-address")
public class DeliveryAddressCheckoutStepController extends AbstractCheckoutStepController
{
	@Resource(name = "hpeFacadeGenericUtil")
	private HPEFacadeGenericUtil hpeFacadeGenericUtil;
	/**
	 *
	 */
	private static final String GUEST_ADDRESS = "guestAddress";
	/**
	 *
	 */
	private static final String LOGGED_IN_USER_ADDRESS = "loggedInUserAddress";
	private static final Logger LOG = Logger.getLogger(DeliveryAddressCheckoutStepController.class);
	private static final String DELIVERY_ADDRESS = "delivery-address";
	private static final String SHOW_SAVE_TO_ADDRESS_BOOK_ATTR = "showSaveToAddressBook";
	private static final Boolean SHIPPINGFLAG = true;
	private static final String ERROR = "error";
	private static final String GTS_GEOLOCATION_CHECK = "gts.geolocation.check";
	private static final String SUCCESS_MSG = "SuccessMsg";
	private static final String ADDRESS_FORM = "addressForm";
	private static final String FALSE = "false";
	private static final String SESSION_MULTI_RESELLER = "sesison_multi_reseller";
	private static final String SESSION_PRODUCT_RESTRICTION = "session_product_restriction";
	private static final String SESSION_PRODUCT_OUTOFSTOCK = "session_product_outofstock";
	private static final String SESSION_CART_SHOP_DISABLE = "session_shop_disable";
	private static final String SESSION_CART_UNAPPROVED_PRODUCTS = "session_unapproved_products";

	@Resource
	private MessageSource messageSource;

	@Resource(name = "hpeAddressDataUtil")
	private HpeAddressDataUtil hpeAddressDataUtil;

	@Resource(name = "hpeAddressDoctorIntegrationFacade")
	private HPEAddressDoctorIntegrationFacade hpeAddressDoctorIntegrationFacade;

	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;

	@Resource(name = "hpeCustomerFacade")
	private HPECustomerFacade hpeCustomerFacade;

	@Resource(name = "customerConsentDataStrategy")
	protected CustomerConsentDataStrategy customerConsentDataStrategy;

	@Resource(name = "autoLoginStrategy")
	private AutoLoginStrategy autoLoginStrategy;

	@Resource(name = "consentFacade")
	protected ConsentFacade consentFacade;

	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;


	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "baseStoreService")
	private BaseStoreService baseStoreService;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Override
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	@RequireHardLogIn
	@PreValidateQuoteCheckoutStep
	@PreValidateCheckoutStep(checkoutStep = DELIVERY_ADDRESS)
	public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException
	{
		/* Code portion to execute the cart checks */
		final String redirectCartCheck = executeCartChecks();
		if (!redirectCartCheck.isEmpty())
		{
			return redirectCartCheck;
		}

		getCheckoutFacade().setDeliveryAddressIfAvailable();
		final CartData cartData = getCheckoutFacade().getCheckoutCart();

		populateCommonModelAttributes(model, cartData, new HpeAddressForm());
		hpeFacadeGenericUtil.miraklShopName(model);

		HpeAddressForm newAddress = null;
		if (JaloSession.getCurrentSession().getAttribute(LOGGED_IN_USER_ADDRESS) != null && !(userFacade.isAnonymousUser()))
		{
			newAddress = (HpeAddressForm) JaloSession.getCurrentSession().getAttribute(LOGGED_IN_USER_ADDRESS);
			if (newAddress.getSaveInAddressBook() != null)
			{
				model.addAttribute(LOGGED_IN_USER_ADDRESS, newAddress);
			}
			JaloSession.getCurrentSession().removeAttribute(LOGGED_IN_USER_ADDRESS);
		}
		else if (JaloSession.getCurrentSession().getAttribute(GUEST_ADDRESS) != null && (userFacade.isAnonymousUser()))
		{
			newAddress = (HpeAddressForm) JaloSession.getCurrentSession().getAttribute(GUEST_ADDRESS);
			model.addAttribute(GUEST_ADDRESS, newAddress);
			model.addAttribute(ADDRESS_FORM, newAddress);
			JaloSession.getCurrentSession().removeAttribute(GUEST_ADDRESS);
		}

		model.addAttribute("newAddress", newAddress);

		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCheckoutJsonObjectForAnalytics();
		model.addAttribute("cartDataJsonObject", cartDataJsonObject);
		model.addAttribute("shippingFlag", SHIPPINGFLAG);
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);

		return ControllerConstants.Views.Pages.MultiStepCheckout.AddEditDeliveryAddressPage;
	}

	/**
	 * Method to execute all cart checks
	 *
	 * @return
	 */
	private String executeCartChecks()
	{
		final String redirectString = "";
		final boolean restrictMultiReseller = configurationService.getConfiguration()
				.getBoolean(HpeCoreConstants.MULTI_RESELLER_RESTRICTION);

		final StringBuilder unApprovedProducts = hpeCartFacade.checkProductAvailabilityInCart();

		if (unApprovedProducts != null)
		{
			LOG.debug("DeliveryAddressCheckoutStepController:enterStep --> found some of the product is out of stock "
					+ "hence returning back to Cart page");
			JaloSession.getCurrentSession().setAttribute(SESSION_CART_UNAPPROVED_PRODUCTS, unApprovedProducts);
			return REDIRECT_PREFIX + "/cart";
		}

		final StringBuilder outOfStockProduct = hpeCartFacade.checkCartEntryStock();

		if (outOfStockProduct != null)
		{
			LOG.debug("DeliveryAddressCheckoutStepController:enterStep --> found some of the product is out of stock "
					+ "hence returning back to Cart page");
			JaloSession.getCurrentSession().setAttribute(SESSION_PRODUCT_OUTOFSTOCK, outOfStockProduct);
			return REDIRECT_PREFIX + "/cart";
		}
		if (hpeCartFacade.getUpdateCartForShopDisable())
		{
			LOG.debug(
					"DeliveryAddressCheckoutStepController:enterStep --> found some of the product removed from the cart due to shop disable "
							+ "hence returning back to Cart page");
			JaloSession.getCurrentSession().setAttribute(SESSION_CART_SHOP_DISABLE, true);
			return REDIRECT_PREFIX + "/cart";
		}
		if (restrictMultiReseller && hpeCartFacade.checkMultiResellerInCart())
		{
			LOG.debug("DeliveryAddressCheckoutStepController:enterStep --> Found multi reseller products in Cart "
					+ "hence returning back to Cart page");
			JaloSession.getCurrentSession().setAttribute(SESSION_MULTI_RESELLER, true);
			return REDIRECT_PREFIX + "/cart";
		}
		if (!hpeCartFacade.checkMustBeSoldWithSystem())
		{
			LOG.debug(
					"DeliveryAddressCheckoutStepController:enterStep --> found must be sold with the system products found in Cart "
							+ "hence returning back to Cart page");
			JaloSession.getCurrentSession().setAttribute(SESSION_PRODUCT_RESTRICTION, true);
			return REDIRECT_PREFIX + "/cart";
		}
		return redirectString;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@RequireHardLogIn
	public ResponseEntity<String> add(final HpeAddressForm addressForm, final BindingResult bindingResult, final Model model,
			final RedirectAttributes redirectModel, final HttpServletRequest request, final HttpServletResponse response)
			throws CMSItemNotFoundException, IOException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException,
			DuplicateUidException
	{
		UserModel currentUser = userService.getCurrentUser();
		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		getAddressValidator().validate(addressForm, bindingResult);
		populateCommonModelAttributes(model, cartData, addressForm);
		final ObjectMapper mapper = new ObjectMapper();
		final Map<String, String> map = new HashMap();
		String errorString = null;
		Boolean isShippingReg = Boolean.FALSE;
		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, FALSE);

		if ("true".equals(gtsGeoLocationCheck))
		{
			LOG.debug("******GTS call for shipping address add check*******");

			final GTSRequestData gtsRequestData = hpeStorefrontUtil.setGTSRequestData(currentUser.getUid(), addressForm, null);
			boolean gtsResponse = false;
			try
			{
				gtsResponse = hpeUserFacade.getGTSResponse(gtsRequestData);
			}
			catch (final Exception e)
			{
				LOG.error("DeliveryAddressCheckoutStepController:::add()::: ", e);
				map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING_EXCEPTION, null,
						getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);

			}



			LOG.debug("DeliveryAddressCheckoutStepController::add::GTS Response in DeliveryAddressCheckoutStepController*******"
					+ gtsResponse);
			if (!gtsResponse)
			{
				map.put(ERROR,
						messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING, null, getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
			}
			else
			{
				addressForm.setPartnerNumber(gtsRequestData.getExpPartNum());
			}



		}

		if (bindingResult.hasErrors())
		{
			map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.ADDRESS_ERROR_FORMENTRY_INVALID, null,
					getI18nService().getCurrentLocale()));
			errorString = getGTSError(mapper, map);
			return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
		}

		final AddressData newAddress = hpeAddressDataUtil.convertToAddressData(addressForm);


		userCheck(addressForm);
		if ((null != addressForm.getSaveInAddressBook()) && (Boolean.TRUE.equals(addressForm.getSaveInAddressBook())))
		{
			newAddress.setVisibleInAddressBook(addressForm.getSaveInAddressBook());
		}
		if (StringUtil.isNotEmpty(addressForm.getPassword()))
		{
			final ResponseEntity registrationCheck = userCheck(addressForm, model, request, bindingResult, response, redirectModel);
			if (registrationCheck.getStatusCode().equals(HttpStatus.BAD_REQUEST))
			{

				map.put(ERROR,
						messageSource.getMessage(HPEStorefrontConstant.QUOTE_USER_EXISTS, null, getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);

			}
			currentUser = userService.getCurrentUser();
			hpeUserFacade.removeAddress(currentUser);
			newAddress.setVisibleInAddressBook(true);
			isShippingReg = Boolean.TRUE;
		}
		final boolean addressRequiresReview = verifyAddressData(bindingResult, model, redirectModel, newAddress);

		if (addressRequiresReview)
		{
			map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.ADDRESS_ERROR_FORMENTRY_INVALID, null,
					getI18nService().getCurrentLocale()));
			errorString = getGTSError(mapper, map);
			return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
		}

		getUserFacade().addAddress(newAddress);

		setShippingBillingAddress(newAddress);

		hpeFacadeGenericUtil.miraklShopName(model);
		if (isShippingReg)
		{
			map.put(SUCCESS_MSG, messageSource.getMessage(HPEStorefrontConstant.REGISTRATION_SUCCESS_MSG, null,
					getI18nService().getCurrentLocale()));

			errorString = getGTSError(mapper, map);
			return new ResponseEntity(errorString, HttpStatus.OK);
		}

		return new ResponseEntity((getCheckoutStep().nextStep()), HttpStatus.OK);


	}

	/**
	 * @param newAddress
	 */
	private void setShippingBillingAddress(final AddressData newAddress)
	{
		final AddressData previousSelectedAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
		// Set the new address as the selected checkout delivery address
		getCheckoutFacade().setDeliveryAddress(newAddress);
		if (getCheckoutCustomerStrategy().isAnonymousCheckout() && !StringUtils.isEmpty(newAddress.getEmail()))
		{
			getHpeCustomerFacade().updateGuestUserId(newAddress);
		}
		if (previousSelectedAddress != null && !previousSelectedAddress.isVisibleInAddressBook())
		{ // temporary address should be removed
			getUserFacade().removeAddress(previousSelectedAddress);
		}
		// set payment address
		hpeCartFacade.setBillingAddress(newAddress);
	}

	/**
	 * @param bindingResult
	 * @param model
	 * @param redirectModel
	 * @param newAddress
	 * @return
	 */
	private boolean verifyAddressData(final BindingResult bindingResult, final Model model, final RedirectAttributes redirectModel,
			final AddressData newAddress)
	{
		// Verify the address data.
		final AddressVerificationResult<AddressVerificationDecision> verificationResult = getAddressVerificationFacade()
				.verifyAddressData(newAddress);
		return getAddressVerificationResultHandler().handleResult(verificationResult, newAddress, model, redirectModel,
				bindingResult, getAddressVerificationFacade().isCustomerAllowedToIgnoreAddressSuggestions(),
				"checkout.multi.address.updated");
	}

	/**
	 * @param addressForm
	 */
	private void userCheck(final HpeAddressForm addressForm)
	{
		if (userFacade.isAnonymousUser())
		{
			JaloSession.getCurrentSession().setAttribute(GUEST_ADDRESS, addressForm);
		}
		else if (addressForm.getSaveInAddressBook() == null)
		{
			JaloSession.getCurrentSession().setAttribute(LOGGED_IN_USER_ADDRESS, addressForm);
		}
	}

	protected void processAddressVisibilityAndDefault(final HpeAddressForm addressForm, final AddressData newAddress)
	{
		if (addressForm.getSaveInAddressBook() != null)
		{
			newAddress.setVisibleInAddressBook(addressForm.getSaveInAddressBook().booleanValue());
			if (addressForm.getSaveInAddressBook().booleanValue() && CollectionUtils.isEmpty(getUserFacade().getAddressBook()))
			{
				newAddress.setDefaultAddress(true);
			}
		}
		else if (getCheckoutCustomerStrategy().isAnonymousCheckout())
		{
			newAddress.setDefaultAddress(true);
			newAddress.setVisibleInAddressBook(true);
		}
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	@RequireHardLogIn
	public String editAddressForm(@RequestParam("selectedAddressCode") final String editAddressCode, final Model model,
			final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException
	{
		final ValidationResults validationResults = getCheckoutStep().validate(redirectAttributes);
		if (getCheckoutStep().checkIfValidationErrors(validationResults))
		{
			return getCheckoutStep().onValidation(validationResults);
		}
		hpeFacadeGenericUtil.miraklShopName(model);
		AddressData addressData = null;
		if (StringUtils.isNotEmpty(editAddressCode))
		{
			addressData = getCheckoutFacade().getDeliveryAddressForCode(editAddressCode);
		}

		final HpeAddressForm addressForm = new HpeAddressForm();
		final boolean hasAddressData = addressData != null;
		if (hasAddressData)
		{
			hpeAddressDataUtil.convert(addressData, addressForm);
		}

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		if (addressData != null && addressData.isDefaultAddress())
		{
			addressForm.setDefaultAddress(true);
		}
		addressForm.setSaveInAddressBook(true);
		populateCommonModelAttributes(model, cartData, addressForm);

		if (addressData != null)
		{
			model.addAttribute(SHOW_SAVE_TO_ADDRESS_BOOK_ATTR, Boolean.valueOf(!addressData.isVisibleInAddressBook()));
		}

		return ControllerConstants.Views.Pages.MultiStepCheckout.AddEditDeliveryAddressPage;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	@RequireHardLogIn
	public ResponseEntity<String> edit(final HpeAddressForm addressForm, final BindingResult bindingResult, final Model model,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		final ObjectMapper mapper = new ObjectMapper();
		final Map<String, String> map = new HashMap();
		final UserModel currentUser = userService.getCurrentUser();

		String errorString = null;
		getAddressValidator().validate(addressForm, bindingResult);

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		populateCommonModelAttributes(model, cartData, addressForm);
		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, FALSE);

		if ("true".equals(gtsGeoLocationCheck))
		{
			LOG.debug("******GTS call for shipping address edit check*******");

			final GTSRequestData gtsRequestData = hpeStorefrontUtil.setGTSRequestData(currentUser.getUid(), addressForm, null);
			boolean gtsResponse = false;
			try
			{
				gtsResponse = hpeUserFacade.getGTSResponse(gtsRequestData);
			}
			catch (final Exception e)
			{
				LOG.error("DeliveryAddressCheckoutStepController:::add()::: ", e);
				map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING_EXCEPTION, null,
						getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);

			}



			LOG.debug("DeliveryAddressCheckoutStepController::edit::GTS Response in DeliveryAddressCheckoutStepController*******"
					+ gtsResponse);
			if (!gtsResponse)
			{
				map.put(ERROR,
						messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING, null, getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
			}
			else
			{
				addressForm.setPartnerNumber(gtsRequestData.getExpPartNum());
			}



		}
		if (bindingResult.hasErrors())
		{
			map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.ADDRESS_ERROR_FORMENTRY_INVALID, null,
					getI18nService().getCurrentLocale()));
			errorString = getGTSError(mapper, map);
			return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
		}

		final AddressData newAddress = hpeAddressDataUtil.convertToAddressData(addressForm);

		processAddressVisibility(addressForm, newAddress);

		newAddress.setDefaultAddress(CollectionUtils.isEmpty(getUserFacade().getAddressBook())
				|| getUserFacade().getAddressBook().size() == 1 || Boolean.TRUE.equals(addressForm.getDefaultAddress()));

		final boolean addressRequiresReview = verifyAddressData(bindingResult, model, redirectModel, newAddress);

		if (addressRequiresReview)
		{
			if (StringUtils.isNotEmpty(addressForm.getAddressId()))
			{
				final AddressData addressData = getCheckoutFacade().getDeliveryAddressForCode(addressForm.getAddressId());
				if (addressData != null)
				{
					model.addAttribute(SHOW_SAVE_TO_ADDRESS_BOOK_ATTR, Boolean.valueOf(!addressData.isVisibleInAddressBook()));
					model.addAttribute("edit", Boolean.TRUE);
				}
			}

			map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.ADDRESS_ERROR_FORMENTRY_INVALID, null,
					getI18nService().getCurrentLocale()));
			errorString = getGTSError(mapper, map);
			return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
		}

		hpeUserFacade.editAddress(newAddress);
		getCheckoutFacade().setDeliveryModeIfAvailable();
		getCheckoutFacade().setDeliveryAddress(newAddress);

		return new ResponseEntity((getCheckoutStep().nextStep()), HttpStatus.OK);
	}


	protected void processAddressVisibility(final HpeAddressForm addressForm, final AddressData newAddress)
	{

		if (addressForm.getSaveInAddressBook() == null)
		{
			newAddress.setVisibleInAddressBook(true);
		}
		else
		{
			newAddress.setVisibleInAddressBook(Boolean.TRUE.equals(addressForm.getSaveInAddressBook()));
		}
	}

	@RequestMapping(value = "/remove", method =
	{ RequestMethod.GET, RequestMethod.POST })
	@RequireHardLogIn
	public String removeAddress(@RequestParam("addressCode") final String addressCode, final RedirectAttributes redirectModel,
			final Model model) throws CMSItemNotFoundException
	{
		if (getCheckoutFacade().isRemoveAddressEnabledForCart())
		{
			final AddressData addressData = new AddressData();
			addressData.setId(addressCode);
			getUserFacade().removeAddress(addressData);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
					"account.confirmation.address.removed");
		}
		storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		model.addAttribute(ADDRESS_FORM, new HpeAddressForm());

		return getCheckoutStep().currentStep();
	}

	@RequestMapping(value = "/select", method = RequestMethod.POST)
	@RequireHardLogIn
	public String doSelectSuggestedAddress(final HpeAddressForm addressForm, final RedirectAttributes redirectModel)
	{
		final Set<String> resolveCountryRegions = org.springframework.util.StringUtils
				.commaDelimitedListToSet(configurationService.getConfiguration().getString("resolve.country.regions"));

		final AddressData selectedAddress = hpeAddressDataUtil.convertToAddressData(addressForm);
		final CountryData countryData = selectedAddress.getCountry();

		if (!resolveCountryRegions.contains(countryData.getIsocode()))
		{
			selectedAddress.setRegion(null);
		}

		if (addressForm.getSaveInAddressBook() != null)
		{
			selectedAddress.setVisibleInAddressBook(addressForm.getSaveInAddressBook().booleanValue());
		}

		if (Boolean.TRUE.equals(addressForm.getEditAddress()))
		{
			getUserFacade().editAddress(selectedAddress);
		}
		else
		{
			getUserFacade().addAddress(selectedAddress);
		}

		final AddressData previousSelectedAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
		// Set the new address as the selected checkout delivery address
		getCheckoutFacade().setDeliveryAddress(selectedAddress);
		if (previousSelectedAddress != null && !previousSelectedAddress.isVisibleInAddressBook())
		{ // temporary address should be removed
			getUserFacade().removeAddress(previousSelectedAddress);
		}

		GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, "checkout.multi.address.added");

		return getCheckoutStep().nextStep();

	}


	/**
	 * This method gets called when the "Use this Address" button is clicked. It sets the selected delivery address on
	 * the checkout facade - if it has changed, and reloads the page highlighting the selected delivery address.
	 *
	 * @param selectedAddressCode
	 *           - the id of the delivery address.
	 *
	 * @return - a URL to the page to load.
	 */
	@RequestMapping(value = "/select", method = RequestMethod.GET)
	@RequireHardLogIn
	public ResponseEntity<String> doSelectDeliveryAddress(@RequestParam("selectedAddressCode") final String selectedAddressCode,
			final RedirectAttributes redirectAttributes)
	{
		final ObjectMapper mapper = new ObjectMapper();
		final Map<String, String> map = new HashMap();
		final UserModel currentUser = userService.getCurrentUser();

		String errorString = null;
		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, FALSE);
		final ValidationResults validationResults = getCheckoutStep().validate(redirectAttributes);
		if (getCheckoutStep().checkIfValidationErrors(validationResults))
		{
			return new ResponseEntity(getCheckoutStep().onValidation(validationResults), HttpStatus.OK);
		}
		if (StringUtils.isNotBlank(selectedAddressCode))
		{
			final AddressData selectedAddressData = getCheckoutFacade().getDeliveryAddressForCode(selectedAddressCode);
			final HpeAddressForm addressForm = new HpeAddressForm();
			hpeAddressDataUtil.convert(selectedAddressData, addressForm);
			if (selectedAddressData.getRegion() != null)
			{
				addressForm.setRegionIso(selectedAddressData.getRegion().getIsocodeShort());
			}
			if ("true".equals(gtsGeoLocationCheck))
			{
				LOG.debug("******GTS call for shipping address select check*******");

				final GTSRequestData gtsRequestData = hpeStorefrontUtil.setGTSRequestData(currentUser.getUid(), addressForm, null);
				boolean gtsResponse = false;
				try
				{
					gtsResponse = hpeUserFacade.getGTSResponse(gtsRequestData);
				}
				catch (final Exception e)
				{
					LOG.error("DeliveryAddressCheckoutStepController:::select()::: ", e);
					map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING_EXCEPTION, null,
							getI18nService().getCurrentLocale()));
					errorString = getGTSError(mapper, map);
					return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
				}

				LOG.debug(
						"DeliveryAddressCheckoutStepController::select::GTS Response in DeliveryAddressCheckoutStepController*******"
								+ gtsResponse);
				if (!gtsResponse)
				{
					map.put(ERROR, messageSource.getMessage(HPEStorefrontConstant.GTS_ERROR_HANDLING, null,
							getI18nService().getCurrentLocale()));
					errorString = getGTSError(mapper, map);
					return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
				}
				else
				{
					addressForm.setPartnerNumber(gtsRequestData.getExpPartNum());
					selectedAddressData.setPartnerNumber(gtsRequestData.getExpPartNum());
				}
			}
			hpeUserFacade.editAddress(selectedAddressData);
			setDeliveryAddress(selectedAddressData);

			// set payment address
			hpeCartFacade.setBillingAddress(selectedAddressData);
		}
		return new ResponseEntity(getCheckoutStep().nextStep(), HttpStatus.OK);
	}


	protected void setDeliveryAddress(final AddressData selectedAddressData)
	{
		final AddressData cartCheckoutDeliveryAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
		if (isAddressIdChanged(cartCheckoutDeliveryAddress, selectedAddressData))
		{
			getCheckoutFacade().setDeliveryAddress(selectedAddressData);
			if (cartCheckoutDeliveryAddress != null && !cartCheckoutDeliveryAddress.isVisibleInAddressBook())
			{ // temporary address should be removed
				getUserFacade().removeAddress(cartCheckoutDeliveryAddress);
			}
		}
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String back(final RedirectAttributes redirectAttributes)
	{
		return getCheckoutStep().previousStep();
	}

	@RequestMapping(value = "/next", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String next(final RedirectAttributes redirectAttributes)
	{
		return getCheckoutStep().nextStep();
	}

	protected String getBreadcrumbKey()
	{
		return "checkout.multi." + getCheckoutStep().getProgressBarId() + ".breadcrumb";
	}

	protected CheckoutStep getCheckoutStep()
	{
		return getCheckoutStep(DELIVERY_ADDRESS);
	}

	protected void populateCommonModelAttributes(final Model model, final CartData cartData, final HpeAddressForm addressForm)
			throws CMSItemNotFoundException
	{
		final List<AddressData> threeAddress = hpeUserFacade.getHPELastThreeCheckoutDeliveryAddress();

		model.addAttribute("cartData", cartData);
		model.addAttribute(ADDRESS_FORM, addressForm);
		model.addAttribute("deliveryAddresses", threeAddress);
		model.addAttribute("noAddress", Boolean.valueOf(getCheckoutFlowFacade().hasNoDeliveryAddress()));
		model.addAttribute("addressFormEnabled", Boolean.valueOf(getCheckoutFacade().isNewAddressEnabledForCart()));
		model.addAttribute("removeAddressEnabled", Boolean.valueOf(getCheckoutFacade().isRemoveAddressEnabledForCart()));
		model.addAttribute(SHOW_SAVE_TO_ADDRESS_BOOK_ATTR, Boolean.TRUE);
		model.addAttribute(WebConstants.BREADCRUMBS_KEY, getResourceBreadcrumbBuilder().getBreadcrumbs(getBreadcrumbKey()));

		final String countryCode = getCountryCode(threeAddress);
		model.addAttribute("regions", getI18NFacade().getRegionsForCountryIso(countryCode));
		model.addAttribute("country", countryCode);
		prepareDataForPage(model);
		storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setCheckoutStepLinksForModel(model, getCheckoutStep());
	}

	/**
	 * Address Doctor Integration- Method to Get the Address Suggestions from Address Doctor
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return
	 * @throws CMSItemNotFoundException
	 * @throws IOException
	 */
	@RequestMapping(value = "/checkoutShippingAddressVerification", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String addressDoctor(@ModelAttribute(HPEStorefrontConstant.REGISTER) final HpeAddressForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel) throws CMSItemNotFoundException, IOException
	{
		final HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm.setCountryCode(form.getCountryIso());
		hpeRegisterInputForm.setAddress1(form.getLine1());
		hpeRegisterInputForm.setAddress2(form.getLine2());
		hpeRegisterInputForm.setCity(form.getTownCity());
		hpeRegisterInputForm.setStateCode(form.getRegionIso());
		hpeRegisterInputForm.setZipCode(form.getPostcode());

		//Address Doctor Integration Response
		final String addressDoctorResponse = hpeAddressDoctorIntegrationFacade.hpeAddressDoctorIntegration(hpeRegisterInputForm,
				model);
		if (addressDoctorResponse == null && LOG.isDebugEnabled())
		{
			LOG.debug("DeliveryAddressCheckoutStepController...addressDoctor()..Address Doctor Response is Null");
		}

		return addressDoctorResponse;
	}


	/**
	 * @return the hpeUserFacade
	 */
	public HPEUserFacade getHpeUserFacade()
	{
		return hpeUserFacade;
	}

	/**
	 * @param hpeUserFacade
	 *           the hpeUserFacade to set
	 */
	public void setHpeUserFacade(final HPEUserFacade hpeUserFacade)
	{
		this.hpeUserFacade = hpeUserFacade;
	}

	/**
	 * @return the userService
	 */
	public UserService getUserService()
	{
		return userService;
	}

	/**
	 * @param userService
	 *           the userService to set
	 */
	public void setUserService(final UserService userService)
	{
		this.userService = userService;
	}


	protected String processRegisterUserRequest(final String referer, final HPERegisterForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException, KeyManagementException,
			KeyStoreException, NoSuchAlgorithmException, DuplicateUidException
	{
		if (bindingResult.hasErrors())
		{
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return ERROR;
		}

		HPERegisterData data = new HPERegisterData();
		data = hpeStorefrontUtil.convertToHPERegisterData(data, form);

		final String username = form.getEmail();
		final String password = form.getPwd();
		try
		{
			getHpeCustomerFacade().register(data);
			//Login to HPE Passport After Successful Registration in Hybris DB
			final ResponseEntity<String> loginResponseEntity = hpePassportIntegrationFacade.getHPEPassportLogin(username, password);
			if (loginResponseEntity != null && loginResponseEntity.getStatusCode() == HttpStatus.OK
					&& loginResponseEntity.getBody().contains(HPEStorefrontConstant.LOGIN_SESSIONTOKEN))
			{
				JaloSession.getCurrentSession().setAttribute(HPEPassportConstant.SESSIONTOKEN, loginResponseEntity.getBody());
				final Object session = JaloSession.getCurrentSession().getAttribute(HPEPassportConstant.SESSIONTOKEN);
				LOG.debug("***** JaloSession Object*************" + session);
				getAutoLoginStrategy().login(form.getEmail().toLowerCase(), form.getPwd(), request, response);
				hpeStorefrontUtil.setDefaultAddress();
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
						HPEStorefrontConstant.REG_CONFIRMATION);
			}


		}
		catch (final Exception e)
		{
			LOG.warn("registration failed: ", e);
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			bindingResult.rejectValue(HPEStorefrontConstant.EMAIL, HPEStorefrontConstant.REG_ACCOUNT_EXISTS_ERROR);
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return "registration failed: ";
		}

		// Consent form data
		try
		{
			final ConsentForm consentForm = form.getConsentForm();
			if (consentForm != null && consentForm.getConsentGiven())
			{
				getConsentFacade().giveConsent(consentForm.getConsentTemplateId(), consentForm.getConsentTemplateVersion());
			}
		}
		catch (final Exception e)
		{
			LOG.error("Error occurred while creating consents during registration", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					HPEStorefrontConstant.CONSENT_FORM_GLOBAL_ERROR);
		}

		// save anonymous-consent cookies as ConsentData
		hpeStorefrontUtil.saveAnonymousConsentCookiesAsConsentData(request);
		customerConsentDataStrategy.populateCustomerConsentDataInSession();


		return REDIRECT_PREFIX;
	}

	/**
	 * @return
	 */
	protected AutoLoginStrategy getAutoLoginStrategy()
	{
		return autoLoginStrategy;
	}

	/**
	 * @return
	 */
	public HPECustomerFacade getHpeCustomerFacade()
	{
		return hpeCustomerFacade;
	}

	/**
	 * @param hpeCustomerFacade
	 *           the hpeCustomerFacade to set
	 */
	public void setHpeCustomerFacade(final HPECustomerFacade hpeCustomerFacade)
	{
		this.hpeCustomerFacade = hpeCustomerFacade;
	}


	private ResponseEntity userCheck(final HpeAddressForm addressForm, final Model model, final HttpServletRequest request,
			final BindingResult bindingResult, final HttpServletResponse response, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException, KeyManagementException,
			KeyStoreException, NoSuchAlgorithmException, DuplicateUidException
	{
		HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm = hpeStorefrontUtil.convertToRegisterInputForm(hpeRegisterInputForm, addressForm);

		final ResponseEntity<String> hpeRegistrationData = hpePassportIntegrationFacade.hpeRegisterUser(hpeRegisterInputForm);

		final HPERegisterForm hpeRegisterForm = new HPERegisterForm();
		hpeStorefrontUtil.convertToHPERegisterForm(hpeRegisterForm, addressForm);

		if (hpeRegistrationData != null && hpeRegistrationData.getBody() != null)
		{
			if (hpeRegistrationData.getStatusCode() == HttpStatus.OK
					&& hpeRegistrationData.getBody().contains(HPEStorefrontConstant.PROFILE_IDENTITY))
			{

				processRegisterUserRequest(null, hpeRegisterForm, bindingResult, model, request, response, redirectModel);

				final ContentPageModel quoteCMSPage = getContentPageForLabelOrId(
						ControllerConstants.Views.Pages.QuoteSummary.QUOTESUMMARY_CMS_PAGE);
				storeCmsPageInModel(model, quoteCMSPage);
				setUpMetaDataForContentPage(model, quoteCMSPage);
				return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.BAD_REQUEST);
			}
		}
		else
		{
			return new ResponseEntity<>("Invalid Username or Password", HttpStatus.BAD_REQUEST);
		}
	}

	private String getCountryCode(final List<AddressData> threeAddress)
	{
		if (CollectionUtils.isNotEmpty(threeAddress))
		{
			return threeAddress.get(0).getCountry().getIsocode();
		}
		String countryCode = null;
		final BaseStoreModel currentBaseStore = baseStoreService.getCurrentBaseStore();
		if (currentBaseStore != null)
		{
			countryCode = ((CMSSiteModel) ((List) (currentBaseStore.getCmsSites())).get(0)).getSiteIdentifier();
		}
		if (countryCode != null)
		{
			countryCode = countryCode.toUpperCase();
		}
		return countryCode;
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}

	private String getGTSError(final ObjectMapper mapper, final Map<String, String> map)
	{
		try
		{
			return mapper.writeValueAsString(map);
		}
		catch (final Exception ex)
		{
			LOG.error("Error during HPERegisterPageController - getGTSError", ex);
		}
		return null;
	}
}
