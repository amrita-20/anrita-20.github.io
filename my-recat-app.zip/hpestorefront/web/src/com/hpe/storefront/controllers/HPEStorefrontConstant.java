/**
 *
 */
package com.hpe.storefront.controllers;

import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.hpe.storefront.controllers.misc.HPEAddToCartController;


/**
 * @author Nandhini Marimuthu
 * @version 1.0
 *
 */
public class HPEStorefrontConstant
{
	public static final String USER_LOGIN_DISBALED = "User is Disabled";

	public static final String USER_DETAILS_UPDATED = "account.confirmation.profile.updated";

	public static final String BAD_RESPONSE_FROM_HPEPASSPORT = "Bad Response received from HPE Passport";

	public static final String INVALID_USER = "Your Email/Password combination is incorrect. Please try again.";

	public static final String ERROR_RESPONSE = "errorResponse";

	public static final String VIDEO = "videoBCReferenceId";

	public static final String GTS_ERROR_RESPONSE = "gtsErrorResponse";

	public static final String GTS_ERROR_RESPONSE_CODE_EXCEPTION = "GTS_LOGIN_FAILED_EXCEPTION";

	public static final String GTS_ERROR_RESPONSE_CODE = "GTS_LOGIN_FAILED";

	public static final String GTS_APPROVED_STATUS = "APPROVED";

	public static final String REGISTRATION_SUCCESS_MSG = "text.header.welcome";
	public static final String MODEL_PRODUCT_DATA = "modelProductData";


	/* Register Page Controller Constant */
	public static final Pattern EMAIL_REGEX = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b");
	public static final String COUNTRY_LIST = "CountryList";
	public static final String REGION_LIST = "RegionList";
	public static final String COUNTRY_CODE = "CountryCode";
	public static final String COUNTRY_USCODE = "US";
	public static final String REGISTER = "register";
	public static final String PROFILE_IDENTITY = "profileIdentity";
	public static final String NOADDRESSSUGGESTIONS = "noAddressSuggestions";
	public static final String ADDRESSSUGGESTIONS = "addressSuggestions";
	public static final String INVALID_ADDRESS = "addressDoctorIntegration.invalid.address.entered";
	public static final String ALLOWENTERED = "allowEnteredAddress";
	public static final String ENTEREDADDRESS = "enteredAddress";
	public static final String PERFECTADDRESS = "perfectAddress";
	public static final String ADDRESSSUGGESTION1 = "addressDoctorSuggestion1";
	public static final String ADDRESSSUGGESTION2 = "addressDoctorSuggestion2";
	public static final String ADDRESS = "Address";
	public static final String FIRSTNAME = "firstName";
	public static final String LASTNAME = "lastName";
	public static final String FIRSTNAME_INVALID = "register.firstName.invalid";
	public static final String LASTNAME_INVALID = "register.lastName.invalid";
	public static final String NAME_INVALID = "register.name.invalid";
	public static final String TITLE_CODE = "titleCode";
	public static final String TITLE_INVALID = "register.title.invalid";
	public static final String EMAIL = "email";
	public static final String EMAIL_INVALID = "register.email.invalid";
	public static final String PWD = "pwd"; //NOSONAR
	public static final String PWD_INVALID = "register.pwd.invalid"; //NOSONAR
	public static final String CHECKPWD = "checkPwd"; //NOSONAR
	public static final String CHECKPWD_INVALID = "register.checkPwd.invalid"; //NOSONAR
	public static final String CHECKPWD_VALIDATION = "validation.checkPwd.equals"; //NOSONAR
	public static final String FORM_GLOBAL_ERROR = "form.global.error";
	public static final String CONSENT_FORM_GLOBAL_ERROR = "consent.form.global.error";
	public static final String REG_ACCOUNT_EXISTS_ERROR = "registration.error.account.exists.title";
	public static final String REG_CONFIRMATION = "registration.confirmation.message.title";
	public static final String LOGIN_SESSIONTOKEN = "sessionToken";
	public static final String SEO_ROBOTS_TAG = "robots.content";
	public static final String ELOQUA_ADDRESS = "eloqua.url";
	public static final String ELOQUA_REGISTER_FORMNAME = "eloqua.elqRegisterFormName";
	public static final String ELOQUA_SITEID = "eloqua.elqSiteId";
	public static final String ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1 = "eloqua.C_Aprimo_Activity_ID__Most_Recent1";
	public static final String ELOQUA_C_RESPONSE_TYPE1 = "eloqua.C_Response_Type1";
	public static final String ELOQUA_C_LEAD_SOURCE___MOST_RECENT1 = "eloqua.C_Lead_Source___Most_Recent1";
	public static final String ELOQUA_C_GRM_ID1 = "eloqua.C_GRM_ID1";
	public static final String ELOQUA_C_GRM_CLEANED_STATUS1 = "eloqua.C_GRM_Cleansed_Status1";
	public static final String ELOQUA_C_FORM_SOURCE1 = "eloqua.C_Form_Source1";
	public static final String ELOQUA_FORMNAME = "eloqua.FormName";
	public static final String ELOQUA_PRIVACY_CHANGE_SOURCE = "eloqua.privacyChangeSource";
	public static final String ELOQUA_MCID_DETAIL_FORM_NAME = "eloqua.mcid_detailFormName";
	public static final String ELOQUA_MKP_CART_STATUS = "eloqua.MKP_Cart_Status";
	public static final String ELOQUA_METHOD_OPT_IN = "eloqua.Method_Opt-in";
	public static final String ELOQUA_COOKIE_WRITE = "eloqua.elqCookieWrite";
	public static final String ELOQUA_GET_QUOTE_FORM_NAME = "eloqua.elqGetQuoteFormName";
	public static final String ELOQUA_ADD_TO_CART_FORM_NAME = "eloqua.elqAddToCartFormName";
	public static final String ELOQUA_PRIVACY_CHANGE_SOURCE_ADD_TO_CART = "eloqua.privacyChangeSourceAddToCart";
	public static final String ELOQUA_MKP_CART_STATUS_ADD_TO_CART = "eloqua.MKP_Cart_Status_Add_To_Cart";
	public static final String ELOQUA_CONTACT_US_FORMNAME = "eloqua.elqContactUsFormName";
	public static final String ELOQUA_C_RESPONSE_TYPE1_CONTACT_US = "eloqua.C_Response_Type1_Contact_Us";
	public static final String ELOQUA_C_FORM_SOURCE1_CONTACT_US = "eloqua.C_Form_Source1_Contact_Us";
	public static final String ELOQUA_PRIVACY_CHANGE_SOURCE_CONTACT_US = "eloqua.privacyChangeSourceContactus";
	public static final String ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_GET_QUOTE = "eloqua.C_Aprimo_Activity_ID__Most_Recent1_Get_Quote";
	public static final String ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_ADD_TO_CART = "eloqua.C_Aprimo_Activity_ID__Most_Recent1_Add_To_Cart";
	public static final String ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_CONTACT_US = "eloqua.C_Aprimo_Activity_ID__Most_Recent1_Contact_Us";
	public static final String ELOQUA_ORDER_COMPLETE_FORMNAME = "eloqua.elqOrderCompleteFormName";
	public static final String ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_ORDER_COMPLETE = "eloqua.C_Aprimo_Activity_ID__Most_Recent1_Order_Complete";
	public static final String ELOQUA_C_LEAD_SOURCE___MOST_RECENT1_ORDER_COMPLETE = "eloqua.C_Lead_Source___Most_Recent1_Order_Complete";
	public static final String ELOQUA_PRIVACY_CHANGE_SOURCE_ORDER_COMPLETE = "eloqua.privacyChangeSourceOrderComplete";
	public static final String ELOQUA_MKP_CART_STATUS_ORDER_COMPLETE = "eloqua.eloqua.MKP_Cart_Status_Order_Complete";
	public static final String ELOQUA_PRODUCT_INTEREST_1 = "eloqua.product_interest_1";
	public static final String ELOQUA_MCID_APRIMO_ASSET_GET_QUOTE = "eloqua.mcid_aprimo_asset_getquote";
	public static final String ELOQUA_PRIVACY_CHANGE_RESOURCE_GET_QUOTE = "eloqua.privacyChangeSource";
	public static final String ELOQUA_SALES_PRETEXT_SURVEY = "eloqua.salesPretextSurvey";
	public static final String ELOQUA_PURL_BASE_URL = "eloqua.purlBaseURL";
	public static final String ELOQUA_HAS_SURVEY = "eloqua.HasSurvey";
	public static final String ELOQUA_C_RESPONSE_TYPE1_GET_QUOTE = "eloqua.C_Response_Type1.getquote";
	public static final String ELOQUA_C_LEAD_SOURCE___MOST_RECENT1_GET_QUOTE = "eloqua.C_Lead_Source___Most_Recent1.getquote";
	public static final String ELOQUA_C_FORM_SOURCE1_GET_QUOTE = "eloqua.C_Form_Source1.getquote";
	public static final String QUOTENUMBER = "quotenumber";

	public static final String STORE_ENVIRONMENT_TEST = "store.test";
	public static final String GTS_ERROR_HANDLING = "gts.error.message";
	public static final String GTS_ERROR_HANDLING_EXCEPTION = "gts.error.exception.message";
	public static final String PRODUCT = "product";
	public static final String TITLE = "title";
	public static final String MEDIA = "media";
	public static final String URL = "urlLink";
	public static final String CONTENT = "content";
	public static final String HEADLINE = "headline";
	public static final String LINKNAME1 = "linkname1";
	public static final String LINKNAME2 = "linkname2";
	public static final String LINK1 = "link1";
	public static final String LINK2 = "link2";
	public static final String ORDER = "order";
	public static final String QAID = "qaId";
	public static final String SEQUENCEID = "sequenceId";
	public static final String QUESTION = "question";
	public static final String DESCRIPTION = "description";
	public static final String ANSWERS = "answers";
	public static final String INDEX_ATTR = "indexAttr";
	public static final String GUIDEDSELLING = "guidedSelling";
	public static final String SHOW_CAT_ONLY = "showCategoriesOnly";
	public static final String CAT_NAME = "categoryName";
	public static final String PAGE_TYPE = "pageType";
	public static final String USR_LOCATION = "userLocation";
	public static final String GS_LIST = "gsList";
	public static final String PAGE_SIZES = "pageSizes";
	public static final String SELECTED_PAGE_SIZE = "selectedPageSize";
	public static final String PRODUCT_LIST_JSON_OBJECT = "productListJsonObject";

	public static final String REQ_TIME = "requestTime";
	public static final String RES_TIME = "responseTime";
	public static final String PRODUCT_HIERARCHY = "productHierarchy";
	public static final String PAYLOADSIZE = "payloadSize";
	public static final String PROD_RESULT = "productResult";
	public static final String ZOOM = "zoom";
	public static final String CART_DATA = "cartData";
	public static final String TYPE_MISMATCH = "typeMismatch";
	public static final String SAVE_CART_FORM = "saveCartForm";
	public static final String CONTENT_DESCRIPTION = "Content-Disposition";
	public static final String ERROR_MSG = "errorMsg";
	public static final String SUCCESS_MSG = "successMsg";
	public static final String REMOVE = "REMOVE";
	public static final String GTS_ERROR = "gtsError";
	public static final String LOGGEDINUSER_ADDRESS = "loggedInUserAddress";
	public static final String GUEST_ADDRESS = "guestAddress";
	public static final String US_ISO_CODE = "US";

	public static final String HPEELOQUAMODEL = "hpeEloquaModel";
	public static final String HPEGETQUOTEFORM = "hpeGetQuoteForm";
	public static final String HPEREGISTERFORM = "hpeRegisterForm";
	public static final String GET_QUOTE_URL = "getquote.url";
	public static final String CHANNELCENTRAL_GET_QUOTE_URL = "channelCentral.getquote.url";
	public static final String REMEMBER_ME_TOKEN_VALID = "rememberMeTokenValid";
	public static final String ADDRESS_ERROR_FORMENTRY_INVALID = "address.error.formentry.invalid";
	public static final String QUOTE_USER_EXISTS = "quote.user.exists";
	/* Product Carousel Constant */
	public static final String CAROUSEL_COMPONENT_UID = "YourInventoryComponent";
	public static final String MOXIE_BASE_URL = "moxieBaseUrl";
	public static final String MOXIE = "moxie";

	public static final String URL_LINK = "urlLink";


	public static final String HPEELOGUQ_DATA_LIST = "hpeeloguqDataList";

	public static final String QUICK_ORDER_ERROR_MSG = "quickOrderErrorMsg";
	public static final String QUICK_ORDER_ERROR_DATA = "quickOrderErrorData";
	public static final String NUMBER_SHOWING = "numberShowing";
	public static final String MULTID_ERROR_MSGS = "multidErrorMsgs";
	public static final String MODIFICATIONS = "modifications";
	public static final String IS_QUOTE = "isQuote";
	public static final Logger LOG = Logger.getLogger(HPEAddToCartController.class);
	public static final String BASKET_ERROR_OCCURRED = "basket.error.occurred";
	public static final String BASKET_INFORMATION_QUANTITY_REDUCED_NUMBER_OF_ITEMS_ADDED = "basket.information.quantity.reducedNumberOfItemsAdded.";
	public static final String BASKET_INFORMATION_QUANTITY_NO_ITEMS_ADDED = "basket.information.quantity.noItemsAdded.";
	public static final String ENTRY = "entry";
	public static final String CART_CODE = "cartCode";
	public static final String QUANTITY_ATTR = "quantity";
	public static final String TYPE_MISMATCH_ERROR_CODE = "typeMismatch";
	public static final String ERROR_MSG_TYPE = "errorMsg";
	public static final String QUANTITY_INVALID_BINDING_MESSAGE_KEY = "basket.error.quantity.invalid.binding";
	public static final String SHOWN_PRODUCT_COUNT = "hpestorefront.storefront.minicart.shownProductCount";

	public static final String DELIVERY_ADDRESS = "deliveryAddress";
	public static final String SILENT_ORDER_POST_FORM = "silentOrderPostForm";
	public static final String META_ROBOTS = "metaRobots";
	public static final String ADDRESS_FORM = "addressForm";
	public static final String SOP_PAYMENT_DETAILS_FORM = "sopPaymentDetailsForm";
	public static final String COUNTRY = "country";
	public static final String REGIONS = "regions";
	public static final String SUPPORTED_COUNTRIES = "supportedCountries";
	public static final String ADDRESS_ID = "addressId";
	public static final String CART_DATA_ATTR = "cartData";
	public static final String BILLING_ADDRESS = "billing-address";
	public static final String READ_ONLY_MULTI_D_MAP = "readOnlyMultiDMap";
	public static final String MULTI = "multi";

	public static final String CHECKOUT_MULTI_PAYMENT_METHOD_PAYMENTSERVICE_FAILED_MSG = "checkout.multi.paymentMethod.paymentservice.failedMsg";
	public static final String PAYMENT_AUTHORIZATION_URI = "paymentAuthorizationURI";
	public static final String PAYMENT_AUTHORIZATION_ID = "paymentAuthorizationId";
	public static final String PAYMENT_INFOS = "paymentInfos";
	public static final String PAYMENT_FORM_URL = "paymentFormUrl";
	public static final String SILENT_ORDER_PAGE_DATA = "silentOrderPageData";
	public static final String HAS_NO_PAYMENT_INFO = "hasNoPaymentInfo";
	public static final String CART_DATA_JSON_OBJECT = "cartDataJsonObject";
	public static final String IS_ADDRESS_ADD_MODIFY = "isAddressAddModify";
	public static final String IS_ADDRESS_MODIFIED = "isAddressModified";
	public static final String PAYMENT_METHOD = "payment-method";

	public static final String REDIRECT_PREFIX = "redirect:";

	public static final String IS_PRODUCT_AVAILABLE = "isProductAvailable";
	public static final String CART = "cart";
	public static final String AUTO_GENERATED_NAME = "autoGeneratedName";
	public static final String HAS_SESSION_CART = "hasSessionCart";
	public static final String TEXT_ACCOUNT_SAVED_CART_SAVED_CART_BREADCRUMB = "text.account.savedCart.savedCartBreadcrumb";
	public static final String TEXT_ACCOUNT_SAVED_CARTS = "text.account.savedCarts";
	public static final String TOTAL_PRICE = "totalPrice";
	public static final String SAVED_CART_DATA = "savedCartData";
	public static final String ENTRY_TOTAL_PRICE = "EntryTotalPrice";
	public static final String MY_ACCOUNT_DETAIL = "myAccountDetail";
	public static final String REFRESH_SAVED_CART_INTERVAL = "refreshSavedCartInterval";
	public static final String REFRESH_SAVED_CART = "refreshSavedCart";
	public static final String MY_ACCOUNT_SAVED_CARTS_URL = "/my-account/saved-carts";
	public static final String REDIRECT_TO_SAVED_CARTS_PAGE = REDIRECT_PREFIX + MY_ACCOUNT_SAVED_CARTS_URL;
	public static final String SAVED_CARTS_CMS_PAGE = "saved-carts";
	public static final String SAVED_CART_DETAILS_CMS_PAGE = "savedCartDetailsPage";
	public static final String SAVED_CART_CODE_PATH_VARIABLE_PATTERN = "{cartCode:.*}";
	public static final String REFRESH_UPLOADING_SAVED_CART = "refresh.uploading.saved.cart";
	public static final String REFRESH_UPLOADING_SAVED_CART_INTERVAL = "refresh.uploading.saved.cart.interval";

	public static final String SITE_QUOTE_ENABLED = "siteQuoteEnabled";
	public static final String QUANTITY = "quantity";
	public static final String READ_ONLY = "readOnly";
	public static final String IS_VARIANT_PRODUCT_AVAILABLE = "isVariantProductAvailable";
	public static final String PRDRESTRICTION = "prdrestriction";
	public static final String CART_MULTIRESELLER = "cartMultiReseller";
	public static final String BASKET_PRODUCTRESTRICTION_DISABLE_CHECKOUT = "basket.productrestriction.disable.checkout";
	public static final String BASKET_MULTIRESELLER_DISABLE_CHECKOUT = "basket.multireseller.disable.checkout";
	public static final String CART_IS_RE_CALCULATED_SUCCESSFULLY = "Cart is re calculated successfully";
	public static final String BASKET_SHOPDISABLE_REMOVE_CART = "basket.shopdisable.remove.cart";
	public static final String BASKET_BUNDLE_STOCK_CART = "basket.bundle.stock.check";
	public static final String BASKET_PRODUCT_STOCK_CART = "hpestorefront.savedcart.stockcheck.message";
	public static final String BASKET_PRODUCT_UNAPPROVED_CHECK = "hpestorefront.savedcart.message";
	public static final String REMOVE_MESSAGE = "remvoeMessage";
	public static final String KEYWORDS = "keywords";
	public static final String BASKET_ERROR_QUANTITY_INVALID = "basket.error.quantity.invalid";
	public static final String SUCCESSFUL_MODIFICATION_CODE = "success";
	public static final String VOUCHER_FORM = "voucherForm";
	public static final String SITE_QUOTES_ENABLED = "site.quotes.enabled.";
	public static final String ACTION_CODE_PATH_VARIABLE_PATTERN = "{actionCode:.*}";
	public static final String REDIRECT_CART_URL = REDIRECT_PREFIX + "/cart";
	public static final String REDIRECT_QUOTE_EDIT_URL = REDIRECT_PREFIX + "/quote/%s/edit/";
	public static final String REDIRECT_QUOTE_VIEW_URL = REDIRECT_PREFIX + "/my-account/my-quotes/%s/";

	public static final String EMAIL2 = "email";
	public static final String GIFT_COUPONS = "giftCoupons";
	public static final String ORDERCONFIRMATION_JSON_OBJECT = "orderconfirmationJsonObject";
	public static final String CANONICAL = "canonical";
	public static final String PAYMENT_INFO = "paymentInfo";
	public static final String DELIVERY_MODE = "deliveryMode";
	public static final String ALL_ITEMS = "allItems";
	public static final String ORDER_DATA = "orderData";
	public static final String ORDER_CODE = "orderCode";

	public static final String ELOQUAPRIVACYCHANGECONTACTUS = "eloquaprivacychangecontactus";
	public static final String ELOQUAFORMSOURCECONTACTUS = "eloquaformsourcecontactus";
	public static final String ELOQUARESPONSETYPECONTACTUS = "eloquaresponsetypecontactus";
	public static final String ELOQUACONTACTUSFORMNAME = "eloquacontactusformname";
	public static final String ELOQUAMETHODOPTIN = "eloquamethodoptin";
	public static final String ELOQUAGRMCLEANEDSTATUS = "eloquagrmcleanedstatus";
	public static final String ELOQUAGRMID = "eloquagrmid";
	public static final String ELOQUAAPRIMOACTIVITYIDCONTACTUS = "eloquaaprimoactivityidcontactus";
	public static final String ELOQUALEADSOURCE = "eloqualeadsource";
	public static final String ELOQUASITEID = "eloquasiteid";
	public static final String ELOQUA = "eloqua";
	public static final String ELOQUA_HASSURVEY = "eloquahassurvey";
	public static final String ELOQUA_PURLBASEURL = "eloquapurlbaseurl";
	public static final String ELOQUA_SALES_PRE_TEXT_SURVEY = "eloquasalespretextsurvey";
	public static final String ELOQUA_PRIVACY_CHANGE_RESOURCE_GETQUOTE = "eloquaprivacychangeresourcegetquote";
	public static final String ELOQUA_PRODUCT_INTREST = "eloquaproductinterest";
	public static final String ELOQUA_MCIDAPRIMO_ACTIVITY_IDGETQUOTE = "eloquamcidaprimoactivityidgetquote";
	public static final String ELOQUA_LEAD_SOURCE_GETQUOTE = "eloqualeadsourcegetquote";
	public static final String ELOQUA_FORM_SOURCE_GETQUOTE = "eloquaformsourcegetquote";

	public static final String QUOTENUMBER2 = "quotenumber";
	public static final String HPE_ELOQUA_MODEL = "hpeEloquaModel";
	public static final String CONTACT_PHONE = "contactPhone";
	public static final String CONTACT_MAIL = "contactMail";
	public static final String DECISION_MAKER2 = "decisionMaker";
	public static final String PRODUCT2 = "product";
	public static final String SELECTED_TIME_FRAME = "selectedTimeFrame";
	public static final String PRODUCT_CODE_POST = "productCodePost";
	public static final String QUOTE_DATA_JSON_OBJECT = "quoteDataJsonObject";
	public static final String GET_QUOTE_FORM = "GetQuoteForm";
	public static final String ELOQUAAPRIMOACTIVITYIDGETQUOTE = "eloquaaprimoactivityidgetquote";
	public static final String ELOQUAGETQUOTEFORMNAME = "eloquagetquoteformname";
	public static final String ELOQUACOOKIEWRITE = "eloquacookiewrite";
	public static final String PRODUCT_CODE = "productCode";
	public static final String TITLE_DATA = "titleData";
	public static final String CURRENT_USER = "currentUser";
	public static final String CUSTOMER_ADDRESS = "customerAddress";
	public static final String METATAGS = "metatags";
	public static final String STORETEST = "storetest";
	public static final String ELOQUA_RESPONSE_TYPE_GET_QUOTE = "eloquaresponsetypegetquote";
	public static final String HPE_REGISTER_INPUT_FORM = "hpeRegisterInputForm";
	public static final String QUOTE_CODE = "quoteCode";
	public static final String ELOQUA_PRODUCT_CODE = "eloquaProductCode";

	public static final String SCRIPTVIDEO = "scriptvideo";
	public static final String CONFIGURATOR_TYPE = "configuratorType";

	public static final String PRODUCT_DATA_MODEL_TEN = "productDataModelTen";

	public static final String GALLERY_IMAGES = "galleryImages";

	public static final String EMPTY_RESOURCES = "emptyResources";
	public static final String EMPTY_FEATURES = "emptyFeatures";

	public static final String PRODUCT_REFERENCE_DATA_LIST = "productReferenceDataList";

	public static final String FUTURE_STOCKS = "futureStocks";


	public static final String REVIEWS_TOTAL = "reviewsTotal";

	public static final String REVIEWS2 = "reviews";

	public static final String SHOW_REVIEW_FORM = "showReviewForm";

	public static final String ZOOM_IMAGE_URL = "zoomImageUrl";

	public static final String PRODUCT_VARIANT_LIST_SIZE = "productVariantListSize";


	public static final String PRODUCTJSON2 = "productjson";

	public static final String SHOP_LIST = "shopList";

	public static final String BUNDLE_PRICE = "bundlePrice";

	public static final String LIST_OF_BUNDLE_OFFER = "listOfBundleOffer";

	public static final String LIST_OF_BUNDLE_WITHOUT_OFFER = "listOfBundle";

	public static final String FUTURE_STOCK_ENABLED2 = "futureStockEnabled";

	public static final String US_COUNTRY = "uscountry";




	public static final String ELOQUAMKPCARTSTATUSADDTOCART = "eloquamkpcartstatusaddtocart";

	public static final String ELOQUAFORMSOURCEADDTOCART = "eloquaformsourceaddtocart";

	public static final String ELOQUAFORMSOURCE = "eloquaformsource";




	public static final String ELOQUARESPONSETYPE = "eloquaresponsetype";
	public static final String ELOQUAAPRIMOACTIVITYIDADDTOCART = "eloquaaprimoactivityidaddtocart";
	public static final String ELOQUAADDTOCARTFORMNAME = "eloquaaddtocartformname";
	public static final String CUSTOMER_EMAIL_ADDRESS = "customerEmailAddress";
	public static final String CALL2_END = "call2End";
	public static final String CALL2_START = "call2Start";
	public static final String CALL1_END = "call1End";
	public static final String CALL1_START = "call1Start";
	public static final String AUTH_END = "authEnd";
	public static final String AUTH_START = "authStart";
	public static final String PAYLOAD_SIZE = "payloadSize";
	public static final String RESPONSE_TIME = "responseTime";
	public static final String REQUEST_TIME = "requestTime";
	public static final String SOURCE_CODE = "sourceCode";
	public static final String PRODUCT_RESTRICTION_FLAG = "ProductRestrictionFlag";
	public static final String CUSTOMER_FIRST_NAME = "customerFirstName";
	public static final String CUSTOMER_LAST_NAME = "customerLastName";

	public static final String ELOQUAMKPCARTSTATUS = "eloquamkpcartstatus";
	public static final String ELOQUAPRIVACYCHANGE = "eloquaprivacychange";
	public static final String ELOQUAAPRIMOACTIVITYID = "eloquaaprimoactivityid";
	public static final String ELOQUAREGISTRATIONFORMNAME = "eloquaregistrationformname";

	public static final String SEARCH_RESULTS = "searchResults";

	public static final String SEARCH_TEXT = "searchText";
	public static final String SEARCH_VALUE = "searchValue";
	public static final String USER_LOCATION = "userLocation";
	public static final String SEARCH_PAGE_DATA = "searchPageData";
	public static final String SEARCH_META_DESCRIPTION_ON = "search.meta.description.on";
	public static final String SEARCH_META_DESCRIPTION_RESULTS = "search.meta.description.results";
	public static final String LOGO_URL = "logoUrl";
	public static final String BASE_PRODUCT_CODE = "baseProductCode";
	public static final String STOCK_AVAILABLE_UPPER_LIMIT = "product.stock.available.upper.limit";
	public static final String STOCK_LIMITED_AVAILABLE_UPPER_LIMIT = "product.stock.limited.available.upper.limit";
	public static final String STOCK_LIMITED_AVAILABLE_LOWER_LIMIT = "product.stock.limited.available.lower.limit";
	public static final String CLASSIFICATION_CLASS_CODE = "product.classification.class.code";
	public static final String CLASSIFICATION_SERVICE_CLASS_CODE = "product.service.classification.class.code";
	public static final String CLASSIFICATION_ATTR_NAME = "product.service.classification.attr.name";
	public static final String SOURCE_SERVICE_REFERENCE = "sourceServiceReference";
	public static final String LEAST_PARTNER_PRICE = "leastPricePdp";
	public static final String SHOWMORE_FACET_VALUE_LIMIT = "showmore.facet.value.limit";
	public static final String MAIN_PRODUCT_CODE = "mainProductCode";

	//My account orders page
	public static final String ORDERS_SEARCH_PAGE_DATA = "ordersSearchPageData";
	public static final String ORDERS_PAGE_SIZE = "myaccount.orderhistory.page.size";
	public static final int PAGE_ZERO = 0;
	public static final int PAGE_ONE = 1;
	public static final String FILTERS = "filters";
	public static final String ALL_ORDERS = "All orders";
	public static final String ALL = "all";
	public static final String FILTER_NAME = "filterName";
	public static final String COUNT = "count";

	//My account quotes page
	public static final String QUOTES_SEARCH_PAGE_DATA = "quotesSearchPageData";




	private HPEStorefrontConstant()
	{
	}


	//Order Confirmation Page HPE Contact No
	public static final String HPE_CONTACT_NO_KEY = "hpeContactNo";
	public static final String HPE_CONTACT_NO = "hpe.contact.no";
	public static final String SECO_META_KEYWORD = "seo.homepage.meta.keyword";
	public static final String DATETIMEFORMAT = "hpeOCAWebservice.dateTimeFormat";
	public static final String KILOBYTES = " KB";
	public static final String NO_ERROR_PAYLOAD = "No or Error Payload";
	public static final String HIDE_CTA_SITES = "plp.hidecta.sites";
	public static final String CHANNEL_CENTRAL = "channelCentral";
	public static final String SINGLE_VARIANT = "singleVariant";
	public static final String JSON = "getQuoteJSON";
	public static final String BUTTON_TYPE = "flag";
	public static final String PRODUCTCODE = "productCode";
	public static final String HPE_ELOQUA_FORM = "hpeEloquaForm";
	public static final String ELOQUA_C_BOM = "eloquaC_Bom";
	public static final String LIST_OF_BUNDLE = "bundleList";
	public static final String VAT_INCLUDED = "-vat-Included";

	//Analytics
	public static final String US_SITE_UID = "hpeUSSiteB2C";

	public static final String CATEGORY_DESCRIPTION = "category.og.description";
	public static final String SEO_DESCRIPTION = "seo.homepage.org.text.description";
	public static final String SEO_KEYWORD = "seo.homepage.meta.keyword";


}
