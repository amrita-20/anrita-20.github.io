/*
 * [y] hybris Platform

 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */


/**
 * @author Suneetha Nandhimandalam
 *
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.i18n.I18NService;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.servicelayer.session.SessionService;

import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEAnalyticsUtil;


/**
 * Controller for home page
 */
@Controller
@RequestMapping("/")
public class HPEHomePageController extends HPEAbstractPageController
{

	private static final Logger LOG = Logger.getLogger(HPEHomePageController.class);
	private static final String LOGOUT = "logout";
	private static final String ACCOUNT_CONFIRMATION_SIGNOUT_TITLE = "account.confirmation.signout.title";
	private static final String ACCOUNT_CONFIRMATION_CLOSE_TITLE = "account.confirmation.close.title";

	// Request URL for canonical
	private static final String REQUESTURL = "requestUrl";
	// Added session service to set the request url for canonical tag
	@Resource(name = "sessionService")
	private SessionService sessionService;
	@Resource(name = "mediaService")
	private MediaService mediaService;
	@Resource(name = "configurationService")
	private ConfigurationService configurationService;
	@Resource(name = "catalogVersionService")
	private CatalogVersionService catalogVersionService;

	@Resource(name = "messageSource")
	private MessageSource messageSource;

	@Resource
	private I18NService i18NService;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;


	@RequestMapping(method = RequestMethod.GET)
	public String home(@RequestParam(value = WebConstants.CLOSE_ACCOUNT, defaultValue = "false") final boolean closeAcc,
			@RequestParam(value = LOGOUT, defaultValue = "false") final boolean logout, final Model model,
			final RedirectAttributes redirectModel, final HttpServletRequest request) throws CMSItemNotFoundException
	{
		LOG.debug(" Entering home method...");

		final List<MetaElementData> metadata = new LinkedList<>();

		if (logout)
		{
			String message = ACCOUNT_CONFIRMATION_SIGNOUT_TITLE;
			if (closeAcc)
			{
				message = ACCOUNT_CONFIRMATION_CLOSE_TITLE;
			}
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.INFO_MESSAGES_HOLDER, message);
			return REDIRECT_PREFIX + ROOT;
		}

		storeCmsPageInModel(model, getContentPageForLabelOrId(null));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(null));
		updatePageTitle(model, getContentPageForLabelOrId(null));
		final MediaModel media = getMediaByCode("/images/theme/logo-hybris.png");

		model.addAttribute(HPEStorefrontConstant.ELOQUA,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADDRESS));
		model.addAttribute(HPEStorefrontConstant.STORETEST,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.STORE_ENVIRONMENT_TEST));

		sessionService.setAttribute(REQUESTURL, request.getRequestURL().toString());
		final String description = messageSource.getMessage(HPEStorefrontConstant.SEO_DESCRIPTION, null,
				i18NService.getCurrentLocale());
		final String metaKeywords = messageSource.getMessage(HPEStorefrontConstant.SEO_KEYWORD, null,
				i18NService.getCurrentLocale());
		metadata.add(createMetaElement("keywords", metaKeywords));
		metadata.add(createMetaElement("description", description + ' ' + getCmsSiteService().getCurrentSite().getName()));
		metadata.add(createMetaElementProperty("og:url", sessionService.getAttribute(REQUESTURL).toString()));
		metadata.add(createMetaElementProperty("og:type", "Website"));
		metadata.add(createMetaElementProperty("og:title", "Home"));
		metadata
				.add(createMetaElementProperty("og:description", description + ' ' + getCmsSiteService().getCurrentSite().getName()));
		if (media != null)
		{
			metadata.add(createMetaElementProperty("og:image", media.getURL()));
		}
		model.addAttribute(HPEStorefrontConstant.METATAGS, metadata);
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCartDataJsonObjectForAnalytics();
		model.addAttribute(HPEStorefrontConstant.CART_DATA_JSON_OBJECT, cartDataJsonObject);

		return getViewForPage(model);
	}

	protected MetaElementData createMetaElementProperty(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}

	protected void updatePageTitle(final Model model, final AbstractPageModel cmsPage)
	{
		storeContentPageTitleInModel(model, getPageTitleResolver().resolveHomePageTitle(cmsPage.getTitle()));
	}

	protected MediaModel getMediaByCode(final String mediaCode)
	{
		if (StringUtils.isNotEmpty(mediaCode))
		{
			for (final CatalogVersionModel catalogVersionModel : catalogVersionService.getSessionCatalogVersions())
			{
				final MediaModel media = getMediaByCodeAndCatalogVersion(mediaCode, catalogVersionModel);
				if (media != null)
				{
					return media;
				}
			}
		}
		return null;
	}

	protected MediaModel getMediaByCodeAndCatalogVersion(final String mediaCode, final CatalogVersionModel catalogVersionModel)
	{
		try
		{
			return mediaService.getMedia(catalogVersionModel, mediaCode);
		}
		catch (final UnknownIdentifierException ignore)
		{
			// Ignore this exception
		}
		return null;
	}
}
