/**
 *
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hpe.facades.wishlist.HPEWishlistFacade;


/**
 * @author SU953735
 *
 */
@Controller
@RequestMapping("/bookmark")
public class HPEBookmarkPageController extends AbstractPageController
{
	private static final Logger LOG = Logger.getLogger(HPEBookmarkPageController.class);

	@Resource(name = "hpeWishlist")
	private HPEWishlistFacade wishlistFacade;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public @ResponseBody String addProductToBookmark(@RequestParam("productCode") final String productCode)
	{
		LOG.info("HPEBookmarkPageController::addProductToBookmark::addProductToBookmark method");
		wishlistFacade.addProductToWishlist(productCode);
		return productCode + "added";
	}

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public @ResponseBody String removeProductFromBookmark(@RequestParam("productCode") final String productCode)
	{
		LOG.info("HPEBookmarkPageController::removeProductFromBookmark::removeProductFromBookmark method");
		wishlistFacade.removeProductFromWishlist(productCode);
		return productCode + "removed";

	}


}
