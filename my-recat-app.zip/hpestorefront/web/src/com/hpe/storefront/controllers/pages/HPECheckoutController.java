/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorfacades.flow.impl.SessionOverrideCheckoutFlowFacade;
import de.hybris.platform.acceleratorservices.controllers.page.PageType;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.consent.data.ConsentCookieData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractCheckoutController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.GuestForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.GuestRegisterForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.LoginForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.validation.GuestRegisterValidator;
import de.hybris.platform.acceleratorstorefrontcommons.security.AutoLoginStrategy;
import de.hybris.platform.acceleratorstorefrontcommons.strategy.CustomerConsentDataStrategy;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.commercefacades.consent.ConsentFacade;
import de.hybris.platform.commercefacades.coupon.data.CouponData;
import de.hybris.platform.commercefacades.order.CheckoutFacade;
import de.hybris.platform.commercefacades.order.OrderFacade;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.commerceservices.util.ResponsiveUtils;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.order.OrderEntry;
import de.hybris.platform.servicelayer.exceptions.ModelNotFoundException;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.util.Config;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.order.HPECartFacade;
import com.hpe.facades.order.HPECheckoutFacade;
import com.hpe.facades.registration.HPECustomerFacade;
import com.hpe.facades.registration.data.HPERegisterData;
import com.hpe.hpepassport.constant.HPEPassportConstant;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.address.form.HpeAddressForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.hpe.storefront.security.cookie.HPELoggedInUserNotificationCookieGenerator;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * CheckoutController
 */
@Controller
@RequestMapping(value = "/checkout")
public class HPECheckoutController extends AbstractCheckoutController
{

	private static final Logger LOG = Logger.getLogger(HPECheckoutController.class);
	/**
	 * We use this suffix pattern because of an issue with Spring 3.1 where a Uri value is incorrectly extracted if it
	 * contains on or more '.' characters. Please see https://jira.springsource.org/browse/SPR-6164 for a discussion on
	 * the issue and future resolution.
	 */
	private static final String ORDER_CODE_PATH_VARIABLE_PATTERN = "{orderCode:.*}";

	private static final String CHECKOUT_ORDER_CONFIRMATION_CMS_PAGE_LABEL = "orderConfirmation";
	private static final String CONTINUE_URL_KEY = "continueUrl";
	private static final String CONSENT_FORM_GLOBAL_ERROR = "consent.form.global.error";

	@Resource(name = "hpeCustomerFacade")
	private HPECustomerFacade hpeCustomerFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;

	@Resource(name = "productFacade")
	private ProductFacade productFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "orderFacade")
	private OrderFacade orderFacade;

	@Resource(name = "checkoutFacade")
	private CheckoutFacade checkoutFacade;

	@Resource(name = "guestRegisterValidator")
	private GuestRegisterValidator guestRegisterValidator;

	@Resource(name = "autoLoginStrategy")
	private AutoLoginStrategy autoLoginStrategy;

	@Resource(name = "consentFacade")
	protected ConsentFacade consentFacade;

	@Resource(name = "customerConsentDataStrategy")
	protected CustomerConsentDataStrategy customerConsentDataStrategy;

	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@Resource(name = "hpeDefaultCheckoutFacade")
	private HPECheckoutFacade hpeDefaultCheckoutFacade;

	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "loggedInUserNotificationCookieGenerator")
	private HPELoggedInUserNotificationCookieGenerator loggedInUserNotificationCookieGenerator;


	@ExceptionHandler(ModelNotFoundException.class)
	public String handleModelNotFoundException(final ModelNotFoundException exception, final HttpServletRequest request)
	{
		request.setAttribute("message", exception.getMessage());
		return FORWARD_PREFIX + "/404";
	}

	@RequestMapping(method = RequestMethod.GET)
	public String checkout(final RedirectAttributes redirectModel)
	{
		if (getCheckoutFlowFacade().hasValidCart())
		{
			checkoutFacade.prepareCartForCheckout();
			return getCheckoutRedirectUrl();
		}

		LOG.debug("HPECheckoutController::checkout::Missing, empty or unsupported cart");

		// No session cart or empty session cart. Bounce back to the cart page.
		return REDIRECT_PREFIX + "/cart";
	}

	@RequestMapping(value = "/orderConfirmation/" + ORDER_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.GET)
	@RequireHardLogIn
	public String orderConfirmation(@PathVariable(HPEStorefrontConstant.ORDER_CODE)
	final String orderCode, final HttpServletRequest request, final Model model, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException
	{
		if (JaloSession.getCurrentSession().getAttribute("loggedInUserAddress") != null)
		{
			JaloSession.getCurrentSession().removeAttribute("loggedInUserAddress");
		}
		SessionOverrideCheckoutFlowFacade.resetSessionOverrides();
		return processOrderCode(orderCode, model, request, redirectModel);
	}

	@RequestMapping(value = "/orderConfirmation/userRegOrder/", method = RequestMethod.POST)
	public String orderSummaryUserReg(@RequestParam(HPEStorefrontConstant.ORDER_CODE)
	final String orderCode, final GuestRegisterForm form, final BindingResult bindingResult, final HttpServletRequest request,
			final Model model, final RedirectAttributes redirectModel, final HttpServletResponse response)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, KeyManagementException,
			KeyStoreException, NoSuchAlgorithmException, IOException, DuplicateUidException
	{
		final HpeAddressForm hpeAddressForm = (HpeAddressForm) JaloSession.getCurrentSession().getAttribute("guestAddress");

		hpeAddressForm.setPassword(form.getPwd());

		if (StringUtils.isNotEmpty(form.getPwd()))
		{
			final ResponseEntity registrationCheck = userCheck(hpeAddressForm, model, request, bindingResult, response,
					redirectModel);
			if (registrationCheck.getStatusCode().equals(HttpStatus.BAD_REQUEST))
			{
				GlobalMessages.addErrorMessage(model, "quote.user.exists");
			}
			else
			{
				hpeCustomerFacade.summaryReg(orderCode);
			}
		}
		JaloSession.getCurrentSession().removeAttribute("guestAddress");
		SessionOverrideCheckoutFlowFacade.resetSessionOverrides();
		return processOrderCode(orderCode, model, request, redirectModel);
	}

	@RequestMapping(value = "/orderConfirmation/" + ORDER_CODE_PATH_VARIABLE_PATTERN, method = RequestMethod.POST)
	public String orderConfirmation(final GuestRegisterForm form, final BindingResult bindingResult, final Model model,
			final HttpServletRequest request, final HttpServletResponse response, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException
	{
		getGuestRegisterValidator().validate(form, bindingResult);
		return processRegisterGuestUserRequest(form, bindingResult, model, request, response, redirectModel);
	}

	protected String processRegisterGuestUserRequest(final GuestRegisterForm form, final BindingResult bindingResult,
			final Model model, final HttpServletRequest request, final HttpServletResponse response,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		if (bindingResult.hasErrors())
		{
			form.setTermsCheck(false);
			GlobalMessages.addErrorMessage(model, "form.global.error");
			return processOrderCode(form.getOrderCode(), model, request, redirectModel);
		}
		try
		{
			getCustomerFacade().changeGuestToCustomer(form.getPwd(), form.getOrderCode());
			getAutoLoginStrategy().login(getCustomerFacade().getCurrentCustomer().getUid(), form.getPwd(), request, response);
			getSessionService().removeAttribute(WebConstants.ANONYMOUS_CHECKOUT);
		}
		catch (final DuplicateUidException e)
		{
			// User already exists
			LOG.warn("guest registration failed: " + e);
			form.setTermsCheck(false);
			model.addAttribute(new GuestRegisterForm());
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					"guest.checkout.existingaccount.register.error", new Object[]
					{ form.getUid() });
			return REDIRECT_PREFIX + request.getHeader("Referer");
		}

		// Consent form data
		try
		{
			final ConsentForm consentForm = form.getConsentForm();
			if (consentForm != null && consentForm.getConsentGiven())
			{
				getConsentFacade().giveConsent(consentForm.getConsentTemplateId(), consentForm.getConsentTemplateVersion());
			}
		}
		catch (final Exception e)
		{
			LOG.error("Error occurred while creating consents during registration", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, CONSENT_FORM_GLOBAL_ERROR);
		}

		// save anonymous-consent cookies as ConsentData
		final Cookie cookie = WebUtils.getCookie(request, WebConstants.ANONYMOUS_CONSENT_COOKIE);
		if (cookie != null)
		{
			try
			{
				final ObjectMapper mapper = new ObjectMapper();
				final List<ConsentCookieData> consentCookieDataList = Arrays.asList(mapper.readValue(
						URLDecoder.decode(cookie.getValue(), StandardCharsets.UTF_8.displayName()), ConsentCookieData[].class));
				consentCookieDataList.stream().filter(consentData -> WebConstants.CONSENT_GIVEN.equals(consentData.getConsentState()))
						.forEach(consentData -> consentFacade.giveConsent(consentData.getTemplateCode(),
								Integer.valueOf(consentData.getTemplateVersion())));
			}
			catch (final UnsupportedEncodingException e)
			{
				LOG.error(String.format("Cookie Data could not be decoded : %s", cookie.getValue()), e);
			}
			catch (final IOException e)
			{
				LOG.error("Cookie Data could not be mapped into the Object", e);
			}
			catch (final Exception e)
			{
				LOG.error("Error occurred while creating Anonymous cookie consents", e);
			}
		}

		customerConsentDataStrategy.populateCustomerConsentDataInSession();

		return REDIRECT_PREFIX + "/";
	}

	protected String processOrderCode(final String orderCode, final Model model, final HttpServletRequest request,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{
		OrderData orderDetails;

		try
		{
			orderDetails = hpeDefaultCheckoutFacade.getOrderDetailsForCode(orderCode);
		}
		catch (final UnknownIdentifierException e)
		{
			LOG.warn("Attempted to load an order confirmation that does not exist or is not visible. Redirect to home page.");
			return REDIRECT_PREFIX + ROOT;
		}

		addRegistrationConsentDataToModel(model);

		if (orderDetails.isGuestCustomer() && !StringUtils.substringBefore(orderDetails.getUser().getUid(), "|")
				.equals(getSessionService().getAttribute(WebConstants.ANONYMOUS_CHECKOUT_GUID)))
		{
			return getCheckoutRedirectUrl();
		}

		final List<OrderEntryData> configEntries = new ArrayList<OrderEntryData>();
		final List<ProductOption> options = new ArrayList<>(Arrays.asList(ProductOption.BASIC, ProductOption.URL,
				ProductOption.PRICE, ProductOption.CATEGORIES, ProductOption.VARIANT_MATRIX_BASE));

		setProductDetails(orderDetails, configEntries, options);

		orderDetails = hpeCartFacade.getConfigEntries(configEntries, orderDetails);
		

		model.addAttribute(HPEStorefrontConstant.ORDER_CODE, orderCode);
		model.addAttribute(HPEStorefrontConstant.ORDER_DATA, orderDetails);
		model.addAttribute(HPEStorefrontConstant.ALL_ITEMS, orderDetails.getEntries());
		model.addAttribute(HPEStorefrontConstant.DELIVERY_ADDRESS, orderDetails.getDeliveryAddress());
		model.addAttribute(HPEStorefrontConstant.DELIVERY_MODE, orderDetails.getDeliveryMode());
		model.addAttribute(HPEStorefrontConstant.PAYMENT_INFO, orderDetails.getPaymentInfo());
		model.addAttribute(HPEStorefrontConstant.PAGE_TYPE, PageType.ORDERCONFIRMATION.name());
		model.addAttribute(HPEStorefrontConstant.CANONICAL, request.getRequestURL().toString());
		model.addAttribute(HPEStorefrontConstant.HPE_CONTACT_NO_KEY, Config.getParameter(HPEStorefrontConstant.HPE_CONTACT_NO));

		// Converting orderData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject orderconfirmationJsonObject = hpeAnalyticsUtil.getOrderConfirmationDataForAnalytics(orderDetails);
		model.addAttribute(HPEStorefrontConstant.ORDERCONFIRMATION_JSON_OBJECT, orderconfirmationJsonObject);

		final List<CouponData> giftCoupons = orderDetails.getAppliedOrderPromotions().stream()
				.filter(x -> CollectionUtils.isNotEmpty(x.getGiveAwayCouponCodes())).flatMap(p -> p.getGiveAwayCouponCodes().stream())
				.collect(Collectors.toList());
		model.addAttribute(HPEStorefrontConstant.GIFT_COUPONS, giftCoupons);

		processEmailAddress(model, orderDetails);

		final String continueUrl = (String) getSessionService().getAttribute(WebConstants.CONTINUE_URL);
		model.addAttribute(CONTINUE_URL_KEY, (continueUrl != null && !continueUrl.isEmpty()) ? continueUrl : ROOT);

		final AbstractPageModel cmsPage = getContentPageForLabelOrId(CHECKOUT_ORDER_CONFIRMATION_CMS_PAGE_LABEL);
		storeCmsPageInModel(model, cmsPage);
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(CHECKOUT_ORDER_CONFIRMATION_CMS_PAGE_LABEL));
		model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);

		if (ResponsiveUtils.isResponsive())
		{
			return getViewForPage(model);
		}

		return ControllerConstants.Views.Pages.Checkout.CheckoutConfirmationPage;
	}

	/**
	 * @param orderDetails
	 * @param configEntries
	 * @param options
	 */
	private void setProductDetails(final OrderData orderDetails, final List<OrderEntryData> configEntries,
			final List<ProductOption> options)
	{
		String productCode;
		ProductData productData;
		ProductData baseProductData;
		if (orderDetails.getEntries() != null && !orderDetails.getEntries().isEmpty())
		{
			for (final OrderEntryData entry : orderDetails.getEntries())
			{
				productCode = entry.getProduct().getCode();
				productData = productFacade.getProductForCodeAndOptions(productCode, options);

				if (null != productData.getBaseProduct())
				{
					baseProductData = productFacade.getProductForCodeAndOptions(productData.getBaseProduct(), options);
					productData.setBaseProductUrl(baseProductData.getUrl());
				}
				if (null != productData.getBaseProduct() && null != entry.getConfigID() && entry.getIsStarterProduct())
				{
					baseProductData = productFacade.getProductForCodeAndOptions(productData.getBaseProduct(), options);
					productData.setBaseProductUrl(baseProductData.getUrl());
				}
				entry.setProduct(productData);

				if (StringUtils.isNotEmpty(entry.getConfigID()))
				{
					configEntries.add(entry);
				}
			}
		}
	}

	protected void processEmailAddress(final Model model, final OrderData orderDetails)
	{


		final String uid = orderDetails.getUser().getUid();
		String email = "";

		if (userFacade.isAnonymousUser())
		{
			final String[] tokens = uid.split("\\|");

			if (tokens.length > 1)
			{
				email = tokens[1];
			}
		}
		else
		{

			email = uid;
		}
		model.addAttribute(HPEStorefrontConstant.EMAIL2, email);
	}

	protected GuestRegisterValidator getGuestRegisterValidator()
	{
		return guestRegisterValidator;
	}

	protected AutoLoginStrategy getAutoLoginStrategy()
	{
		return autoLoginStrategy;
	}

	protected void generateOrderSkus()
	{
		String orderedSkus = null;
		final OrderModel order = new OrderModel();

		final List<AbstractOrderEntryModel> entries = order.getEntries();
		final Iterator orderEntriesIterator = entries.iterator();
		while (orderEntriesIterator.hasNext())
		{
			orderedSkus = orderedSkus + ((OrderEntry) orderEntriesIterator.next()).getProduct().getCode();
		}
	}

	private ResponseEntity userCheck(final HpeAddressForm addressForm, final Model model, final HttpServletRequest request,
			final BindingResult bindingResult, final HttpServletResponse response, final RedirectAttributes redirectModel)

	{
		HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm = hpeStorefrontUtil.convertToRegisterInputForm(hpeRegisterInputForm, addressForm);

		final ResponseEntity<String> hpeRegistrationData = hpePassportIntegrationFacade.hpeRegisterUser(hpeRegisterInputForm);

		final HPERegisterForm hpeRegisterForm = new HPERegisterForm();
		hpeStorefrontUtil.convertToHPERegisterForm(hpeRegisterForm, addressForm);

		if (hpeRegistrationData != null && hpeRegistrationData.getBody() != null)
		{
			if (hpeRegistrationData.getStatusCode() == HttpStatus.OK
					&& hpeRegistrationData.getBody().contains(HPEStorefrontConstant.PROFILE_IDENTITY))
			{

				processRegisterUserRequest(null, hpeRegisterForm, bindingResult, model, request, response, redirectModel);
				return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.BAD_REQUEST);
			}
		}
		else
		{
			return new ResponseEntity<>("Invalid Username or Password", HttpStatus.BAD_REQUEST);
		}


	}

	protected String processRegisterUserRequest(final String referer, final HPERegisterForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel)
	{
		if (bindingResult.hasErrors())
		{
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return "error";
		}

		HPERegisterData data = new HPERegisterData();
		data = hpeStorefrontUtil.convertToHPERegisterData(data, form);

		final String username = form.getEmail();
		final String password = form.getPwd();
		try
		{
			hpeCustomerFacade.register(data);
			//Login to HPE Passport After Successful Registration in Hybris DB
			final ResponseEntity<String> loginResponseEntity = hpePassportIntegrationFacade.getHPEPassportLogin(username, password);
			if (loginResponseEntity != null && loginResponseEntity.getStatusCode() == HttpStatus.OK
					&& loginResponseEntity.getBody().contains(HPEStorefrontConstant.LOGIN_SESSIONTOKEN))
			{
				JaloSession.getCurrentSession().setAttribute(HPEPassportConstant.SESSIONTOKEN, loginResponseEntity.getBody());
				final Object session = JaloSession.getCurrentSession().getAttribute(HPEPassportConstant.SESSIONTOKEN);
				LOG.debug("HPECheckoutController::processRegisterUserRequest::JaloSession Object::" + session);
				getAutoLoginStrategy().login(form.getEmail().toLowerCase(), form.getPwd(), request, response);
				hpeStorefrontUtil.setDefaultAddress();
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
						HPEStorefrontConstant.REG_CONFIRMATION);
				loggedInUserNotificationCookieGenerator.addCookie(request, response, form.getEmail());
			}


		}
		catch (final Exception e)
		{
			LOG.warn("registration failed: ", e);
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			bindingResult.rejectValue(HPEStorefrontConstant.EMAIL, HPEStorefrontConstant.REG_ACCOUNT_EXISTS_ERROR);
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return "registration failed: ";
		}

		// Consent form data
		try
		{
			final ConsentForm consentForm = form.getConsentForm();
			if (consentForm != null && consentForm.getConsentGiven())
			{
				getConsentFacade().giveConsent(consentForm.getConsentTemplateId(), consentForm.getConsentTemplateVersion());
			}
		}
		catch (final Exception e)
		{
			LOG.error("Error occurred while creating consents during registration", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					HPEStorefrontConstant.CONSENT_FORM_GLOBAL_ERROR);
		}

		// save anonymous-consent cookies as ConsentData
		hpeStorefrontUtil.saveAnonymousConsentCookiesAsConsentData(request);
		customerConsentDataStrategy.populateCustomerConsentDataInSession();


		return REDIRECT_PREFIX;
	}
}
