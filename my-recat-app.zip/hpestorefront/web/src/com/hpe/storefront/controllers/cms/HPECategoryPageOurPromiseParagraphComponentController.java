/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.c2l.LanguageModel;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.HPECategoryPageOurPromiseParagraphComponentModel;
import com.hpe.facades.category.HPECategory;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;


/**
 * @author NA20006812
 *
 */
@Controller("HPECategoryPageOurPromiseParagraphComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.HPECategoryPageOurPromiseParagraphComponent)
public class HPECategoryPageOurPromiseParagraphComponentController
		extends AbstractCMSComponentController<HPECategoryPageOurPromiseParagraphComponentModel>
{
	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;

	@Resource(name = "hpeCategory")
	private HPECategory hpeCategory;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final HPECategoryPageOurPromiseParagraphComponentModel component)
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
		final LanguageModel currentLanguage = hpeCategory.getCurrentLanguage();
		model.addAttribute(HPEStorefrontConstant.CONTENT, component.getContent());
		model.addAttribute(HPEStorefrontConstant.HEADLINE, component.getHeadline());
		model.addAttribute(HPEStorefrontConstant.LINKNAME1, component.getLinkName1());

		if (component.getLink1() != null)
		{
			if (component.getLink1().contains("http"))
			{
				model.addAttribute(HPEStorefrontConstant.LINK1, component.getLink1());
			}
			else
			{
				model.addAttribute(HPEStorefrontConstant.LINK1,
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getLink1());
			}
		}
		else
		{
			model.addAttribute(HPEStorefrontConstant.LINK1,
					"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}
	}

	@Override
	protected String getView(final HPECategoryPageOurPromiseParagraphComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix
				+ StringUtils.lowerCase(HPECategoryPageOurPromiseParagraphComponentModel._TYPECODE);

	}
}
