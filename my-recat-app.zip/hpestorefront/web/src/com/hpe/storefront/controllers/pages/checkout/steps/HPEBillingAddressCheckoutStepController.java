/*
 * HPEBillingAddressCheckoutStepController
 */
package com.hpe.storefront.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.validation.ValidationResults;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.servicelayer.user.UserService;

import java.util.Collection;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.facades.order.HPECheckoutFacade;
import com.hpe.storefront.address.form.HPESopPaymentDetailsForm;
import com.hpe.storefront.address.form.HpeAddressForm;
import com.hpe.storefront.checkout.steps.validation.impl.HPEBillingAddressValidator;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HpeAddressDataUtil;


/**
 * @author AM20013064
 *
 */
@Controller
@RequestMapping(value = "/checkout/multi/billing-address")
public class HPEBillingAddressCheckoutStepController extends AbstractCheckoutStepController
{

	private static final Logger LOGGER = Logger.getLogger(HPEBillingAddressCheckoutStepController.class);
	@Resource(name = "hpeBillingAddressValidator")
	private HPEBillingAddressValidator paymentDetailsValidator;



	@Resource(name = "hpeAddressDataUtil")
	private HpeAddressDataUtil addressDataUtil;

	@Resource(name = "hpeWePayFacade")
	private com.hpe.facades.wepay.HPEWePayAuthorizationFacade hpeWePayFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "hpeDefaultCheckoutFacade")
	private HPECheckoutFacade hpeDefaultCheckoutFacade;



	@ModelAttribute("billingCountries")
	public Collection<CountryData> getBillingCountries()
	{
		return getCheckoutFacade().getBillingCountries();
	}



	@Override
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	@RequireHardLogIn
	public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException
	{
		getCheckoutFacade().setDeliveryModeIfAvailable();
		setupAddPaymentPage(model);
		setCheckoutStepLinksForModel(model, getCheckoutStep());
		final HPESopPaymentDetailsForm sopPaymentDetailsForm = new HPESopPaymentDetailsForm();
		setupSilentOrderPostPage(sopPaymentDetailsForm, model);
		final HpeAddressForm addressForm = new HpeAddressForm();
		sopPaymentDetailsForm.setBillingAddress(addressForm);
		model.addAttribute(sopPaymentDetailsForm);

		return ControllerConstants.Views.Pages.MultiStepCheckout.AddBillingAddressPage;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@RequireHardLogIn
	public String add(final Model model, @Valid
	final HPESopPaymentDetailsForm paymentDetailsForm, final BindingResult bindingResult, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException
	{

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		model.addAttribute(HPEStorefrontConstant.CART_DATA_ATTR, cartData);

		AddressData addressData = null;

		if (paymentDetailsForm.isUseDeliveryAddress())
		{
			addressData = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
			if (addressData == null)
			{
				GlobalMessages.addErrorMessage(model,
						"checkout.multi.paymentMethod.createSubscription.billingAddress.noneSelectedMsg");
				return ControllerConstants.Views.Pages.MultiStepCheckout.AddBillingAddressPage;
			}
			addressData.setBillingAddress(true); // mark this as billing address
		}
		else
		{
			final HpeAddressForm addressForm = buildAddressForm(paymentDetailsForm);
			addressData = addressDataUtil.convertToAddressData(addressForm);
			addressData.setShippingAddress(Boolean.TRUE.equals(addressForm.getShippingAddress()));
			addressData.setBillingAddress(Boolean.TRUE.equals(addressForm.getBillingAddress()));
		}

		final long startTime = System.currentTimeMillis();
		getAddressVerificationFacade().verifyAddressData(addressData);
		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("HPEBillingAddressCheckoutStepController:::add:::Time taken to validate the addresss by Address Doctor : "
					+ (System.currentTimeMillis() - startTime));
		}

		hpeDefaultCheckoutFacade.createBillingAddress(addressData);
		if (!checkPaymentSubscription(model, paymentDetailsForm, addressData))
		{
			model.addAttribute(HPEStorefrontConstant.ADDRESS_ID, addressData.getId());
			setCheckoutStepLinksForModel(model, getCheckoutStep());
		}

		return getCheckoutStep().nextStep();
	}

	private HpeAddressForm buildAddressForm(final HPESopPaymentDetailsForm paymentDetailsForm)
	{
		final HpeAddressForm hpeAddressForm = new HpeAddressForm();
		hpeAddressForm.setTitleCode(paymentDetailsForm.getBillTo_titleCode());
		hpeAddressForm.setFirstName(paymentDetailsForm.getBillTo_firstName());
		hpeAddressForm.setLastName(paymentDetailsForm.getBillTo_lastName());
		hpeAddressForm.setCompanyName(paymentDetailsForm.getBillTo_company());
		hpeAddressForm.setLastName(paymentDetailsForm.getBillTo_attentionTo());
		hpeAddressForm.setLine1(paymentDetailsForm.getBillTo_street1());
		hpeAddressForm.setLine2(paymentDetailsForm.getBillTo_street2());
		hpeAddressForm.setTownCity(paymentDetailsForm.getBillTo_city());
		hpeAddressForm.setPostcode(paymentDetailsForm.getBillTo_postalCode());
		hpeAddressForm.setRegionIso(paymentDetailsForm.getBillTo_state());
		hpeAddressForm.setCountryIso(paymentDetailsForm.getBillTo_country());
		hpeAddressForm.setPhone(paymentDetailsForm.getBillTo_phoneNumber());
		return hpeAddressForm;
	}

	protected boolean checkPaymentSubscription(final Model model, @Valid
	final HPESopPaymentDetailsForm paymentDetailsForm, final AddressData newPaymentSubscription)
	{

		if (newPaymentSubscription != null && StringUtils.isNotBlank(newPaymentSubscription.getId()))
		{

			if (Boolean.TRUE.equals(paymentDetailsForm.getBillingAddress())
					&& CollectionUtils.isEmpty(getUserFacade().getAddressBook()))
			{
				newPaymentSubscription.setDefaultAddress(true);
			}

		}

		else
		{
			GlobalMessages.addErrorMessage(model, "checkout.multi.paymentMethod.createSubscription.failedMsg");
			return false;
		}
		return true;
	}

	@RequestMapping(value = "/billingaddressform", method = RequestMethod.GET)
	public String getCountryAddressForm(@RequestParam("countryIsoCode")
	final String countryIsoCode, @RequestParam("useDeliveryAddress")
	final boolean useDeliveryAddress, final Model model)
	{

		model.addAttribute(HPEStorefrontConstant.SUPPORTED_COUNTRIES, getCountries());
		model.addAttribute(HPEStorefrontConstant.REGIONS, getI18NFacade().getRegionsForCountryIso(countryIsoCode));
		model.addAttribute(HPEStorefrontConstant.COUNTRY, countryIsoCode);

		final HPESopPaymentDetailsForm sopPaymentDetailsForm = new HPESopPaymentDetailsForm();
		model.addAttribute(HPEStorefrontConstant.SOP_PAYMENT_DETAILS_FORM, sopPaymentDetailsForm);
		if (useDeliveryAddress)
		{
			final AddressData deliveryAddress = getCheckoutFacade().getCheckoutCart().getDeliveryAddress();
			if (deliveryAddress.getRegion() != null && !StringUtils.isEmpty(deliveryAddress.getRegion().getIsocode()))
			{
				sopPaymentDetailsForm.setBillTo_state(deliveryAddress.getRegion().getIsocodeShort());
			}

			sopPaymentDetailsForm.setBillTo_titleCode(deliveryAddress.getTitleCode());
			sopPaymentDetailsForm.setBillTo_firstName(deliveryAddress.getFirstName());
			sopPaymentDetailsForm.setBillTo_lastName(deliveryAddress.getLastName());
			sopPaymentDetailsForm.setBillTo_company(deliveryAddress.getCompanyName());
			sopPaymentDetailsForm.setBillTo_attentionTo(deliveryAddress.getAttentionTo());
			sopPaymentDetailsForm.setBillTo_street1(deliveryAddress.getLine1());
			sopPaymentDetailsForm.setBillTo_street2(deliveryAddress.getLine2());
			sopPaymentDetailsForm.setBillTo_city(deliveryAddress.getTown());
			sopPaymentDetailsForm.setBillTo_postalCode(deliveryAddress.getPostalCode());
			sopPaymentDetailsForm.setBillTo_country(deliveryAddress.getCountry().getIsocode());
			sopPaymentDetailsForm.setBillTo_phoneNumber(deliveryAddress.getPhone());
		}
		return ControllerConstants.Views.Fragments.Checkout.BillingAddressForm;
	}

	@RequestMapping(value = "/remove", method =
	{ RequestMethod.GET, RequestMethod.POST })
	@RequireHardLogIn
	public String removeAddress(@RequestParam("addressCode")
	final String addressCode, final RedirectAttributes redirectModel, final Model model) throws CMSItemNotFoundException
	{
		if (getCheckoutFacade().isRemoveAddressEnabledForCart())
		{
			final AddressData addressData = new AddressData();
			addressData.setId(addressCode);
			getUserFacade().removeAddress(addressData);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
					"account.confirmation.address.removed");
		}
		storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		model.addAttribute(HPEStorefrontConstant.ADDRESS_FORM, new HpeAddressForm());

		return getCheckoutStep().currentStep();
	}



	@RequestMapping(value = "/select", method = RequestMethod.GET)
	@RequireHardLogIn
	public String doSelectDeliveryAddress(@RequestParam("selectedAddressCode")
	final String selectedAddressCode, final RedirectAttributes redirectAttributes)
	{
		final ValidationResults validationResults = getCheckoutStep().validate(redirectAttributes);
		if (getCheckoutStep().checkIfValidationErrors(validationResults))
		{
			return getCheckoutStep().onValidation(validationResults);
		}
		if (StringUtils.isNotBlank(selectedAddressCode))
		{
			hpeDefaultCheckoutFacade.getBillingAddressDataForId(selectedAddressCode, true);

		}
		return getCheckoutStep().nextStep();
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String back(final RedirectAttributes redirectAttributes)
	{

		return getCheckoutStep().previousStep();
	}

	@RequestMapping(value = "/next", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String next(final RedirectAttributes redirectAttributes)
	{

		return getCheckoutStep().nextStep();
	}



	protected void setupAddPaymentPage(final Model model) throws CMSItemNotFoundException
	{

		model.addAttribute(HPEStorefrontConstant.META_ROBOTS, "noindex,nofollow");
		prepareDataForPage(model);
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				getResourceBreadcrumbBuilder().getBreadcrumbs("checkout.multi.paymentMethod.breadcrumb"));
		final ContentPageModel contentPage = getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL);
		storeCmsPageInModel(model, contentPage);
		setUpMetaDataForContentPage(model, contentPage);
		setCheckoutStepLinksForModel(model, getCheckoutStep());
	}

	protected void setupSilentOrderPostPage(final HPESopPaymentDetailsForm sopPaymentDetailsForm, final Model model)
	{


		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		model.addAttribute(HPEStorefrontConstant.SILENT_ORDER_POST_FORM, new HPESopPaymentDetailsForm());
		model.addAttribute(HPEStorefrontConstant.CART_DATA_ATTR, cartData);
		model.addAttribute(HPEStorefrontConstant.DELIVERY_ADDRESS, cartData.getDeliveryAddress());
		model.addAttribute(HPEStorefrontConstant.SOP_PAYMENT_DETAILS_FORM, sopPaymentDetailsForm);
		if (StringUtils.isNotBlank(sopPaymentDetailsForm.getBillTo_country()))
		{
			model.addAttribute(HPEStorefrontConstant.REGIONS,
					getI18NFacade().getRegionsForCountryIso(sopPaymentDetailsForm.getBillTo_country()));
			model.addAttribute(HPEStorefrontConstant.COUNTRY, sopPaymentDetailsForm.getBillTo_country());
		}
	}



	protected CheckoutStep getCheckoutStep()
	{
		return getCheckoutStep(HPEStorefrontConstant.BILLING_ADDRESS);
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}


}
