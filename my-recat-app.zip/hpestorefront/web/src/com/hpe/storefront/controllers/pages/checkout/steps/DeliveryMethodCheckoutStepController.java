/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.pages.checkout.steps;

import static de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages.ERROR_MESSAGES_HOLDER;
import static de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages.INFO_MESSAGES_HOLDER;
import static de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages.addErrorMessage;
import static de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages.addFlashMessage;
import static de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages.addInfoMessage;
import static org.apache.commons.lang3.StringUtils.isEmpty;

import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.PreValidateQuoteCheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.session.SessionService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.facades.util.HPEFacadeGenericUtil;
import com.hpe.storefront.address.form.HPEUpdateShippingOptionForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.mirakl.client.core.exception.MiraklApiException;
import com.mirakl.hybris.facades.order.ShippingFacade;


@Controller
@RequestMapping(value = "/checkout/multi/delivery-method")
public class DeliveryMethodCheckoutStepController extends AbstractCheckoutStepController
{
	private static final Logger LOG = Logger.getLogger(DeliveryMethodCheckoutStepController.class);
	private static final String DELIVERY_METHOD = "delivery-method";
	private static final String ORDER_PRICES_CHANGED_MESSAGE = "order.prices.changed";

	@Resource(name = "shippingFacade")
	protected ShippingFacade shippingFacade;

	@Resource(name = "REDIRECT_TO_DELIVERY_ADDRESS")
	protected String REDIRECT_TO_DELIVERY_ADDRESS;

	@Resource(name = "REDIRECT_TO_DELIVERY_METHOD")
	protected String REDIRECT_TO_DELIVERY_METHOD;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "hpeFacadeGenericUtil")
	private HPEFacadeGenericUtil hpeFacadeGenericUtil;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	private static final String MIRAKL_CONNECTOR_ACTIOVATION_FLAG = "mirakl.connector.activation.flag";

	@RequestMapping(value = "/choose", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	@PreValidateQuoteCheckoutStep
	@PreValidateCheckoutStep(checkoutStep = DELIVERY_METHOD)
	public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException
	{

		final String mirakl_activated = configurationService.getConfiguration().getString(MIRAKL_CONNECTOR_ACTIOVATION_FLAG, Boolean.TRUE.toString());
		if (Boolean.parseBoolean(mirakl_activated))
		{
			try
			{
				shippingFacade.setAvailableShippingOptions();
			}
			catch (final MiraklApiException e)
			{
				LOG.error("Exception occurred while setting available delivery options", e);
				addFlashMessage(redirectAttributes, ERROR_MESSAGES_HOLDER, HPEStorefrontConstant.GTS_ERROR_HANDLING_EXCEPTION);

				return REDIRECT_TO_DELIVERY_ADDRESS;
			}
			if (shippingFacade.updateOffersPrice())
			{
				addInfoMessage(model, ORDER_PRICES_CHANGED_MESSAGE);
			}
		}
		// Try to set default delivery mode
		getCheckoutFacade().setDeliveryModeIfAvailable();

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		model.addAttribute("cartData", cartData);
		model.addAttribute("deliveryMethods", getCheckoutFacade().getSupportedDeliveryModes());
		this.prepareDataForPage(model);
		storeCmsPageInModel(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL));
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				getResourceBreadcrumbBuilder().getBreadcrumbs("checkout.multi.deliveryMethod.breadcrumb"));
		model.addAttribute("metaRobots", "noindex,nofollow");
		model.addAttribute("defaultShippingMethodFlag", "true");

		JaloSession.getCurrentSession().removeAttribute("optionSelected");
		model.addAttribute("dvr", "dvr");
		setCheckoutStepLinksForModel(model, getCheckoutStep());

		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCheckoutJsonObjectForAnalytics();
		model.addAttribute("cartDataJsonObject", cartDataJsonObject);
		hpeFacadeGenericUtil.miraklShopName(model);

		return ControllerConstants.Views.Pages.MultiStepCheckout.ChooseDeliveryMethodPage;
	}

	/**
	 * This method gets called when the "Use Selected Delivery Method" button is clicked. It sets the selected delivery
	 * mode on the checkout facade and reloads the page highlighting the selected delivery Mode.
	 *
	 * @param selectedDeliveryMethod
	 *           - the id of the delivery mode.
	 * @return - a URL to the page to load.
	 */
	@RequestMapping(value = "/select", method = RequestMethod.POST)
	@RequireHardLogIn
	public String doSelectDeliveryMode(@RequestParam("shipping_option")
	final String selectedDeliveryMethod, final Model model, @Valid
	final HPEUpdateShippingOptionForm form, final BindingResult bindingResult)
	{
		if (bindingResult.hasErrors())
		{
			for (final ObjectError error : bindingResult.getAllErrors())
			{
				addErrorMessage(model, error.getDefaultMessage());
			}

			return ControllerConstants.Views.Pages.MultiStepCheckout.ChooseDeliveryMethodPage;
		}

		final String mirakl_activated = configurationService.getConfiguration().getString(MIRAKL_CONNECTOR_ACTIOVATION_FLAG, Boolean.TRUE.toString());

		if (isEmpty(form.getShopId()) || !Boolean.parseBoolean(mirakl_activated))
		{
			getCheckoutFacade().setDeliveryMode(selectedDeliveryMethod);
		}
		else
		{
			shippingFacade.updateShippingOptions(selectedDeliveryMethod, form.getLeadTimeToShip(), form.getShopId());
		}
		JaloSession.getCurrentSession().setAttribute("optionSelected", "true");
		return REDIRECT_TO_DELIVERY_METHOD;
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String back(final RedirectAttributes redirectAttributes)
	{
		return getCheckoutStep().previousStep();
	}

	@RequestMapping(value = "/next", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String next(final RedirectAttributes redirectAttributes)
	{
		final String mirakl_activated = configurationService.getConfiguration().getString(MIRAKL_CONNECTOR_ACTIOVATION_FLAG, Boolean.TRUE.toString());
		if (Boolean.parseBoolean(mirakl_activated))
		{
			try
			{
				shippingFacade.setAvailableShippingOptions();
			}
			catch (final MiraklApiException e)
			{
				LOG.error("DeliveryMethodCheckoutStepController:::next():::Exception while setting available delivery options", e);
				addFlashMessage(redirectAttributes, ERROR_MESSAGES_HOLDER, e.getLocalizedMessage());
				return REDIRECT_TO_DELIVERY_METHOD;
			}
			if (shippingFacade.updateOffersPrice())
			{
				addFlashMessage(redirectAttributes, INFO_MESSAGES_HOLDER, ORDER_PRICES_CHANGED_MESSAGE);
				return REDIRECT_TO_DELIVERY_METHOD;
			}
		}
		return getCheckoutStep().nextStep();
	}

	protected CheckoutStep getCheckoutStep()
	{
		return getCheckoutStep(DELIVERY_METHOD);
	}

	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}
}
