/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */

package com.hpe.storefront.controllers.cms;



import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.CustomerSupportBlockModel;
import com.hpe.storefront.controllers.ControllerConstants;


@Controller("CustomerSupportBlockController")
@RequestMapping(value = ControllerConstants.Actions.Cms.CustomerSupportBlock)
public class CustomerSupportBlockController extends AbstractCMSComponentController<CustomerSupportBlockModel>

{
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model, final CustomerSupportBlockModel component)
	{
		model.addAttribute("shippinginfo", component.getShippingInformation());
		model.addAttribute("email", component.getEmail());
		model.addAttribute("phone", component.getPhone());
		model.addAttribute("availability", component.getAvailability());
	}

	@Override
	protected String getView(final CustomerSupportBlockModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(CustomerSupportBlockModel._TYPECODE);

	}

}
