/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.misc;

import de.hybris.platform.acceleratorservices.urlresolver.SiteBaseUrlResolutionService;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.AbstractController;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.store.services.BaseStoreService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hpe.storefront.controllers.ControllerConstants;


@Controller
public class SiteMapController extends AbstractController
{
	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;


	@Resource
	BaseStoreService baseStoreService;

	@Resource(name = "siteBaseUrlResolutionService")
	private SiteBaseUrlResolutionService siteBaseUrlResolutionService;

	private static final Logger LOG = Logger.getLogger(SiteMapController.class);


	@RequestMapping(value = "/sitemap-index.xml", method = RequestMethod.GET, produces = "application/xml")
	public String getSitemapIndexXml(final Model model, final HttpServletResponse response)
	{
		final List<String> siteMapIndexUrls = new ArrayList<>();

		for (final CMSSiteModel siteModel : cmsSiteService.getSites())
		{
			final String mediaUrlForSite = siteBaseUrlResolutionService.getMediaUrlForSite(siteModel, false, "") + "/sitemap.xml";

			if (mediaUrlForSite.contains("localhost"))
			{
				LOG.debug("Removing URL conatining localhost.");
			}
			else
			{
				siteMapIndexUrls.add(mediaUrlForSite);
			}
		}
		model.addAttribute("siteMapindexUrls", siteMapIndexUrls);
		model.addAttribute("siteMapIndexFlag", true);
		return ControllerConstants.Views.Pages.Misc.MiscSiteMapPage;
	}

	@RequestMapping(value = "/sitemap.xml", method = RequestMethod.GET, produces = "application/xml")
	public String getSitemapXml(final Model model, final HttpServletResponse response)
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();

		final String mediaUrlForSite = siteBaseUrlResolutionService.getMediaUrlForSite(currentSite, false, "");

		final List<String> siteMapUrls = new ArrayList<>();

		final Collection<MediaModel> siteMaps = currentSite.getSiteMaps();
		for (final MediaModel siteMap : siteMaps)
		{
			siteMapUrls.add(mediaUrlForSite + siteMap.getURL());
		}

		model.addAttribute("siteMapIndexFlag", false);
		model.addAttribute("siteMapUrls", siteMapUrls);

		return ControllerConstants.Views.Pages.Misc.MiscSiteMapPage;
	}
}
