/*
*HPEGetQuotePageController
*/
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorservices.storefront.data.MetaElementData;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.ConsentForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.GuestForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.LoginForm;
import de.hybris.platform.acceleratorstorefrontcommons.security.AutoLoginStrategy;
import de.hybris.platform.acceleratorstorefrontcommons.strategy.CustomerConsentDataStrategy;
import de.hybris.platform.variants.model.HPEVariantProductModel;
import org.springframework.context.MessageSource;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.commercefacades.consent.ConsentFacade;
import de.hybris.platform.commercefacades.customer.CustomerFacade;
import de.hybris.platform.commercefacades.order.CartFacade;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.quote.data.QuoteData;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.order.QuoteEntryModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.core.model.product.UnitModel;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.product.UnitService;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.util.Config;
import de.hybris.platform.variants.model.HPEVariantProductModel;
import de.hybris.platform.commercefacades.product.data.PriceData;
import com.hpe.facades.product.HPEProductFacade;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hpe.facades.addressdoctor.HPEAddressDoctorIntegrationFacade;
import com.hpe.facades.channelcentral.data.ChannelCentralResponseData;
import com.hpe.facades.constants.HpeFacadesConstants;
import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.quote.HPEEloquaFacade;
import com.hpe.facades.registration.HPECustomerFacade;
import com.hpe.facades.registration.data.HPERegisterData;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.hpepassport.constant.HPEPassportConstant;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.eloquaintegration.form.HPEGetQuoteForm;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.hpe.storefront.security.cookie.HPELoggedInUserNotificationCookieGenerator;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.storefront.util.HPEStorefrontUtil;

import net.sourceforge.pmd.util.StringUtil;
import de.hybris.platform.commerceservices.i18n.CommerceCommonI18NService;

@Controller
@Scope("tenant")
public class HPEGetQuotePageController extends AbstractPageController
{
	private static final Logger LOGGER = Logger.getLogger(HPEGetQuotePageController.class);
	private static final String ERROR = "error";

	@Resource(name = "hpeEloquaFacade")
	private HPEEloquaFacade eloquaFacade;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "customerFacade")
	private CustomerFacade customerFacade;
	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;

	@Resource(name = "hpeCustomerFacade")
	private HPECustomerFacade hpeCustomerFacade;

	@Resource(name = "autoLoginStrategy")
	private AutoLoginStrategy autoLoginStrategy;

	@Resource(name = "consentFacade")
	private ConsentFacade consentFacade;
	
	@Resource(name = "hpeProductFacade")		
	private HPEProductFacade hpeProductFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "customerConsentDataStrategy")
	protected CustomerConsentDataStrategy customerConsentDataStrategy;

	@Resource(name = "cartFacade")
	private CartFacade cartFacade;

	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@Resource(name = "hpeAddressDoctorIntegrationFacade")
	private HPEAddressDoctorIntegrationFacade hpeAddressDoctorIntegrationFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@Resource(name = "sessionService")
	private SessionService sessionService;

	@Resource(name = "loggedInUserNotificationCookieGenerator")
	private HPELoggedInUserNotificationCookieGenerator loggedInUserNotificationCookieGenerator;

	@Resource(name = "modelService")
	private ModelService modelService;

	@Autowired
	private EventService eventService;

	@Resource
	private UnitService unitService;
	
	@Resource
	private MessageSource messageSource;

	@Resource(name = "productService")
	private ProductService productService;

	private static final String UNIT_CODE = "pieces";
	
	@Resource(name = "commerceCommonI18NService")
	private CommerceCommonI18NService commerceCommonI18NService;
	
	
	@ModelAttribute("vatMessage")
	public String getVatMessage()
	{
		return hpeProductFacade.getVatMessage();
	}

	@RequestMapping(value = "/getquotepage/quoterequest", method = { RequestMethod.GET, RequestMethod.POST })
	public String getQuoteSingleVariant(@RequestParam(value = "productCodePost") final String code,
			final Model model) throws CMSItemNotFoundException
	{
		final String flag = HPEStorefrontConstant.SINGLE_VARIANT;
		fillModelForGetQuote(code, flag, model);
		return getViewForPage(model);
	}

	@RequestMapping(value = "/getQuotePage/customizeItem", method =
	{ RequestMethod.POST }, consumes =
	{ MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<String> channelCentralGetQuote(@RequestBody final ChannelCentralResponseData productConfig,
			final Model model,
			final HttpServletRequest request, final HttpServletResponse response)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException
	{
		final ObjectMapper objectMapper = new ObjectMapper();
		final String JSON = objectMapper.writeValueAsString(productConfig);
		sessionService.setAttribute(HPEStorefrontConstant.JSON, JSON);
		return new ResponseEntity(HttpStatus.OK);
	}

	@RequestMapping(value = "/getquotepage", method =
	{ RequestMethod.GET, RequestMethod.POST })
	public String getQuotePage(final Model model) throws CMSItemNotFoundException
	{
		final String flag = HPEStorefrontConstant.CHANNEL_CENTRAL;
		final String JSON = sessionService.getAttribute(HPEStorefrontConstant.JSON);
		fillModelForGetQuote(JSON, flag, model);
		return getViewForPage(model);
	}

	private void fillModelForGetQuote(final String code, final String flag, final Model model) throws CMSItemNotFoundException
	{

		final String countryCode = hpeStorefrontUtil.getCountryCode();
		final LanguageModel currentLanguage = commerceCommonI18NService.getDefaultLanguage();
		final Locale locale = commerceCommonI18NService.getLocaleForLanguage(currentLanguage);
		ProductData hpeQuoteBaseVariant = new ProductData();
		final String offerConfigId = getUniqueProductConfigId();
		List<QuoteEntryModel> quoteEntryModelList = new ArrayList<>();
		final List<HPEVariantProductModel> productList = new ArrayList<>();
		Model hpeModel = model;
		String eloquaProductCode = "";
		if (null != code && flag.equalsIgnoreCase(HPEStorefrontConstant.CHANNEL_CENTRAL))
		{
			ChannelCentralResponseData channelCentralResponseJson = new ChannelCentralResponseData();
			channelCentralResponseJson = getChannelCentralResponseData(code, channelCentralResponseJson);
			eloquaProductCode = channelCentralResponseJson.getBaseUnits().get(0).getPartNumber();
			final QuoteEntryModel quoteEntryModel = eloquaFacade.getQuoteEntryModel(channelCentralResponseJson);
			quoteEntryModelList.add(quoteEntryModel);
			hpeQuoteBaseVariant = hpeQuoteProductDetail(quoteEntryModel.getProduct().getCode());
			quoteEntryModelList = eloquaFacade.getQuoteEntryModelsForProductConfig(channelCentralResponseJson, quoteEntryModelList);
			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.PRODUCTCODE, hpeQuoteBaseVariant.getCode());
			addQuoteEntry(quoteEntryModelList, productList, offerConfigId);
		}
		else
		{
			eloquaProductCode=code;
		}
		
		if (!userFacade.isAnonymousUser())
		{
			final CustomerData currentUser = eloquaFacade.getCustomerData(hpeModel);
			hpeModel.addAttribute(HPEStorefrontConstant.CURRENT_USER, currentUser);

			final AddressData customerAddress = eloquaFacade.getAddressData();
			hpeModel.addAttribute(HPEStorefrontConstant.CUSTOMER_ADDRESS, customerAddress);
		}
		String bomDetail = "";
				if (!countryCode.equalsIgnoreCase(HPEStorefrontConstant.COUNTRY_USCODE) && null != code && null != quoteEntryModelList
				&& !quoteEntryModelList.isEmpty())
		{

			for (final QuoteEntryModel item : quoteEntryModelList)
			{
				final double totalPrice = item.getTotalPrice() != null ? item.getTotalPrice() : 0.00;
				

				final String elquaoLine = item.getEntryNumber().toString() + '~' + item.getQuantity().toString() + '~'
						+ item.getProduct().getCode() + '~' + item.getProduct().getName(locale) + '~' + totalPrice;

				if (quoteEntryModelList.indexOf(item) != (quoteEntryModelList.size() - 1))
				{
					bomDetail = bomDetail + elquaoLine + '|';
				}
				else
				{
					bomDetail = bomDetail + elquaoLine;
				}
			}

		}
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_C_BOM, bomDetail);

		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_PRODUCT_CODE, eloquaProductCode);
		hpeModel.addAttribute(HPEStorefrontConstant.TITLE_DATA, userFacade.getTitles());
		hpeModel = hpeStorefrontUtil.countryListGenerate(hpeModel);
		hpeModel.addAttribute(HPEStorefrontConstant.PRODUCT_CODE, code);
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA, Config.getParameter(HPEStorefrontConstant.ELOQUA_ADDRESS));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUASITEID, Config.getParameter(HPEStorefrontConstant.ELOQUA_SITEID));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUACOOKIEWRITE, Config.getParameter(HPEStorefrontConstant.ELOQUA_COOKIE_WRITE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUAGETQUOTEFORMNAME, Config.getParameter(HPEStorefrontConstant.ELOQUA_GET_QUOTE_FORM_NAME));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUAAPRIMOACTIVITYIDGETQUOTE,
				Config.getParameter(HPEStorefrontConstant.ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_GET_QUOTE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_RESPONSE_TYPE_GET_QUOTE,
				Config.getParameter(HPEStorefrontConstant.ELOQUA_C_RESPONSE_TYPE1_GET_QUOTE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_HASSURVEY, Config.getParameter(HPEStorefrontConstant.ELOQUA_HAS_SURVEY));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_PURLBASEURL, Config.getParameter(HPEStorefrontConstant.ELOQUA_PURL_BASE_URL));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_SALES_PRE_TEXT_SURVEY, Config.getParameter(HPEStorefrontConstant.ELOQUA_SALES_PRETEXT_SURVEY));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_RESOURCE_GETQUOTE,
				Config.getParameter(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_RESOURCE_GET_QUOTE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_PRODUCT_INTREST, Config.getParameter(HPEStorefrontConstant.ELOQUA_PRODUCT_INTEREST_1));
		hpeModel.addAttribute("eloquamcidaprimoactivityidgetquote",
				Config.getParameter(HPEStorefrontConstant.ELOQUA_MCID_APRIMO_ASSET_GET_QUOTE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUAGRMID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_ID1));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUAGRMCLEANEDSTATUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_CLEANED_STATUS1));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUAMETHODOPTIN,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_METHOD_OPT_IN));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_LEAD_SOURCE_GETQUOTE,
				Config.getParameter(HPEStorefrontConstant.ELOQUA_C_LEAD_SOURCE___MOST_RECENT1_GET_QUOTE));
		hpeModel.addAttribute(HPEStorefrontConstant.ELOQUA_FORM_SOURCE_GETQUOTE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_FORM_SOURCE1_GET_QUOTE));
		hpeModel.addAttribute("GetQuoteForm", new HPEGetQuoteForm());
		
		final JSONObject quoteDataJsonObject = hpeAnalyticsUtil.getQuoteJsonObjectForAnalytics(eloquaProductCode, null);
		hpeModel.addAttribute(HPEStorefrontConstant.QUOTE_DATA_JSON_OBJECT, quoteDataJsonObject);

		hpeModel.addAttribute(HPEStorefrontConstant.PAGE_TYPE, "QUOTE");
		hpeModel.addAttribute(HPEStorefrontConstant.BUTTON_TYPE, flag);
		sessionService.setAttribute("getQuoteFlag", flag);
		final ContentPageModel offersCMSPage = getContentPageForLabelOrId(
				ControllerConstants.Views.Pages.GetQuote.GETQUOTE_CMS_PAGE);
		storeCmsPageInModel(model, offersCMSPage);
		setUpMetaDataForContentPage(model, offersCMSPage);
		sessionService.setAttribute("productCodePost", code);
	}

	/**
	 * @param code
	 */
	private void productDetail(final String code, final Model model)
	{
		final ProductData product = productFacade.getProductForCodeAndOptions(code, Arrays.asList(ProductOption.BASIC,
				ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE, ProductOption.PRICE_RANGE));
		if (product.getBaseProduct() != null)
		{
			final ProductData baseproduct = productFacade.getProductForCodeAndOptions(product.getBaseProduct(), Arrays
					.asList(ProductOption.BASIC, ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE, ProductOption.PRICE_RANGE));
			product.setBaseProductUrl(baseproduct.getUrl());
		}
		else
		{
			product.setUrl(product.getUrl());
		}
		model.addAttribute(HPEStorefrontConstant.PRODUCT, product);
	}

	/**
	 * @param code
	 */
	private ProductData hpeQuoteProductDetail(final String code)
	{
		final ProductData product = productFacade.getProductForCodeAndOptions(code, Arrays.asList(ProductOption.BASIC,
				ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE, ProductOption.PRICE_RANGE));
		if (product.getBaseProduct() != null)
		{
			final ProductData baseproduct = productFacade.getProductForCodeAndOptions(product.getBaseProduct(), Arrays
					.asList(ProductOption.BASIC, ProductOption.PRICE, ProductOption.VARIANT_MATRIX_BASE, ProductOption.PRICE_RANGE));
			product.setBaseProductUrl(baseproduct.getUrl());
		}
		else
		{
			product.getUrl();
		}
		return product;
	}

	@RequestMapping(value = "/handleGetQuote", method = RequestMethod.POST)
	private ResponseEntity<String> addressCheck(@RequestParam(value = "productCode", required = false) final String code,
			@RequestParam(value = "flag", required = false) final String flag,
			@ModelAttribute("GetQuoteForm") final HPEGetQuoteForm form, final Model model, final HttpServletRequest request,
			final BindingResult bindingResult, final HttpServletResponse response, final RedirectAttributes redirectModel)
			throws CMSItemNotFoundException, JsonGenerationException, JsonMappingException, IOException, KeyManagementException,
			KeyStoreException, NoSuchAlgorithmException, DuplicateUidException
	{
		

		final String countryCode = hpeStorefrontUtil.getCountryCode();
		final ObjectMapper mapper = new ObjectMapper();
		final Map<String, String> map = new HashMap();
		String errorString = null;
		ProductData hpeQuoteBaseVariant = new ProductData();
		List<QuoteEntryModel> quoteEntryModelList = new ArrayList<>();
		final List<HPEVariantProductModel> productList = new ArrayList<>();
		final String offerConfigId = getUniqueProductConfigId();
		if (flag.equalsIgnoreCase(HPEStorefrontConstant.CHANNEL_CENTRAL))
		{
			ChannelCentralResponseData channelCentralResponseJson = new ChannelCentralResponseData();
			channelCentralResponseJson = getChannelCentralResponseData(code, channelCentralResponseJson);
			final QuoteEntryModel quoteEntryModel = eloquaFacade.getQuoteEntryModel(channelCentralResponseJson);
			quoteEntryModelList.add(quoteEntryModel);
			hpeQuoteBaseVariant = hpeQuoteProductDetail(quoteEntryModel.getProduct().getCode());
			quoteEntryModelList = eloquaFacade.getQuoteEntryModelsForProductConfig(channelCentralResponseJson, quoteEntryModelList);
			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.PRODUCTCODE, hpeQuoteBaseVariant.getCode());
			for (final QuoteEntryModel quoteEntry : quoteEntryModelList)
			{
				if (quoteEntry.getProduct() instanceof HPEVariantProductModel)
				{
					productList.add((HPEVariantProductModel) quoteEntry.getProduct());
					quoteEntry.setConfigID(offerConfigId);
					quoteEntry.setTotalPrice(quoteEntry.getTotalPrice());
				}
			}
			sessionService.removeAttribute(HPEStorefrontConstant.JSON);
		}
		else if (flag.equalsIgnoreCase(HPEStorefrontConstant.SINGLE_VARIANT))
		{
			final QuoteEntryModel quoteEntryModel = modelService.create(QuoteEntryModel.class);
			final UnitModel unit = unitService.getUnitForCode(UNIT_CODE);
			final ProductModel product = productService.getProduct(code);
			final PriceData price = hpeProductFacade.getProductLeastPartnerPrice(code);
			quoteEntryModel.setUnit(unit);
			quoteEntryModel.setQuantity(Long.valueOf(1));
			quoteEntryModel.setProduct(product);
			quoteEntryModel.setTotalPrice(null != price ? price.getValue().doubleValue() : 0.0);
			quoteEntryModel.setIsStarterProduct(HpeFacadesConstants.ISSTARTERPRODUCT);
			quoteEntryModelList.add(quoteEntryModel);
			hpeQuoteBaseVariant = hpeQuoteProductDetail(code);
			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.PRODUCTCODE, code);
		}
		final QuoteData hpeEloqua = convertToEloquaData(form);
		final HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm.setConfirmPassword(form.getCheckpassword());
		hpeRegisterInputForm.setEmailAddress(form.getC_EmailAddress());
		hpeRegisterInputForm.setFirstName(form.getC_FirstName());
		hpeRegisterInputForm.setLastName(form.getC_LastName());
		hpeRegisterInputForm.setNewPassword(form.getPassword());
		hpeRegisterInputForm.setUserId(form.getC_EmailAddress());
		hpeRegisterInputForm.setContactByEmail("Y");
		hpeRegisterInputForm.setCountryCode(countryCode);
		hpeRegisterInputForm.setZipCode(form.getZipPostal());
		hpeRegisterInputForm.setAddress1(form.getAddress1());
		hpeRegisterInputForm.setAddress2(form.getAddress2());

		if (StringUtil.isNotEmpty(form.getPassword()))
		{
			final ResponseEntity registrationCheck = userCheck(form, hpeRegisterInputForm, model, request, bindingResult, response,
					redirectModel);

			if (registrationCheck.getStatusCode().equals(HttpStatus.BAD_REQUEST))
			{
				map.put(ERROR,
						messageSource.getMessage(HPEStorefrontConstant.QUOTE_USER_EXISTS, null, getI18nService().getCurrentLocale()));
				errorString = getGTSError(mapper, map);
				return new ResponseEntity(errorString, HttpStatus.BAD_REQUEST);
			}
		}
		model.addAttribute(HPEStorefrontConstant.SELECTED_TIME_FRAME, form.getC_Timeframe_to_Buy1());
		eloquaFacade.saveFormDataToEloqua(hpeEloqua, hpeQuoteBaseVariant, quoteEntryModelList, offerConfigId);
		final String quoteCode = sessionService.getAttribute(HPEStorefrontConstant.QUOTENUMBER);
		map.put(HPEStorefrontConstant.QUOTE_CODE, quoteCode);
		model.addAttribute(HPEStorefrontConstant.HPE_REGISTER_INPUT_FORM, hpeRegisterInputForm);
		productDetail(hpeQuoteBaseVariant.getCode(), model);
		final ContentPageModel quoteCMSPage = getContentPageForLabelOrId(
				ControllerConstants.Views.Pages.QuoteSummary.QUOTESUMMARY_CMS_PAGE);
		storeCmsPageInModel(model, quoteCMSPage);
		setUpMetaDataForContentPage(model, quoteCMSPage);
		model.addAttribute(HPEStorefrontConstant.HPEELOQUAMODEL, hpeEloqua);
		map.put(HPEStorefrontConstant.PRODUCT_CODE, code);
		final HPEGetQuoteForm hpeGetQuoteForm = (HPEGetQuoteForm) JaloSession.getCurrentSession()
				.getAttribute(HPEStorefrontConstant.HPEGETQUOTEFORM);
		hpeGetQuoteForm.setZipPostal(form.getZipPostal());
		hpeGetQuoteForm.setC_Email_Opt_In1(form.getC_Email_Opt_In1());
		hpeGetQuoteForm.setC_Phone_Opt_in1(form.getC_Phone_Opt_in1());
		hpeGetQuoteForm.setPurchaseRole1(form.getPurchaseRole1());
		JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.HPEGETQUOTEFORM, hpeGetQuoteForm);
		model.addAttribute("TESTING", "TESTING SUCCESS");
		return new ResponseEntity(mapper.writeValueAsString(map), HttpStatus.OK);
	}

	ChannelCentralResponseData getChannelCentralResponseData(final String code,
			ChannelCentralResponseData channelCentralResponseJson)
	{
		final ObjectMapper objectMapper = new ObjectMapper();
		if (StringUtil.isNotEmpty(code))
		{
			try
			{
				channelCentralResponseJson = objectMapper.readValue(code, ChannelCentralResponseData.class);
			}
			catch (final JsonParseException e)
			{
				LOGGER.error("HPEGetQuotePageController:JsonParseException", e);

			}
			catch (final org.codehaus.jackson.map.JsonMappingException e)
			{
				LOGGER.error("HPEGetQuotePageController:JsonMappingException", e);
			}
			catch (final IOException e)
			{
				LOGGER.error("HPEGetQuotePageController:IOException", e);
			}
		
		}

		return channelCentralResponseJson;
	}
	/**
	 * @param mapper
	 * @param map
	 * @return
	 */
	private String getGTSError(final ObjectMapper mapper, final Map<String, String> map)
	{
		try
		{
			return mapper.writeValueAsString(map);
		}
		catch (final Exception ex)
		{
			LOGGER.error("Error during HPERegisterPageController - getGTSError", ex);
		}
		return null;
	}

	@RequestMapping(value = "/quotesummarypage", method = RequestMethod.GET)
	public String getQuoteSummary(final Model model,
			final HttpServletRequest request) throws CMSItemNotFoundException
	{
		productDetail(sessionService.getAttribute(HPEStorefrontConstant.PRODUCTCODE), model);
		final String quoteCode = sessionService.getAttribute(HPEStorefrontConstant.QUOTENUMBER);
		final QuoteData hpeQuoteData = eloquaFacade.getQuoteData(quoteCode);
		model.addAttribute(HPEStorefrontConstant.HPE_ELOQUA_MODEL, hpeQuoteData);
                 final ContentPageModel quoteCMSPage = getContentPageForLabelOrId(
				ControllerConstants.Views.Pages.QuoteSummary.QUOTESUMMARY_CMS_PAGE);
		model.addAttribute(HPEStorefrontConstant.HPE_ELOQUA_FORM,
				sessionService.getAttribute(HPEStorefrontConstant.HPEGETQUOTEFORM));
		storeCmsPageInModel(model, quoteCMSPage);
		setUpMetaDataForContentPage(model, quoteCMSPage);
		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject quoteDataJsonObject = hpeAnalyticsUtil
				.getQuoteJsonObjectForAnalytics(sessionService.getAttribute(HPEStorefrontConstant.PRODUCTCODE), quoteCode);
		model.addAttribute("quoteDataJsonObject", quoteDataJsonObject);
		return getViewForPage(model);
	}

	@RequestMapping(value = "/quotesummaryhistory", method = RequestMethod.GET)
	public String getQuoteHistory(@RequestParam(value = "quoteCode") final String quote, final Model model)
			throws CMSItemNotFoundException
	{
		final QuoteData hpeQuoteData = eloquaFacade.getQuoteData(quote);
		model.addAttribute(HPEStorefrontConstant.HPE_ELOQUA_MODEL, hpeQuoteData);
		final ContentPageModel quoteCMSPage = getContentPageForLabelOrId(
				ControllerConstants.Views.Pages.QuoteSummary.QUOTESUMMARY_CMS_PAGE);
		storeCmsPageInModel(model, quoteCMSPage);
		setUpMetaDataForContentPage(model, quoteCMSPage);
		return getViewForPage(model);
	}

	/**
	 *
	 */
	private ResponseEntity userCheck(final HPEGetQuoteForm form, final HPERegisterInputForm hpeRegisterInputForm,
			final Model model, final HttpServletRequest request, final BindingResult bindingResult,
			final HttpServletResponse response, final RedirectAttributes redirectModel)
	{
		final ResponseEntity<String> hpeRegistrationData = hpePassportIntegrationFacade.hpeRegisterUser(hpeRegisterInputForm);
		final String countryCode = hpeStorefrontUtil.getCountryCode();
		final HPERegisterForm hpeRegisterForm = new HPERegisterForm();
		hpeRegisterForm.setFirstName(form.getC_FirstName());
		hpeRegisterForm.setLastName(form.getC_LastName());
		hpeRegisterForm.setEmail(form.getC_EmailAddress());
		hpeRegisterForm.setEmailCheck("Y");
		hpeRegisterForm.setCountryCode(countryCode);
		hpeRegisterForm.setPwd(form.getPassword());
		hpeRegisterForm.setCheckPwd(form.getCheckpassword());
		hpeRegisterForm.setTitleCode(form.getTitleCode());
		hpeRegisterForm.setAddress1(form.getAddress1());
		hpeRegisterForm.setAddress2(form.getAddress2());
		hpeRegisterForm.setCity(form.getC_City());
		hpeRegisterForm.setCompany(form.getC_Company());
		hpeRegisterForm.setZipCode(form.getZipPostal());
		hpeRegisterForm.setStateCode(form.getStateProv());

		try
		{
			if (hpeRegistrationData != null && hpeRegistrationData.getBody() != null)
			{
				if (hpeRegistrationData.getStatusCode() == HttpStatus.OK
						&& hpeRegistrationData.getBody().contains(HPEStorefrontConstant.PROFILE_IDENTITY))
				{

					processRegisterUserRequest(null, hpeRegisterForm, bindingResult, model, request, response, redirectModel);

					final ContentPageModel quoteCMSPage = getContentPageForLabelOrId(
							ControllerConstants.Views.Pages.QuoteSummary.QUOTESUMMARY_CMS_PAGE);
					storeCmsPageInModel(model, quoteCMSPage);
					setUpMetaDataForContentPage(model, quoteCMSPage);
					return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity<>(hpeRegistrationData.getBody(), HttpStatus.BAD_REQUEST);
				}
			}
		}
		catch (final CMSItemNotFoundException ex)
		{
			LOGGER.error("HPEGetQuotePageController:userCheck::Error during HPEGetQuotePageController - userCheck", ex);
		}
		return new ResponseEntity<>("Invalid Username or Password", HttpStatus.BAD_REQUEST);
	}

	/**
	 * @param hpeGetQuoteForm
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return
	 */
	@RequestMapping(value = "/getQuoteAddressSuggestion", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)

	public @ResponseBody String addressDoctor(@ModelAttribute(HPEStorefrontConstant.REGISTER) final HPERegisterForm form,
			final BindingResult bindingResult, final Model model, final HPEGetQuoteForm hpeGetQuoteForm,
			final RedirectAttributes redirectModel) throws CMSItemNotFoundException, IOException
	{
		final HPERegisterInputForm hpeRegisterInputForm = new HPERegisterInputForm();
		hpeRegisterInputForm.setCountryCode(hpeGetQuoteForm.getC_Country());
		hpeRegisterInputForm.setAddress1(hpeGetQuoteForm.getAddress1());
		hpeRegisterInputForm.setAddress2(hpeGetQuoteForm.getAddress2());
		hpeRegisterInputForm.setCity(hpeGetQuoteForm.getC_City());
		hpeRegisterInputForm.setStateCode(hpeGetQuoteForm.getStateProv());
		hpeRegisterInputForm.setZipCode(hpeGetQuoteForm.getZipPostal());
		JaloSession.getCurrentSession().setAttribute("hpeGetQuoteForm", hpeGetQuoteForm);
		//Address Doctor Integration Response
		final String addressDoctorResponse = hpeAddressDoctorIntegrationFacade.hpeAddressDoctorIntegration(hpeRegisterInputForm,
				model);
		if (addressDoctorResponse != null)
		{
			LOGGER.debug("GetQuotePageController...AddressDoctorResponse");
		}
		else
		{
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("GetQuotePageController::addressDoctor()::Address Doctor Response is Null");
			}
		}
		return addressDoctorResponse;
	}

	/**
	 * @param hpeGetQuoteForm
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return
	 */

	private QuoteData convertToEloquaData(final HPEGetQuoteForm form)
	{
		final QuoteData hpeEloqua = new QuoteData();
		hpeEloqua.setC_Country(form.getC_Country());
		hpeEloqua.setC_FirstName(form.getC_FirstName());
		hpeEloqua.setC_LastName(form.getC_LastName());
		hpeEloqua.setC_Company(form.getC_Company());
		hpeEloqua.setAddress1(form.getAddress1());
		hpeEloqua.setAddress2(form.getAddress2());
		hpeEloqua.setStateProv(form.getStateProv());
		hpeEloqua.setZipPostal(form.getZipPostal());
		hpeEloqua.setC_City(form.getC_City());
		hpeEloqua.setC_EmailAddress(form.getC_EmailAddress());
		hpeEloqua.setC_MobilePhone(form.getC_MobilePhone());
		hpeEloqua.setC_Business_Need(form.getC_Business_Need());
		hpeEloqua.setC_Estimated_Budget1(form.getC_Estimated_Budget1());
		hpeEloqua.setC_MobilePhone(form.getC_MobilePhone());
		hpeEloqua.setC_Estimated_Budget1(form.getC_Estimated_Budget1());
		hpeEloqua.setC_BusPhone(form.getC_BusPhone());
		hpeEloqua.setC_Lead_Currency1(form.getC_Lead_Currency1());
		hpeEloqua.setMobileOptIn1(form.getMobileOptIn1());
		hpeEloqua.setC_Timeframe_to_Buy1(form.getC_Timeframe_to_Buy1());
		hpeEloqua.setC_Phone_Opt_in1(form.getC_Phone_Opt_in1());
		hpeEloqua.setC_Email_Opt_In1(form.getC_Email_Opt_In1());
		hpeEloqua.setPurchaseRole1(form.getPurchaseRole1());
		return hpeEloqua;
	}
	protected String processRegisterUserRequest(final String referer, final HPERegisterForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel)

	{
		if (bindingResult.hasErrors())
		{
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return "error";
		}
		HPERegisterData data = new HPERegisterData();
		data = hpeStorefrontUtil.populateBasicRegisterData(data, form);
		data.setCountryCode(form.getCountryCode());
		data.setZipCode(form.getZipCode());
		data.setStateCode(form.getStateCode());
		final String username = form.getEmail();
		final String password = form.getPwd();
		try
		{
			getHpeCustomerFacade().register(data);
			//Login to HPE Passport After Successful Registration in Hybris DB
			final ResponseEntity<String> loginResponseEntity = hpePassportIntegrationFacade.getHPEPassportLogin(username, password);
			if (loginResponseEntity != null && loginResponseEntity.getStatusCode() == HttpStatus.OK
					&& loginResponseEntity.getBody().contains(HPEStorefrontConstant.LOGIN_SESSIONTOKEN))
			{
				JaloSession.getCurrentSession().setAttribute(HPEPassportConstant.SESSIONTOKEN, loginResponseEntity.getBody());
				final Object session = JaloSession.getCurrentSession().getAttribute(HPEPassportConstant.SESSIONTOKEN);
				LOGGER.debug("***** JaloSession Object*************" + session);
				getAutoLoginStrategy().login(form.getEmail().toLowerCase(), form.getPwd(), request, response);
				GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER,
						HPEStorefrontConstant.REG_CONFIRMATION);
				loggedInUserNotificationCookieGenerator.addCookie(request, response, form.getEmail());
			}
		}
		catch (final DuplicateUidException e)
		{
			LOGGER.warn("registration failed: ", e);
			form.setTermsCheck(false);
			model.addAttribute(form);
			model.addAttribute(new LoginForm());
			model.addAttribute(new GuestForm());
			bindingResult.rejectValue(HPEStorefrontConstant.EMAIL, HPEStorefrontConstant.REG_ACCOUNT_EXISTS_ERROR);
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.FORM_GLOBAL_ERROR);
			return "registration failed: ";
		}
		// Consent form data
		try
		{
			final ConsentForm consentForm = form.getConsentForm();
			if (consentForm != null && consentForm.getConsentGiven())
			{
				getConsentFacade().giveConsent(consentForm.getConsentTemplateId(), consentForm.getConsentTemplateVersion());
			}
		}
		catch (final Exception e)
		{
			LOGGER.error("Error occurred while creating consents during registration", e);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER,
					HPEStorefrontConstant.CONSENT_FORM_GLOBAL_ERROR);
		}
		// save anonymous-consent cookies as ConsentData
		hpeStorefrontUtil.saveAnonymousConsentCookiesAsConsentData(request);
		customerConsentDataStrategy.populateCustomerConsentDataInSession();
		return REDIRECT_PREFIX;
	}

	/**
	 * @return
	 */
	protected AutoLoginStrategy getAutoLoginStrategy()
	{
		return autoLoginStrategy;
	}

	/**
	 * @return
	 */
	public HPECustomerFacade getHpeCustomerFacade()
	{
		return hpeCustomerFacade;
	}

	/**
	 * @param hpeCustomerFacade
	 *           the hpeCustomerFacade to set
	 */
	public void setHpeCustomerFacade(final HPECustomerFacade hpeCustomerFacade)
	{
		this.hpeCustomerFacade = hpeCustomerFacade;
	}


	@ModelAttribute("canonical")
	public String getRequestToModel(final HttpServletRequest request)
	{
		final String url = request.getRequestURL().toString();
		if (url.endsWith("/"))
		{
			return url.substring(0, url.lastIndexOf('/'));
		}
		return url;
	}
		@Override
		protected MetaElementData createMetaElement(final String name, final String content)
	{
		final MetaElementData element = new MetaElementData();
		element.setProperty(name);
		element.setContent(content);
		return element;
	}

	/**
	 * @return
	 */
	private String getUniqueProductConfigId()
	{
		final UUID uuid = UUID.randomUUID();
		return uuid.toString().replace("-", "");
	}

	private void addQuoteEntry(final List<QuoteEntryModel> quoteEntryModelList, final List<HPEVariantProductModel> productList,
			final String offerConfigId)
	{
		for (final QuoteEntryModel quoteEntry : quoteEntryModelList)
		{
			if (quoteEntry.getProduct() instanceof HPEVariantProductModel)
			{
				productList.add((HPEVariantProductModel) quoteEntry.getProduct());
				quoteEntry.setConfigID(offerConfigId);
			}
		}

	}

}
