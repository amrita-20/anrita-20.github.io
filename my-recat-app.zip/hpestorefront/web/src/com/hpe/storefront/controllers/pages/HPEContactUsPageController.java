/**
 *
 */
package com.hpe.storefront.controllers.pages;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hpe.facades.country.HPECountryFacade;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;



/**
 * @author NI953553
 *
 */
@Controller
public class HPEContactUsPageController extends AbstractPageController
{
	@Resource(name = "hpeCountryFacade")
	private HPECountryFacade hpeCountryFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@RequestMapping(value = "/contactus", method = RequestMethod.GET)
	public String contactUs(final Model model, final HttpServletRequest request) throws CMSItemNotFoundException
	{
		model.addAttribute(HPEStorefrontConstant.ELOQUA,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_ADDRESS));
		final List<CountryData> countryList = hpeCountryFacade.findCountries();
		model.addAttribute(HPEStorefrontConstant.COUNTRY_LIST, countryList);
		model.addAttribute(HPEStorefrontConstant.ELOQUASITEID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_SITEID));
		model.addAttribute(HPEStorefrontConstant.ELOQUALEADSOURCE,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_LEAD_SOURCE___MOST_RECENT1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAAPRIMOACTIVITYIDCONTACTUS,
				configurationService.getConfiguration()
						.getString(HPEStorefrontConstant.ELOQUA_C_APRIMO_Activity_ID__MOST_RECENT1_CONTACT_US));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMID,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_ID1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAGRMCLEANEDSTATUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_GRM_CLEANED_STATUS1));
		model.addAttribute(HPEStorefrontConstant.ELOQUAMETHODOPTIN,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_METHOD_OPT_IN));
		model.addAttribute(HPEStorefrontConstant.ELOQUACONTACTUSFORMNAME,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_CONTACT_US_FORMNAME));
		model.addAttribute(HPEStorefrontConstant.ELOQUARESPONSETYPECONTACTUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_RESPONSE_TYPE1_CONTACT_US));
		model.addAttribute(HPEStorefrontConstant.ELOQUAFORMSOURCECONTACTUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_C_FORM_SOURCE1_CONTACT_US));
		model.addAttribute(HPEStorefrontConstant.ELOQUAPRIVACYCHANGECONTACTUS,
				configurationService.getConfiguration().getString(HPEStorefrontConstant.ELOQUA_PRIVACY_CHANGE_SOURCE_CONTACT_US));

		return ControllerConstants.Views.Pages.Contactus.ContactUsPage;
	}

}
