/**
 *
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.core.model.c2l.LanguageModel;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.ui.Model;

import com.hpe.core.model.HPEHomePageParagraphComponentModel;
import com.hpe.facades.category.HPECategory;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 * @author AM20013064
 *
 */
public class HPEHomePageParagraphComponentController extends AbstractCMSComponentController<HPEHomePageParagraphComponentModel>

{
	@Resource(name = "cmsSiteService")
	private CMSSiteService cmsSiteService;

	@Resource(name = "hpeCategory")
	private HPECategory hpeCategory;

	@Override
	protected void fillModel(final HttpServletRequest request, final Model model,
			final HPEHomePageParagraphComponentModel component)
	{
		final CMSSiteModel currentSite = cmsSiteService.getCurrentSite();
		final LanguageModel currentLanguage = hpeCategory.getCurrentLanguage();
		model.addAttribute("content", component.getContent());
		model.addAttribute("headline", component.getHeadline());
		model.addAttribute("linkName", component.getLinkName());
		if (component.getUrlLink() != null)
		{
			if (component.getUrlLink().contains("http"))
			{
				model.addAttribute("urlLink", component.getUrlLink());
			}
			else
			{
				model.addAttribute("urlLink",
						"/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode() + component.getUrlLink());
			}
		}
		else
		{
			model.addAttribute("urlLink", "/" + currentSite.getSiteIdentifier() + "/" + currentLanguage.getIsocode());
		}
	}

	@Override
	protected String getView(final HPEHomePageParagraphComponentModel component)
	{
		return ControllerConstants.Views.Cms.ComponentPrefix + StringUtils.lowerCase(HPEHomePageParagraphComponentModel._TYPECODE);

	}

}
