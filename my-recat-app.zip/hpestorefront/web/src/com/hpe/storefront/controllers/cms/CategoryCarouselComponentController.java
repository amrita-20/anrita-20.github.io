/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.controllers.cms;

import de.hybris.platform.commercefacades.product.data.CategoryData;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hpe.core.model.CategoryCarouselComponentModel;
import com.hpe.facades.categorycarousel.HPECategoryCarouselFacade;
import com.hpe.storefront.controllers.ControllerConstants;


/**
 * Controller for CategoryCarouselComponentController.
 */
@Controller("CategoryCarouselComponentController")
@RequestMapping(value = ControllerConstants.Actions.Cms.CategoryCarouselComponent)
public class CategoryCarouselComponentController extends AbstractAcceleratorCMSComponentController<CategoryCarouselComponentModel>
{
	private static final Logger LOG = Logger.getLogger(CategoryCarouselComponentController.class);

	@Resource(name = "categoryCarouselFacade")
	private HPECategoryCarouselFacade categoryCarouselFacade;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.acceleratorstorefrontcommons.controllers.cms.AbstractCMSComponentController#fillModel(javax
	 * .servlet.http.HttpServletRequest, org.springframework.ui.Model,
	 * de.hybris.platform.cms2.model.contents.components.AbstractCMSComponentModel)
	 */
	@Override
	protected void fillModel(final HttpServletRequest request, final Model model, final CategoryCarouselComponentModel component)
	{
		final List<CategoryData> categories = new ArrayList<>();

		categories.addAll(collectLinkedCategories(component));
		LOG.info("CategoryCarouselComponent size: " + categories.size());

		model.addAttribute("isIndustryOrWorkload", component.isIsIndustryOrWorkload());
		model.addAttribute("title", component.getTitle());
		model.addAttribute("categoryData", categories);
	}

	protected List<CategoryData> collectLinkedCategories(final CategoryCarouselComponentModel component)
	{
		return categoryCarouselFacade.collectCategories(component);
	}

}
