/**
 *
 */
package com.hpe.storefront.controllers.pages.checkout.steps;

import de.hybris.platform.acceleratorservices.payment.data.PaymentData;
import de.hybris.platform.acceleratorstorefrontcommons.annotations.RequireHardLogIn;
import de.hybris.platform.acceleratorstorefrontcommons.checkout.steps.CheckoutStep;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.checkout.steps.AbstractCheckoutStepController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.PaymentDetailsForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.SopPaymentDetailsForm;
import de.hybris.platform.acceleratorstorefrontcommons.util.AddressDataUtil;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.commercefacades.order.CartFacade;
import de.hybris.platform.commercefacades.order.data.CCPaymentInfoData;
import de.hybris.platform.commercefacades.order.data.CardTypeData;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.servicelayer.user.UserService;

import java.io.IOException;
import java.util.Collection;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hpe.facades.addressdoctor.HPEAddressDoctorIntegrationFacade;
import com.hpe.facades.util.HPEFacadeGenericUtil;
import com.hpe.facades.wepay.HPEWePayAuthorizationFacade;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.controllers.ControllerConstants;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEAnalyticsUtil;
import com.hpe.wepay.service.impl.HPEPaymentResponseEntity;

@Controller
@RequestMapping(value = "/checkout/multi/payment-method")
public class HPEPaymentMethodCheckoutStepController extends AbstractCheckoutStepController
{

	private static final Logger LOGGER = Logger.getLogger(HPEPaymentMethodCheckoutStepController.class);


	@Resource(name = "addressDataUtil")
	private AddressDataUtil addressDataUtil;

	@Resource(name = "hpeWePayFacade")
	private HPEWePayAuthorizationFacade hpeWePayFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "hpeAddressDoctorIntegrationFacade")
	private HPEAddressDoctorIntegrationFacade hpeAddressDoctorIntegrationFacade;

	@Resource(name = "cartFacade")
	private CartFacade cartFacade;

	@Resource(name = "hpeFacadeGenericUtil")
	private HPEFacadeGenericUtil hpeFacadeGenericUtil;

	@Resource(name = "hpeAnalyticsUtil")
	private HPEAnalyticsUtil hpeAnalyticsUtil;

	@ModelAttribute("billingCountries")
	public Collection<CountryData> getBillingCountries()
	{
		return getCheckoutFacade().getBillingCountries();
	}

	@Override
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	@RequireHardLogIn
	public String enterStep(final Model model, final RedirectAttributes redirectAttributes) throws CMSItemNotFoundException
	{
		getCheckoutFacade().setDeliveryModeIfAvailable();
		setupAddPaymentPage(model);

		callWePayAuthorizationService(model); //Calling WePay Service for payment authorization, set the authorization ID in session to save it against the order.

		setCheckoutStepLinksForModel(model, getCheckoutStep());

		final CartData cartData = cartFacade.getSessionCart();
		model.addAttribute(cartData);
		hpeFacadeGenericUtil.miraklShopName(model);

		final SopPaymentDetailsForm sopPaymentDetailsForm = new SopPaymentDetailsForm();
		// Converting cartData to JSON Object so that Tag Manager tool can parse and send the details to Adobe Analytics.
		final JSONObject cartDataJsonObject = hpeAnalyticsUtil.getCheckoutJsonObjectForAnalytics();
		model.addAttribute(HPEStorefrontConstant.CART_DATA_JSON_OBJECT, cartDataJsonObject);

		try
		{
			setupSilentOrderPostPage(sopPaymentDetailsForm, model);
			return ControllerConstants.Views.Pages.MultiStepCheckout.SilentOrderPostPage;
		}
		catch (final Exception e)
		{
			LOGGER.error("HPEPaymentMethodCheckoutStepController:enterStep:Failed to build beginCreateSubscription request", e);
			GlobalMessages.addErrorMessage(model, "checkout.multi.paymentMethod.addPaymentDetails.generalError");
			model.addAttribute(HPEStorefrontConstant.SOP_PAYMENT_DETAILS_FORM, sopPaymentDetailsForm);
		}

		return ControllerConstants.Views.Pages.MultiStepCheckout.AddPaymentMethodPage;
	}

	protected boolean checkPaymentSubscription(final Model model, @Valid final PaymentDetailsForm paymentDetailsForm,
			final CCPaymentInfoData newPaymentSubscription)
	{
		LOGGER.debug("checkPaymentSubscription method ***");

		if (newPaymentSubscription != null && StringUtils.isNotBlank(newPaymentSubscription.getSubscriptionId()))
		{
			if (Boolean.TRUE.equals(paymentDetailsForm.getSaveInAccount()) && getUserFacade().getCCPaymentInfos(true).size() <= 1)
			{
				getUserFacade().setDefaultPaymentInfo(newPaymentSubscription);
			}
			getCheckoutFacade().setPaymentDetails(newPaymentSubscription.getId());
		}
		else
		{
			GlobalMessages.addErrorMessage(model, "checkout.multi.paymentMethod.createSubscription.failedMsg");
			return false;
		}
		return true;
	}

	@RequestMapping(value = "/back", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String back(final RedirectAttributes redirectAttributes)
	{
		LOGGER.debug("back method ***");
		return getCheckoutStep().previousStep();
	}

	@RequestMapping(value = "/next", method = RequestMethod.GET)
	@RequireHardLogIn
	@Override
	public String next(final RedirectAttributes redirectAttributes)
	{
		LOGGER.debug("next method ***");
		return getCheckoutStep().nextStep();
	}

	protected CardTypeData createCardTypeData(final String code, final String name)
	{
		final CardTypeData cardTypeData = new CardTypeData();
		cardTypeData.setCode(code);
		cardTypeData.setName(name);
		return cardTypeData;
	}

	protected void setupAddPaymentPage(final Model model) throws CMSItemNotFoundException
	{
		model.addAttribute(HPEStorefrontConstant.HAS_NO_PAYMENT_INFO, Boolean.valueOf(getCheckoutFlowFacade().hasNoPaymentInfo()));
		prepareDataForPage(model);
		model.addAttribute(WebConstants.BREADCRUMBS_KEY,
				getResourceBreadcrumbBuilder().getBreadcrumbs("checkout.multi.paymentMethod.breadcrumb"));
		final ContentPageModel contentPage = getContentPageForLabelOrId(MULTI_CHECKOUT_SUMMARY_CMS_PAGE_LABEL);
		storeCmsPageInModel(model, contentPage);
		setUpMetaDataForContentPage(model, contentPage);
		setCheckoutStepLinksForModel(model, getCheckoutStep());
	}

	protected void setupSilentOrderPostPage(final SopPaymentDetailsForm sopPaymentDetailsForm, final Model model)
	{
		try
		{
			final PaymentData silentOrderPageData = getPaymentFacade().beginSopCreateSubscription("/checkout/multi/sop/response",
					"/integration/merchant_callback");
			model.addAttribute(HPEStorefrontConstant.SILENT_ORDER_PAGE_DATA, silentOrderPageData);
			sopPaymentDetailsForm.setParameters(silentOrderPageData.getParameters());
			model.addAttribute(HPEStorefrontConstant.PAYMENT_FORM_URL, silentOrderPageData.getPostUrl());
		}
		catch (final IllegalArgumentException e)
		{
			model.addAttribute(HPEStorefrontConstant.PAYMENT_FORM_URL, "");
			model.addAttribute(HPEStorefrontConstant.SILENT_ORDER_PAGE_DATA, null);
			LOGGER.warn("Failed to set up silent order post page", e);
			GlobalMessages.addErrorMessage(model, "checkout.multi.sop.globalError");
		}

		final CartData cartData = getCheckoutFacade().getCheckoutCart();
		model.addAttribute(HPEStorefrontConstant.SILENT_ORDER_POST_FORM, new PaymentDetailsForm());
		model.addAttribute(HPEStorefrontConstant.CART_DATA_ATTR, cartData);
		model.addAttribute(HPEStorefrontConstant.DELIVERY_ADDRESS, cartData.getDeliveryAddress());
		model.addAttribute(HPEStorefrontConstant.SOP_PAYMENT_DETAILS_FORM, sopPaymentDetailsForm);
		model.addAttribute(HPEStorefrontConstant.PAYMENT_INFOS, getUserFacade().getCCPaymentInfos(true));
		if (StringUtils.isNotBlank(sopPaymentDetailsForm.getBillTo_country()))
		{
			model.addAttribute(HPEStorefrontConstant.REGIONS,
					getI18NFacade().getRegionsForCountryIso(sopPaymentDetailsForm.getBillTo_country()));
			model.addAttribute(HPEStorefrontConstant.COUNTRY, sopPaymentDetailsForm.getBillTo_country());
		}
	}

	protected CheckoutStep getCheckoutStep()
	{
		LOGGER.debug("getCheckoutStep method ***");

		return getCheckoutStep(HPEStorefrontConstant.PAYMENT_METHOD);
	}

	private void callWePayAuthorizationService(final Model model)
	{
		LOGGER.debug("Calling WePay Authoation Service ***");
		final String paymentShortDescription = getMessageSource().getMessage("payment.short.description", null,
				getI18nService().getCurrentLocale());
		final String paymentLongDescription = getMessageSource().getMessage("payment.long.description", null,
				getI18nService().getCurrentLocale());
		try
		{
			final HPEPaymentResponseEntity wePayResponse = hpeWePayFacade.callWePayAuthorizationService(paymentShortDescription,
					paymentLongDescription);
			if (wePayResponse != null)
			{
				model.addAttribute(HPEStorefrontConstant.PAYMENT_AUTHORIZATION_ID, wePayResponse.getPreapprovalID());
				model.addAttribute(HPEStorefrontConstant.PAYMENT_AUTHORIZATION_URI, wePayResponse.getPreapprovalURI());

				hpeWePayFacade.savePaymentAuthorizationId(wePayResponse.getPreapprovalID());
			}
		}
		catch (final Exception ex)
		{
			LOGGER.error(ex);
			GlobalMessages.addErrorMessage(model, HPEStorefrontConstant.CHECKOUT_MULTI_PAYMENT_METHOD_PAYMENTSERVICE_FAILED_MSG);
		}
	}

	/**
	 * Address Doctor Integration- Method to Get the Address Suggestions from Address Doctor
	 *
	 * @param form
	 * @param bindingResult
	 * @param model
	 * @param request
	 * @param response
	 * @param redirectModel
	 * @return
	 * @throws CMSItemNotFoundException
	 * @throws IOException
	 */
	@RequestMapping(value = "/checkoutBillingAddressVerification", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String addressDoctor(@ModelAttribute(HPEStorefrontConstant.REGISTER) final SopPaymentDetailsForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel) throws CMSItemNotFoundException, IOException
	{
		final HPERegisterInputForm hpeCheckoutBillingAddressForm = new HPERegisterInputForm();
		hpeCheckoutBillingAddressForm.setCountryCode(form.getBillTo_country());
		hpeCheckoutBillingAddressForm.setAddress1(form.getBillTo_street1());
		hpeCheckoutBillingAddressForm.setAddress2(form.getBillTo_street2());
		hpeCheckoutBillingAddressForm.setCity(form.getBillTo_city());
		hpeCheckoutBillingAddressForm.setStateCode(form.getBillTo_state());
		hpeCheckoutBillingAddressForm.setZipCode(form.getBillTo_postalCode());

		//Address Doctor Integration Response
		final String addressDoctorResponse = hpeAddressDoctorIntegrationFacade
				.hpeAddressDoctorIntegration(hpeCheckoutBillingAddressForm, model);
		if (addressDoctorResponse != null)
		{
			return addressDoctorResponse;
		}
		else
		{
			if (LOGGER.isDebugEnabled())
			{
				LOGGER.debug("HPEPaymentMethodCheckoutStepController:addressDoctor():Address Doctor Response is Null");
			}
		}
		return addressDoctorResponse;
	}
}

