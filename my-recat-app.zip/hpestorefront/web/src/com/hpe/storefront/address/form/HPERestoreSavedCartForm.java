/**
 *
 */
package com.hpe.storefront.address.form;

import de.hybris.platform.acceleratorstorefrontcommons.forms.RestoreSaveCartForm;


/**
 * @author SU40019348
 *
 */
public class HPERestoreSavedCartForm extends RestoreSaveCartForm
{
	private String description;

	/**
	 * @return the description
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * @param description
	 *           the description to set
	 */
	public void setDescription(final String description)
	{
		this.description = description;
	}

}
