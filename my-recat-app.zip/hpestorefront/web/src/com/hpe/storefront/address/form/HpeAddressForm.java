/**
 *
 */
package com.hpe.storefront.address.form;

import de.hybris.platform.acceleratorstorefrontcommons.forms.AddressForm;


/**
 * @author narmada.ammineni
 *
 */
public class HpeAddressForm extends AddressForm
{
	private String attentionTo;
	private String companyName;
	private String partnerNumber;
	private String email;
	private String password;
	private String chkPassword;


	
	
	public String getPassword()
	{
		return password;
	}

	/**
	 * @param password
	 *           the password to set
	 */
	
	public void setPassword(final String password)
	{
		this.password = password;
	}

	/**
	 * @return the chkPassword
	 */
	
	public String getChkPassword()
	{
		return chkPassword;
	}

	/**
	 * @param chkPassword
	 *           the chkPassword to set
	 */
	
	public void setChkPassword(final String chkPassword)
	{
		this.chkPassword = chkPassword;
	}



	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email
	 *           the email to set
	 */
	public void setEmail(final String email)
	{
		this.email = email;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName()
	{
		return companyName;
	}

	/**
	 * @param companyName
	 *           the companyName to set
	 */
	public void setCompanyName(final String companyName)
	{
		this.companyName = companyName;
	}




	/**
	 * @return the attentionTo
	 */
	public String getAttentionTo()
	{
		return attentionTo;
	}

	/**
	 * @param attentionTo
	 *           the attentionTo to set
	 */
	public void setAttentionTo(final String attentionTo)
	{
		this.attentionTo = attentionTo;
	}


	/**
	 * @return the partnerNumber
	 */
	public String getPartnerNumber()
	{
		return partnerNumber;
	}

	/**
	 * @param partnerNumber
	 *           the partnerNumber to set
	 */
	public void setPartnerNumber(final String partnerNumber)
	{
		this.partnerNumber = partnerNumber;
	}
}
