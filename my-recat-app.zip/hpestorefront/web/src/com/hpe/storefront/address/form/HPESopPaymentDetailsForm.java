/**
 *
 */
package com.hpe.storefront.address.form;

import de.hybris.platform.acceleratorstorefrontcommons.forms.SopPaymentDetailsForm;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 * @author AM20013064
 *
 */
public class HPESopPaymentDetailsForm extends SopPaymentDetailsForm
{
	private HpeAddressForm billingAddress;
	private Boolean editAddress;
	private String billTo_city; // NOSONAR
	private String billTo_country; // NOSONAR
	private String billTo_customerID; // NOSONAR
	private String billTo_email; // NOSONAR
	private String billTo_firstName; // NOSONAR
	private String billTo_lastName; // NOSONAR
	private String billTo_phoneNumber; // NOSONAR
	private String billTo_postalCode; // NOSONAR
	private String billTo_titleCode; // NOSONAR
	private String billTo_state; // NOSONAR
	private String billTo_street1; // NOSONAR
	private String billTo_street2; // NOSONAR
	private String billTo_company; // NOSONAR
	private String billTo_attentionTo;

	/**
	 * @return the billTo_city
	 */

	@Override
	public String getBillTo_city()
	{
		return billTo_city;
	}

	/**
	 * @param billTo_city
	 *           the billTo_city to set
	 */

	@Override
	public void setBillTo_city(final String billTo_city)
	{
		this.billTo_city = billTo_city;
	}

	/**
	 * @return the billTo_country
	 */

	@Override
	public String getBillTo_country()
	{
		return billTo_country;
	}

	/**
	 * @param billTo_country
	 *           the billTo_country to set
	 */

	@Override
	public void setBillTo_country(final String billTo_country)
	{
		this.billTo_country = billTo_country;
	}

	/**
	 * @return the billTo_customerID
	 */

	@Override
	public String getBillTo_customerID()
	{
		return billTo_customerID;
	}

	/**
	 * @param billTo_customerID
	 *           the billTo_customerID to set
	 */

	@Override
	public void setBillTo_customerID(final String billTo_customerID)
	{
		this.billTo_customerID = billTo_customerID;
	}

	/**
	 * @return the billTo_email
	 */

	@Override
	public String getBillTo_email()
	{
		return billTo_email;
	}

	/**
	 * @param billTo_email
	 *           the billTo_email to set
	 */

	@Override
	public void setBillTo_email(final String billTo_email)
	{
		this.billTo_email = billTo_email;
	}

	/**
	 * @return the billTo_firstName
	 */
	@Override
	@NotNull(message = "{address.firstName.invalid}")
	@Size(min = 1, max = 255, message = "{address.firstName.invalid}")

	public String getBillTo_firstName()
	{
		return billTo_firstName;
	}

	/**
	 * @param billTo_firstName
	 *           the billTo_firstName to set
	 */

	@Override
	public void setBillTo_firstName(final String billTo_firstName)
	{
		this.billTo_firstName = billTo_firstName;
	}

	/**
	 * @return the billTo_lastName
	 */
	@Override
	@NotNull(message = "{address.lastName.invalid}")
	@Size(min = 1, max = 255, message = "{address.lastName.invalid}")
	public String getBillTo_lastName()
	{
		return billTo_lastName;
	}

	/**
	 * @param billTo_lastName
	 *           the billTo_lastName to set
	 */
	@Override
	public void setBillTo_lastName(final String billTo_lastName)
	{
		this.billTo_lastName = billTo_lastName;
	}

	/**
	 * @return the billTo_phoneNumber
	 */
	@Override
	public String getBillTo_phoneNumber()
	{
		return billTo_phoneNumber;
	}

	/**
	 * @param billTo_phoneNumber
	 *           the billTo_phoneNumber to set
	 */
	@Override
	public void setBillTo_phoneNumber(final String billTo_phoneNumber)
	{
		this.billTo_phoneNumber = billTo_phoneNumber;
	}

	/**
	 * @return the billTo_postalCode
	 */
	@Override
	@NotNull(message = "{address.postcode.invalid}")
	@Size(min = 1, max = 10, message = "{address.postcode.invalid}")
	public String getBillTo_postalCode()
	{
		return billTo_postalCode;
	}

	/**
	 * @param billTo_postalCode
	 *           the billTo_postalCode to set
	 */
	@Override
	public void setBillTo_postalCode(final String billTo_postalCode)
	{
		this.billTo_postalCode = billTo_postalCode;
	}

	/**
	 * @return the billTo_titleCode
	 */
	@Override
	@NotNull(message = "{address.title.invalid}")
	@Size(min = 1, max = 255, message = "{address.title.invalid}")

	public String getBillTo_titleCode()
	{
		return billTo_titleCode;
	}

	/**
	 * @param billTo_titleCode
	 *           the billTo_titleCode to set
	 *
	 *           public void setBillTo_titleCode(final String billTo_titleCode) { this.billTo_titleCode =
	 *           billTo_titleCode; }
	 *
	 *           /**
	 * @return the billTo_state
	 */

	@Override
	public String getBillTo_state()
	{
		return billTo_state;
	}

	/**
	 * @param billTo_state
	 *           the billTo_state to set
	 */

	@Override
	public void setBillTo_state(final String billTo_state)
	{
		this.billTo_state = billTo_state;
	}

	/**
	 * @return the billTo_street1
	 */
	@Override
	@NotNull(message = "{address.line1.invalid}")
	@Size(min = 1, max = 255, message = "{address.line1.invalid}")

	public String getBillTo_street1()
	{
		return billTo_street1;
	}

	/**
	 * @param billTo_street1
	 *           the billTo_street1 to set
	 */

	@Override
	public void setBillTo_street1(final String billTo_street1)
	{
		this.billTo_street1 = billTo_street1;
	}

	/**
	 * @return the billTo_street2
	 */

	@Override
	public String getBillTo_street2()
	{
		return billTo_street2;
	}

	/**
	 * @param billTo_street2
	 *           the billTo_street2 to set
	 */

	@Override
	public void setBillTo_street2(final String billTo_street2)
	{
		this.billTo_street2 = billTo_street2;
	}



	/**
	 * @return the editAddress
	 */
	public Boolean getEditAddress()
	{
		return editAddress;
	}

	/**
	 * @param editAddress
	 *           the editAddress to set
	 */
	public void setEditAddress(final Boolean editAddress)
	{
		this.editAddress = editAddress;
	}

	private Boolean saveInAddressBook;

	/**
	 * @return the saveInAddressBook
	 */
	public Boolean getSaveInAddressBook()
	{
		return saveInAddressBook;
	}

	/**
	 * @param saveInAddressBook
	 *           the saveInAddressBook to set
	 */
	public void setSaveInAddressBook(final Boolean saveInAddressBook)
	{
		this.saveInAddressBook = saveInAddressBook;
	}

	private Boolean saveInAccount;

	/**
	 * @return the saveInAccount
	 */
	public Boolean getSaveInAccount()
	{
		return saveInAccount;
	}

	/**
	 * @param saveInAccount
	 *           the saveInAccount to set
	 */
	public void setSaveInAccount(final Boolean saveInAccount)
	{
		this.saveInAccount = saveInAccount;
	}

	/**
	 * @return the billingAddress
	 */
	public HpeAddressForm getBillingAddress()
	{
		return billingAddress;
	}

	/**
	 * @param billingAddress
	 *           the billingAddress to set
	 */
	public void setBillingAddress(final HpeAddressForm billingAddress)
	{
		this.billingAddress = billingAddress;
	}

	private Boolean newBillingAddress;

	/**
	 * @return the newBillingAddress
	 */
	public Boolean getNewBillingAddress()
	{
		return newBillingAddress;
	}

	/**
	 * @param newBillingAddress
	 *           the newBillingAddress to set
	 */
	public void setNewBillingAddress(final Boolean newBillingAddress)
	{
		this.newBillingAddress = newBillingAddress;
	}


	/**
	 * @return the billTo_company
	 */
	public String getBillTo_company()
	{
		return billTo_company;
	}

	/**
	 * @param billTo_company
	 *           the billTo_company to set
	 */
	public void setBillTo_company(final String billTo_company)
	{
		this.billTo_company = billTo_company;
	}

	/**
	 * @return the billTo_attentionTo
	 */
	public String getBillTo_attentionTo()
	{
		return billTo_attentionTo;
	}

	/**
	 * @param billTo_attentionTo
	 *           the billTo_attentionTo to set
	 */
	public void setBillTo_attentionTo(final String billTo_attentionTo)
	{
		this.billTo_attentionTo = billTo_attentionTo;
	}

	private String billTo_addressId;

	/**
	 * @return the billTo_addressId
	 */
	public String getBillTo_addressId()
	{
		return billTo_addressId;
	}

	/**
	 * @param billTo_addressId
	 *           the billTo_addressId to set
	 */
	public void setBillTo_addressId(final String billTo_addressId)
	{
		this.billTo_addressId = billTo_addressId;
	}



}
