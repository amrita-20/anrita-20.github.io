/**
 *
 */
package com.hpe.storefront.util;

import de.hybris.platform.util.Config;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;


/**
 * @author DA20002251
 *
 */
public class GenericUtil
{

	public static final String LIST_PAGE_SIZE = "storefront.searchlist.page.pageSizes";

	private GenericUtil()
	{
		throw new IllegalStateException("Utility class");
	}

	public static Collection<String> getSearchListPageSizes()
	{
		Collection pageSizes = null;
		final String listPageSizes = Config.getParameter(LIST_PAGE_SIZE);
		final String[] sizeArray = listPageSizes.split(",");
		final List<String> sizeList = Arrays.asList(sizeArray);
		pageSizes = sizeList;

		return pageSizes;
	}
}
