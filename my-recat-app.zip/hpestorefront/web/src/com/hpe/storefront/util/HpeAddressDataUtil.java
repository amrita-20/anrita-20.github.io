/**
 *
 */
package com.hpe.storefront.util;

import de.hybris.platform.acceleratorstorefrontcommons.forms.UpdatePasswordForm;
import de.hybris.platform.acceleratorstorefrontcommons.util.AddressDataUtil;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CustomerData;

import com.hpe.hpepassport.form.data.HPEChangePasswordInputForm;
import com.hpe.storefront.address.form.HpeAddressForm;


/**
 * @author AM20013064
 *
 */
public class HpeAddressDataUtil extends AddressDataUtil
{
	public void convertBasic(final AddressData source, final HpeAddressForm target)
	{
		super.convertBasic(source, target);

		target.setAttentionTo(source.getAttentionTo());
		target.setCompanyName(source.getCompanyName());
		target.setEmail(source.getEmail());
		target.setPartnerNumber(source.getPartnerNumber());

	}

	public void convert(final AddressData source, final HpeAddressForm target)
	{

		super.convert(source, target);
		convertBasic(source, target);

	}

	public AddressData convertToVisibleAddressData(final HpeAddressForm addressForm)
	{
		super.convertToVisibleAddressData(addressForm);
		final AddressData addressData = convertToAddressData(addressForm);
		addressData.setVisibleInAddressBook(true);
		return addressData;
	}


	public AddressData convertToAddressData(final HpeAddressForm hpeaddressForm)
	{
		setRegionIsoWithCountry(hpeaddressForm);
		final AddressData address = super.convertToAddressData(hpeaddressForm);

		address.setAttentionTo(hpeaddressForm.getAttentionTo());
		address.setCompanyName(hpeaddressForm.getCompanyName());
		address.setPartnerNumber(hpeaddressForm.getPartnerNumber());
		address.setEmail(hpeaddressForm.getEmail());
		return address;

	}

	private void setRegionIsoWithCountry(final HpeAddressForm hpeaddressForm)
	{
		if (hpeaddressForm.getRegionIso() != null && hpeaddressForm.getCountryIso() != null
				&& !hpeaddressForm.getRegionIso().contains(hpeaddressForm.getCountryIso()))
			{
				hpeaddressForm.setRegionIso(hpeaddressForm.getCountryIso() + "-" + hpeaddressForm.getRegionIso());
			}
	}

	public HPEChangePasswordInputForm convertToChangeInputForm(final CustomerData currentCustomerData,
			final UpdatePasswordForm updatePasswordForm)
	{
		final HPEChangePasswordInputForm hpeChangePasswordInputForm = new HPEChangePasswordInputForm();

		hpeChangePasswordInputForm.setUserId(currentCustomerData.getUid());
		hpeChangePasswordInputForm.setConfirmPassword(updatePasswordForm.getCheckNewPassword());
		hpeChangePasswordInputForm.setNewPassword(updatePasswordForm.getNewPassword());
		hpeChangePasswordInputForm.setCurrentPassword(updatePasswordForm.getCurrentPassword());

		return hpeChangePasswordInputForm;

	}

}



