/**
 *
 */
package com.hpe.storefront.util;

import de.hybris.platform.acceleratorservices.storefront.util.PageTitleResolver;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.core.model.product.ProductModel;

import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;


/**
 * @author AN392930
 *
 */
public class HPEPageTitleResolver extends PageTitleResolver
{
	@Override
	public String resolveCategoryPageTitle(final CategoryModel category)
	{
		final StringBuilder stringBuilder = new StringBuilder();
		final List<CategoryModel> categories = this.getCategoryPath(category);
		for (final CategoryModel c : categories)
		{
			stringBuilder.append(c.getName()).append(TITLE_WORD_SEPARATOR);
			break;
		}

		final CMSSiteModel currentSite = getCmsSiteService().getCurrentSite();
		if (currentSite != null)
		{
			stringBuilder.append(currentSite.getName());
		}

		return StringEscapeUtils.escapeHtml(stringBuilder.toString());
	}

	@Override

	public String resolveProductPageTitle(final ProductModel product)
	{
		// Lookup site (or store)
		final CMSSiteModel currentSite = getCmsSiteService().getCurrentSite();

		// Construct page title
		final String identifier = product.getName();
		final String articleNumber = product.getCode();
		final String productName = StringUtils.isEmpty(identifier) ? articleNumber : identifier;
		final StringBuilder builder = new StringBuilder(productName);


		if (currentSite != null)
		{
			builder.append(TITLE_WORD_SEPARATOR).append(currentSite.getName());
		}

		return StringEscapeUtils.escapeHtml(builder.toString());
	}
}
