/**
 *
 */
package com.hpe.storefront.util;


import de.hybris.platform.acceleratorstorefrontcommons.consent.data.ConsentCookieData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractSearchPageController.ShowMode;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.acceleratorstorefrontcommons.forms.SaveCartForm;
import de.hybris.platform.acceleratorstorefrontcommons.forms.SopPaymentDetailsForm;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.commercefacades.consent.ConsentFacade;
import de.hybris.platform.commercefacades.gts.data.WePayRequestData;
import de.hybris.platform.commercefacades.i18n.I18NFacade;
import de.hybris.platform.commercefacades.order.SaveCartFacade;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartParameterData;
import de.hybris.platform.commercefacades.order.data.CommerceSaveCartResultData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.search.data.SearchQueryData;
import de.hybris.platform.commercefacades.search.data.SearchStateData;
import de.hybris.platform.commercefacades.user.UserFacade;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commercefacades.user.data.CountryData;
import de.hybris.platform.commercefacades.user.data.RegionData;
import de.hybris.platform.commerceservices.order.CommerceSaveCartException;
import de.hybris.platform.commerceservices.search.facetdata.FacetData;
import de.hybris.platform.commerceservices.search.facetdata.FacetValueData;
import de.hybris.platform.commerceservices.search.facetdata.ProductSearchPageData;
import de.hybris.platform.commerceservices.search.pagedata.PageableData;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.servicelayer.data.PaginationData;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.hpe.core.model.PLPGuidedSellingModel;
import com.hpe.facades.country.HPECountryFacade;
import com.hpe.facades.populators.HPEPLPGuidedSellingPopulator;
import com.hpe.facades.product.data.search.pagedata.PLPGuidedSellingData;
import com.hpe.facades.region.HPERegionFacade;
import com.hpe.facades.registration.HPECustomerFacade;
import com.hpe.facades.registration.data.HPERegisterData;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.facades.util.GTSRequestData;
import com.hpe.hpepassport.form.data.HPERegisterInputForm;
import com.hpe.storefront.address.form.HpeAddressForm;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.passportintegration.form.HPERegisterForm;
import com.sap.security.core.server.csi.XSSEncoder;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;



/**
 * @author SR351338
 *
 */

public class HPEStorefrontUtil
{
	private static final Logger LOG = Logger.getLogger(HPEStorefrontUtil.class);

	public final static String SHIP_TO = "SP";
	public final static String BILL_TO = "BT";
	private static final String FACET_SEPARATOR = ":";
	public static final int MAX_PAGE_LIMIT = 100;
	private static final String GTS_EMB_IPADDRESS = "gts.emb_IPAddress";
	private static final String GTS_EMB_ADDRESS = "gts.emb_address";
	private static final String GTS_LANGUAGE = "gts.language";
	private static final String GTS_lOGSYSTEM = "gts.logSystem";
	private static final String GTS_RPL_SCRN = "gts.rpl_scrn";
	private static final String GTS_EMB_EMAL = "gts.emb_emal";
	@Resource(name = "hpeCustomerFacade")
	private HPECustomerFacade hpeCustomerFacade;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "userService")
	private UserService userService;

	@Resource(name = "hpeCountryFacade")
	private HPECountryFacade hpeCountryFacade;

	@Resource(name = "hpeRegionFacade")
	private HPERegionFacade hpeRegionFacade;


	@Resource(name = "baseStoreService")
	private BaseStoreService baseStoreService;

	@Resource(name = "cmsSiteService")
	private CMSSiteService CmsSiteService;

	@Resource(name = "userFacade")
	private UserFacade userFacade;

	@Resource(name = "consentFacade")
	protected ConsentFacade consentFacade;

	@Resource(name = "saveCartFacade")
	private SaveCartFacade saveCartFacade;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	@Resource(name = "hpePLPGuidedSellingPopulator")
	private HPEPLPGuidedSellingPopulator plpGuidedSellingPopulator;



	/**
	 * @return the userFacade
	 */
	public UserFacade getUserFacade()
	{
		return userFacade;
	}

	public BaseStoreService getBaseStoreService()
	{
		return baseStoreService;
	}

	public CMSSiteService getCMSSiteService()
	{
		return CmsSiteService;
	}

	/**
	 * @param userFacade
	 *           the userFacade to set
	 */
	public void setUserFacade(final UserFacade userFacade)
	{
		this.userFacade = userFacade;
	}

	/**
	 * @return the i18NFacade
	 */
	public I18NFacade getI18NFacade()
	{
		return i18NFacade;
	}

	/**
	 * @param i18nFacade
	 *           the i18NFacade to set
	 */
	public void setI18NFacade(final I18NFacade i18nFacade)
	{
		i18NFacade = i18nFacade;
	}

	@Resource(name = "i18NFacade")
	private I18NFacade i18NFacade;


	public GTSRequestData setGTSRequestData(final String username, final HpeAddressForm addressForm, final String remoteAddress)
	{

		final GTSRequestData data = new GTSRequestData();

		final String countryCode = CmsSiteService.getCurrentSite().getSiteIdentifier();

		data.setLogSystem(configurationService.getConfiguration().getString(GTS_lOGSYSTEM));

		data.setLanguiso(configurationService.getConfiguration().getString(GTS_LANGUAGE));
		data.setCountry(countryCode != null ? countryCode.toUpperCase() : "");

		if (null == username && null == addressForm)
		{
			data.setIpAddr(remoteAddress);
			data.setEmbIpad(configurationService.getConfiguration().getString(GTS_EMB_IPADDRESS));
			return data;
		}
		else if (null != username && null == addressForm)
		{
			data.setEmail(username);
			data.setName(username);
			final String ExpPartNumber = getUID();
			data.setExpPartNum(ExpPartNumber);
			data.setEmbEmal(configurationService.getConfiguration().getString(GTS_EMB_EMAL));
			return data;
		}
		else
		{

			final String ExpPartNumber = getUID();
			addressForm.setPartnerNumber(ExpPartNumber);

			data.setEmail(addressForm.getEmail() != null ? addressForm.getEmail().trim() : username);
			data.setEmbEmal(configurationService.getConfiguration().getString(GTS_EMB_EMAL));

			data.setEmbAddr(configurationService.getConfiguration().getString(GTS_EMB_ADDRESS));
			data.setRplScrn(configurationService.getConfiguration().getString(GTS_RPL_SCRN));
			data.setCity(addressForm.getTownCity());
			data.setRegion(addressForm.getRegionIso() != null ? addressForm.getRegionIso() : "");
			data.setCountry(addressForm.getCountryIso());
			data.setPcode(addressForm.getPostcode());
			data.setName(addressForm.getFirstName().concat(" ").concat(addressForm.getLastName()));
			data.setStreet(addressForm.getLine1());
			data.setExpPartNum(SHIP_TO + ExpPartNumber);

			return data;
		}
	}

	public GTSRequestData setGTSRequestData(final HPERegisterForm form)
	{
		final GTSRequestData data = new GTSRequestData();
		data.setLogSystem(configurationService.getConfiguration().getString(GTS_lOGSYSTEM));
		data.setLanguiso(configurationService.getConfiguration().getString(GTS_LANGUAGE));

		if (null == form)
		{
			return data;
		}
		else
		{

			final String ExpPartNumber = getUID();
			data.setExpPartNum(SHIP_TO + ExpPartNumber);
			data.setEmail(form.getEmail());
			data.setEmbAddr(configurationService.getConfiguration().getString(GTS_EMB_ADDRESS));
			data.setEmbEmal(configurationService.getConfiguration().getString(GTS_EMB_EMAL));
			data.setRplScrn(configurationService.getConfiguration().getString(GTS_RPL_SCRN));
			data.setCity(form.getCity());
			data.setCountry(form.getCountryCode());
			data.setPcode(form.getZipCode());
			data.setName(form.getFirstName().concat(" ").concat(form.getLastName()));
			data.setStreet(form.getAddress1());
			data.setRegion(form.getStateCode() != null ? form.getStateCode() : "");

			return data;
		}
	}


	public GTSRequestData setGTSRequestDataForBillingAddress(final String username, final SopPaymentDetailsForm BillingAddressForm,
			final String remoteAddress)
	{
		final GTSRequestData data = new GTSRequestData();
		data.setLogSystem(configurationService.getConfiguration().getString(GTS_lOGSYSTEM));
		data.setIpAddr(remoteAddress);
		data.setEmbIpad(configurationService.getConfiguration().getString(GTS_EMB_IPADDRESS));
		data.setEmail(username);
		data.setLanguiso(configurationService.getConfiguration().getString(GTS_LANGUAGE));
		final String ExpPartNumber = getUID();
		data.setEmail(username);
		data.setEmbAddr(configurationService.getConfiguration().getString(GTS_EMB_ADDRESS));
		data.setEmbEmal(configurationService.getConfiguration().getString(GTS_EMB_EMAL));
		data.setRplScrn(configurationService.getConfiguration().getString(GTS_RPL_SCRN));
		data.setCity(BillingAddressForm.getBillTo_city());
		data.setCountry(BillingAddressForm.getBillTo_country());
		data.setPcode(BillingAddressForm.getBillTo_postalCode());
		data.setName(BillingAddressForm.getBillTo_firstName());
		data.setStreet(BillingAddressForm.getBillTo_street1());
		data.setExpPartNum(BILL_TO + ExpPartNumber);

		return data;
	}


	public String remoteAddress(final HttpServletRequest request)
	{
		String remoteAddr = "";

		if (request != null)
		{
			remoteAddr = request.getHeader("X-Real-IP");
			LOG.info("HPEStorefrontUtil:::client ip addres:::" + remoteAddr);
			if (remoteAddr == null || StringUtils.isEmpty(remoteAddr))
			{
				remoteAddr = request.getRemoteAddr();

				LOG.debug("remoteAddr" + remoteAddr);
			}
		}
		return remoteAddr;
	}

	public static String getUID()
	{
		final int DIGITS = 18;

		final StringBuilder sb = new StringBuilder(DIGITS);
		for (int i = 0; i < DIGITS; i++)
		{
			sb.append((char) (Math.random() * 10 + '0'));
		}
		return sb.toString();
	}

	public Model countryListGenerate(final Model model)
	{
		String countryCode = null;
		final BaseStoreModel currentBaseStore = baseStoreService.getCurrentBaseStore();
		if (currentBaseStore != null)
		{
			countryCode = ((CMSSiteModel) ((List) (currentBaseStore.getCmsSites())).get(0)).getSiteIdentifier();
		}
		if (countryCode != null)
		{
			countryCode = countryCode.toUpperCase();
		}
		final List<CountryData> countryList = hpeCountryFacade.findCountriesByCode(countryCode);
		final List<RegionData> finalRegionList = hpeRegionFacade.findRegionforCountry(countryCode);
		finalRegionList.sort(Comparator.comparing(RegionData::getIsocodeShort));
		model.addAttribute(HPEStorefrontConstant.COUNTRY_LIST, countryList);
		model.addAttribute(HPEStorefrontConstant.REGION_LIST, finalRegionList);
		return model;
	}

	/**
	 * @param data
	 * @return
	 */
	public GTSRequestData setGTSRequestData(final WePayRequestData requestData)
	{


		final GTSRequestData data = new GTSRequestData();



		final String countryCode = CmsSiteService.getCurrentSite().getSiteIdentifier();

		data.setLogSystem(configurationService.getConfiguration().getString(GTS_lOGSYSTEM));
		data.setLanguiso(configurationService.getConfiguration().getString(GTS_LANGUAGE));
		data.setCountry(countryCode != null ? countryCode.toUpperCase() : "");
		final String ExpPartNumber = getUID();
		data.setExpPartNum(BILL_TO + ExpPartNumber);
		data.setEmbAddr(configurationService.getConfiguration().getString(GTS_EMB_ADDRESS));
		data.setRplScrn(configurationService.getConfiguration().getString(GTS_RPL_SCRN));
		data.setEmbEmal(configurationService.getConfiguration().getString(GTS_EMB_EMAL));
		data.setPcode(requestData.getZipCode());
		data.setEmail(requestData.getPayerEmail());
		data.setName(requestData.getPayerName());
		return data;
	}

	/**
	 * @param form
	 */
	public void setDefaultAddress()
	{
		final CustomerModel currentUser = (CustomerModel) userService.getCurrentUser();
		final AddressData profileAddressData = hpeUserFacade.getProfileAddress(currentUser);

		profileAddressData.setDefaultAddress(true);
		profileAddressData.setProfileAddress(true);
		profileAddressData.setShippingAddress(true);
		hpeUserFacade.setDefaultAddress(profileAddressData);

	}

	/**
	 * This method will populate PLP Guided Selling Data and return JSON Array.
	 *
	 * @param category
	 * @return
	 * @throws JSONException
	 */
	public JSONArray populatePLPSellingData(final CategoryModel category) throws JSONException
	{
		final Collection<PLPGuidedSellingData> gsDataList = new ArrayList<PLPGuidedSellingData>();
		final Set<PLPGuidedSellingModel> gsModels = category.getPLPGuidedSelling();

		for (final PLPGuidedSellingModel gsModel : gsModels)
		{
			final PLPGuidedSellingData gsData = new PLPGuidedSellingData();

			plpGuidedSellingPopulator.populate(gsModel, gsData);
			gsDataList.add(gsData);
		}
		final JSONArray jsonArray = new JSONArray();


		for (final PLPGuidedSellingData obj : gsDataList)
		{
			final JSONArray jsonArray1 = new JSONArray();
			final JSONObject formDetailsJson = new JSONObject();
			formDetailsJson.put("qaId", obj.getQaId().toString());
			formDetailsJson.put("sequenceId", obj.getSequenceId().toString());
			formDetailsJson.put("question", obj.getQuestion().toString());
			formDetailsJson.put("description", obj.getDescription().toString());
			for (final String ans : obj.getAnswers())
			{
				jsonArray1.add(ans);
			}
			formDetailsJson.put("answers", jsonArray1);
			formDetailsJson.put("indexAttr", obj.getIndexAttr().toString());
			jsonArray.add(formDetailsJson);
		}
		return jsonArray;
	}

	public void saveAnonymousConsentCookiesAsConsentData(final HttpServletRequest request)
	{
		final Cookie cookie = WebUtils.getCookie(request, WebConstants.ANONYMOUS_CONSENT_COOKIE);
		if (cookie != null)
		{
			try
			{
				final ObjectMapper mapper = new ObjectMapper();
				final List<ConsentCookieData> consentCookieDataList = Arrays.asList(mapper.readValue(
						URLDecoder.decode(cookie.getValue(), StandardCharsets.UTF_8.displayName()), ConsentCookieData[].class));
				consentCookieDataList.stream().filter(consentData -> WebConstants.CONSENT_GIVEN.equals(consentData.getConsentState()))
						.forEach(consentData -> consentFacade.giveConsent(consentData.getTemplateCode(),
								Integer.valueOf(consentData.getTemplateVersion())));
			}
			catch (final UnsupportedEncodingException e)
			{
				LOG.error(String.format("Cookie Data could not be decoded : %s", cookie.getValue()), e);
			}
			catch (final IOException e)
			{
				LOG.error("Cookie Data could not be mapped into the Object", e);
			}
			catch (final Exception e)
			{
				LOG.error("Error occurred while creating Anonymous cookie consents", e);
			}
		}
	}

	public void getSavedCart(final SaveCartForm form, final BindingResult bindingResult, final RedirectAttributes redirectModel,
			final CommerceSaveCartParameterData commerceSaveCartParameterData) throws CommerceSaveCartException
	{
		try
		{
			final CommerceSaveCartResultData saveCartData = saveCartFacade.saveCart(commerceSaveCartParameterData);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.CONF_MESSAGES_HOLDER, "basket.save.cart.on.success",
					new Object[]
					{ saveCartData.getSavedCartData().getName() });
		}
		catch (final CommerceSaveCartException csce)
		{
			LOG.error(csce.getMessage(), csce);
			GlobalMessages.addFlashMessage(redirectModel, GlobalMessages.ERROR_MESSAGES_HOLDER, "basket.save.cart.on.error",
					new Object[]
					{ form.getName() });
		}
	}

	public HPERegisterData populateBasicRegisterData(final HPERegisterData data, final HPERegisterForm form)
	{
		data.setFirstName(form.getFirstName());
		data.setLastName(form.getLastName());
		data.setLogin(form.getEmail());
		data.setPassword(form.getPwd());
		data.setTitleCode(form.getTitleCode());
		data.setAddress1(form.getAddress1());
		data.setAddress2(form.getAddress2());
		data.setCity(form.getCity());
		data.setCompany(form.getCompany());

		return data;
	}

	/**
	 * This method returns the country code.
	 *
	 * @return
	 */
	public String getCountryCode()
	{
		String countryCode = null;
		final BaseStoreModel currentBaseStore = baseStoreService.getCurrentBaseStore();
		if (currentBaseStore != null)
		{
			countryCode = ((CMSSiteModel) ((List) (currentBaseStore.getCmsSites())).get(0)).getSiteIdentifier();
		}
		if (countryCode != null)
		{
			countryCode = countryCode.toUpperCase();
		}
		return countryCode;
	}

	public HPERegisterInputForm convertToRegisterInputForm(final HPERegisterInputForm hpeRegisterInputForm,
			final HpeAddressForm addressForm)
	{
		hpeRegisterInputForm.setConfirmPassword(addressForm.getPassword());
		hpeRegisterInputForm.setEmailAddress(addressForm.getEmail());
		hpeRegisterInputForm.setFirstName(addressForm.getFirstName());
		hpeRegisterInputForm.setLastName(addressForm.getLastName());
		hpeRegisterInputForm.setNewPassword(addressForm.getPassword());
		hpeRegisterInputForm.setUserId(addressForm.getEmail());
		hpeRegisterInputForm.setContactByEmail("Y");
		hpeRegisterInputForm.setCountryCode(addressForm.getCountryIso());

		return hpeRegisterInputForm;
	}

	public HPERegisterForm convertToHPERegisterForm(final HPERegisterForm hpeRegisterForm, final HpeAddressForm addressForm)
	{
		hpeRegisterForm.setFirstName(addressForm.getFirstName());
		hpeRegisterForm.setLastName(addressForm.getLastName());
		hpeRegisterForm.setEmail(addressForm.getEmail());
		hpeRegisterForm.setEmailCheck(addressForm.getEmail());
		hpeRegisterForm.setCountryCode(addressForm.getCountryIso());
		hpeRegisterForm.setPwd(addressForm.getPassword());
		hpeRegisterForm.setCheckPwd(addressForm.getChkPassword());
		hpeRegisterForm.setTitleCode(addressForm.getTitleCode());
		hpeRegisterForm.setAddress1(addressForm.getLine1());
		hpeRegisterForm.setAddress2(addressForm.getLine2());
		hpeRegisterForm.setCity(addressForm.getTownCity());
		hpeRegisterForm.setCompany(addressForm.getCompanyName());
		hpeRegisterForm.setZipCode(addressForm.getPostcode());
		hpeRegisterForm.setStateCode(addressForm.getRegionIso());
		hpeRegisterForm.setAttentionTo(addressForm.getAttentionTo());

		return hpeRegisterForm;
	}

	public HPERegisterData convertToHPERegisterData(final HPERegisterData data, final HPERegisterForm form)
	{
		data.setFirstName(form.getFirstName());
		data.setLastName(form.getLastName());
		data.setLogin(form.getEmail());
		data.setPassword(form.getPwd());
		data.setTitleCode(form.getTitleCode());
		data.setAddress1(form.getAddress1());
		data.setAddress2(form.getAddress2());
		data.setCity(form.getCity());
		data.setCompany(form.getCompany());
		data.setCountryCode(form.getCountryCode());
		data.setZipCode(form.getZipCode());
		data.setStateCode(form.getStateCode());
		data.setMobileNumber(form.getMobileNumber());

		return data;
	}

	public ProductSearchPageData<SearchStateData, ProductData> encodeSearchPageData(
			final ProductSearchPageData<SearchStateData, ProductData> searchPageData)
	{
		final SearchStateData currentQuery = searchPageData.getCurrentQuery();

		if (currentQuery != null)
		{
			try
			{
				final SearchQueryData query = currentQuery.getQuery();
				final String encodedQueryValue = XSSEncoder.encodeHTML(query.getValue());
				query.setValue(encodedQueryValue);
				currentQuery.setQuery(query);
				searchPageData.setCurrentQuery(currentQuery);
				searchPageData.setFreeTextSearch(XSSEncoder.encodeHTML(searchPageData.getFreeTextSearch()));

				final List<FacetData<SearchStateData>> facets = searchPageData.getFacets();
				if (CollectionUtils.isNotEmpty(facets))
				{
					processFacetData(facets);
				}
			}
			catch (final UnsupportedEncodingException e)
			{
				if (LOG.isDebugEnabled())
				{
					LOG.debug("Error occured during Encoding the Search Page data values", e);
				}
			}
		}
		return searchPageData;
	}

	protected void processFacetData(final List<FacetData<SearchStateData>> facets) throws UnsupportedEncodingException
	{
		for (final FacetData<SearchStateData> facetData : facets)
		{
			final List<FacetValueData<SearchStateData>> topFacetValueDatas = facetData.getTopValues();
			if (CollectionUtils.isNotEmpty(topFacetValueDatas))
			{
				processFacetDatas(topFacetValueDatas);
			}
			final List<FacetValueData<SearchStateData>> facetValueDatas = facetData.getValues();
			if (CollectionUtils.isNotEmpty(facetValueDatas))
			{
				processFacetDatas(facetValueDatas);
			}
		}
	}

	protected void processFacetDatas(final List<FacetValueData<SearchStateData>> facetValueDatas)
			throws UnsupportedEncodingException
	{
		for (final FacetValueData<SearchStateData> facetValueData : facetValueDatas)
		{
			final SearchStateData facetQuery = facetValueData.getQuery();
			final SearchQueryData queryData = facetQuery.getQuery();
			final String queryValue = queryData.getValue();
			if (StringUtils.isNotBlank(queryValue))
			{
				final String[] queryValues = queryValue.split(FACET_SEPARATOR);
				final StringBuilder queryValueBuilder = new StringBuilder();
				queryValueBuilder.append(XSSEncoder.encodeHTML(queryValues[0]));
				for (int i = 1; i < queryValues.length; i++)
				{
					queryValueBuilder.append(FACET_SEPARATOR).append(queryValues[i]);
				}
				queryData.setValue(queryValueBuilder.toString());
			}
		}
	}

	public PageableData createPageableData(final int pageNumber, final int pageSize, final String sortCode,
			final ShowMode showMode)
	{
		final PageableData pageableData = new PageableData();
		pageableData.setCurrentPage(pageNumber);
		pageableData.setSort(sortCode);

		if (ShowMode.All == showMode)
		{
			pageableData.setPageSize(MAX_PAGE_LIMIT);
		}
		else
		{
			pageableData.setPageSize(pageSize);
		}
		return pageableData;
	}

	public PaginationData createPaginationData(final int pageNumber, final int pageSize, final ShowMode showMode)
	{
		final PaginationData pageableData = new PaginationData();
		pageableData.setCurrentPage(pageNumber);

		if (ShowMode.All == showMode)
		{
			pageableData.setPageSize(MAX_PAGE_LIMIT);
		}
		else
		{
			pageableData.setPageSize(pageSize);
		}
		return pageableData;
	}
}
