/*
 * Copyright (C) 2018-2019 HPE
 *
 */
package com.hpe.storefront.util;

import de.hybris.platform.commercefacades.order.CheckoutFacade;
import de.hybris.platform.commercefacades.order.EntryGroupData;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.DeliveryModeData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.CategoryData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.product.data.VariantOptionData;
import de.hybris.platform.commercefacades.search.data.SearchStateData;
import de.hybris.platform.commerceservices.search.facetdata.ProductCategorySearchPageData;
import de.hybris.platform.commerceservices.search.pagedata.SearchPageData;
import de.hybris.platform.configurablebundleservices.model.BundleTemplateModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.site.BaseSiteService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.hpe.facades.bundle.HPEBundleFacade;
import com.hpe.facades.order.HPECartFacade;
import com.hpe.facades.product.Breadcrumb;
import com.hpe.facades.product.impl.HPEProductBreadcrumbBuilder;
import com.hpe.storefront.controllers.HPEStorefrontConstant;


/**
 * @author AR20021484
 *
 */
public class HPEAnalyticsUtil
{
	private static final Logger LOGGER = Logger.getLogger(HPEAnalyticsUtil.class);

	@Resource(name = "hpeCartFacade")
	private HPECartFacade hpeCartFacade;

	@Resource(name = "hpeProductBreadcrumbBuilder")
	private HPEProductBreadcrumbBuilder hpeProductBreadcrumbBuilder;

	@Resource(name = "hpeBundleFacade")
	private HPEBundleFacade hpeBundleFacade;

	@Resource(name = "productVariantFacade")
	private ProductFacade productFacade;

	@Resource(name = "baseSiteService")
	protected BaseSiteService baseSiteService;

	@Resource(name = "checkoutFacade")
	private CheckoutFacade checkoutFacade;

	private static final String CARTID = "cartID";
	private static final String CURRENCY = "currency";
	private static final String CARTTOTAL = "cartTotal";
	private static final String ZERO = "0";
	private static final String PRODUCTID = "productID";
	private static final String PRODUCTNAME = "productName";
	private static final String VENDOR = "vendor";
	private static final String QUANTITY = "quantity";
	private static final String BASEPRICE = "basePrice";
	private static final String PRODUCTINFO = "productInfo";
	private static final String SHIPPING = "shipping";
	private static final String VOUCHERDISCOUNT = "voucherDiscount";
	private static final String PRICE = "price";
	private static final String BASEPRODUCT = "baseProduct";
	private static final String NAVIGATIONLIST = "navigationList";
	private static final String NAVIGATIONCATEGORY = "navigationCategory";
	private static final String ITEM = "item";
	private final String ONE = "1";
	private static final String PAYMENTMETHOD = "paymentMethod";
	private static final String CREDITCARD = "creditcard";
	private static final String SHIPPINGMETHOD = "shippingMethod";
	private static final String TOTALTAX = "taxTotal";
	private static final String TRANSACTIONID = "transactionID";
	private static final String CARTDETAIL = "cartDetail";
	private static final String BUNDLEPRODUCTS = "bundleProducts";
	private static final String EMPTY_STRING = "";

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getCartDataJsonObjectForAnalytics()
	{
		final JSONObject jsonObject = new JSONObject();

		if (HPEStorefrontConstant.US_SITE_UID.equalsIgnoreCase(baseSiteService.getCurrentBaseSite().getUid()))
		{
			final CartData cartData = hpeCartFacade.getSessionCart();
			List itemList;
			if (cartData != null)
			{
				jsonObject.put(CARTID, cartData.getCode());
				jsonObject.put(PRICE, prepareCartPriceDetails(cartData));

				final List<OrderEntryData> entries = cartData.getEntries();
				itemList = prepareVariantList(entries, null);
				itemList = prepareConfigList(cartData, itemList);
				itemList = prepareBundleList(cartData, itemList);
				jsonObject.put(ITEM, itemList);
			}
		}
		return jsonObject;
	}

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getCheckoutJsonObjectForAnalytics()
	{
		final CartData cartData = hpeCartFacade.getSessionCart();
		final List<OrderEntryData> entries = cartData.getEntries();
		final JSONObject jsonObject = new JSONObject();
		List itemList;
		jsonObject.put(CARTID, cartData.getCode());
		jsonObject.put(PRICE, prepareCartPriceDetails(cartData));
		itemList = prepareVariantList(entries, null);
		itemList = prepareConfigList(cartData, itemList);
		itemList = prepareBundleList(cartData, itemList);
		jsonObject.put(ITEM, itemList);

		return jsonObject;
	}

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getProductDataJsonObjectForAnalytics(final ProductData productData,
			final List<BundleTemplateModel> lstBundleModel)
	{
		final List<Breadcrumb> breadcrumbList = hpeProductBreadcrumbBuilder.getBreadcrumbs(productData.getCode());
		final List<VariantOptionData> variants = productData.getVariantOptions();
		final JSONObject jsonObject = new JSONObject();
		final JSONObject baseProduct = new JSONObject();
		JSONArray productInfos = new JSONArray();
		final JSONArray navigationList = new JSONArray();

		baseProduct.put(PRODUCTID, productData.getCode());
		baseProduct.put(PRODUCTNAME, productData.getName());

		if (breadcrumbList != null)
		{
			for (final Breadcrumb breadcrumb : breadcrumbList)
			{
				navigationList.put(breadcrumb.getName());
			}
		}

		if (null != lstBundleModel)
		{
			final Iterator bundleIterator = lstBundleModel.iterator();

			while (bundleIterator.hasNext())
			{
				final BundleTemplateModel bundleTemplate = (BundleTemplateModel) bundleIterator.next();
				final List<ProductModel> bundleProducts = bundleTemplate.getProducts();
				productInfos = prepareBundleProducts(bundleTemplate, bundleProducts, productInfos);
			}
		}

		if (variants != null)
		{
			for (final VariantOptionData variant : variants)
			{
				final JSONObject productInfo = new JSONObject();
				final JSONObject productDetail = new JSONObject();
				productDetail.put(PRODUCTID, variant.getCode());
				productDetail.put(PRODUCTNAME, variant.getName());
				productDetail.put(PRICE, (variant.getPriceData() != null) ? variant.getPriceData().getValue() : null);
				productDetail.put(QUANTITY, ONE);

				productInfo.put(PRODUCTINFO, productDetail);
				productInfos.put(productInfo);
			}
		}

		jsonObject.put(BASEPRODUCT, baseProduct);
		jsonObject.put(NAVIGATIONLIST, navigationList);
		jsonObject.put(PRODUCTINFO, productInfos);
		jsonObject.put(CARTDETAIL, getCartDataJsonObjectForAnalytics());

		return jsonObject;
	}

	/**
	 *
	 * @param bundleTemplate
	 * @param bundleProducts
	 * @param productInfos
	 * @return
	 */
	private JSONArray prepareBundleProducts(final BundleTemplateModel bundleTemplate, final List<ProductModel> bundleProducts,
			final JSONArray productInfos)
	{
		if (bundleProducts != null && !bundleProducts.isEmpty())
		{
			final JSONObject productInfo = new JSONObject();
			final JSONObject bundleInfo = new JSONObject();
			final StringBuilder strBuf = new StringBuilder();

			bundleInfo.put(PRODUCTID, bundleTemplate.getId());
			bundleInfo.put(PRODUCTNAME, bundleTemplate.getName());
			bundleInfo.put(PRICE, (bundleTemplate.getBundlePrice() != null) ? bundleTemplate.getBundlePrice().doubleValue() : null);
			bundleInfo.put(QUANTITY, ONE);

			for (int i = 0; i < bundleProducts.size(); i++)
			{
				final ProductModel bundleProduct = bundleProducts.get(i);
				strBuf.append(bundleProduct.getCode());
				if (i < bundleProducts.size() - 1)
				{
					strBuf.append("|");
				}
			}
			bundleInfo.put(BUNDLEPRODUCTS, strBuf.toString());

			productInfo.put(PRODUCTINFO, bundleInfo);
			productInfos.put(productInfo);
		}
		return productInfos;
	}

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getProductListJsonObjectForAnalytics(
			final ProductCategorySearchPageData<SearchStateData, ProductData, CategoryData> searchPageData,
			final List<Breadcrumb> breadCrumbs)
	{

		final JSONObject jsonObject = new JSONObject();
		final JSONArray productInfoList = new JSONArray();
		final JSONArray jsonArray = new JSONArray();

		if (breadCrumbs != null)
		{
			for (int index = 0; index < breadCrumbs.size(); index++)
			{
				jsonArray.put(breadCrumbs.get(index).getName());
			}
		}
		try
		{
			if (searchPageData != null && searchPageData.getResults() != null)
			{
				for (int index = 0; index < searchPageData.getResults().size(); index++)
				{
					final String productCode = searchPageData.getResults().get(index).getCode();
					final String productName = searchPageData.getResults().get(index).getName();
					final JSONObject product = new JSONObject();
					final JSONObject productInfo = new JSONObject();

					product.put(PRODUCTID, productCode);
					product.put(PRODUCTNAME, productName);
					productInfo.put(PRODUCTINFO, product);
					productInfoList.put(productInfo);
				}

				jsonObject.put(PRODUCTINFO, productInfoList);
				jsonObject.put(NAVIGATIONCATEGORY, jsonArray);
			}
		}
		catch (final JSONException e)
		{
			LOGGER.error(e);
		}
		return jsonObject;
	}

	/**
	 *
	 * @param cartData
	 * @return
	 */
	public JSONObject getSavedCartDetailForAnalytics(final CartData cartData)
	{
		final List<OrderEntryData> entries = cartData.getEntries();
		final JSONObject jsonObject = new JSONObject();
		jsonObject.put(CARTID, cartData.getCode());
		jsonObject.put(PRICE, prepareCartPriceDetails(cartData));
		jsonObject.put(ITEM, prepareVariantList(entries, null));

		return jsonObject;
	}

	public JSONObject getSavedCartsForAnalytics(final SearchPageData<CartData> searchPageData)
	{

		final List<CartData> cartDatas = searchPageData.getResults();
		final JSONObject jsonObject = new JSONObject();
		if (cartDatas != null && !cartDatas.isEmpty())
		{
			for (final CartData cartData : cartDatas)
			{
				final List<OrderEntryData> entries = cartData.getEntries();
				jsonObject.put(CARTID, cartData.getCode());
				jsonObject.put(PRICE, prepareCartPriceDetails(cartData));
				jsonObject.put(ITEM, prepareVariantList(entries, null));
			}
		}
		return jsonObject;
	}

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getQuoteJsonObjectForAnalytics(final String productCode, final String quoteNumber)
	{
		final CartData cartData = hpeCartFacade.getSessionCart();
		final JSONObject jsonObject = new JSONObject();
		final JSONArray productInfos = new JSONArray();
		jsonObject.put(CARTID, cartData.getCode());

		jsonObject.put(PRICE, prepareCartPriceDetails(cartData));

		final ProductData product = productFacade.getProductForCodeAndOptions(productCode,
				Arrays.asList(ProductOption.BASIC, ProductOption.PRICE, ProductOption.VARIANT_MATRIX_PRICE));

		final JSONObject productDetail = new JSONObject();
		final JSONObject productInfo = new JSONObject();
		productDetail.put(PRODUCTID, productCode);
		productDetail.put(PRODUCTNAME, product.getName());
		productDetail.put(PRICE, (product.getPrice() != null) ? product.getPrice().getValue() : null);
		productDetail.put(QUANTITY, ONE);

		final List<OrderEntryData> entries = cartData.getEntries();

		final List itemList = prepareVariantList(entries, null);
		productInfo.put(PRODUCTINFO, productDetail);
		productInfos.put(productInfo);
		jsonObject.put(PRODUCTINFO, productInfos);
		jsonObject.put(TRANSACTIONID, quoteNumber);
		jsonObject.put(ITEM, itemList);

		return jsonObject;
	}

	/**
	 * This method is used to prepare a JSON object and set in the JSP page. The JSON Object is parsed by Tealium Tag
	 * Manager tool for analytics.
	 */
	public JSONObject getOrderConfirmationDataForAnalytics(final OrderData orderData)
	{
		final JSONObject jsonObject = new JSONObject();
		jsonObject.put(TRANSACTIONID, orderData.getCode());
		jsonObject.put(CARTID, orderData.getCode());

		final HashMap<String, Object> price = new HashMap();
		price.put(CURRENCY, orderData.getTotalPrice() != null ? orderData.getTotalPrice().getCurrencyIso() : EMPTY_STRING);
		price.put(SHIPPING, orderData.getDeliveryCost() != null ? orderData.getDeliveryCost().getValue() : ZERO);
		price.put(VOUCHERDISCOUNT, orderData.getTotalDiscounts() != null ? orderData.getTotalDiscounts().getValue() : ZERO);
		price.put(CARTTOTAL, orderData.getTotalPriceWithTax() != null ? orderData.getTotalPriceWithTax().getValue() : ZERO);
		price.put(BASEPRICE, orderData.getTotalPrice() != null ? orderData.getTotalPrice().getValue() : ZERO);
		price.put(SHIPPINGMETHOD, getDefaultDeliveryModeName());
		jsonObject.put(PRICE, price);
		jsonObject.put(PAYMENTMETHOD, CREDITCARD);

		final List<OrderEntryData> entries = orderData.getEntries();
		final List<EntryGroupData> bundleEntries = orderData.getRootGroups();

		List itemList = prepareVariantList(entries, orderData.getCode());
		itemList = prepareConfigListOrderConfirmation(orderData, itemList);
		if (bundleEntries != null)
		{
			for (final EntryGroupData bundleEntryData : bundleEntries)
			{

				final String bundleID = bundleEntryData.getExternalReferenceId();
				final String bundleName = bundleEntryData.getLabel();
				final List<OrderEntryData> bundleProducts = bundleEntryData.getOrderEntries();
				final BigDecimal bundlePrice = bundleEntryData.getEntryGroupPrice();
				final Integer bundleQuantity = bundleEntryData.getBundleQuantity();

				itemList = buildProductDetailsOrderConfirmation(itemList, bundleID, bundleName, bundlePrice, bundleQuantity,
						bundleProducts);
			}
		}

		jsonObject.put(ITEM, itemList);
		jsonObject.put(PRICE, prepareOrderDataPriceDetails(orderData));
		return jsonObject;
	}

	/**
	 *
	 * @param cartData
	 * @return
	 */
	private HashMap<String, Object> prepareCartPriceDetails(final CartData cartData)
	{
		final HashMap<String, Object> price = new HashMap();
		price.put(CURRENCY, cartData.getTotalPrice() != null ? cartData.getTotalPrice().getCurrencyIso() : EMPTY_STRING);
		price.put(SHIPPING, cartData.getDeliveryCost() != null ? cartData.getDeliveryCost().getValue() : null);
		price.put(VOUCHERDISCOUNT, cartData.getTotalDiscounts() != null ? cartData.getTotalDiscounts().getValue() : null);
		price.put(CARTTOTAL, cartData.getTotalPriceWithTax() != null ? cartData.getTotalPriceWithTax().getValue() : null);
		price.put(SHIPPINGMETHOD, getDefaultDeliveryModeName());
		price.put(TOTALTAX, cartData.getTotalTax() != null ? cartData.getTotalTax().getValue() : null);
		price.put(BASEPRICE, getBasePrice(cartData));

		return price;
	}

	private HashMap<String, Object> prepareOrderDataPriceDetails(final OrderData orderData)
	{
		final HashMap<String, Object> price = new HashMap();
		price.put(CURRENCY, orderData.getTotalPrice() != null ? orderData.getTotalPrice().getCurrencyIso() : EMPTY_STRING);
		price.put(SHIPPING, orderData.getDeliveryCost() != null ? orderData.getDeliveryCost().getValue() : ZERO);
		price.put(VOUCHERDISCOUNT, orderData.getTotalDiscounts() != null ? orderData.getTotalDiscounts().getValue() : ZERO);
		price.put(CARTTOTAL, orderData.getTotalPriceWithTax() != null ? orderData.getTotalPriceWithTax().getValue() : ZERO);
		price.put(SHIPPINGMETHOD, getDefaultDeliveryModeName());
		price.put(TOTALTAX, orderData.getTotalTax() != null ? orderData.getTotalTax().getValue() : ZERO);
		price.put(BASEPRICE, getOrderDataBasePrice(orderData));

		return price;
	}

	/**
	 *
	 * @param cartData
	 * @return
	 */
	private double getBasePrice(final CartData cartData)
	{
		if (cartData.getTotalPrice() != null && cartData.getDeliveryCost() != null)
		{
			return cartData.getTotalPrice().getValue().doubleValue() - cartData.getDeliveryCost().getValue().doubleValue();
		}
		return cartData.getTotalPriceWithTax() == null ? 0.0d : cartData.getTotalPriceWithTax().getValue().doubleValue();
	}

	/**
	 *
	 * @param orderData
	 * @return
	 */
	private double getOrderDataBasePrice(final OrderData orderData)
	{
		if (orderData.getTotalPrice() != null && orderData.getDeliveryCost() != null)
		{
			return orderData.getTotalPrice().getValue().doubleValue() - orderData.getDeliveryCost().getValue().doubleValue();
		}
		return orderData.getTotalPriceWithTax() == null ? 0.0d : orderData.getTotalPriceWithTax().getValue().doubleValue();
	}

	private List prepareVariantList(final List<OrderEntryData> entries, final String orderCode)
	{
		final List itemList = new ArrayList();

		if (entries != null)
		{
			populateVariantDetail(entries, itemList, orderCode);
		}
		return itemList;
	}

	/**
	 * @param entries
	 * @param itemList
	 */
	private void populateVariantDetail(final List<OrderEntryData> entries, final List itemList, final String orderCode)
	{
		for (final OrderEntryData entryData : entries)
		{
			if (entryData != null && entryData.getConfigID() == null)
			{
				final JSONObject productDetail = new JSONObject();
				final JSONObject productInfo = new JSONObject();

				productDetail.put(PRODUCTID, (entryData.getProduct() != null) ? entryData.getProduct().getCode() : null);
				productDetail.put(PRODUCTNAME, (entryData.getProduct() != null) ? entryData.getProduct().getName() : null);
				productDetail.put(VENDOR, entryData.getShopName());
				productDetail.put(QUANTITY, entryData.getQuantity());
				productDetail.put(PRICE, (entryData.getTotalPrice() != null) ? entryData.getTotalPrice().getValue() : ZERO);
				productDetail.put(SHIPPINGMETHOD, (entryData.getProduct() != null)
						? getProductShippingMethod(entryData.getProduct().getCode(), orderCode) : null);
				productInfo.put(PRODUCTINFO, productDetail);
				itemList.add(productInfo);
			}
		}
	}

	/**
	 *
	 * @param cartData
	 * @param itemList
	 * @return
	 */
	private List prepareBundleList(final CartData cartData, final List itemList)
	{
		if (cartData == null || cartData.getRootGroups() == null)
		{
			return itemList;
		}
		final List<EntryGroupData> entryGroups = cartData.getRootGroups();

		for (final EntryGroupData entryGroup : entryGroups)
		{
			final String bundleID = entryGroup.getExternalReferenceId();
			if (bundleID != null)
			{
				final String bundleName = entryGroup.getLabel();
				final BigDecimal bundlePrice = entryGroup.getEntryGroupPrice();
				final Integer bundleQuantity = entryGroup.getBundleQuantity();
				final List<ProductModel> bundleBaseProductList = entryGroup.getBundleBaseProduct();
				String bundleBaseProductCode = null;
				if (bundleBaseProductList != null && !bundleBaseProductList.isEmpty())
				{
					bundleBaseProductCode = bundleBaseProductList.get(0).getCode();
				}

				final List<OrderEntryData> bundleProducts = entryGroup.getOrderEntries();
				buildProductDetails(itemList, bundleID, bundleName, bundlePrice, bundleQuantity, bundleProducts,
						bundleBaseProductCode);
			}
		}

		return itemList;
	}

	/**
	 *
	 * @param cartData
	 * @param itemList
	 * @return
	 */
	private List prepareConfigList(CartData cartData, final List itemList)
	{
		if (cartData == null || cartData.getEntries() == null)
		{
			return itemList;
		}

		List<OrderEntryData> configEntries = collectConfigEntriesinCart(cartData);
		cartData = hpeCartFacade.getConfigEntries(configEntries, cartData);
		configEntries = cartData.getEntries();

		populateConfigDetailOrderConfirmation(itemList, configEntries);
		return itemList;
	}

	private void buildProductDetails(final List itemList, final String bundleID, final String bundleName,
			final BigDecimal bundlePrice, final Integer bundleQuantity, final List<OrderEntryData> bundleProducts,
			final String bundleBaseProductCode)
	{
		if (bundleProducts != null && !bundleProducts.isEmpty())
		{
			final JSONObject productDetail = new JSONObject();
			final JSONObject productInfo = new JSONObject();
			final StringBuilder strBuf = new StringBuilder();
			String vendor = null;
			String shippingMethod = null;
			productDetail.put(PRODUCTID, bundleID);
			productDetail.put(PRODUCTNAME, bundleName);
			productDetail.put(PRICE, (bundlePrice != null) ? bundlePrice.doubleValue() : null);
			productDetail.put(QUANTITY, (bundleQuantity != null) ? bundleQuantity.intValue() : null);
			productDetail.put(SHIPPINGMETHOD,
					(bundleBaseProductCode != null) ? getProductShippingMethod(bundleBaseProductCode, null) : null);


			for (int i = 0; i < bundleProducts.size(); i++)
			{
				final OrderEntryData bundleProduct = bundleProducts.get(i);
				if (bundleProduct != null && bundleProduct.getProduct() != null)
				{
					vendor = bundleProduct.getShopName();
					shippingMethod = (bundleProduct.getDeliveryMode() != null) ? bundleProduct.getDeliveryMode().getName() : null; 
					strBuf.append(bundleProduct.getProduct().getCode());
				}
				if (i < bundleProducts.size() - 1)
				{
					strBuf.append("|");
				}
			}

			productDetail.put(BUNDLEPRODUCTS, strBuf.toString());
			productDetail.put(VENDOR, vendor);
			productDetail.put(SHIPPINGMETHOD, shippingMethod);

			productInfo.put(PRODUCTINFO, productDetail);
			itemList.add(productInfo);
		}
	}

	private List buildProductDetailsOrderConfirmation(final List itemList, final String bundleID, final String bundleName,
			final BigDecimal bundlePrice, final Integer bundleQuantity, final List<OrderEntryData> bundleProducts)
	{
		String vendor = null;
		String shippingMethod = null;

		if (bundleProducts != null && !bundleProducts.isEmpty() && bundleID != null)
		{
			final JSONObject productDetail = new JSONObject();
			final JSONObject productInfo = new JSONObject();
			final StringBuilder strBuf = new StringBuilder();
			productDetail.put(PRODUCTID, bundleID);
			productDetail.put(PRODUCTNAME, bundleName);
			productDetail.put(PRICE, (bundlePrice != null) ? bundlePrice.doubleValue() : null);
			productDetail.put(QUANTITY, (bundleQuantity != null) ? bundleQuantity.intValue() : null);


			for (int i = 0; i < bundleProducts.size(); i++)
			{
				final OrderEntryData bundleProduct = bundleProducts.get(i);
				if (bundleProduct != null)
				{
					final ProductData product = bundleProduct.getProduct();
					if (product != null)
					{
						strBuf.append(product.getCode());
					}
					vendor = bundleProduct.getShopName();
					shippingMethod = (bundleProduct.getDeliveryMode() != null) ? bundleProduct.getDeliveryMode().getName() : null;
				}
				if (i < bundleProducts.size() - 1)
				{
					strBuf.append("|");
				}
			}

			productDetail.put(VENDOR, vendor);
			productDetail.put(SHIPPINGMETHOD, shippingMethod);
			productDetail.put(BUNDLEPRODUCTS, strBuf.toString());
			productInfo.put(PRODUCTINFO, productDetail);
			itemList.add(productInfo);
		}
		return itemList;
	}


	public JSONObject getComparePageDetails(final Map<String, ProductData> productDetails)
	{
		final JSONArray productInfoList = new JSONArray();
		final JSONObject jsonObject = new JSONObject();

		if (productDetails != null)
		{
			final Set<String> productKeys = productDetails.keySet();
			if (productKeys != null)
			{
				populateCompareDetail(productDetails, productInfoList, productKeys);
			}
		}
		jsonObject.put(PRODUCTINFO, productInfoList);
		return jsonObject;
	}

	/**
	 * @param productDetails
	 * @param productInfoList
	 * @param productKeys
	 */
	private void populateCompareDetail(final Map<String, ProductData> productDetails, final JSONArray productInfoList,
			final Set<String> productKeys)
	{
		final Iterator keyIterator = productKeys.iterator();
		while (keyIterator != null && keyIterator.hasNext())
		{
			final String key = keyIterator.next().toString();
			final JSONObject product = new JSONObject();
			final JSONObject productInfo = new JSONObject();

			final ProductData productData = productDetails.get(key);
			product.put(PRODUCTID, (productData != null) ? productData.getCode() : null);
			product.put(PRODUCTNAME, (productData != null) ? productData.getName() : null);
			if (productData != null)
			{
				product.put(PRICE, (productData.getPrice() != null) ? productData.getPrice().getValue() : null);
			}

			productInfo.put(PRODUCTINFO, product);
			productInfoList.put(productInfo);
		}
	}

	private List prepareConfigListOrderConfirmation(OrderData orderData, final List itemList)
	{
		if (orderData == null || orderData.getEntries() == null)
		{
			return itemList;
		}

		List<OrderEntryData> configEntries = collectConfigEntriesinOrder(orderData);
		orderData = hpeCartFacade.getConfigEntries(configEntries, orderData);
		configEntries = orderData.getEntries();

		populateConfigDetailOrderConfirmation(itemList, configEntries);
		return itemList;
	}

	/**
	 * @param itemList
	 * @param configEntries
	 */
	private void populateConfigDetailOrderConfirmation(final List itemList, final List<OrderEntryData> configEntries)
	{
		String configID;
		String configName;
		double configPrice;
		Long configQuantity;
		for (final OrderEntryData configEntry : configEntries)
		{
			if (configEntry != null && configEntry.getIsStarterProduct())
			{
				final JSONObject productDetail = new JSONObject();
				final JSONObject productInfo = new JSONObject();

				configName = (configEntry.getProduct() != null) ? configEntry.getProduct().getName() : null;
				configID = configEntry.getConfigID();
				configPrice = (configEntry.getTotalPrice() != null) ? configEntry.getTotalPrice().getValue().doubleValue() : null;
				configQuantity = configEntry.getQuantity();

				productDetail.put(PRODUCTID, configID);
				productDetail.put(PRODUCTNAME, configName);
				productDetail.put(PRICE, configPrice);
				productDetail.put(QUANTITY, (configQuantity != null) ? configQuantity.intValue() : null);
				productDetail.put(VENDOR, configEntry.getShopName());
				productDetail.put(SHIPPINGMETHOD,
						(configEntry.getDeliveryMode() != null) ? configEntry.getDeliveryMode().getName() : null);

				productInfo.put(PRODUCTINFO, productDetail);
				itemList.add(productInfo);
			}
		}
	}

	private List<OrderEntryData> collectConfigEntriesinCart(final CartData orderDetails)
	{
		final List<OrderEntryData> configEntries = new ArrayList();
		if (orderDetails.getEntries() != null && !orderDetails.getEntries().isEmpty())
		{
			for (final OrderEntryData entry : orderDetails.getEntries())
			{
				if (StringUtils.isNotEmpty(entry.getConfigID()))
				{
					configEntries.add(entry);
				}
			}
		}
		return configEntries;
	}

	private List<OrderEntryData> collectConfigEntriesinOrder(final OrderData orderDetails)
	{
		final List<OrderEntryData> configEntries = new ArrayList();
		if (orderDetails.getEntries() != null && !orderDetails.getEntries().isEmpty())
		{
			for (final OrderEntryData entry : orderDetails.getEntries())
			{
				if (StringUtils.isNotEmpty(entry.getConfigID()))
				{
					configEntries.add(entry);
				}
			}
		}
		return configEntries;
	}

	private String getDefaultDeliveryModeName()
	{
		final List deliveryModes = checkoutFacade.getSupportedDeliveryModes();
		String deliveryModeName = null;
		if (deliveryModes != null && !deliveryModes.isEmpty())
		{
			deliveryModeName = ((DeliveryModeData) deliveryModes.get(0)).getName();
		}
		return deliveryModeName;
	}

	/**
	 * 
	 * @param productCode
	 * @param orderCode
	 * @return
	 */
	private String getProductShippingMethod(final String productCode, final String orderCode)
	{
		return hpeCartFacade.getShippingMethodFromMarketPlace(productCode, orderCode);
	}
}
