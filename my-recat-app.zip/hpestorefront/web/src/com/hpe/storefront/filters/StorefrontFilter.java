/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.filters;

import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.commercefacades.storesession.StoreSessionFacade;
import de.hybris.platform.multicountry.constants.MulticountryConstants;
import de.hybris.platform.servicelayer.session.SessionService;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.PathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import com.hpe.facades.product.HPEBrowseHistory;
import com.hpe.facades.product.HPEBrowseHistoryEntry;


/**
 * Filter that initializes the session for the hpestorefront. This is a spring configured filter that is
 * executed by the PlatformFilterChain.
 */
public class StorefrontFilter extends OncePerRequestFilter
{
	public static final String AJAX_REQUEST_HEADER_NAME = "X-Requested-With";
	public static final String ORIGINAL_REFERER = "originalReferer";

	private StoreSessionFacade storeSessionFacade;
	private HPEBrowseHistory hpeBrowseHistory;
	private Set<String> refererExcludeUrlSet;
	private PathMatcher pathMatcher;

	@Resource
	private SessionService sessionService;

	@Override
	public void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws IOException, ServletException
	{
		final HttpSession session = request.getSession();
		final String queryString = request.getQueryString();

		if (isSessionNotInitialized(session, queryString))
		{
			initDefaults(request);

			markSessionInitialized(session);
		}

		if (isGetMethod(request))
		{
			if (StringUtils.isBlank(request.getHeader(AJAX_REQUEST_HEADER_NAME)) && !isRequestPathExcluded(request))
			{
				final String requestURL = request.getRequestURL().toString();
				session.setAttribute(ORIGINAL_REFERER, StringUtils.isNotBlank(queryString) ? requestURL + "?" + queryString
						: requestURL);
			}

			getHpeBrowseHistory().addBrowseHistoryEntry(new HPEBrowseHistoryEntry(request.getRequestURI(), null));
		}

		filterChain.doFilter(request, response);
	}

	protected boolean isGetMethod(final HttpServletRequest httpRequest)
	{
		return "GET".equalsIgnoreCase(httpRequest.getMethod());
	}

	protected boolean isRequestSecure(final HttpServletRequest httpRequest)
	{
		return httpRequest.isSecure();
	}

	protected boolean isSessionNotInitialized(final HttpSession session, final String queryString)
	{
		return session.isNew() || StringUtils.contains(queryString, CMSFilter.CLEAR_CMSSITE_PARAM)
				|| !isSessionInitialized(session);
	}

	@Required
	public void setStoreSessionFacade(final StoreSessionFacade storeSessionFacade)
	{
		this.storeSessionFacade = storeSessionFacade;
	}

	/**
	 * @param hpeBrowseHistory
	 *           the hpeBrowseHistory to set
	 */
	@Required
	public void setHpeBrowseHistory(final HPEBrowseHistory hpeBrowseHistory)
	{
		this.hpeBrowseHistory = hpeBrowseHistory;
	}

	protected void initDefaults(final HttpServletRequest request)
	{
		getStoreSessionFacade().initializeSession(Collections.list(request.getLocales()));
	}

	protected StoreSessionFacade getStoreSessionFacade()
	{
		return storeSessionFacade;
	}

	/**
	 * @return the hpeBrowseHistory
	 */
	public HPEBrowseHistory getHpeBrowseHistory()
	{
		return hpeBrowseHistory;
	}


	protected boolean isSessionInitialized(final HttpSession session)
	{
		if (session.getAttribute(this.getClass().getName()) != null)
		{
			final Object availabilityGroups = sessionService.getAttribute(MulticountryConstants.AVAILABILITY_GROUPS);
			if (availabilityGroups instanceof Collection<?> && !((Collection) availabilityGroups).isEmpty())
			{
				return true;
			}
		}

		return false;
	}

	protected void markSessionInitialized(final HttpSession session)
	{
		session.setAttribute(this.getClass().getName(), "initialized");
	}

	protected boolean isRequestPathExcluded(final HttpServletRequest request)
	{
		final Set<String> inputSet = getRefererExcludeUrlSet();
		final String servletPath = request.getServletPath();

		for (final String input : inputSet)
		{
			if (getPathMatcher().match(input, servletPath))
			{
				return true;
			}
		}

		return false;
	}

	protected Set<String> getRefererExcludeUrlSet()
	{
		return refererExcludeUrlSet;
	}

	@Required
	public void setRefererExcludeUrlSet(final Set<String> refererExcludeUrlSet)
	{
		this.refererExcludeUrlSet = refererExcludeUrlSet;
	}

	protected PathMatcher getPathMatcher()
	{
		return pathMatcher;
	}

	@Required
	public void setPathMatcher(final PathMatcher pathMatcher)
	{
		this.pathMatcher = pathMatcher;
	}
}
