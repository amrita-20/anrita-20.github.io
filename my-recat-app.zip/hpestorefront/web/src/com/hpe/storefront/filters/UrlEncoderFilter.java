/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.filters;

import de.hybris.platform.acceleratorfacades.urlencoder.UrlEncoderFacade;
import de.hybris.platform.acceleratorfacades.urlencoder.data.UrlEncoderData;
import de.hybris.platform.acceleratorstorefrontcommons.constants.WebConstants;
import de.hybris.platform.cms2.misc.CMSFilter;
import de.hybris.platform.servicelayer.session.SessionService;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.web.filter.OncePerRequestFilter;

import com.hpe.storefront.web.wrappers.UrlEncodeHttpRequestWrapper;


/**
 * This filter inspects the url and inject the url attributes if any for that CMSSite. Calls facades to fetch the list
 * of attributes and encode them in the URL.
 */
public class UrlEncoderFilter extends OncePerRequestFilter
{
	private static final Logger LOG = Logger.getLogger(UrlEncoderFilter.class.getName());

	private UrlEncoderFacade urlEncoderFacade;
	private SessionService sessionService;

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws ServletException, IOException
	{
		if (LOG.isDebugEnabled())
		{
			LOG.debug("request.getRequestURI()=[" + request.getRequestURI() + "]");
			LOG.debug("request.getRequestURL()=[" + request.getRequestURL() + "]");
			LOG.debug("request.getServletPath()=[" + request.getServletPath() + "]");
			LOG.debug("request.getContextPath()=[" + request.getContextPath() + "]");
			LOG.debug("request.getQueryString()=[" + request.getQueryString() + "]");
		}

		final List<UrlEncoderData> currentUrlEncoderDatas = getUrlEncoderFacade().getCurrentUrlEncodingData();

		if (currentUrlEncoderDatas != null && !currentUrlEncoderDatas.isEmpty())
		{
			final String currentPattern = getSessionService().getAttribute(WebConstants.URL_ENCODING_ATTRIBUTES);
			final String newPattern = getUrlEncoderFacade().calculateAndUpdateUrlEncodingData(request.getRequestURI().toString(),
					request.getContextPath());
			final String newPatternWithSlash = "/" + newPattern;
			final String originalContextPath = StringUtils.isBlank(request.getContextPath()) ? "/" : request.getContextPath();
			final boolean isCmsRequest = StringUtils.contains(request.getQueryString(), CMSFilter.PREVIEW_TICKET_ID_PARAM);

			if (LOG.isDebugEnabled())
			{
				LOG.debug("currentPattern=[" + currentPattern + "]");
				LOG.debug("newPattern=[" + newPattern + "]");
				LOG.debug("newPatternWithSlash=[" + newPatternWithSlash + "]");
				LOG.debug("originalContextPath=[" + originalContextPath + "]");
			}

			if (!StringUtils.equalsIgnoreCase(currentPattern, newPatternWithSlash))
			{
				getUrlEncoderFacade().updateSiteFromUrlEncodingData();
				getSessionService().setAttribute(WebConstants.URL_ENCODING_ATTRIBUTES, newPatternWithSlash);
			}

			final UrlEncodeHttpRequestWrapper wrappedRequest = new UrlEncodeHttpRequestWrapper(request, newPattern);
			wrappedRequest.setAttribute(WebConstants.URL_ENCODING_ATTRIBUTES, newPatternWithSlash);
			wrappedRequest.setAttribute("originalContextPath", originalContextPath);

			// LOG wrappedRequest attributes
			if (LOG.isDebugEnabled())
			{
				LOG.debug("wrappedRequest.getRequestURI()=[" + wrappedRequest.getRequestURI() + "]");
				LOG.debug("wrappedRequest.getRequestURL()=[" + wrappedRequest.getRequestURL() + "]");
				LOG.debug("wrappedRequest.getServletPath()=[" + wrappedRequest.getServletPath() + "]");
				LOG.debug("wrappedRequest.getContextPath()=[" + wrappedRequest.getContextPath() + "]");
				LOG.debug("wrappedRequest.getQueryString()=[" + wrappedRequest.getQueryString() + "]");
				LOG.debug("filterChain.doFilter(wrappedRequest, response)");
			}

			filterChain.doFilter(wrappedRequest, response);
		}
		else
		{
			request.setAttribute(WebConstants.URL_ENCODING_ATTRIBUTES, "");
			filterChain.doFilter(request, response);
		}
	}

	private String getRedirectUrlBasedOnEncodingAttributes(final HttpServletRequest request, final String newPatternWithSlash,
			final String cmsRequest)
	{
		final String requestURL = request.getRequestURL().toString();
		try
		{
			final URIBuilder builder = new URIBuilder();
			final URI uri = new URI(requestURL);
			builder.setScheme(uri.getScheme());
			builder.setPort(uri.getPort());
			builder.setHost(uri.getHost());
			builder.setPath(newPatternWithSlash + cmsRequest);
			final String queryString = request.getQueryString();
			if (StringUtils.isNotBlank(queryString))
			{
				builder.setParameters(URLEncodedUtils.parse(queryString, StandardCharsets.UTF_8));
			}
			return builder.build().toString();
		}
		catch (final URISyntaxException e)
		{
			LOG.warn("Could not build redirect URL for " + requestURL, e);
			return null;
		}
	}

	protected UrlEncoderFacade getUrlEncoderFacade()
	{
		return urlEncoderFacade;
	}

	@Required
	public void setUrlEncoderFacade(final UrlEncoderFacade urlEncoderFacade)
	{
		this.urlEncoderFacade = urlEncoderFacade;
	}

	protected SessionService getSessionService()
	{
		return sessionService;
	}

	@Required
	public void setSessionService(final SessionService sessionService)
	{
		this.sessionService = sessionService;
	}
}
