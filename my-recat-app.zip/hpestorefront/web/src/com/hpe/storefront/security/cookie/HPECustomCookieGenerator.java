/**
 *
 */
package com.hpe.storefront.security.cookie;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author chenna
 *
 */
public class HPECustomCookieGenerator extends EnhancedCookieGenerator
{
	public void addCookie(final HttpServletRequest request, final HttpServletResponse response, final String cookieValue)
	{
		final Cookie cookie = super.createCookie(cookieValue);
		cookie.setDomain(getDomainForCookie(request));
		final Integer maxAge = this.getCookieMaxAge();
		if (maxAge != null)
		{
			cookie.setMaxAge(maxAge);
		}
		if (this.isCookieSecure())
		{
			cookie.setSecure(true);
		}
		if (this.isCookieHttpOnly())
		{
			cookie.setHttpOnly(true);
		}
		response.addCookie(cookie);
		if (this.logger.isDebugEnabled())
		{
			this.logger.debug("HPECustomCookieGenerator:addCookie:Added cookie with name [" + this.getCookieName() + "] and value [" + cookieValue + "]");
		}
	}

	public void removeCookie(final HttpServletRequest request, final HttpServletResponse response)
	{
		final Cookie cookie = this.createCookie("");
		cookie.setDomain(getDomainForCookie(request));
		cookie.setMaxAge(0);
		if (this.isCookieSecure())
		{
			cookie.setSecure(true);
		}

		if (this.isCookieHttpOnly())
		{
			cookie.setHttpOnly(true);
		}

		response.addCookie(cookie);
		if (this.logger.isDebugEnabled())
		{
			this.logger.debug("HPECustomCookieGenerator:removeCookie:Removed cookie with name [" + this.getCookieName() + "]");
		}
	}

	protected String getDomainForCookie(final HttpServletRequest request)
	{
		final String serverName = request.getServerName();
		if (serverName.matches(".*[a-zA-Z].*") && serverName.indexOf('.') >= 0)
		{
			return serverName.replaceAll(".*\\.(?=.*\\.)", "");
		}
		return serverName;
	}
}
