/*
 * Creating Cookie Name for SSO / Site Minder.
 */
package com.hpe.storefront.security.cookie;

/**
 * @author $atya
 *
 */
public class HPESessionCookieGenerator extends HPECustomCookieGenerator
{
	private static final String HPP_SESSION = "HPPSESSION";

	@Override
	public String getCookieName()
	{
		return HPP_SESSION;
	}
}
