/*
 * Storing cart indicator in the cookie for other systems to call the OCC service.
 */
package com.hpe.storefront.security.cookie;

/**
 * CookieGenerator for cart items.
 *
 */
public class HPEUserCartNotificationCookieGenerator extends HPECustomCookieGenerator
{
	private static final String USER_HAS_CART = "user-has-cart";

	@Override
	public String getCookieName()
	{
		return USER_HAS_CART;
	}
}
