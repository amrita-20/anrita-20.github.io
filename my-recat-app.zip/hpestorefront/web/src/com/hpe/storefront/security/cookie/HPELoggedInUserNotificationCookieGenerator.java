/*
 * User logged in indicator stored in the cookie for other systems
 */
package com.hpe.storefront.security.cookie;

/**
 * CookieGenerator for logged in user
 *
 */
public class HPELoggedInUserNotificationCookieGenerator extends HPECustomCookieGenerator
{
	private static final String LOGGED_IN_USER_NOTIFICATION = "hybris-store-logged-in";

	@Override
	public String getCookieName()
	{
		return LOGGED_IN_USER_NOTIFICATION;
	}
}
