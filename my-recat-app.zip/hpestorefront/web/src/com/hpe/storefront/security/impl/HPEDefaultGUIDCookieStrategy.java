/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.security.impl;

import de.hybris.platform.acceleratorstorefrontcommons.security.GUIDCookieStrategy;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Hex;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.Assert;
import org.springframework.web.util.CookieGenerator;

import com.hpe.storefront.interceptors.beforecontroller.RequireHardLoginBeforeControllerHandler;
import com.hpe.storefront.security.cookie.HPELoggedInUserNotificationCookieGenerator;
import com.hpe.storefront.security.cookie.HPEUserCartNotificationCookieGenerator;

import net.sourceforge.pmd.util.StringUtil;


/**
 * Default implementation of {@link GUIDCookieStrategy}
 */
public class HPEDefaultGUIDCookieStrategy implements GUIDCookieStrategy
{
	private static final Logger LOG = Logger.getLogger(HPEDefaultGUIDCookieStrategy.class);
	private static final String USER_NAME = "j_username";
	private static final String EMAIL = "email";
	private final SecureRandom random;
	private final MessageDigest sha;

	private CookieGenerator cookieGenerator;
	@Resource(name = "loggedInUserNotificationCookieGenerator")
	private HPELoggedInUserNotificationCookieGenerator loggedInUserNotificationCookieGenerator;
	@Resource(name = "userCartNotificationCookieGenerator")
	private HPEUserCartNotificationCookieGenerator userCartNotificationCookieGenerator;

	public HPEDefaultGUIDCookieStrategy() throws NoSuchAlgorithmException
	{
		random = SecureRandom.getInstance("SHA1PRNG");
		sha = MessageDigest.getInstance("SHA-1");
		Assert.notNull(random);
		Assert.notNull(sha);
	}

	@Override
	public void setCookie(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (!request.isSecure())
		{
			// We must not generate the cookie for insecure requests, otherwise there is not point doing this at all
			throw new IllegalStateException("Cannot set GUIDCookie on an insecure request!");
		}

		final String guid = createGUID();

		getCookieGenerator().addCookie(response, guid);
		setLoggedInUserCookie(request, response);
		request.getSession().setAttribute(RequireHardLoginBeforeControllerHandler.SECURE_GUID_SESSION_KEY, guid);

		if (LOG.isInfoEnabled())
		{
			LOG.info("Setting guid cookie and session attribute: " + guid);
		}
	}

	@Override
	public void deleteCookie(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (!request.isSecure())
		{
			LOG.error("Cannot remove secure GUIDCookie during an insecure request. I should have been called from a secure page.");
		}
		else
		{
			// Its a secure page, we can delete the cookie
			getCookieGenerator().removeCookie(response);
			invalidateCookies(request, response);
		}
	}

	protected String createGUID()
	{
		final String randomNum = String.valueOf(getRandom().nextInt());
		final byte[] result = getSha().digest(randomNum.getBytes());
		return String.valueOf(Hex.encodeHex(result));
	}

	protected CookieGenerator getCookieGenerator()
	{
		return cookieGenerator;
	}

	/**
	 * @param cookieGenerator
	 *           the cookieGenerator to set
	 */
	@Required
	public void setCookieGenerator(final CookieGenerator cookieGenerator)
	{
		this.cookieGenerator = cookieGenerator;
	}


	protected SecureRandom getRandom()
	{
		return random;
	}

	protected MessageDigest getSha()
	{
		return sha;
	}

	private void setLoggedInUserCookie(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (StringUtil.isNotEmpty(request.getParameter(USER_NAME)))
		{
			loggedInUserNotificationCookieGenerator.addCookie(request, response, request.getParameter(USER_NAME));
		}
		else if (StringUtil.isNotEmpty(request.getParameter(EMAIL)))
		{
			loggedInUserNotificationCookieGenerator.addCookie(request, response, request.getParameter(EMAIL));
		}
	}

	private void invalidateCookies(final HttpServletRequest request, final HttpServletResponse response)
	{
		loggedInUserNotificationCookieGenerator.removeCookie(request, response);
		userCartNotificationCookieGenerator.removeCookie(request, response);
	}
}
