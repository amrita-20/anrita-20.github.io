/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package com.hpe.storefront.security;


import de.hybris.platform.acceleratorstorefrontcommons.security.AbstractAcceleratorAuthenticationProvider;
import de.hybris.platform.acceleratorstorefrontcommons.security.BruteForceAttackCounter;
import de.hybris.platform.core.Constants;
import de.hybris.platform.core.GenericSearchConstants.LOG;
import de.hybris.platform.core.Registry;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.jalo.JaloConnection;
import de.hybris.platform.jalo.JaloSession;
import de.hybris.platform.jalo.user.User;
import de.hybris.platform.jalo.user.UserManager;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.spring.security.CoreUserDetails;
import de.hybris.platform.util.Config;

import java.util.Collections;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.hpe.facades.hpepassport.HPEPassportIntegrationFacade;
import com.hpe.facades.user.HPEUserFacade;
import com.hpe.hpepassport.constant.HPEPassportConstant;
import com.hpe.storefront.controllers.HPEStorefrontConstant;
import com.hpe.storefront.util.HPEStorefrontUtil;


/**
 * Derived authentication provider supporting additional authentication checks. See
 * {@link de.hybris.platform.spring.security.RejectUserPreAuthenticationChecks}.
 *
 * <ul>
 * <li>prevent login without password for users created via CSCockpit</li>
 * <li>prevent login as user in group admingroup</li>
 * </ul>
 *
 * any login as admin disables SearchRestrictions and therefore no page can be viewed correctly
 */
public class AcceleratorAuthenticationProvider extends AbstractAcceleratorAuthenticationProvider
{
	private static final String ROLE_ADMIN_GROUP = "ROLE_" + Constants.USER.ADMIN_USERGROUP.toUpperCase();

	private static final String HPE_PASSPORT_LOCAL_FLAG = "hpepassportintegration.authentication.call.flag";

	private static final String GTS_GEOLOCATION_CHECK = "gts.geolocation.check";

	private static final String TRUE_CONSTANT = "true";

	private GrantedAuthority adminAuthority = new SimpleGrantedAuthority(ROLE_ADMIN_GROUP);

	private static final Logger LOG = Logger.getLogger(AcceleratorAuthenticationProvider.class);



	private BruteForceAttackCounter bruteForceAttackCounter;

	@Resource(name = "hpePassportIntegrationFacade")
	private HPEPassportIntegrationFacade hpePassportIntegrationFacade;

	@Resource(name = "hpeUserFacade")
	private HPEUserFacade hpeUserFacade;

	@Resource(name = "hpeStorefrontUtil")
	private HPEStorefrontUtil hpeStorefrontUtil;

	@Resource(name = "configurationService")
	private ConfigurationService configurationService;

	/**
	 * @see de.hybris.platform.acceleratorstorefrontcommons.security.AbstractAcceleratorAuthenticationProvider#additionalAuthenticationChecks(org.springframework.security.core.userdetails.UserDetails,
	 *      org.springframework.security.authentication.AbstractAuthenticationToken)
	 */
	@Override
	protected void additionalAuthenticationChecks(final UserDetails details, final AbstractAuthenticationToken authentication)
	{
		super.additionalAuthenticationChecks(details, authentication);

		// Check if the user is in role admingroup
		if (getAdminAuthority() != null && details.getAuthorities().contains(getAdminAuthority()))
		{
			throw new LockedException("Login attempt as " + Constants.USER.ADMIN_USERGROUP + " is rejected");
		}
	}

	@Override
	public Authentication authenticate(final Authentication authentication)
	{
		final String username = (authentication.getPrincipal() == null) ? "NONE_PROVIDED" : authentication.getName();
		final boolean isBruteForceAttack = getBruteForceAttackCounter().isAttack(username);
		UserModel userModel = null;
		final String gtsGeoLocationCheck = configurationService.getConfiguration().getString(GTS_GEOLOCATION_CHECK, "false");
		if (TRUE_CONSTANT.equals(gtsGeoLocationCheck))
		{
			LOG.debug("******GTS call for  address check*******");
			boolean gtsResponse = Boolean.FALSE;
			try
			{
				final Boolean gtsCheck = (Boolean) JaloSession.getCurrentSession().getAttribute("gtsCheck");

				if (null != gtsCheck && gtsCheck)
				{
					JaloSession.getCurrentSession().removeAttribute("gtsCheck");
				}
				else
				{
					gtsResponse = hpeUserFacade.getGTSResponse(hpeStorefrontUtil.setGTSRequestData(username, null, null));
				}

			}
			catch (final Exception e)
			{
				JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.GTS_ERROR_RESPONSE,
						HPEStorefrontConstant.GTS_ERROR_RESPONSE_CODE_EXCEPTION);
				LOG.error("*****GTS call failed in Login******", e);
				throw new BadCredentialsException(messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS,
						HPEStorefrontConstant.GTS_ERROR_RESPONSE_CODE_EXCEPTION));
			}
			LOG.debug("gtsResponse value is Login page: " + gtsResponse);
			if (!gtsResponse)
			{
				//forward to home page
				JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.GTS_ERROR_RESPONSE,
						HPEStorefrontConstant.GTS_ERROR_RESPONSE_CODE);
				LOG.debug("*****GTS call failed in Login******");
				throw new BadCredentialsException(messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS,
						HPEStorefrontConstant.GTS_ERROR_RESPONSE_CODE));


			}
		}
		// throw BadCredentialsException if user does not exist
		try
		{
			userModel = getUserService().getUserForUID(StringUtils.lowerCase(username));
		}
		catch (final UnknownIdentifierException e)
		{
			if (isBruteForceAttack)
			{
				LOG.warn("Brute force attack attempt for non existing user name " + username);
			}
			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
			throw new BadCredentialsException(
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
		}

		/* Checks User disabling */
		if (userModel.isLoginDisabled())
		{

			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
					HPEStorefrontConstant.USER_LOGIN_DISBALED);
			throw new BadCredentialsException(HPEStorefrontConstant.USER_LOGIN_DISBALED);

		}
		// throw BadCredentialsException if it's brute force attack
		if (isBruteForceAttack)
		{
			userModel.setLoginDisabled(true);
			getModelService().save(userModel);
			bruteForceAttackCounter.resetUserCounter(userModel.getUid());
			JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
			throw new BadCredentialsException(
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
		}

		// throw BadCredentialsException if the user does not belong to customer user group
		if (!getUserService().isMemberOfGroup(userModel, getUserService().getUserGroupForUID(Constants.USER.CUSTOMER_USERGROUP)))
		{
			JaloSession.getCurrentSession().setAttribute("errorResponse",
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
			throw new BadCredentialsException(
					messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
		}

		return hpeAuthenticate(authentication);
	}


	/**
	 * Method to get HPE Authentication
	 *
	 * @param authentication
	 * @return
	 * @throws AuthenticationException
	 */
	public Authentication hpeAuthenticate(final Authentication authentication)
	{

		if (Registry.hasCurrentTenant() && JaloConnection.getInstance().isSystemInitialized())
		{

			final String username = authentication.getPrincipal() == null ? "NONE_PROVIDED" : authentication.getName();

			UserDetails userDetails = null;

			try
			{
				userDetails = this.retrieveUser(username);

			}
			catch (final UsernameNotFoundException arg5)
			{
				JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
						this.messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER));
				throw new BadCredentialsException(
						this.messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS, HPEStorefrontConstant.INVALID_USER),
						arg5);

			}

			final User user = UserManager.getInstance().getUserByLogin(userDetails.getUsername());

			final Object credential = authentication.getCredentials();

			final String flagString = Config.getParameter(HPE_PASSPORT_LOCAL_FLAG);
			boolean booleanFlag = Boolean.TRUE;
			if (flagString != null)
			{
				booleanFlag = Boolean.parseBoolean(flagString);
			}
			if (booleanFlag)
			{
				if (credential instanceof String)
				{
					LOG.debug("Before Rest Api Call." + new Date().toString());
					ResponseEntity<String> loginResponseEntity = null;
					try
					{

						loginResponseEntity = hpePassportIntegrationFacade.getHPEPassportLogin(username, credential.toString());
						LOG.debug("After Rest Api Call." + new Date().toString());

						if (loginResponseEntity != null && loginResponseEntity.getBody() != null)
						{
							if (loginResponseEntity.getStatusCode() == HttpStatus.OK
									&& loginResponseEntity.getBody().contains("sessionToken"))
							{
								JaloSession.getCurrentSession().setAttribute(HPEPassportConstant.SESSIONTOKEN,
										loginResponseEntity.getBody());
								final Object session = JaloSession.getCurrentSession().getAttribute(HPEPassportConstant.SESSIONTOKEN);
								LOG.debug("***** JaloSession Object*************" + session);
								JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
										new ResponseEntity<String>(loginResponseEntity.getBody(), HttpStatus.OK));
								JaloSession.getCurrentSession().setUser(user);
								return this.createSuccessAuthentication(authentication, userDetails);
							}
							else
							{
								JaloSession.getCurrentSession().setAttribute(HPEStorefrontConstant.ERROR_RESPONSE,
										new ResponseEntity<String>(loginResponseEntity.getBody(), HttpStatus.BAD_REQUEST));
								throw new BadCredentialsException(this.messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS,
										HPEStorefrontConstant.INVALID_USER));

							}
						}
					}
					catch (final Exception e)
					{

						throw new BadCredentialsException(this.messages.getMessage(CORE_AUTHENTICATION_PROVIDER_BAD_CREDENTIALS,
								HPEStorefrontConstant.INVALID_USER), e);
					}
				}
			}
			else
			{

				JaloSession.getCurrentSession().setUser(user);
				return this.createSuccessAuthentication(authentication, userDetails);
			}
		}
		else
		{
			return this.createSuccessAuthentication(authentication, new CoreUserDetails("systemNotInitialized",
					"systemNotInitialized", true, false, true, true, Collections.emptyList(), (String) null));
		}
		return authentication;

	}

	public void setAdminGroup(final String adminGroup)
	{
		if (StringUtils.isBlank(adminGroup))
		{
			adminAuthority = null;
		}
		else
		{
			adminAuthority = new SimpleGrantedAuthority(adminGroup);
		}
	}

	protected GrantedAuthority getAdminAuthority()
	{
		return adminAuthority;
	}



}
