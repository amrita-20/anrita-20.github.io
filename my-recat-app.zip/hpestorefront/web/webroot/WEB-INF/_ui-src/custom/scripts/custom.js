var date = new Date();
var timeStamp = date.getTime();
const ELOQUA_URL = $('#eloquaURL').text()+ '=' + timeStamp;
var currentUrl = location.href;



var ctxPath = ACC.config.encodedContextPath || '';
const BASE_URL = location.protocol+'//'+location.hostname+ (window.location.port ? ':' + window.location.port : '') + ctxPath;
var pdpUrl = currentUrl;
var pdpurlSubString = '/p/';
if (pdpUrl.indexOf(pdpurlSubString) !== -1) {

	$('.hpe-product-gallery .owl-carousel.owl-theme').find('*').hide();
	$('.owl-carousel-nav').hide();
	$(document).ready(function(){
	  	$('.hpe-product-gallery .owl-carousel.owl-theme').find('*').show();
		$('.hpe-product-gallery .owl-carousel.owl-theme').find('button').hide();
		$('.owl-carousel-nav').show();
	})
}

$('body').on('click','.add-cart-btn',function(){
	var data = $(this).closest('form').serialize();

	var request = $.ajax({
		cache: false,
		url: BASE_URL+"/cart/add",
		type: 'POST',
		data:data
	});

	request.done(function(data) {
		location.href=BASE_URL+'/cart';
	});

	request.fail(function(jqXHR) {
		console.log('fail');
	});
});

// Clear all filters for models tab in PDP
$("#clearFacetModels").click(function() {
		location.href = location.origin + location.pathname;
});

function clearFacetServices(){
	$('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Services")').click();
}


function showSpecification(code,tabType, e){
	e.preventDefault();
	$('.show-specification_'+code+'_'+tabType).text($('.show-specification_'+code+'_'+tabType).text() ===$('.show-specification-hidden-text').val()? $('.hide-specification-hidden-text').val() : $('.show-specification-hidden-text').val());
	if($('.show-specification_'+code+'_'+tabType).text() === $('.show-specification-hidden-text').val()){
				 $('#displayTableSpecification'+code+'_'+tabType).hide();
	} 
	else{
		$('#displayTableSpecification'+code+'_'+tabType).show();
	
	var currentUrl = location.href;
	var mystr = (currentUrl).slice(BASE_URL.length);
	var remainingstring = mystr.split('/').splice(0,
			mystr.split('/').length - 1).join('/');
	
	var url = BASE_URL + remainingstring + "/classification?variantCode="+code;
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			
		var trHTML='';
		Object.keys(data).length>0?trHTML='':trHTML=$('.no-showhide-specification-hidden-text').val();
					$(data).each(function(i,val)
							 {
								var j=0;
							  $.each(val,function(key,value)
							  {		
								
							
								if(key.toLowerCase().includes('headline')){
									if(j!=0){
										trHTML += '<br>';
									}
									trHTML += '<div class="row"><div class="col-12"><b>' + value + '</b></div></div>';	
									i++;
								}
								else{
									if(i>0){
										trHTML +='<br>';
									}
									i=0;
								trHTML += '<div class="row"><div class="col-4"><b>' + key + '</b></div><div class="col-8 hpe-product-specification-alignment">' + value + '</div></div>';	
								}		 
								j++;
									});
							
							}); 
			
					 $('#displayTableSpecification'+code+'_'+tabType).html(trHTML); 
	$('#spinner').hide();
	}
	});
	}
	}


$('#optionsTab').on('click','.getaQuoteOptionsBtn',function(){
	var quoteUrl = $(this).attr('quoteurl');  
	location.href = quoteUrl;
});

$('.productService .offerdropdown').each(function(i, ele) {
	var price = $(ele).find('option:selected', this).attr('offer-price');
	$(ele).closest('div').find('.productPrice').text(price);
	var productCode = $(ele).find('option:selected', this).val();
	$(ele).closest('.product-service-tab').find('input[name=productCodePost]').val(productCode);
})

$('.productService .offerdropdown').on('change',function(){
	var currentDropdown = $(this);
	var price = $(currentDropdown).find('option:selected', this).attr('offer-price');
	var productCode = $(currentDropdown).find('option:selected', this).val();
	$(currentDropdown).closest('div').find('.productPrice').text(price);
	$(currentDropdown).closest('.product-service-tab').find('input[name=productCodePost]').val(productCode);
})

$('.productModels .select-modelsTab').each(function(i, ele) {
	var price = $(ele).find('option:selected', this).attr('offer_price');
	$(ele).closest('div').find('.productPrice').text(price);
	var productCode = $(ele).find('option:selected', this).attr('offer_id');
	$(ele).closest('.product-models-slot').find('input[name=productCodePost]').val(productCode);
})

$('.productModels .select-modelsTab').on('change',function(){
	var currentDropdown = $(this);
	var price = $(currentDropdown).find('option:selected', this).attr('offer-price');
	var productCode = $(currentDropdown).find('option:selected', this).val();
	$(currentDropdown).closest('div').find('.productPrice').text(price);
	$(currentDropdown).closest('.product-service-tab').find('input[name=productCodePost]').val(productCode);
})



$('#optionsTab').on('click','.optionsaddToCartBtn',function(){
	var data = $(this).closest('form').serialize();
	var url = $(this).closest('form').attr('action');
	var request = $.ajax({
        cache: false,
        url: url,
		type: 'POST',
		data:data
    });

    request.done(function(data) {
		location.href=BASE_URL+'/cart';
    });

    request.fail(function(jqXHR) {
        console.log('fail');
    });
});


function getQuoteURLPopulate(getQuoteButton,code){
	var quoteURL = BASE_URL+'/getquotepage?productCodePost='+code;
	getQuoteButton.attr('quoteurl',quoteURL);
	return;
}


$('#optionsTab').on('change','.variantOffers',function(){	
	var offer_price = $(this).find('option:selected').attr('formattedprice');
	$(this).closest('.selectContainer').find('.hpe-product-list__price .offer_price').text(offer_price);
	
	var offer_code = $(this).find('option:selected').attr('id');
	$(this).closest('.main_container').find('input.productcode').val(offer_code);
	return;
});


function callOptions(optionsData) {
    $('#optionsTab').html(optionsData);
    if($('#modelProductDataCode').parent().has('p').length > 0){
    	var modelProductDataCode = $('#modelProductDataCode').html();
    	$('#modelProductDataCode').parent().find('p').append('<b>'+modelProductDataCode+'</b>');
        $('#modelProductDataCode').parent().find('p').css('margin','0px');
        $('#modelProductDataCode').hide();
    }
   

}


$(document).ready(function() {
	
    $('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Option")').hide();
    
    $(document).on("change", ".page-productDetails .modelsFacet", function() {
		
		var url = location.href;
		$(this).parents("form").attr("action", url);  
		$(this).parents("form").submit();
	});
	
	$(document).on("change", ".page-productDetails .optionsFacet", function() {
		
		var code = $('input[name="sourceCode_Option"]').val();
		var currentUrl = location.href;
		var mystr = (currentUrl).slice(BASE_URL.length);
		var remainingstring = mystr.split('/').splice(0,
				mystr.split('/').length - 1).join('/');
		$('#spinner').show();
		var url = BASE_URL + remainingstring + "/showOptions?sourceCode="+code;
		$(this).parents("form").attr("action", url);
		var form = $(this).parents("form");
		$.ajax({
			type : "GET",
			url : url,
			data : form.serialize(),
			success : function(data) {
				$('#spinner').hide();
				$('html, body').animate({
		            scrollTop: $('.hpe-more-information').offset().top 
		        }, 500);
				$('#optionsTab').html(data);
				 var productFacetArr = $('#product-facet-option').children('.facet.js-facet');
			        for (let i = 0; i < productFacetArr.length; i++) {
			        	if(i===2){
			        		break;
			        	}
			        	var attrClass = productFacetArr[i].classList[2];
			        		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
			        		$('.' + attrClass).find('section').attr('aria-hidden', true);
			        }
			}
		});
	});
	
	$(document).on("change", ".page-productDetails .sortModels", function() {
		var url = location.href;
		$(this).parents("form").attr("action", url);  
		$(this).parents("form").submit();
	});
	
	$(document).on("click", '.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Services")', function() {
		var code = $(this).children().attr("id");
		var currentUrl = location.href;
		var mystr = (currentUrl).slice(BASE_URL.length);
		var remainingstring = mystr.split('/').splice(0,
				mystr.split('/').length - 1).join('/');
		$('#spinner').show();
		var url = BASE_URL + remainingstring + "/showServices?sourceCode="+code;
		$.ajax({
			type : "GET",
			url : url,
			success : function(data) {
				$('#spinner').hide();
				$('.productServicesTabDisplay').html(data);
				 var productFacetArr = $('#product-facet-service').children('.facet.js-facet');
			        for (let i = 0; i < productFacetArr.length; i++) {
			        	if(i===2){
			        		break;
			        	}
			        	var attrClass = productFacetArr[i].classList[2];
			        		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
			        		$('.' + attrClass).find('section').attr('aria-hidden', true);
			        }
			}
		});
	});
	
	$(document).on("change", ".page-productDetails .servicesFacet", function() {
		var code = $('input[name="baseProduct"]').val();
		
		var currentUrl = location.href;
		var mystr = (currentUrl).slice(BASE_URL.length);
		var remainingstring = mystr.split('/').splice(0,
				mystr.split('/').length - 1).join('/');
		$('#spinner').show();
		var url = BASE_URL + remainingstring + "/showServices?sourceCode="+code;
		$(this).parents("form").attr("action", url);
		var form = $(this).parents("form");
		$.ajax({
			type : "GET",
			url : url,
			data : form.serialize(),
			success : function(data) {
				$('#spinner').hide();
				 $('html, body').animate({
			            scrollTop: $('.hpe-more-information').offset().top 
			        }, 500);
				$('.productServicesTabDisplay').html(data);
				 var productFacetArr = $('#product-facet-service').children('.facet.js-facet');
			        for (let i = 0; i < productFacetArr.length; i++) {
			        	
			        	var attrClass = productFacetArr[i].classList[2];
			        	
			        	if(($('.' + attrClass + ' input:checkbox:checked').length > 0) || (i<2) ){
							$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
				    		$('.' + attrClass).find('section').attr('aria-hidden', true);
			        	}
			        		
			        }
			}
		});
	});
	
	$(document).on("change", ".page-productDetails .sortOptions", function() {
		
		var code = $('input[name="sourceCode_Option"]').val();
		var currentUrl = location.href;
		var mystr = (currentUrl).slice(BASE_URL.length);
		var remainingstring = mystr.split('/').splice(0,
				mystr.split('/').length - 1).join('/');
		$('#spinner').show();
		var url = BASE_URL + remainingstring + "/showOptions?sourceCode="+code;
		$(this).parents("form").attr("action", url);
		var form = $(this).parents("form");
		$.ajax({
			type : "GET",
			url : url,
			data : form.serialize(),
			success : function(data) {
				$('#spinner').hide();
				$('html, body').animate({
		            scrollTop: $('.hpe-more-information').offset().top 
		        }, 500);
				$('#optionsTab').html(data);
				var productFacetArr = $('#product-facet-option').children('.facet.js-facet');
		        for (let i = 0; i < productFacetArr.length; i++) {
		        	if(i===2){
		        		break;
		        	}
		        	var attrClass = productFacetArr[i].classList[2];
		        		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
		        		$('.' + attrClass).find('section').attr('aria-hidden', true);
		        }
			}
		});
	});

	$(document).on("change", ".page-productDetails .sortServices", function() {
		var code = $('input[name="baseProduct"]').val();
		var currentUrl = location.href;
		var mystr = (currentUrl).slice(BASE_URL.length);
		var remainingstring = mystr.split('/').splice(0,
				mystr.split('/').length - 1).join('/');
		$('#spinner').show();
		var url = BASE_URL + remainingstring + "/showServices?sourceCode="+code;
		$(this).parents("form").attr("action", url);
		var form = $(this).parents("form");
		$.ajax({
			type : "GET",
			url : url,
			data : form.serialize(),
			success : function(data) {
				$('#spinner').hide();
				 $('html, body').animate({
			            scrollTop: $('.hpe-more-information').offset().top 
			        }, 500);
				$('.productServicesTabDisplay').html(data);
				 var productFacetArr = $('#product-facet-service').children('.facet.js-facet');
			        for (let i = 0; i < productFacetArr.length; i++) {
			        	
			        	var attrClass = productFacetArr[i].classList[2];
			        	
			        	if(($('.' + attrClass + ' input:checkbox:checked').length > 0) || (i<2) ){
							$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
				    		$('.' + attrClass).find('section').attr('aria-hidden', true);
			        	}
			        		
			        }
			}
		});
	});
	
	$.each($('.compatibility-plp .hpe-product-list__meta.hpe-product-list__meta--light'),function(index,value){

		if( $(value).find('.row.mb-1').length>4){

			$(value).find('.row.mb-1:gt(4)').hide();
			$(value).find('.show-more').show();
		}else{
			$(value).find('.show-more').hide();
		} 

	})

	$('.show-more').on('click', function() {
		$(this).closest('.hpe-product-list__about').find('.row.mb-1:gt(4)').toggle();
		$(this).text($(this).text() === $('#hide-showmore-facet-text').val() ? $('#hide-showless-facet-text').val() : $('#hide-showmore-facet-text').val());
	});
	
	$('#modelsTab').on('click','.show-more',function(){
		$(this).closest('.hpe-product-list__about').find('.row.mb-1:gt(4)').toggle();
		$(this).text($(this).text()=== 'Show more'? 'Show less': 'Show more');
	});
	
	
	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Specifications")').hasClass('active')){
		specificationTabOnLoad();
	}
	
	if(window.location.href.includes('add-address')){
		$('html, body').animate({
		scrollTop: $('.padding-add-address-button').offset().top
	}, 500);
	}
});

function doFunction(productcode, variantCode) {
    localStorage.setItem('flag', "compareOptions");
    $('#spinner').show();
    var mystr = (currentUrl).slice(BASE_URL.length);
    var remainingstring = mystr.split('/').splice(0, mystr.split('/').length - 1).join('/');
    var request = $.ajax({
        cache: false,
        url: BASE_URL + remainingstring + "/showOptions?q=" + variantCode + ":relevance:sourceReference:" + variantCode + "&sourceCode="+variantCode,
        type: 'GET'
    });

    request.done(function(data) {
	$('#spinner').hide();
	displayOptionTabOnSuccess(data);

    });

    request.fail(function(jqXHR) {
	$('#spinner').hide();
        console.log('fail');
    });

}

function displayOptionTabOnSuccess(data){
	$('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Option")').show();
	$('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation] a:contains("Option")').click();
        callOptions(data);
        $('html, body').animate({
            scrollTop: $('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Option")').closest('.hpe-more-information').offset().top
        }, 1000);
        var productFacetArr = $('#product-facet-option').children('.facet.js-facet');
        for (let i = 0; i < productFacetArr.length; i++) {
        	if(i===2){
        		break;
        	}
        var attrClass = productFacetArr[i].classList[2];
		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
		$('.' + attrClass).find('section').attr('aria-hidden', true);
        }
}

$('#modelsTab').on('click','.optionAvailableBtnInModel',function(){
	var variantCode = $(this).closest('.hpe-full-bleed--mobile').find('.skuNumber').text();
	var urlArray = currentUrl.split('/');
	var productcode = urlArray[urlArray.length-1];
	doFunction(productcode, variantCode);
});


$('#modelsTab').on('click','.optionAvailableBtn',function(){
	console.log('hello')
});



function displayPaginationData(data){
	var modelsData = data[0].results;

	var finalValue = "";
	var templateValue = $('.model_template');
    $.each(modelsData, function(index, value) {
        var refData = value.baseOptions[0].selected;
        templateValue.find(".hpe-product-list__name").text(value.name);
        templateValue.find(".skuNumber").text(refData.code);
	templateValue.find(".modelsDescription").text(refData.description);
	templateValue.find(".hpe-product-list__image img").attr('src',refData.imageList[0].url);
        // if (refData.hpePartnerPricingData) {
        // 	var finalOptionValue = "";
        // 	$.each(refData.hpePartnerPricingData, function(index, dropDownValue){
        // 		finalOptionValue +=  templateValue.find(".modelVariantOffers option").val(refData.code).text(dropDownValue.partnerName).attr({
    	// 			name:dropDownValue.partnerName,
    	// 			id:refData.code,
    	// 			// price:refData.priceData.value,
    	// 			// formattedPrice:refData.priceData.formattedValue
    	// 		}).prop('outerHTML');
        // 	});
        // 	$('.modelVariantOffers').html(finalOptionValue);
        // 	var offer_price = templateValue.find(".modelVariantOffers option:selected").attr('formattedprice');
        // 	$('.hpe-product-list__price .offer_price').text(offer_price);
        // 	var offer_code = templateValue.find(".modelVariantOffers option:selected").attr('id');
        // 	$('input.productcode').val(offer_code);
		// 	templateValue.find(".main_container form").attr('action',BASE_URL+'/cart/add');
			
		// 	if(refData.isOptionsAvailable){
		// 		templateValue.find(".optionAvailableBtnInModel").attr({
		// 			baseProductCode:value.baseProduct,
		// 			code:refData.code
		// 		}).show();
		// 	}else{
		// 		templateValue.find(".optionAvailableBtnInModel").hide();
		// 	}
			
        //     templateValue.find(".addToCartModelsBtn").show();
        //     templateValue.find(".getaQuoteModelsBtn").hide();
        //     templateValue.find(".selectModelContainer").show();
        // } else {
		// 	templateValue.find(".optionAvailableBtnInModel").hide();
        //     templateValue.find(".selectModelContainer").hide();
        //     templateValue.find(".addToCartModelsBtn").hide();
        //     var getQuoteButton = templateValue.find(".getaQuoteModelsBtn");
        //     getQuoteURLPopulate(getQuoteButton, refData.code);
        //     getQuoteButton.show();

        // }
		
	    	if(refData.classificationList){
			$.each(refData.classificationList,function(index,classificationValue){
				if(classificationValue.code.indexOf('_TS') !== -1){
					var classificationHTMLValue = "";
					var classificationTemplate = $('.model_template .row.mb-1');
						$.each(classificationValue.features,function(index,classificationData){
							
							classificationTemplate.find('.classfication-key strong').text(classificationData.name.split('.')[1]);
							classificationTemplate.find('.classfication-value').text(classificationData.featureValues[0].value);
							if(index>4){
								classificationHTMLValue+=classificationTemplate.hide().prop('outerHTML');
							}else{
								classificationHTMLValue+=classificationTemplate.prop('outerHTML');
							}
							
						});
						
					if(classificationValue.features.length>0 &&classificationValue.features.length<6){
						classificationHTMLValue+=$(classificationTemplate).closest('.classificationData').find('.show-more').hide().prop('outerHTML');
					}else if(classificationValue.features.length>4){
						classificationHTMLValue+=$(classificationTemplate).closest('.classificationData').find('.show-more').show().prop('outerHTML');
					}
					$(templateValue).find('.classificationData').html(classificationHTMLValue);
				}
			});
		}
		templateValue.find(".optionAvailableBtnInModel").hide();
		templateValue.find(".selectModelContainer").hide();
		templateValue.find(".addToCartModelsBtn").hide();
		var getQuoteButton = templateValue.find(".getaQuoteModelsBtn");
		getQuoteURLPopulate(getQuoteButton, refData.code);
		getQuoteButton.show();
        finalValue += $(templateValue).html();

    });
	
	$('#modelsTab').html(finalValue).show();
}



function getPaginationData(currentPage){
	$('#spinner').show();
	var urlArray = currentUrl.split('/');
	var baseProduct = urlArray[urlArray.length-1];
	var request = $.ajax({
	     cache: false,
	     url: BASE_URL + "/p/pagination/?page="+currentPage+"&productCode="+baseProduct+"&pazeSize=10&sort=name-az",
	     type: 'GET',
	 });

     request.done(function(data) {
	     $('#spinner').hide();
    	 displayPaginationData(data);
     });

     request.fail(function(jqXHR) {
         console.log('fail');
     });
     
}

function currentPage(currentPage,action){
    var total = parseInt($('.totalPageNumber').text());

    if(action=='default'){
        if(currentPage==total){
            $('#prevBtn').show().prop('disabled','disabled');
            $('#nextBtn').show().prop('disabled','disabled');
        }
        $('#modelsTab').hide();
    }
}





$('#prevBtn').on('click',function(){

    var pageNumber = parseInt($('.currentPageNumber').text());
    var total = parseInt($('.totalPageNumber').text());
    $('.currentPageNumber').text(pageNumber-1);
    if(pageNumber-1>1 && pageNumber-1<total){
        $(nextBtn).show();
        $(this).show();
        $('#modelsTab').show();

    }
    if(pageNumber-1==1 && pageNumber-1<total){
        $(nextBtn).show();
        $(this).hide();
        $('#modelsTab').hide();
        $('.compatibility-plp').show();
    }
	/*
	if(pageNumber==total){
        pageNumber = pageNumber-2;
    }
	*/
    
	if(pageNumber-2==0){
		$('.compatibility-plp').show();
		$('#modelsTab').hide();
	}else{
		getPaginationData(pageNumber-2);
	}
    
    
})

$('#nextBtn').on('click',function(){
    var pageNumber = parseInt($('.currentPageNumber').text());
    var total = parseInt($('.totalPageNumber').text());
    $('.currentPageNumber').text(pageNumber+1);
    if(pageNumber+1>1 && pageNumber<total-1){
        $(prevBtn).show();
        $(this).show();
        
    }
    if(pageNumber+1==total){
        $(prevBtn).show();
        $(this).hide();
        
    }
    $('#modelsTab').show();
    $('.compatibility-plp').hide();
    getPaginationData(pageNumber);

})


var pdpUrl = currentUrl;
var substring = "/p/";

if (pdpUrl.indexOf(substring) !== -1) {
	currentPage(1,'default');
}

//Show more show less product description starts here
$(".toggleDes").click(function() {
	if ($(this).prev().hasClass("hpeProduct-details")) {
		$(this).children('a').text($('.hide-showless-hidden-text').val());
	} else {
		$(this).children('a').text($('.hide-showmore-hidden-text').val());
	}
	$(this).prev().toggleClass("hpeProduct-details");
});
// for PLP
const sectionPlp = $('.hpe-product-list__row');
const productDescription = $('.hpeProduct-details')
const maxLengthPlp = 300;
$('.hpe-product-list__row').each(function () {
//var myStr = $(this).find('.hpe-product-list__description').text();
var myStr = $(this).find('.plp-description').text();
//console.log($.trim(myStr).length);
if ($.trim(myStr).length < maxLengthPlp) {
$(this).find('.toggleDes').hide();
}
}) 
//PDP and deals of the week
const showMoreText = $('.hpe-show-more1');
const showMoreBtn = $('.hpe-show-more__button');
const contentLength = 300;
showMoreText.each(function () {
    var myStr = $(this).text();
    console.log($.trim(myStr).length);
    if ($.trim(myStr).length < contentLength) {
        $('.hpe-show-more__button').hide();
    }
})

showMoreBtn.on('click', function () {
    showMoreText.toggleClass('hpe-show-more--active').toggleClass('hpe-productDetails_data');
    showMoreBtn.toggleClass('hpe-data-hidden');
});

//Show more show less product description ends here


function validateInputOnFly(identifier, type, x, repeatedFrom,e) {
	var me = $(x).val();
	checkValidInputField(identifier, type, me, repeatedFrom ? repeatedFrom : null,e);
}

function checkValidInputField(identifier, type, value, repeatedFrom,e) {
	var valid = true;
	$('.' + identifier + '-Empty').hide();
	$('.' + identifier + '-Length').hide();
	$('.' + identifier + '-Invalid').hide();
	$('.' + identifier + '-US-Invalid').hide();
	if (!value.length) {
		if(type=="tel"){
			$('.' + identifier + '-LengthCheck').hide();
			valid=true
		}else{
			$('.' + identifier + '-Empty').show();
			valid = false;
		}
		
	}else if(type=="tel"){
			
			
			if(e.type=='keyup'){
				
				var ele = $('.'+identifier).closest('input[type="tel"]');
				value = formatPhoneNumber(ele,value);
			}
			if(value.length>0 && value.length<10){
				$('.' + identifier + '-LengthCheck').show();
				valid=false
			}else{
				$('.' + identifier + '-LengthCheck').hide();
				$('.getQuoteDisclaimer-Empty').hide();
				valid=true;
			}
		} else if (type === 'email') {
		if (!new RegExp(/^([a-zA-Z0-9_+\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/).test(value)) {
			$('.' + identifier + '-Invalid').show();
			valid = false;
		}
	} else if (type === 'password') {
		if (!new RegExp(/^(?=.*\d)(?=.*[a-zA-Z]).*$/).test(value)) {
			$('.' + identifier + '-Invalid').show();
			valid = false;
		}
		if (value.length < 7) {
			$('.' + identifier + '-Length').show();
			valid = false;
		}
		if (repeatedFrom) {
			if (value != $('input.' + repeatedFrom).val()) {
				$('.' + identifier + '-Invalid').show();
				valid = false;
			}
		}
	} else if (type === 'zip') {
		var countrycode = $('input.'+identifier).attr('isocode');
		if (!new RegExp(regexes[countrycode]).test(value)) {
			$('.' + identifier + '-US-Invalid').show();
			valid = false;
		}
	} else if (type === 'check') {
		
		if (($('input:checkbox[id^="quoteemailcontact"]:checked').length==0) && ($('input:checkbox[id^="quotephonecontact"]:checked').length==0)) {
            $('.' + identifier + '-Invalid').show();
            valid = false;
        }
	if($('input[name="C_MobilePhone"]').val()=="" &&$('input:checkbox[id^="quotephonecontact"]:checked').length>0){
			            $('.' + identifier + '-Empty').show();
			            valid = false;
		}

	}else if(type==='amount'){
		if (!new RegExp('^[0-9]+$').test(value)) {
			$('.' + identifier + '-Invalid').show();
			valid = false;
		}
	}
	if(type === 'optionalPassword'){
		if (!value.length) {
			$('.' + identifier + '-Empty').hide();
			valid = true;
		} else if (repeatedFrom) {
			
			if (value != $('input.' + repeatedFrom).val()) {
				$('.' + identifier + '-Invalid').show();
				valid = false;
			}
			  if (!new RegExp(/^(?=.*\d)(?=.*[a-zA-Z]).*$/).test(value)) {

                                                                $('.' + identifier + '-Invalid').show();

                                                                valid = false;

                                                }

                                                if (value.length < 7) {

                                                                $('.' + identifier + '-Length').show();

                                                                valid = false;

                                                }
		}
	} 
	if ((type === 'zip' && $('#select1 , #country').val() == 'US') || type === "phone") {
		if (value.length > 10) {
			$('input.' + identifier).val(value.substring(0, 10));
		}
	}
	
	if (!valid) {
		$('.' + identifier).addClass('hpe-input--error');
	} else {
		$('.' + identifier).removeClass('hpe-input--error');
	}
	return valid;
}
$('#quotephonecontact').change(function(event) {
	checkValidInputField('getQuoteDisclaimer', 'check', 'disclaimer');
});


$('#quoteemailcontact').change(function(event) {
	checkValidInputField('getQuoteDisclaimer', 'check', 'disclaimer');
});

function forgotPasswordFormValidate() {
	var forgottenPwd = document.getElementById('forgottenPwdForm');
	var validforgottenPwdForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validforgottenPwdForm = checkValidInputField('forgotPasswordEmail', 'email', forgottenPwd.email.value);
	return validforgottenPwdForm;
};


function loginFormValidate() {

	var loginForm = document.getElementById('loginForm');
	var validLoginForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validLoginForm = checkValidInputField('loginEmail', 'email', loginForm.j_username.value) && validLoginForm;
	validLoginForm = checkValidInputField('loginPassword', 'text', loginForm.j_password.value) && validLoginForm;
	// if(validLoginForm){
	// 	loginFormSubmit();
	// }
	sessionStorage.setItem('username', loginForm.j_username.value);
	sessionStorage.setItem('password', loginForm.j_password.value);
	return validLoginForm;
};

$('body').on('focus', '.hpe-input input', function() {
	$(this).parent().addClass("hpe-input--active");
});
$('body').on('focusout', '.hpe-input input', function() {
	if ($(this).val().length === 0) {
		$(this).parent().removeClass("hpe-input--active");
	}
});

// vishal code for saved cart description overlap bug
$('body').on('focus', '.hpe-input textarea', function() {
	$(this).parent().addClass("hpe-input--active");
});

$('.hpe-carousel__indicator').first().trigger('click');
$(".hpe-input input").each(function() {
	if ($(this).val().length) {
		$(this).parent().addClass("hpe-input--active");
	}
});

// Added for consistency on create account page
$('body').on('change', '.hpe-input select', function() {
	$(this).parent().addClass("hpe-input--active");
	$(this).siblings("label").removeClass("hidden");
});

$('input[name="textSearch"]').blur(function() {
	$(this).parentsUntil('form').parent('form').addClass('testimony').submit();
});

$("#pageSize-selector").on('change', function() {
	$(this).parents("form").submit();
});

//code to check if the current url has error  as paramter then hide the default error message

// if((location.search.split('error' + '=')[1] || '').split('&')[0] == 'true'){
// 	// window.location.replace = location.protocol + '//' + location.host + location.pathname;
// 	$('.global-alerts').hide();

// }else{
// 	console.log('hello');
// }

if ((location.search.split('error' + '=')[1] || '').split('&')[0] == 'true') {
	$('.global-alerts').hide();
	$('#loginError').hide();
	var errorStr = $('#loginError p').text();
	if (errorStr.indexOf('<') > -1) {
		var init = errorStr.indexOf(',{');
		var fin = errorStr.indexOf('},');
		var str = errorStr.substring(init + 1, fin + 1);
		var a = JSON.parse(str);
		$('#loginError p').html(a.exception.faults[0].faultMessage);
		$('#loginError').show();
	} else if (errorStr == "") {
		$('.global-alerts').hide();
		$('#loginError').hide();
	} else {
		// show the string as it is
		$('#loginError p').html = errorStr;
		$('#loginError').show();
	}
}


$('.login_page-error_icon').on('click', function() {
	$(this).parent().hide();
});

function formatPhoneNumber(ele,value){
	var output;
	var input = value;
	input = input.replace(/[^0-9]/g, '');
	if((window.location.href.indexOf('/de/')== -1))
	{
	var area = input.substr(0, 3);
	var pre = input.substr(3, 3);
	var tel = input.substr(6, 4);
	if (!input.length) {
		output = '';
	} else if (input.length <= 3) {
		output = "(" + area;
	} else if (input.length > 3 && pre.length < 3) {
		output = "(" + area + ")" + "" + pre;
	} else if (input.length > 3 && pre.length == 3 && !tel.length) {
		output = "(" + area + ")" + "" + pre;
	} else if (input.length > 3 && pre.length == 3 && tel.length) {
		output = "(" + area + ")" + "" + pre + "-" + tel;
	}
	}
	else
	{
	output=input;
	}
	ele.val(output);
	return input;
}


function registerFormValidate(formID) {
	var registerForm = document.getElementById(formID);
	var validRegisterForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validRegisterForm = checkValidInputField('registerEmail', 'email', registerForm.email.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerPassword', 'password', registerForm.pwd.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerRepeatPassword', 'password', registerForm.checkPwd.value, 'registerPassword') && validRegisterForm;
	validRegisterForm = checkValidInputField('registerCountry', 'select', registerForm.select1.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerTitle', 'select', registerForm.select3.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerFirstName', 'text', registerForm.firstName.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerLastName', 'text', registerForm.lastName.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerAddress1', 'text', registerForm.address1.value) && validRegisterForm;
	validRegisterForm = checkValidInputField('registerCity', 'text', registerForm.city.value) && validRegisterForm;
	if(registerForm.select2){
		validRegisterForm = checkValidInputField('registerState', 'select', registerForm.select2.value) && validRegisterForm;
	}
	validRegisterForm = checkValidInputField('registerZipCode', 'zip', registerForm.zipCode.value) && validRegisterForm;
	if(registerForm.mobileNumber.value){
		validRegisterForm = checkValidInputField('registerPhoneNumber','tel',registerForm.mobileNumber.value,false,event) && validRegisterForm;
	}
	return validRegisterForm;
}



function shippingAddressForm(formID) {
	var shippingAddressForm = document.getElementById(formID);
	var validShippingAddressForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validShippingAddressForm = checkValidInputField('title', 'select', shippingAddressForm.title.value) && validShippingAddressForm;
	validShippingAddressForm = checkValidInputField('country', 'select', shippingAddressForm.countryIso.value) && validShippingAddressForm;
	validShippingAddressForm = checkValidInputField('firstName', 'text', shippingAddressForm.firstName.value) && validShippingAddressForm;
	validShippingAddressForm = checkValidInputField('lastName', 'text', shippingAddressForm.lastName.value) && validShippingAddressForm;
	validShippingAddressForm = checkValidInputField('address1', 'text', shippingAddressForm.line1.value) && validShippingAddressForm;
	validShippingAddressForm = checkValidInputField('city', 'text', shippingAddressForm.townCity.value) && validShippingAddressForm;
	if(shippingAddressForm.regionIso){
		validShippingAddressForm = checkValidInputField('state', 'select', shippingAddressForm.regionIso.value) && validShippingAddressForm;
	}
	validShippingAddressForm = checkValidInputField('zipCode', 'zip', shippingAddressForm.postcode.value) && validShippingAddressForm;
	if (shippingAddressForm.email) {
		validShippingAddressForm = checkValidInputField('shippingEmail', 'email', shippingAddressForm.email.value) && validShippingAddressForm;
		//validShippingAddressForm = checkValidInputField('shippingPassword', 'password', shippingAddressForm.password.value) && validShippingAddressForm;
		//validShippingAddressForm = checkValidInputField('shippingRepeatPassword', 'password', shippingAddressForm.chkPassword.value,'shippingPassword') && validShippingAddressForm;
	}
	//validShippingAddressForm = checkValidInputField('shippingPassword','password', shippingAddressForm.password.value) && validShippingAddressForm;
	//validShippingAddressForm = checkValidInputField('shippingRepeatPassword','password', shippingAddressForm.chkPassword.value,'shippingPassword') && validShippingAddressForm;
	if(shippingAddressForm.chkPassword !== undefined){
	validShippingAddressForm = checkValidInputField('shippingRepeatPassword','optionalPassword', shippingAddressForm.chkPassword.value, 'shippingPassword') && validShippingAddressForm;
	}
	if(shippingAddressForm.phone.value){
		validShippingAddressForm = checkValidInputField('shippingPhone', 'tel', shippingAddressForm.phone.value,false,event) && validShippingAddressForm;
	}
	return validShippingAddressForm;
}

function quoteFormValidate(formID) {
	var quoteForm = document.getElementById(formID);
	var validQuoteForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	if (quoteForm.C_EmailAddress) {
		validQuoteForm = checkValidInputField('getQuoteEmail', 'email', quoteForm.C_EmailAddress.value) && validQuoteForm;
	}
	// validQuoteForm = checkValidInputField('getQuotePassword','password',quoteForm.pwd.value) && validQuoteForm;
	// validQuoteForm = checkValidInputField('getQuoteRepeatPass','password',quoteForm.repeatpwd.value, 'getQuotePassword') && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteFirstName', 'text', quoteForm.C_FirstName.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteLastName', 'text', quoteForm.C_LastName.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteAddress1', 'text', quoteForm.address1.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteCity', 'text', quoteForm.city.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteZipCode', 'zip', quoteForm.zipPostal.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteTitle', 'select', quoteForm.title.value) && validQuoteForm;
	if(quoteForm.stateProv){
		validQuoteForm = checkValidInputField('getQuoteState', 'select', quoteForm.stateProv.value) && validQuoteForm;
	}
	validQuoteForm = checkValidInputField('getQuoteCountry', 'select', quoteForm.C_Country.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteDisclaimer', 'check', 'disclaimer') && validQuoteForm;

	validQuoteForm = checkValidInputField('getQuoteBusinessNeed', 'text', quoteForm.C_Business_Need.value) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteEstimated_Budget', 'amount', quoteForm.C_Estimated_Budget1.value,null,event) && validQuoteForm;
	validQuoteForm = checkValidInputField('getQuoteTimeframe_to_Buy', 'select', quoteForm.C_Timeframe_to_Buy1.value) && validQuoteForm;
	if(quoteForm.C_MobilePhone.value){
		validQuoteForm = checkValidInputField('getQuotePhone', 'tel', quoteForm.C_MobilePhone.value,false,event) && validQuoteForm;
	}
	return validQuoteForm;
}

function updateProfileFormValidate(formID) {
	var profileForm = document.getElementById(formID);
	var validProfileForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validProfileForm = checkValidInputField('shippingEmail', 'email', profileForm.email.value) && validProfileForm;
	validProfileForm = checkValidInputField('country', 'select', profileForm.countryIso.value) && validProfileForm;
	validProfileForm = checkValidInputField('title', 'select', profileForm.titleCode.value) && validProfileForm;
	validProfileForm = checkValidInputField('firstName', 'text', profileForm.firstName.value) && validProfileForm;
	validProfileForm = checkValidInputField('lastName', 'text', profileForm.lastName.value) && validProfileForm;
	validProfileForm = checkValidInputField('address1', 'text', profileForm.line1.value) && validProfileForm;
	validProfileForm = checkValidInputField('city', 'text', profileForm.townCity.value) && validProfileForm;
	if($(profileForm.regionIso).is(':visible')){
		validProfileForm = checkValidInputField('state', 'select', profileForm.regionIso.value) && validProfileForm;
	}
	validProfileForm = checkValidInputField('zipCode', 'zip', profileForm.postcode.value) && validProfileForm;
	if(profileForm.phone.value){
		validProfileForm = checkValidInputField('phoneNum','tel',profileForm.phone.value,false,event) && validProfileForm;
	}
	return validProfileForm;
}


function formValidate(formID) {

	if (formID == 'updateProfileForm') {
		return updateProfileFormValidate(formID);
	} else if (formID == 'registerUserPage') {
		return registerFormValidate(formID);
	} else if (formID == 'addressForm') {
		return shippingAddressForm(formID);
	} else if (formID == 'getQuoteForm') {
		return quoteFormValidate(formID);
	}

};

function scrollToError(){
	$('html, body').animate({
		scrollTop: $('.hpe-input__error-message:visible:first ,.hpe-notification.hpe-notification--warning:visible:first, .hpe-notification.hpe-notification--critical:visible:first, .hpe-notification.hpe-notification--ok:visible:first').offset().top - 115
	}, 1000);
}


function handleValidation(formID, formData, url, e) {
	if (formValidate(formID)) {


		var request = $.ajax({
			url: url,
			type: "POST",
			data: formData,
			dataType: 'json'
		});
		$('#spinner').show();
		request.done(function(successRes) {
			$('#spinner').hide();
			let addressData = JSON.parse(successRes).Address[0];
			var formID = $('#addressSuggestions').closest('form').attr('id');
			if (addressData.hasOwnProperty("noAddressSuggestions")) {

				localStorage.setItem('registerFormData', '');

				localStorage.setItem('deliveryAddressFormData', '');

				localStorage.setItem('getQuoteFormData', '');
				
				localStorage.setItem('updateProfileFormData', '');
				
				$('#address_1,#address_2,#address_3').closest('section').hide();

				$('#addressSuggestions section:first .failedMessage').html(addressData.noAddressSuggestions);
				$('#addressSuggestions section:first .failedMessage').show();
				$('#addressSuggestions section:first .successMessage').hide();
				$('#addressSuggestions').show();
				scrollToError();
				
			} else {

				if (addressData.perfectAddress){
					let formData = $("#"+formID).serialize();
					if (formID=='registerUserPage') {
						
						url = BASE_URL + '/register/registerUser';
						handleRegistration(formID, formData, url, e);
					}else if(formID=='getQuoteForm'){
						quoteSubmit(formData);
					}else if(formID=='updateProfileForm'){
						handleProfileUpdate(formData);
					}else if(formID=='addressForm'){
						var r_val=$('input[type=radio][name=shipping]:checked').attr('id');
            if($('#validateMyAccountAddress').length>0)
							{
							$('#addressSuggestions').closest('form').submit();
							}
			       else if((r_val == "new_address") || r_val==undefined){
							 shippingAddressFormSubmit(formData);
				            }

				            else{
				            	shippingAddressFormEditSubmit(formData);
				            }
					}

				} else {
					let enteredAddress = addressData.enteredAddress;
					let addressSuggestion1 = JSON.parse(addressData.addressDoctorSuggestion1).completeAddressSuggetion;
					let addressSuggestion2;
					if(addressData.addressDoctorSuggestion2){
						addressSuggestion2 = JSON.parse(addressData.addressDoctorSuggestion2).completeAddressSuggetion;
					}
					

					$('#address_1').val(addressSuggestion1);
					$('#address_1').closest('div').children('p').html(addressSuggestion1);
					$("#addressSuggestions input:radio[id=address_1]").attr('suggestedAddress', addressData.addressDoctorSuggestion1);
					
					$('#address_3').val(enteredAddress);
					$('#address_3').closest('div').children('p').html(enteredAddress);

					if (addressSuggestion2) {
						$('#address_2').val(addressSuggestion2);
						$('#address_2').closest('div').children('p').html(addressSuggestion2);
						$("#addressSuggestions input:radio[id=address_2]").attr('suggestedAddress', addressData.addressDoctorSuggestion2);
					} else {
						$('#address_2').closest('div').hide();
					}

					$("#addressSuggestions input:radio[name=address]:first").attr('checked', true);
					

					var formID = $('#addressSuggestions').closest('form').attr('id');
					selectedRadio(formID);
					
					$('#addressSuggestions section:first .failedMessage').hide();
					$('#addressSuggestions section:first .successMessage').show();
					$('#address_1,#address_2,#address_3').closest('section').show();
					$('#addressSuggestions').show();
					scrollToError();
				}

			}
		});

		request.fail(function(jqXHR) {
			$('#spinner').hide();
			localStorage.setItem('registerFormData', '');
			localStorage.setItem('deliveryAddressFormData', '');
			localStorage.setItem('getQuoteFormData', '');
			localStorage.setItem('updateProfileFormData', '');
			var errorText = $('#addressDoctorError').text();
			$('#address_1,#address_2,#address_3').closest('section').hide();
			var formID = $('#addressSuggestions').closest('form').attr('id');
			$('#addressSuggestions section:first .failedMessage').html(errorText);
			$('#addressSuggestions section:first .failedMessage').show();
			$('#addressSuggestions section:first .successMessage').hide();
			$('#addressSuggestions').show();
			scrollToError()
		});

	} else {
		scrollToError()
		e.preventDefault();
	}

}


$('#addressForm').on('change keyup', '#line1,#line2,#townCity,#region,#postcode', function() {
	if ($('#addressSuggestions').is(":visible")) {
		$('#addressSuggestions').hide();
		// $("#validateAddress").attr('formData','');
		localStorage.setItem('deliveryAddressFormData', '');
		//$('#validateAddress').prop("disabled",false);
	}
});


$('#registerUserPage').on('change keyup', '#zip,#select2,#city,#address1,#address2,#select1', function() {
	if ($('#addressSuggestions').is(":visible")) {
		$('#addressSuggestions').hide();
	}
});

$('#getQuoteForm').on('change keyup', '#address-line-1,#address-line-2,#city,#select2,#zip', function() {
	if ($('#addressSuggestions').is(":visible")) {
		$('#addressSuggestions').hide();
		localStorage.setItem('getQuoteFormData', '');
	}
});

$('#updateProfileForm').on('change keyup', '#line1,#line2,#townCity,#region,#country,#postcode', function() {
	if ($('#addressSuggestions').is(":visible")) {
		$('#addressSuggestions').hide();
		localStorage.setItem('updateProfileFormData', '');
	}
});

$('#orderSummeryNewUser').on('submit', function() {
	
	var orderSummeryNewUser = document.getElementById('orderSummeryNewUser');
	var validOrderSummeryNewUser = true;
		
	 validOrderSummeryNewUser = checkValidInputField('orderConfirmPass','password',orderSummeryNewUser.pwd.value) && validOrderSummeryNewUser;
	 validOrderSummeryNewUser = checkValidInputField('orderConfirmRepeatPass','password',orderSummeryNewUser.repeatpwd.value, 'orderConfirmPass') && validOrderSummeryNewUser;
	 return validOrderSummeryNewUser;
});



function selectedRadio(formID) {
	let getRadioID = $("input[name=address]:checked").attr('id') || 'address_3';
	// let getRadioID = $(this).attr('id');
	if (getRadioID != 'address_3') {
		let checkedRadioAddress = $("input[name=address]:checked").attr('suggestedaddress');
		var address = JSON.parse(checkedRadioAddress)
		var formData = $('#' + formID).serializeArray();
		for (let i = 0; i < formData.length; i++) {
			if (formData[i].name == 'address1' || formData[i].name == 'line1' || formData[i].name == 'billTo_street1' || formData[i].name == 'address-line-1') {
				formData[i].value = address.addressline1;
			} else if (formData[i].name == 'city' || formData[i].name == 'C_City' || formData[i].name == 'townCity' || formData[i].name == 'billTo_city') {
				formData[i].value = address.city;
			} else if (formData[i].name == 'stateCode' || formData[i].name == 'regionIso' || formData[i].name == 'stateProv') {
				formData[i].value = address.state;
			} else if (formData[i].name == 'zipCode' || formData[i].name == 'postcode' || formData[i].name == 'billTo_postalCode' || formData[i].name == 'zipPostal') {
				formData[i].value = address.postCode;
			} else if (formData[i].name == 'address') {
				delete formData[i];
			} else if (formData[i].name == 'address2' || formData[i].name == 'line2' || formData[i].name == 'billTo_street2') {
				formData[i].value = address.addressline2;
			}
		}

		formData = formData.filter(function(e) {
			return e
		});

		formData = $.param(formData);

		if (formID == 'addressForm') {

			// $("#validateAddress").attr('formData',formData);
			localStorage.setItem('deliveryAddressFormData', formData);

		} else if (formID == 'updateProfileForm') {

			localStorage.setItem('updateProfileFormData', formData);
			// $("#validateDeliveryAddress").attr('formData',formData);
		} else if (formID == 'getQuoteForm') {

			localStorage.setItem('getQuoteFormData', formData);
			// $("#validateDeliveryAddress").attr('formData',formData);
		} else {
			// $("#registerUserBtn").attr('formData',formData);
			localStorage.setItem('registerFormData', formData);
		}

	} else {
		if (formID == 'addressForm') {
			// $("#validateAddress").attr('formData','');
			localStorage.setItem('deliveryAddressFormData','');
		} else if (formID == 'updateProfileForm') {
			// $("#validateDeliveryAddress").attr('formData','');
			localStorage.setItem('updateProfileFormData','');
		} else if (formID == 'getQuoteForm') {
			// $("#validateDeliveryAddress").attr('formData','');
			localStorage.setItem('getQuoteFormData','');
		} else {
			// $("#registerUserBtn").attr('formData',$('#'+formID).serialize());
			localStorage.setItem('registerFormData','');
		}

	}

}

$('#addressSuggestions').on('change', 'input[name=address]', function() {
	var formID = $(this).closest('form').attr('id')
	selectedRadio(formID);
});


function serializedDatatoObject(storedformData){
	var data = storedformData.split("&");
	var obj={};
	for(var key in data)
	{
		obj[data[key].split("=")[0]] = data[key].split("=")[1];
	}

	delete obj.CSRFToken;
	delete obj.text;
	return obj;
}



function formDataSelection(formID,localStorageVariable){

		selectedRadio(formID);

		
		var storedformData = localStorage.getItem(localStorageVariable);
		var storedformDataObj = serializedDatatoObject(storedformData);

		var currentFormData = $('#' + formID).serialize();
		var currentFormDataObj =  serializedDatatoObject(currentFormData);
		if(storedformData.length==0){
			return currentFormData;
		}else if($.param(storedformDataObj) != $.param(currentFormDataObj)){
			return storedformData;
		}

}



function handleRegistration(formID, formData, url, e) {
	if (registerFormValidate(formID)) {
		var request = $.ajax({
			url: url,
			type: "POST",
			data: formData,
			dataType: 'json'
		});
		$('#spinner').show();
		request.done(function(successRes) {
			localStorage.setItem('registerFormData', '');
			eloquaRegister();
			sessionStorage.setItem('username', $('input[type="email"]').val());
			sessionStorage.setItem('password', $('input[type="password"]').val());
			$('#spinner').hide();

			var chekoutURL = document.referrer;
			if (chekoutURL.indexOf("checkout") !== -1) {

				location.href = BASE_URL+ "/checkout/multi/delivery-address/add";

			} else {
				location.href = BASE_URL;
			}
		});

		request.fail(function(jqXHR, textStatus, errorThrown) {
			$('#spinner').hide();

			if (JSON.parse(jqXHR.responseJSON).hasOwnProperty('gtsError')) {
				$('#regError p').html(JSON.parse(jqXHR.responseJSON).gtsError);
				$('#regError').show();
				$('html, body').animate({
					scrollTop: $('.hpe-page-header').offset().top - 20
				}, 'slow');
				submitRegisterFailToTagManager();
			} else {
				var err = JSON.parse(jqXHR.responseJSON).exception.faults;
				console.log(err);
				var flag = 0;
				var errMsg;
				for (let i = 0; i < err.length; i++) {
					if (err[i].ruleNumber == 250) {
						errMsg = err[i].faultMessage;
						flag = 1;
						console.log(err[i].faultMessage);
					}
				}
				if (flag) {
					$('#regError p').html(errMsg);
					$('#regError').show();
					$('html, body').animate({
						scrollTop: $('.hpe-page-header').offset().top - 20
					}, 'slow');

				} else {
					$('#regError p').html(err[0].faultMessage);
					$('#regError').show();
					$('html, body').animate({
						scrollTop: $('.hpe-page-header').offset().top - 20
					}, 'slow');

				}
				submitRegisterFailToTagManager();
			}



		});
	}
}




//GetQuote eloqua integration start

function eloquaGetQuote() {

	if (quoteFormValidate('getQuoteForm')) {
		
		var fData;
		var quoteURL = currentUrl;
		if (quoteURL.indexOf('/quoterequest') !== -1) {
			fData = $("#getQuoteForm input,#getQuoteForm select").not("input[type='password']").serialize();
		}else{
			fData = $("#getQuoteForm input,#getQuoteForm select").not("input[type='password'],input[name='productCode']").serialize();
		}
		fData = fData + '&mcid_tid=' + timeStamp;
		
		if(!$('#quotephonecontact').val()){
			fData= fData + '&C_Phone_Opt_in1='
		}
		
		if(!$('#quoteemailcontact').val()){
			fData= fData + '&C_Email_Opt_In1='
		}
		
		if(!$('#decision').is(":checked")){
			fData= fData + '&purchaseRole1='+$('#decision').val()
		}
		
		if(!$('#contactQuoteCheckbox').is(":checked")){
			fData= fData + '&HpeContact='+$('#contactQuoteCheckbox').val()
		}
		
		var request = $.ajax({
			cache: false,
			url: ELOQUA_URL,
			type: 'POST',
			async:false,
			data: fData + '&source_page_URL=' + document.referrer
		});

		request.done(function(data, statusText, xhr) {
			var status = xhr.status;

			var head = xhr.getAllResponseHeaders();
			console.log(status);
			console.log(head);
			console.log(data);
		});

		request.fail(function(jqXHR, textStatus) {
			console.log('fail');
		});
	}

}


function quoteSubmit(formData){
	var request = $.ajax({
		url: BASE_URL + '/handleGetQuote',
		type: "POST",
		data: formData,
		dataType: 'json'
	});

	$('#spinner').show();
	request.done(function(successRes) {
		localStorage.setItem('getQuoteFormData', '');
		eloquaGetQuote();
		$('#spinner').hide();
		location.href = BASE_URL + "/quotesummarypage?" + 'quoteCode=' + JSON.parse(successRes).quoteCode;
		completequote(location.search.split('=')[1]);		
	});

	request.fail(function(jqXHR, textStatus, errorThrown) {
		$('#spinner').hide();
		$('#getQuoteError p').text(JSON.parse(jqXHR.responseJSON).error);
		$('#getQuoteError').show();
		scrollToError();
	});
}



function handleProfileUpdate(formData){
	var request = $.ajax({
		url: BASE_URL + '/my-account/update-profile',
		type: "POST",
		data: formData,
		dataType: 'json'
	});

	$('#spinner').show();
	request.done(function(successRes) {
		localStorage.setItem('updateProfileFormData', '');
		$('#spinner').hide();
		$("#successMessage").text(JSON.parse(successRes).error);
		$('.successNotification').show();
		scrollToError();
		setTimeout(function() {
			location.reload();
		}, 3000);
		
	});

	request.fail(function(jqXHR, textStatus, errorThrown) {
		$('#spinner').hide();
		$('#shippingAddressErrorMsg').text(JSON.parse(jqXHR.responseJSON).error)
		$('.shippingAddress').show();
		scrollToError();
	});
}



$("#updateProfileBtn").on('click', function(e) {
	var url;
	var formID = $('#addressSuggestions').closest('form').attr('id');
	if ($('#addressSuggestions').is(":visible")) {
		url = 'my-account/contactAddressDoctorVerification';
		$('#spinner').show();
		var formData = formDataSelection(formID,'updateProfileFormData');
		if (updateProfileFormValidate(formID)) {
			handleProfileUpdate(formData);
		} else {
			$('#spinner').hide();
			scrollToError();
			e.preventDefault();
		}
	} else {
		var formData = $("#updateProfileForm").serialize();
		url = BASE_URL+'/my-account/contactAddressDoctorVerification';
		handleValidation(formID, formData, url, e);
	}
});



//GetQuote eloqua integration end

$("#getQuote").on('click', function(e) {
	var url;

	var formID = $('#addressSuggestions').closest('form').attr('id');
	if ($('#addressSuggestions').is(":visible")) {
		$('#spinner').show();
		var formData = formDataSelection(formID,'getQuoteFormData');
		if (quoteFormValidate(formID)) {

			quoteSubmit(formData);

		} else {
			$('#spinner').hide();
			scrollToError();
			e.preventDefault();
		}
	} else {
		var formData = $("#getQuoteForm").serialize();
		url = BASE_URL + '/getQuoteAddressSuggestion';
		handleValidation(formID, formData, url, e);
	}
});

function shippingAddressFormSubmit(formData){
	var request = $.ajax({
		url: BASE_URL + '/checkout/multi/delivery-address/add',
		type: "POST",
		data: formData,
		dataType: 'json'
	});

	$('#spinner').show();
	request.done(function(successRes) {
		localStorage.setItem('deliveryAddressFormData', '');
		$('#spinner').hide();
		
		var substring = "SuccessMsg";

		if (successRes.indexOf(substring) !== -1) {
			
			$("#successMessage").text(JSON.parse(successRes).SuccessMsg);
			$('.successNotification').show();
			$('.shippingAddress').hide();
			scrollToError();
			setTimeout(function() {
				location.href= BASE_URL+'/checkout/multi/delivery-method/choose';
			}, 3000);
		}else{
			location.href= BASE_URL+successRes.split(":")[1];
		}
		
	});

	request.fail(function(jqXHR, textStatus, errorThrown) {
		$('#spinner').hide();
		$('#shippingAddressErrorMsg').text(JSON.parse(jqXHR.responseJSON).error)
		$('.shippingAddress').show();
		$('.successNotification').hide();
		scrollToError();
	});
}

//update the address on edit address 
function shippingAddressFormEditSubmit(formData){

    var request = $.ajax({

        url: BASE_URL + '/checkout/multi/delivery-address/edit',

        type: "POST",

        data: formData,

        dataType: 'json'

    });

 

    $('#spinner').show();

    request.done(function(successRes) {

        localStorage.setItem('deliveryAddressFormData', '');

        $('#spinner').hide();

        

        var substring = "SuccessMsg";

 

        if (successRes.indexOf(substring) !== -1) {

            

            $("#successMessage").text(JSON.parse(successRes).SuccessMsg);

            $('.successNotification').show();

            scrollToError();

            setTimeout(function() {

                location.href= BASE_URL+'/checkout/multi/delivery-method/choose';

            }, 3000);

        }else{

            location.href= BASE_URL+successRes.split(":")[1];

        }

        

    });

 

    request.fail(function(jqXHR, textStatus, errorThrown) {

        $('#spinner').hide();

        $('#shippingAddressErrorMsg').text(JSON.parse(jqXHR.responseJSON).error)

        $('.shippingAddress').show();

        scrollToError();

    });

}

//address doctor in cart


$("#validateAddress").on('click', function(e) {
	var url;
	var formID = $('#addressSuggestions').closest('form').attr('id');
	var r_val=$('input[type=radio][name=shipping]:checked').attr('id');
	if ($('#addressSuggestions').is(":visible")) {
		$('#spinner').show();
		var formData = formDataSelection(formID,'deliveryAddressFormData');
		if (shippingAddressForm(formID)) {
			  if((r_val == "new_address")|| (r_val==undefined)){
	            
	            	shippingAddressFormSubmit(formData);
	            }

	            else{
	            	shippingAddressFormEditSubmit(formData);
	            }
		} else {
			$('#spinner').hide();
			scrollToError();
			e.preventDefault();
		}


	} else {
		var formData = $("#addressForm").serialize();
		url = BASE_URL+ '/checkout/multi/delivery-address/checkoutShippingAddressVerification';
		handleValidation(formID, formData, url, e);
	}
});

$("#registerUserBtn").on('click', function(e) {
	var url = BASE_URL + '/register';
	var formID = $('#addressSuggestions').closest('form').attr('id');
	if ($('#addressSuggestions').is(":visible")) {
		url = url + '/registerUser';
		$('#spinner').show();
		var formData = formDataSelection(formID,'registerFormData');
		if (registerFormValidate(formID)) {
			handleRegistration(formID, formData, url, e);
		} else {
			$('#spinner').hide();
			scrollToError();
			e.preventDefault();
		}
		
	} else {
		var formData = $("#registerUserPage").serialize();
		url = url+'/addressVerification';
		handleValidation(formID, formData, url, e);
	}
});

$('#useDeliveryAddress').on('change', function() {
	if ($('#useDeliveryAddress').prop('checked')) {
		$('.submit_silentOrderPostForm').show();
		$('#validateBillingAddress').hide();
	} else {
		//$('.submit_silentOrderPostForm').hide();
		$('#validateBillingAddress').show();
	}
})


$('#j_username').on("keyup", function() {
	validateInputOnFly('loginEmail', 'email', this);
});

function forgotPwdEmailValidation() {
	$('#forgottenPwdEmail').on("keyup", function() {
		validateInputOnFly('forgotPasswordEmail', 'email', this);
	});
}

$('#j_password').on("keyup", function() {
	validateInputOnFly('loginPassword', 'text', this);
});
//disallowing spaces in password field
$('#j_password,#password,#repeat-password').on('keypress', function(e) {
	if (e.which == 32)
		return false;
});






//Product facets and filtering start

$('#product-facet').children('.facet.js-facet').slice(0, 2).children('section').attr('aria-hidden', true);


var cartURL = currentUrl;
var substring = "/cart";

if (cartURL.indexOf(substring) !== -1) {
	var ipArr = $('input[name="quantity"]');
	ipArr.each(function(index, value) {
		if (parseInt($(value).val()) > 1) {
			$(value).closest('div').children('.cart-btn-minus').attr('disabled', false);
		}
	})
}



$(document).on('click', '.hpe-filter__button--more' , function() {

	var attrId = $(this).closest('div').attr('id');
	$('#' + attrId + ' ul').css('max-height', 'inherit');

	if ($(this).text() === $('span.show-less-text').text()) {
		$('#' + attrId + ' ul').css('max-height', '8em');
		$(this).text($('span.show-more-text').text());
	} else {
		$('#' + attrId + ' ul').css('max-height', 'inherit');
		$(this).text($('span.show-less-text').text());
	}
});




var productFacetArr = $('#product-facet').children('.facet.js-facet');

for (let i = 0; i < productFacetArr.length; i++) {

	var attr = $(productFacetArr[i]).find('section').attr('aria-hidden');

	var attrID = $(productFacetArr[i]).attr('id');

	var facetTextBoxInputArr = $(productFacetArr[i]).find('li input[type=checkbox]');

	for (let j = 0; j < facetTextBoxInputArr.length; j++) {

		if (j >= 4 && $(facetTextBoxInputArr[j]).is(':checked')) {
			$('#' + attrID + ' ul').css('max-height', 'inherit');
			$('#' + attrID).find('.hpe-filter__button--more').text('Show Less');
			attr = 'true';
		} else if ($(facetTextBoxInputArr[j]).is(':checked')) {
			attr = 'true';
		}

	}
	if ($(productFacetArr[i]).find('li').length <= 4) {
		$('#' + attrID + ' .hpe-filter__button').hide();
	}

	if (attr == 'false') {
		$('#' + attrID + ' .hpe-disclosure__button').removeClass('hpe-disclosure__button--active');
		$('#' + attrID).find('section').attr('aria-hidden', false);
	} else {
		$('#' + attrID + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
		$('#' + attrID).find('section').attr('aria-hidden', true);
	}
}

//on click of toggle facet button show/hide facet section
$('.hpe-more-information .content').on('click','.hpe-toggle-facet-section', function() {

	if($(this).parent().parent().prop('id')==='product-facet-option' ||$(this).parent().parent().prop('id')==='product-facet-service'){
	var attr = $(this).parent().find('section').attr('aria-hidden');
	var attrID = $(this).parent().attr('class').split(' ').length>2?$(this).parent().attr('class').split(' ')[2]:'';
		if (attr == 'false') {
			$(this).addClass('hpe-disclosure__button--active');
			$('.' + attrID).find('section').attr('aria-hidden', true);
		} else {
			$(this).removeClass('hpe-disclosure__button--active');
			$('.' + attrID).find('section').attr('aria-hidden', false);		
		}
		var $this = $(this);
		alignFacets($this)
	}

});

function alignFacets(getElem){
	var i = 1;
	var sum = 0;
	var getlength = getElem.parent().find('li').length;
	getElem.parent().find('li').each(function(){
		sum += $(this).height()+8;				
		if(i == 4){		
			return false;
		}
		i++;		
	});
	getElem.parent().find('ul').css('max-height',sum+'px');
}


//Product facets and filtering end




$('body').on('click', '.contactSubmitBtn', function() {
	if (contactUsFormValidate()) {
		
		var data = 'mcid_tid=' + timeStamp + '&mcid_url=' + currentUrl + '&' + $('#contactUs').serialize();
		var request = $.ajax({
			cache: false,
			url: ELOQUA_URL,
			type: 'POST',
			data: data
		});

		request.done(function(data, statusText, xhr) {
			$('#contactUs').hide();
			$('#contactUsFormSubmitted').show();

		});

		request.fail(function(jqXHR, textStatus) {
			console.log('fail');
		});
	}
	// request.complete(function(){

	// })
});

function contactUsFormValidate() {
	var contactUsForm = document.getElementById('contactUs');
	var validContactUsForm = true;
	$('.hpe-input__error-message').hide();
	$('.hpe-input').removeClass('hpe-input--error');
	validContactUsForm = checkValidInputField('contactUsCountry', 'select', contactUsForm.C_Country.value) && validContactUsForm;
	validContactUsForm = checkValidInputField('contactUsFirstName', 'text', contactUsForm.C_FirstName.value) && validContactUsForm;
	validContactUsForm = checkValidInputField('contactUsLastName', 'text', contactUsForm.C_LastName.value) && validContactUsForm;
	validContactUsForm = checkValidInputField('contactUsEmail', 'email', contactUsForm.C_EmailAddress.value) && validContactUsForm;
	validContactUsForm = checkValidInputField('contactUsSubject', 'select', contactUsForm.ordersupport.value) && validContactUsForm;
	validContactUsForm = checkValidInputField('contactUsHelp', 'text', contactUsForm.help_text.value) && validContactUsForm;
	return validContactUsForm;
}




//Add to cart page integration with Eloqua start.

$('#addToCartButton').on('click', function() {

	
	var data = 'mcid_tid=' + timeStamp + '&mcid_url=' + currentUrl + '&' + $('#addToCartForm').serialize();
	var request = $.ajax({
		cache: false,
		url: ELOQUA_URL,
		type: 'POST',
		data: data,
		async: false
	});

	request.done(function(data, statusText, xhr) {
		var status = xhr.status;
		var head = xhr.getAllResponseHeaders();
		console.log(status);
		//console.log(head);
		console.log(data);
		$('#addToCartForm').submit();
	});

	request.fail(function(jqXHR, textStatus) {
		console.log('fail');
	});
})
//Add to cart page integration with Eloqua end.


// Account registration page integration with Eloqua start.




function eloquaRegister() {


	var data = $("#registerUserPage input:not('.eloquaExclude')").serialize() + '&C_EmailAddress=' + $('input[type="email"]').val() + '&mcid_tid=' + timeStamp + '&mcid_url=' + currentUrl;

	var request = $.ajax({
		cache: false,
		url: ELOQUA_URL,
		type: 'POST',
		data: data,
		async: false

	});
	request.done(function(data, statusText, xhr) {
		var status = xhr.status;
		var head = xhr.getAllResponseHeaders();
		console.log(status);
		console.log(head);
		console.log(data);
	});

	request.fail(function(jqXHR, textStatus) {
		console.log('fail');
	});
}


// Account registration page integration with Eloqua end.


//PDP Zoom changes.

function imageZoom(imgID, resultID) {
	var img, lens, result, cx, cy;
	img = document.getElementById(imgID);
	result = document.getElementById(resultID);
	document.getElementById(resultID).style.display = "block";
	var lens = document.getElementById('lenseDiv1');
	if (!lens) {
		lens = document.createElement("DIV");
		lens.setAttribute("id", "lenseDiv1");
		lens.setAttribute("class", "img-zoom-lens");
		img.parentElement.insertBefore(lens, img);
	}
	lens.style.display = "block";

	cx = result.offsetWidth / lens.offsetWidth;
	cy = result.offsetHeight / lens.offsetHeight;

	result.style.backgroundImage = "url('" + img.dataset.zoomimage + "')";
	result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";

	lens.addEventListener("mousemove", moveLens);
	img.addEventListener("mousemove", moveLens);

	lens.addEventListener("touchmove", moveLens);
	img.addEventListener("touchmove", moveLens);

	function moveLens(e) {
		var pos, x, y;

		e.preventDefault();

		pos = getCursorPos(e);

		x = pos.x - (lens.offsetWidth / 2);
		y = pos.y - (lens.offsetHeight / 2);

		if (x > img.width - lens.offsetWidth) {
			x = img.width - lens.offsetWidth;
		}
		if (x < 0) {
			x = 0;
		}
		if (y > img.height - lens.offsetHeight) {
			y = img.height - lens.offsetHeight;
		}
		if (y < 0) {
			y = 0;
		}

		lens.style.left = x + "px";
		lens.style.top = y + "px";

		result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
	}

	function getCursorPos(e) {
		var a, x = 0,
			y = 0;
		e = e || window.event;

		a = img.getBoundingClientRect();

		x = e.pageX - a.left;
		y = e.pageY - a.top;

		x = x - window.pageXOffset;
		y = y - window.pageYOffset;
		return {
			x: x,
			y: y
		};
	}
}

function normalImg() {
	document.getElementById("myresult").style.display = "none";
	document.getElementById("lenseDiv1").style.display = "none";
}

// PDP Zoom changes.

// order confirm page eloqua changes start
$('#placeOrder').on('click', function() {

	
	var data = 'mcid_tid=' + timeStamp + '&mcid_url=' + currentUrl + '&' + $('#placeOrderForm').serialize();
	var request = $.ajax({
		cache: false,
		url: ELOQUA_URL,
		type: 'POST',
		data: data
	});

	request.done(function(data, statusText, xhr) {
		var status = xhr.status;
		var head = xhr.getAllResponseHeaders();
		console.log(status);
		console.log(head);
		console.log(data);
	});

	request.fail(function(jqXHR, textStatus) {
		console.log('fail');
	});
})

// order confirm page eloqua changes end



/**Bookmark Changes**/


$('.hpe-bookmark').on('change', 'input[type=checkbox]', function() {


	var id = $(this).closest('form').attr('id');
	var bookmarkFlag = $(this).val();
	var selected;
	if (bookmarkFlag == "false") {
		selected = '/add';
	} else {
		selected = '/remove';
	}




	var request = $.ajax({
		cache: false,

		url: BASE_URL + '/bookmark' + selected,

		type: 'POST',

		data: $('#' + id).serialize()

	});


	request.done(function(data, statusText, xhr) {

		var status = xhr.status;

		var head = xhr.getAllResponseHeaders();

		console.log(status);

		console.log(head);

		console.log(data);
		
		if (bookmarkFlag == "false") {
			$(this).prop('checked', false);
			$('#' + id + ' input[type=checkbox]').val(true);
		} else {
			$(this).prop('checked', true);
			$('#' + id + ' input[type=checkbox]').val(false);
			var myAccURL = 'my-account';
			if (location.href.indexOf(myAccURL) !== -1) {
				location.reload();
			}
		}
	});



	request.fail(function(jqXHR, textStatus) {

		if (bookmarkFlag == "true") {
			$(this).prop('checked', true);
			$('#' + id + ' input[type=checkbox]').val(true);
		} else {
			$(this).prop('checked', false);
			$('#' + id + ' input[type=checkbox]').val(false);
		}
	});

})
/**Mirakl Starts here
 *@Auther ar20020675
 *
 */
var variantOffersUrl = currentUrl;
substring = "/p/";
var stringData = $('#variantData').text();
if((stringData != undefined || stringData != '') && stringData.length != 0) { 
	if (variantOffersUrl.indexOf(substring) !== -1) {
		function variantOffers() {
			var miraklData = JSON.parse(stringData);
			$.each(miraklData, function(index, element) {
				$.each(element, function(vpCode, val) {

					/*********Mirakl for Varient Carousel starts here************************/
					$('.variant-items article').each(function(i, elem) {
						let currentSelectElement;
						let formattedElement;
						let totalPriceFormattedValue;
						if($(elem).find('input.varient-code-head').val() == vpCode){
							if(val == '' ){
								$(elem).find('.Formatedv').parent().css('visibility','hidden');
								$(elem).find('.shopSelectItems span').css('visibility','hidden');
								$(elem).find('.shopSelectItems select').css('visibility','hidden');
							}
						}
						$.each(val, function(index, ele) {
							let productCodeJson = val[index].productCode;
							let productCodeHtml = $(elem).find('input.varient-code-head').val();
							if (productCodeJson === productCodeHtml) {
								if (val[index].shopName) {
									$(elem).each(function(counter, eleme) {
										let selectElement = $(eleme).find('.offer-select');
										selectElement.append($("<option id='" + val[index].code + "' name='" + val[index].shopName + "'></option>")
											.attr("value", val[index].productCode)
											.text(val[index].shopName));
										currentSelectElement = selectElement;
										formattedElement = $(eleme).find('.Formatedv');
										if (index === 0) {
											totalPriceFormattedValue = val[index].price.formattedValue;
										}
									})
								}
							}
						})

						// Set first time selected for combobox
						$(currentSelectElement).prop('selectedIndex', 0)
						$(formattedElement).html("<code>" + totalPriceFormattedValue + "</code>");
						
					})
					
				
					
					
//**********Mirakl for compatibility Model Starts here*****************	
					$('.compatibility-plp article').each(function(i, elem) {
						let currentSelectElement;
						let formattedElement;
						let totalPriceFormattedValue;

						$.each(val, function(index, ele) {
							let productCodeJson = val[index].productCode;
							let productCodeHtml = $(elem).find('input.varient-code-head').val();
							if (productCodeJson === productCodeHtml) {
								if (val[index].shopName) {
									$(elem).each(function(counter, eleme) {
										let selectElement = $(eleme).find('.offer-select');
										selectElement.append($("<option id='" + val[index].code + "' name='" + val[index].shopName + "'></option>")
											.attr("value", val[index].productCode)
											.text(val[index].shopName));
										currentSelectElement = selectElement;
										formattedElement = $(eleme).find('.Formatedv');
										if (index === 0) {
											totalPriceFormattedValue = val[index].price.formattedValue;
										}
									})
								}
							}
						})

						// Set first time selected for combobox
						$(currentSelectElement).prop('selectedIndex', 0)
						$(formattedElement).html("<code>" + totalPriceFormattedValue + "</code>");
						if(totalPriceFormattedValue==undefined || totalPriceFormattedValue.length<1){
						$(formattedElement).parent().hide();
						}
					})
					
//**********Mirakl for compatibility Model Ends here*****************						
					

				});
			});


			// *****Show/hide addcart and get quote*****************************************************
			let addCartButton;
			let quoteButton;
			let selectElement;
			let customizeItem;
			let shopDdl;
			let baseModelPrice;
			let stockOut;

			$.each(miraklData, function(index, element) {
				$.each(element, function(vpCode, val) {
					$('.variant-items article').each(function(i, elem) {
						selectElement = $(elem).find('.offer-select');
						addCartButton = $(elem).find('.add-cart-btn');
						quoteButton = $(elem).find('.quote-btn1');
						customizeItem = $(elem).find('.customize-lik');
						shopDdl = $(elem).find('.shopSelectItems');
						baseModelPrice = $(elem).find('.base-model-price');
						if (selectElement[0] != undefined && selectElement[0].length > 0) {
							$(addCartButton).show();
							$(quoteButton).hide();
							$(customizeItem).show();
							$(shopDdl).show();
							$(baseModelPrice).show();
						} else {
							//addCartButton.hide();
							//quoteButton.show();
							//$(customizeItem).hide();
							//$(shopDdl).hide();
							//$(baseModelPrice).hide();							
							//$(this).parent().hide();
						}
					})
					
					
// Compatibility show hide starts here
					$('.compatibility-plp article').each(function(i, elem) {
						selectElement = $(elem).find('.offer-select');
						addCartButton = $(elem).find('.add-cart-btn');
						quoteButton = $(elem).find('.quote-btn1');
						customizeItem = $(elem).find('.customize-lik');
						shopDdl = $(elem).find('.shopSelectItems');
						baseModelPrice = $(elem).find('.base-model-price');						
						stockOut = $(elem).find('.stock-outOf-stock');
						if (selectElement[0] !=undefined && selectElement[0].length > 0) {
							$(addCartButton).show();
							$(quoteButton).hide();
							$(customizeItem).hide();
							$(shopDdl).show();
							$(baseModelPrice).show();
							$(stockOut).hide();
						} else {
							$(addCartButton).hide();
							$(quoteButton).show();
							$(customizeItem).hide();
							$(shopDdl).hide();
							$(baseModelPrice).hide();
							$(stockOut).show();
						}
					})
					
//Compatibility show/hide ends here
				});
			});
			//******************************************************************************

			$(function() {
				$('.offer-select').change(function() {
					var tprice = '';
					var prc = '';
					var actualPrice = 0.00;
					var offercode = '';

					var $currentSelectedOption = $('.offer-select').find('option:selected');
					var currentProductCode = $(this).val();
					var currentShopName = $(this).children(":selected").text();
					var currentOfferId = $(this).children(":selected").attr('id');
					//Setting offer code as id of options
					var offerid = $(this).children(":selected").attr("id");
					$.each(miraklData, function(index, element) {
						$.each(element, function(ei, val) {
							$.each(val, function(ei1, val1) {
								var firstValue = val1;
								if (firstValue.productCode === currentProductCode &&
									firstValue.shopName === currentShopName && firstValue.code === currentOfferId) {
									if (firstValue.totalPrice) {
										actualPrice = firstValue.price.value;
										//tprice = firstValue.totalPrice.formattedValue;
										prc = firstValue.price.formattedValue;
									}

									/*if (firstValue.price) {
										prc = firstValue.price.formattedValue;
									}*/

									if (firstValue.code) {
										offerCode = firstValue.code;
									}
									$('.variant-items article').each(function(i, elem) {
										var productCodeHtml = $(elem).find('input.varient-code-head').val();
										if (productCodeHtml === currentProductCode) {
											var formattedElement = $(elem).find('.Formatedv');
											$(formattedElement).html("<code price='" + actualPrice + "'>" + prc + "</code>");
											var offerCodeElement = $(elem).find('[name="productCodePost"]');
											offerCodeElement.val(offerCode);
										}

									})
									
//** Compatibility price change starts here
			$('.compatibility-plp article').each(function(i, elem) {
										var productCodeHtml = $(elem).find('input.varient-code-head').val();
										if (productCodeHtml === currentProductCode) {
											var formattedElement = $(elem).find('.Formatedv');
											$(formattedElement).html('<strong class="hpe-product-list__price">'+ prc+'</strong>');
											var offerCodeElement = $(elem).find('[name="productCodePost"]');
											offerCodeElement.val(offerCode);
										}

									})	
//** Compatibility price change ends here
								}

							})
						})
					});
				}).change();

			});
		}

		/*********Mirakl for single SKU Varient Items Dropdown Data binding starts here*********************/
		function singleSKUVarientOffers() {
			var singleSkuMirakl = JSON.parse(stringData);
			// ************** Single item filled ************
			$.each(singleSkuMirakl, function(index, element) {
				$.each(element, function(ei, val) {
					$.each(val, function(ei1, val1) {
						let selectElement = $('.offer-select1');
						if (selectElement) {
							selectElement.append($("<option id='" + val1.code + "' name='" + val1.shopName + "'></option>")
								.attr("value", val1.productCode)
								.text(val1.shopName));
							let currentSelectElement = selectElement;
							let formattedElement = $('.Formatedv1');
							let totalPriceFormattedValue;
							if (index === 0) {
								totalPriceFormattedValue = val1.price.formattedValue;
							}
							// Set first time selected for combobox
							$(currentSelectElement).prop('selectedIndex', 0)
							$(formattedElement).html("<code>" + totalPriceFormattedValue + "</code>");
							if(totalPriceFormattedValue==undefined || totalPriceFormattedValue.length<1){
								$(formattedElement).parent().hide();
							}
						}
					})
				});
			});

			//*****Show/hide addcart and get quote*****************************************************
			let addCartButton;
			let quoteButton;
			let selectElement;
			let customizeItem;
			let shopDdl;
			let baseModelPrice;
			let customizedBy;

			$.each(singleSkuMirakl, function(index, element) {
				$.each(element, function(vpCode, val) {
					selectElement = $('.offer-select1');
					addCartButton = $('.add-cart-btn1');
					quoteButton = $('.quote-btn2');
					customizeItem = $('.customize-lik');
					shopDdl = $('.shop_ddl_SinglSku');
					baseModelPrice = $('.hpePrice_baseModel_singleSku')
					customizedBy = $('.customizeItem_SingleSku');
					if (selectElement[0] != undefined && selectElement[0].length > 0) {
						$(customizedBy).show()
						$(addCartButton).show();
						$(quoteButton).hide();
						/*$(customizeItem).show();*/
						$(shopDdl).show();
						$(baseModelPrice).show();
					} else {
						addCartButton.hide();
						quoteButton.show();
						$(customizedBy).hide();
						$(shopDdl).hide();
						$(baseModelPrice).hide();
						$(customizedBy).hide()
					}
				});
			});
			//******************************************************************************
			$(function() {
				$('.offer-select1').change(function() {
					let tprice = '';
					let prc = '';
					let actualPrice = 0.00;
					let offercode = '';
					let $currentSelectedOption = $('.offer-select1').find('option:selected');
					let currentProductCode = $(this).val();
					let currentShopName = $(this).children(":selected").text();
					let currentOfferId = $(this).children(":selected").attr('id');
					//Setting offer code as id of options
					let offerid = $(this).children(":selected").attr("id");
					$.each(singleSkuMirakl, function(index, element) {
						$.each(element, function(ei, val) {
							$.each(val, function(ei1, val1) {
								var firstValue = val1;
								if (firstValue.productCode === currentProductCode &&
									firstValue.shopName === currentShopName && firstValue.code === currentOfferId) {
									if (firstValue.totalPrice) {
										actualPrice = firstValue.totalPrice.value;
										tprice = firstValue.totalPrice.formattedValue;
									}

									if (firstValue.price) {
										prc = firstValue.price.formattedValue;
									}

									if (firstValue.code) {
										offerCode = firstValue.code;
									}
									var formattedElement = $('.formatedPriceValue');
									$(formattedElement).html("<code price='" + actualPrice + "'>" + tprice + "</code>");
									var offerCodeElement = $('[name="productCodePost"]');
									offerCodeElement.val(offerCode);
								}
							});
						});
					});
				}).change();
			});
			/*********Mirakl for single SKU Varient Items Dropdown Data binding ends here*********************/

		}

		variantOffers();
		singleSKUVarientOffers();
	}
}else{
	$('.variant-items article').each(function(i, elem) {					
		$(elem).find('.Formatedv').parent().css('visibility','hidden');
		$(elem).find('.shopSelectItems span').css('visibility','hidden');
		$(elem).find('.shopSelectItems select').css('visibility','hidden');		
	});
}
/**Mirakl Ends here**/


// checkout page change for addess selection
$('input:radio[name="shipping"]').change(function() {

	var r_val = $('input[type=radio][name=shipping]:checked').attr('id');

	if (r_val != "new_address") {
		//console.log($('input:hidden[name=selectedAddressCode]').val());
		$('input:hidden[name=selectedAddressCode]').val(r_val);
		
		$("div.selectbutton").show();
		$("div.HPEform").hide();
		
		//$(this).closest("form").submit();
	}
	else{
		$("div.selectbutton").hide();
		$("div.HPEform").show();
	}

});

$(document).ready(function(){
	if($('input[type=radio][name=shipping][id=new_address]').is(":checked")){
		$("div.selectbutton").hide();
		$(".hpe-tabs__section").show();
		$("div.HPEform").show();
	}
})

$('#selectedAddress').on('click', function(){
	$('.spinner').show();
	var r_val = $('input[type=radio][name=shipping]:checked').attr('id');
	$('input:hidden[name=selectedAddressCode]').val(r_val);

	var request = $.ajax({
        cache: false,
        url: BASE_URL+'/checkout/multi/delivery-address/select',
		type: 'GET',
		dataType: 'json',
		data:$(this).closest("form").serialize()
    });

    request.done(function(data) {
    	$('.spinner').hide();
		location.href=BASE_URL+data.split(':')[1];
		
    });

    request.fail(function(jqXHR) {
    	if (jqXHR.responseJSON.length) {
			$('#gtsIPCheckErrorMsg').html(JSON.parse(jqXHR.responseJSON).error);
			$('.gtsIPCheck').show();
			scrollToError();
		}
        $('.spinner').hide();
    });
});






//script for contactus popup margin-top 0 fix
var callClose = false;
$('.hpe-support__tile-link.js-password-forgotten').on('click', function() {
	$('#colorbox').addClass('top0');
	if (!callClose) {
		closeFunction();
	}
	callClose = true;
});

function closeFunction() {
	$('#cboxClose').on('click', function() {
		$('#colorbox').removeClass('top0');
	});
}
/* #40841 fix */
$('.hpe-support__tile a.hpe-support__tile-link.js-password-forgotten span.hpe-support__tile-icon').on('click', function(e) {
	e.preventDefault();
	$(".hpe-support__tile a.hpe-support__tile-link.js-password-forgotten label.hpe-support__tile-label").trigger("click");
});

// for clear facet plp page starts here
$("#clearFacet").click(function() {
	if (location.href.indexOf("/?q=") > -1) {
		location.href = location.origin + location.pathname + '?q=' + $('.results span').text();
	} else if (location.href.indexOf("?q=") > -1) {
		location.href = location.origin + location.pathname + '?q=' + $('.results span').text();
	}
	//else if(location.href.indexOf("search/?text=")>-1){
	//	location.href ;/* = location.origin + location.pathname;*/
	//}
});
// for clear facet plp page ends here

//Bundling
function updateBundlePrice(shopId, bundleId, bundlePrice) {
    var pricelist = bundlePrice.substring(1, bundlePrice.indexOf('}')).split(', ');
    for (var i = 0; i < pricelist.length; i++) {
        if (pricelist[i].search(bundleId + '-' + shopId) >= 0) {
            var price = pricelist[i].substring(pricelist[i].indexOf('=') + 1);
            $('[id="totalBundlePrice-' + bundleId + '"]').html(price);
        }
    }
}

// Sorting countries selection
function sortCountries() {
	$('#country option[value=""]').remove();
	var a = "<option disabled>Country *</option>";
	var countries = $('#country');
	var selected = countries.val();
	var country_list = countries.find('option');
	country_list.sort(function(x, y) {
		return $(x).text() > $(y).text() ? 1 : -1;
	});
	countries.html('').append(country_list);
	countries.prepend(a);
	countries.val(selected);

};

$('#contact').on('change', function() {
	if ($(this).is(":checked")) {
		$(this).val('true');
	} else {
		$(this).val('false');
	}
})

$('#quotephonecontact,#quoteemailcontact').on('change', function() {
	if ($(this).is(":checked")) {
		$(this).val('Y');
	} else {
		$(this).val('');
	}
})

$('#contactQuoteCheckbox,#decision').on('change', function() {
	if ($(this).is(":checked")) {
		$(this).val('Yes');
	} else {
		$(this).val('No');
	}
})

$(document).on('click','.toggleBtnClass',  function() {
	var id = $(this).data('toggle');
	$('.' + id).toggle();
});


if ($('.hpe-tabs__section--active').is(":visible")) {
	$('.hpe-form-checkout__new-address #new_address').attr('checked', 'checked')
}

// Deal Of the week show more/less
$(".deal-of-the-week-show-content").click(function() {
	if ($(this).prev().hasClass("deal-of-the-week")) {
		$(this).children('a').text("Show Less");
	} else {
		$(this).children('a').text("More");
	}
	$(this).prev().toggleClass("deal-of-the-week");

});


//code for saved cart delete button
/*$("#select_all, .saved_checkbox").change(function() {

if($('.saved_checkbox:checkbox:checked').length)
{
document.getElementById('saved_cart_del').disabled = false;
}
else {
document.getElementById('saved_cart_del').disabled = true;
}

});*/


//code for saved cart popup
$("#cancelSaveCartButton").click(function() {
	$.colorbox.close();
});

/* #39555 get quote page spinner fix
$("body.page-getQuotePage #getQuote").click(function(e){
	$("#spinner").show();
	$("#spinner").fadeOut(7000);
});*/

$('.contact-support').on('click', function() {

	$('#contactSupport').toggle();

})


//GTS integration

if ($('#gtsIPCheckErrorMsg').text().length > 0) {

	$(".gtsIPCheck").css('display', 'block');
	setTimeout(function() {
		window.location.href = "https://www.hpe.com";
	}, 10000);
}


//saved cart nav hide show


var savedCartURL = currentUrl;
substring = "/saved-carts";
if(savedCartURL.indexOf(substring) !== -1) {
	$('.hpe-subnav').hide();
}



function populateUserName() {
	if($(".page-login #j_username").val() != undefined || $(".page-checkout-login #j_username").val() != undefined) {
		var username = decodeURIComponent($.cookie("hybris-store-logged-in"));
		if("null" != username) {
			$("#j_username").parent().addClass("hpe-input--active");
			$("#j_username").val(username);
		}
		
	}
}

$(".saved_checkbox").change(function() {

if($('.saved_checkbox:checkbox:checked').length>1)

{

document.getElementById('saved_cart_del').disabled = false;

}

else {

document.getElementById('saved_cart_del').disabled = true;

}

} 

);





$('#addressbook input:visible[type="radio"]').on('change',function(){
	if($(this.checked)){
		$(this).closest('.hpe-form-checkout__address').children('.btnAddressEdit').removeClass('invisible-edit-btn');
		$('#addressbook input:visible[type="radio"]:not(:checked)').closest('.hpe-form-checkout__address').children('.btnAddressEdit').addClass('invisible-edit-btn');
		var selectedRadioID = $(this).attr('id')
		localStorage.setItem('currentRadioID',selectedRadioID);
	}
	
})

//shipping address address selection start
var editAddressURL = currentUrl;
var editAddresssubstring = "/delivery-address/edit";
if (editAddressURL.indexOf(editAddresssubstring) !== -1) {
	var editRadioID = editAddressURL.split('=')[1];
	$('input[id='+editRadioID+']').prop("checked", true);
	
	
	$('#addressbook input:visible[type="radio"]').on('change',function(){
		var otherRadioID = $(this).attr('id')
		localStorage.setItem('currentRadioID',otherRadioID);
		location.href= BASE_URL+'/checkout/multi/delivery-address/add';
	})
	
	
}

var addAddressURL = currentUrl;
var addAddresssubstring = "/delivery-address/add";

if (addAddressURL.indexOf(addAddresssubstring) !== -1) {
	var selectedRadioID = localStorage.getItem('currentRadioID');
	var defaultRadio = $('#addressbook input:visible[type="radio"]')[0];
	if(selectedRadioID){
		$('input[id='+selectedRadioID+']').prop("checked", true);
		$('input[id='+selectedRadioID+']').closest('.hpe-form-checkout__address').children('.btnAddressEdit').removeClass('invisible-edit-btn');
	}else{
		$(defaultRadio).prop("checked", true);
		$(defaultRadio).closest('.hpe-form-checkout__address').children('.btnAddressEdit').removeClass('invisible-edit-btn');
	}
	
}

//shipping address address selection end


$( document ).ready(function() {
	if($('#payment_checkout').length){
		var iframe = $('#payment_checkout').contents();
		$(iframe.context.body).find('#if-footer .span4').addClass("confirmBtn");
	}
});



function updatePriceLabel(optionVal){
	$('#lbl_'+optionVal.id.split('_')[1]).text(optionVal.id.split('_')[3]);
	$('#product_'+optionVal.id.split('_')[1]).val('offer_'+optionVal.id.split('_')[2]);
	
	if(optionVal.id.split('_')[4]>=6){
		$('#lblAvailable_'+optionVal.id.split('_')[1]).text('Available');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).attr('class','');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).addClass('hpe-stock hpe-stock--in');
		
	}
	else if(optionVal.id.split('_')[4]<6 && optionVal.id.split('_')[4]>0){
		$('#lblAvailable_'+optionVal.id.split('_')[1]).text('Limited Stock');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).attr('class','');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).addClass('hpe-stock hpe-stock--low');
	}
	else if(optionVal.id.split('_')[4]<1){
		$('#lblAvailable_'+optionVal.id.split('_')[1]).text('Out Of Stock');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).attr('class','');
		$('#lblAvailable_'+optionVal.id.split('_')[1]).addClass('hpe-stock hpe-stock--out');
	}
}

$(document).on("click",".page-next-button, .page-previous-button", function(e) {
	e.preventDefault();
	var val = $(this).attr("data-value");
	var pageURL = $(this).attr("data-url-type");
	var indexValue=val.indexOf("?");
	var myUrl=(val).slice(indexValue+1);
	var currentUrl = location.href;
	var mystr = (currentUrl).slice(BASE_URL.length);
	var remainingstring = mystr.split('/').splice(0,
			mystr.split('/').length - 1).join('/');
	$('#spinner').show();
	var url = BASE_URL + remainingstring + "/"+pageURL+"?"+myUrl;
	if(pageURL==='showServices') {
    	url+="&sourceCode="+$('input[name="baseProduct"]').val();
    }
    else if(pageURL==='showOptions') {
    	url+="&sourceCode="+$('input[name="sourceCode_Option"]').val();
    }
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			
			 $('html, body').animate({
		            scrollTop: $('.hpe-more-information').offset().top 
		        }, 500);
			
			if(pageURL==='showServices')
			{
				$('.productServicesTabDisplay').html(data);
				var productFacetArr = $('#product-facet-service').children('.facet.js-facet');
		        for (let i = 0; i < productFacetArr.length; i++) {
		        	
		        	var attrClass = productFacetArr[i].classList[2];
		        	
		        	if(($('.' + attrClass + ' input:checkbox:checked').length > 0) || (i<2) ){
						$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
			    		$('.' + attrClass).find('section').attr('aria-hidden', true);
		        	}
		        		
		        }
			}
			else 
			{
				$('#optionsTab').html(data);
				var productFacetArr = $('#product-facet-option').children('.facet.js-facet');
		        for (let i = 0; i < productFacetArr.length; i++) {
		        	if(i===2){
		        		break;
		        	}
		        	var attrClass = productFacetArr[i].classList[2];
		        		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
		        		$('.' + attrClass).find('section').attr('aria-hidden', true);
		        }
			}
		}
	});
});


$(document).on("click",".page-next-my-order-button, .page-previous-my-order-button", function(e) {
	e.preventDefault();
	var val = $(this).attr("data-value");
	var pageURL = $(this).attr("data-url-type");
	var indexValue=val.indexOf("?");
	var myUrl=(val).slice(indexValue);
	var url = BASE_URL+pageURL +myUrl+$('#filterOrders').val(); 
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			if(data.includes('page-login')){
				location.reload();
			}
			else{
				$('.my-account-ajax-content').html(data);
			}
		}
	});
});

$(document).on("click",".page-next-quote-button, .page-previous-quote-button", function(e) {
	e.preventDefault();
	var val = $(this).attr("data-value");
	var pageURL = $(this).attr("data-url-type");
	var indexValue=val.indexOf("?");
	var myUrl=(val).slice(indexValue);
	var url = BASE_URL+pageURL +myUrl;
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			if(data.includes('page-login')){
				location.reload();
			}
			else{
				$('.my-account-quote-content').html(data);
			}
		}
	});
});


$(document).on("change",".select-page-size-pdp", function(){
	console.log($(this).val());
	var q = $(this).parents("form").find('input:hidden[name="text"]').attr('value');
	var pageURL = $(this).parents("form").find('input:hidden[name="urlType"]').attr('value');
	var pageSize = $(this).val();
	var indexValue=q.indexOf("?");
	var myUrl=((q).slice(indexValue+1)) + "&pageSize=" + pageSize;
	console.log(myUrl);
	var currentUrl = location.href;
	var mystr = (currentUrl).slice(BASE_URL.length);
	var remainingstring = mystr.split('/').splice(0,
			mystr.split('/').length - 1).join('/');
	$('#spinner').show();
	var url = BASE_URL + remainingstring + "/"+pageURL+"?"+myUrl;
	if(pageURL==='showServices') {
    	url+="&sourceCode="+$('input[name="baseProduct"]').val();
    }
    else if(pageURL==='showOptions') {
    	url+="&sourceCode="+$('input[name="sourceCode_Option"]').val();
    }
	
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			$('html, body').animate({
	            scrollTop: $('.hpe-more-information').offset().top 
	        }, 500);
			if(pageURL==='showServices')
			{
				$('.productServicesTabDisplay').html(data);
				var productFacetArr = $('#product-facet-service').children('.facet.js-facet');
		        for (let i = 0; i < productFacetArr.length; i++) {
		        	
		        	var attrClass = productFacetArr[i].classList[2];
		        	
		        	if(($('.' + attrClass + ' input:checkbox:checked').length > 0) || (i<2) ){
						$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
			    		$('.' + attrClass).find('section').attr('aria-hidden', true);
		        	}
		        		
		        }
			}
			else 
			{
				$('#optionsTab').html(data);
				var productFacetArr = $('#product-facet-option').children('.facet.js-facet');
		        for (let i = 0; i < productFacetArr.length; i++) {
		        	if(i===2){
		        		break;
		        	}
		        	var attrClass = productFacetArr[i].classList[2];
		        		$('.' + attrClass + ' .hpe-disclosure__button').addClass('hpe-disclosure__button--active');
		        		$('.' + attrClass).find('section').attr('aria-hidden', true);
		        }
			}
		}
	});
})

$('.cart-submit-btn').on('click',function(){
	var showErrorValue = $(this).attr('showerror');
	if(showErrorValue=='true'){
		$('.cartErrorNotification').show();
		$('.cartErrorNotification section').show();
		scrollToError();
	}
	
});


function submitLoginDetails(form,e){
	$('#spinner').show();
	if(loginFormValidate()){
		$(form).closest('form').submit();
	}else{
		$('#spinner').hide();
		e.preventDefault();
	}
}


$('#hpeLoginBtn').on('click',function(e){
	submitLoginDetails(this,e);
});


$('#loginForm input').on('keyup',function(e){
	if (e.keyCode == 13) {
        submitLoginDetails(this,e);
    }
});


$('#placeOrder').on('click',function(e){	
	$(this).closest('form').submit();
	$('#spinner').show();
});

$(document).on('click', '#specificationTab', function(){
	specificationTabOnLoad();
});

function specificationTabOnLoad(){
	var currentUrl = location.href;
	var mystr = (currentUrl).slice(BASE_URL.length);
	var remainingstring = mystr.split('/').splice(0,
			mystr.split('/').length - 1).join('/');
	var code= $('#data-specification-tab-id').attr('data-val');
	var url = BASE_URL + remainingstring + "/classification?variantCode="+code;
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			
		var trHTML='';
		Object.keys(data).length>0?trHTML='':trHTML='No Specification Available';
					 $(data).each(function(i,val)
							 {
								var j=0;
							  $.each(val,function(key,value)
							  {		
								
							
						if((key.toLowerCase().includes('headline')) ||(key.toLowerCase().includes('point'))){
									if(j!=0){
										trHTML += '<br>';
									}
									if(key.toLowerCase().includes('point')){
										trHTML += '<div class="row"><div class="col-12">' + value + '</div></div>';	
									}
									else
										{
										trHTML += '<div class="row"><div class="col-12"><b>' + value + '</b></div></div>';	
										}
									
									i++;
								}
								else{
									if(i>0){
										trHTML +='<br>';
									}
									i=0;
								trHTML += '<p class="hpe-more-information__list-item"><span class=""><b>' + key + '</b></span><span class="hpe-product-specification-text">' + value + '</span></p>';	
								}	 
								j++;
									});
							
							});
			
					 $('#displayTableSpecification'+code).html(trHTML); 
					 $('#spinner').hide();
		}
	});
}
$(document).on('click','.hpe-custom-search-order-btn', function(){
	var pageUrl = $(this).attr("data-url");
	var myUrl = '?orderNo='+$('#searchOrders').val();
	var url = BASE_URL+pageUrl+ myUrl;
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			$('.my-account-ajax-content').html(data);
		}
	});
});
$('.hpe-default-address-change').on('click', function() {
	$(this).closest('form').submit();
		}
);

$("#validateMyAccountAddress").on('click', function(e) {
	var url;
	var formID = $('#addressSuggestions').closest('form').attr('id');
	
	if ($('#addressSuggestions').is(":visible")) {
		$('#spinner').show();
		var formData = $('#' + formID).serialize();
		if (shippingAddressForm(formID)) {

			$('#addressSuggestions').closest('form').submit();
			

		} else {
			$('#spinner').hide();
			scrollToError();
			e.preventDefault();
		}

}
	 else {
		var _formData = $("#addressForm").serialize();
		url = BASE_URL+ '/checkout/multi/delivery-address/checkoutShippingAddressVerification';
		handleValidation(formID, _formData, url, e);
	}
});








$(document).on('change','.hpe-ddl-search-order', function(){
	var pageUrl = $(this).attr("data-url");
	var myUrl = '?filterStatus='+$("#filterOrders option:selected").val();
	var url = BASE_URL+pageUrl+ myUrl;
	$('#spinner').show();
	$.ajax({
		type : "GET",
		url : url,
		success : function(data) {
			$('#spinner').hide();
			if(data.includes('page-login')){
				location.reload();
			}
			else{
			$('.my-account-ajax-content').html(data);
			}
		}
	});

});

$(document).on('change','.hpe-ddl-country-iso', function(){
	var pageUrl = $(this).attr("data-url");
	var data = 'countryIso='+$(this)[0].selectedOptions[0].value;
	var url = BASE_URL+pageUrl;
	$('#postcode').val('').attr('isocode',$(this)[0].selectedOptions[0].value)
	$('.countryIsoCode').text($(this)[0].selectedOptions[0].value);
	var request = $.ajax({
		cache: false,
		url: url,
		type: 'POST',
		data:data
	});

	request.done(function(data) {
		if(data.length<1){
			$(".hpe-region-dynamic").hide();
		} else{
		var $el = $("#region");
	$el.empty();  
	
	 $el.append($('<option value="" disabled="disabled" selected="selected">State*</option>'));
	$.each(data, function(index) {
		$(".hpe-region-dynamic").show();
		$(".hpe-region-dynamic .hpe-input").addClass('hpe-input--active');
		
	  $el.append($("<option></option>")
	     .attr("value",data[index]['isocode']).text(data[index]['isocodeShort']));
	});
	$('.hpe-region-dynamic label[for="state"]').hide();
		}
	});
});  


$(document).on('change','.hpe-ddl-region-iso', function(){
	$('.hpe-region-dynamic label[for="state"]').show();
});
$(document).on('click', '.hpe-product-list__button .hpe-customize-link' , function() {
	$('html, body').animate({
		scrollTop: $(".hpe-configuration").offset().top
	}, 100);
	
	var owl = $('.owl-carousel.variant-items');
	var skuNumber = $(this).attr("variantcode"); //get this on click on configure and buy button
	var ele = $("p:contains("+skuNumber+")")[0];
	var index = $('.owl-carousel.variant-items header p:visible').index($(ele));
	owl.trigger('to.owl.carousel', index); 	
	$(ele).parent().parent().parent().addClass('hpe-card--active');
});

$(document).on('click', '#cancelChannelCentral', function () {
$('.hpe-configuration').removeClass('hpe-configuration--open');
});

$(document).on('click','.removeAddressFromBookButton',function(){
	$('#cboxWrapper').addClass('address-delete-popup-width-height');
})
