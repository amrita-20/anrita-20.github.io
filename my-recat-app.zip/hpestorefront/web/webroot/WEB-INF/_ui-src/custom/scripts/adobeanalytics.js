var digitalData = window.digitalData || {page: {pageInfo: {}, category: {}}, product: [], user: [], transaction:{}};
var metricsargument;
var scriptLoaded;

/* Customer Registration */    
function submitRegisterActiveToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ["mp", "home"];
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    window.utag_cfg_ovrd = {noview : true};
    setCustomerID();
}   
function submitRegisterFailToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ["mp", "register", "fail"];
	digitalData.event=[{
		  eventInfo:{
		    eventName:"register.register"
		  }
		}];
		digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
		setCustomerID();
}   
/* Customer Registration ends here */     
    
/* Homepage */     
function submitHomePageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "home"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.page.pageInfo.language = $('#languageCode').text();
  digitalData.cart= JSON.parse($('#cartdisplayjsondata').text());
	setCustomerID();	
}

/* Homepage ends here*/  

function submitSignInPageDataToTagManager(errorResponse){
	digitalData.event=[{
	  eventInfo:{
	    eventName:"signin"
	  }
	}];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";

	if(errorResponse != undefined){
		digitalData.page.pageInfo.breadCrumbs = ["mp", "sign-in","error"];
	} else {
		digitalData.page.pageInfo.breadCrumbs = ["mp", "sign-in"];
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.page', {'page_name':'mp:sign-in:success'});			
		});	
	}	
	digitalData.page.pageInfo.language = $('#languageCode').text();	
	setCustomerID();	
}

function submitSignInErrorDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ['mp', 'sign-in','error'];
	digitalData.cart.cartID='${cartId}';
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.page.pageInfo.language = $('#languageCode').text();	
	setCustomerID();	
}

function submitCustomerRegistrationPageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "register"];
	digitalData.event=[{
	  eventInfo:{
	    eventName:"register.register"
	  }
	}];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.page.pageInfo.language = $('#languageCode').text();	
	setCustomerID();	
}

function submitCheckoutLoginDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ["mp", "sign-up"];

    digitalData.event=[{
      eventInfo:{
        eventName:"register.signup"
      }
    }];
    
    var cartDetail= JSON.parse($('#cartjsondata').text());
    digitalData.cart = []; 
    digitalData.cart.cartID=cartDetail.cartID;
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitViewCartDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ['mp','view cart'];
    digitalData.event=[{
      eventInfo:{
        eventName:"cart.view"
      }
    }];
    digitalData.cart= JSON.parse($('#cartdisplayjsondata').text());
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitDeliveryAddressDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ['mp', 'checkout', 'delivery address'];

    digitalData.event=[{
      eventInfo:{
        eventName:"checkout.start"
      }
    }];
    digitalData.cart= JSON.parse($('#deliveryaddressjsondata').text());
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitDeliveryMethodToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ['mp', 'checkout', 'delivery method'];

    digitalData.cart= JSON.parse($('#deliverymethodjsondata').text());
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitCheckoutSummaryDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ['mp', 'checkout', 'review'];

    digitalData.event=[{
      eventInfo:{
        eventName:"checkout.review"
      }
    }];
    digitalData.cart= JSON.parse($('#summaryjsondata').text());
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitOrderConfirmationDataToTagManager(){
    digitalData.page.pageInfo.breadCrumbs = ['mp', 'confirm order'];

    digitalData.event=[{
      eventInfo:{
        eventName:"purchase"
      }
    }]; 
    digitalData.cart= JSON.parse($('#orderconfirmationdata').text());
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.transaction.transactionID = digitalData.cart.transactionID;
    digitalData.transaction.paymentMethod = digitalData.cart.paymentMethod;
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitProductDetailDataToTagManager(){
	var productjsonData = JSON.parse($('#productjson').text());
	var category = productjsonData.navigationList[productjsonData.navigationList.length-1];
	digitalData.page.pageInfo.primaryCategory = {"category":category};
	digitalData.page.pageInfo.breadCrumbs = ['mp','pdp',productjsonData.baseProduct.productID,productjsonData.baseProduct.productName];
    digitalData.event=[{
      eventInfo:{
        eventName:"product.view"
      }
    }];

    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.product=productjsonData.productInfo;
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}
/* Channel central- product configurator starts here */
     function cancelconfiguration(dataanalytics){
		 var productCode = localStorage.getItem('productID');
         var productName = localStorage.getItem('productName');

         var text =[{productInfo:{productID:productCode,productName:productName}}];      
         digitalData.product=text;             
        
         digitalData.promises != undefined? digitalData.promises.trackMetricsReady.then(function() {
        	 trackMetrics('new.link', {'link_name':'mp:configuration:cancel','products':digitalData.product});
         }):null;
     	localStorage.removeItem('productID');
     	localStorage.removeItem('productName');     	
     }

     function resetConfiguration(){
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.link', {'link_name':'mp:configuration:refresh'});
		});
	 }

function addtocartconfiguration(dataanalytics){
	 	 var productCode = localStorage.getItem('productID');	
         var productName = localStorage.getItem('productName');
         var productPrice = localStorage.getItem('configureprice');
         var text =[{productInfo:{productID:productCode,productName:productName, price:productPrice, quantity:"1"}}];
         digitalData.product=text;
         
     	var productjsonData = JSON.parse($('#productjson').text());
    	var cartDetail = productjsonData.cartDetail;         

    	if(cartDetail.cartID != undefined){    	
	         digitalData.promises.trackMetricsReady.then(function() {
	                trackMetrics('new.link', {'link_name':'mp:configuration:complete','products':digitalData.product});
	         });
    	} else {
    		digitalData.promises.trackMetricsReady.then(function() {
    			trackMetrics('new.link', {'link_name':'mp:cart:new cart:configuration','products':digitalData.product});			
    		});    		
    	}     
      	localStorage.removeItem('productID');  
     	localStorage.removeItem('productName');
     	localStorage.removeItem('configureprice');      	
} 
$(document).on('click', '#cancelChannelCentral',function(){
	console.log("cancel from channel central clicked");
	cancelconfiguration();
});
$(document).on('click', '#resetChannelCentral',function(){
	console.log("reset from channel central clicked");
	resetConfiguration();
});
$(document).on('click', '#addChCProduct',function(){
	console.log("add to cart from channel central clicked");
	localStorage.setItem('configureprice',$('#addChCProduct').attr('data-analytics-price'));
	addtocartconfiguration()
});
/* Channel central - product configurator ends here */
/* Product Detail Page ends here */
/* Category Page */
function submitCategoryPageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "category", "servers and server systems"];
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.primaryCategory={"category":"servers and server systems"};
    digitalData.event=[{
        eventInfo:{
          eventName:"product.category"
        }
      }];
	digitalData.page.pageInfo.language = $('#languageCode').text();
  	setCustomerID();    
}
/* Category Page ends here */
/* Product Listing Page */
function submitProductListingPageDataToTagManager(){
	 var jsonData = JSON.parse($('#productlistjsondata').text());
	 digitalData.product=jsonData.productInfo;

     digitalData.page.pageInfo.primaryCategory={category: (jsonData.navigationCategory)[jsonData.navigationCategory.length -1]};
	console.log(jsonData.navigationCategory[0]);
 	if(jsonData.navigationCategory.length == 1 && jsonData.navigationCategory[0] == 'Server and Systems'){  
		console.log('server and systems..');
	     digitalData.page.pageInfo.breadCrumbs = ["mp","category", "servers and server systems"];
	     digitalData.event=[{
	       eventInfo:{
	         eventName:"product.category"
	       }
	     }];
 	}else {
		console.log('product listing..');		
	     digitalData.page.pageInfo.breadCrumbs = ["mp","product-listing"];
	  	 for(var i=0;i<jsonData.navigationCategory.length;i++){
			digitalData.page.pageInfo.breadCrumbs.push(jsonData.navigationCategory[i]);
		}
	     
	     digitalData.event=[{
	       eventInfo:{
	         eventName:"product.listing"
	       }
	     }];

 	}     

    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}
/* Product Listing page ends here */

function submitQuoteDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ['mp','get quote'];
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";

	var jsonData = JSON.parse($('#quotePagejsondata').text());
	 digitalData.product=jsonData.productInfo;
	 digitalData.page.pageInfo.language = $('#languageCode').text();	 
	setCustomerID();    
}

function submitQuoteSummaryToTagManager(){
	 var jsonData = JSON.parse($('#quotePagejsondata').text());
	 digitalData.product=jsonData.productInfo;
	 digitalData.transaction.quoteID=jsonData.transactionID;
    digitalData.page.pageInfo.breadCrumbs = ['mp','submit quote'];
    digitalData.event=[{
      eventInfo:{
        eventName:"quote.complete"
      }
    }];
    digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitPaymentPageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "checkout", "payment"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.cart= JSON.parse($('#cartjsondata').text());	
    digitalData.page.pageInfo.language = $('#languageCode').text();
	setCustomerID();    
}

function submitSearchPageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "search", "results"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.page.pageInfo.onsiteSearchTerm = $('#searchText').text();
	digitalData.page.pageInfo.onsiteSearchResults = $('#searchResults').text();	
	
    digitalData.event=[{
        eventInfo:{
          eventName:"search.results"
        }
      }];
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitEmptySearchPageDataToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "search", "results none"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.page.pageInfo.onsiteSearchTerm = $('#searchText').text();
	digitalData.page.pageInfo.onsiteSearchResults = "0";	
	
    digitalData.event=[{
        eventInfo:{
          eventName:"search.results"
        }
      }];
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitSavedCartDetailToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "my account", "saved cart detail"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.cart= JSON.parse($('#savedCartDetail').text());	
	
    digitalData.event=[{
        eventInfo:{
          eventName:"saved.cart"
        }
      }];
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitSavedCartsDetailToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "my account", "saved carts"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
    digitalData.cart= JSON.parse($('#savedCartsDetail').text());	
	
    digitalData.event=[{
        eventInfo:{
          eventName:"saved.carts"
        }
      }];
    digitalData.page.pageInfo.language = $('#languageCode').text();    
	setCustomerID();    
}

function submitMyAccountDetailToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "my account"];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	digitalData.cart= JSON.parse($('#myAccountDetail').text());
	digitalData.page.pageInfo.language = $('#languageCode').text();	
	setCustomerID();	
}

function submitCompareProductDetailToTagManager(){
	digitalData.page.pageInfo.breadCrumbs = ["mp", "product", "compare-product"];
	digitalData.event=[{
	  eventInfo:{
	    eventName:"product.compare"
	  }
	}];
	digitalData.page.pageInfo.technology_stack = "tealium-selfservice";
	setCustomerID();	
    var comparePageJsonObject= JSON.parse($('#comparePageJsonObject').text());
	 digitalData.product=comparePageJsonObject.productInfo;	
	 digitalData.page.pageInfo.language = $('#languageCode').text();	
}

var loadScriptAsync = function(){
	  return new Promise(function(resolve, reject){
	    var tag = document.createElement('script');
	    tag.src = "https://www.hpe.com/global/metrics/bootstrap/prod.js";
	    tag.async = true;
	    tag.onload = function(){
	      resolve();
	    };
		document.head.appendChild(tag);
  });
}

function callProdJavascript(){
	scriptLoaded = loadScriptAsync();
}	

function addtocart(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");
	var productprice = dataanalytics.getAttribute("data-analytics-price");
	var pageName = dataanalytics.getAttribute("data-analytics-pageName");
	
	var productjsonData = JSON.parse($('#productjson').text());
	var cartDetail = productjsonData.cartDetail;

	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName, price:productprice, quantity:"1"}}];	
	digitalData.product=text;
	
	if(cartDetail.cartID != undefined){
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.link', {'link_name':'mp:cart:add to cart','products':digitalData.product, 'finding_methods':pageName});			
		});		
	} else {
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.link', {'link_name':'mp:cart:new cart','products':digitalData.product});			
		});		
	}
}

function addbundletocart(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");
	var productprice = dataanalytics.getAttribute("data-analytics-price");

	var productjsonData = JSON.parse($('#productjson').text());
	var cartDetail = productjsonData.cartDetail;
	
	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName, price:productprice, quantity:"1"}}];	
	digitalData.product=text;

	if(cartDetail.cartID != undefined){
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.link', {'link_name':'mp:bundle:add to cart','products':digitalData.product});			
		});
	} else {
	
		digitalData.promises.trackMetricsReady.then(function() {
			trackMetrics('new.link', {'link_name':'mp:cart:new cart','products':digitalData.product});			
		});
	}	
}

function removeproductfromcart(dataanalytics){
	var getProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getProductName = dataanalytics.getAttribute("data-analytics-productName");

	var text =[{productInfo:{productID:getProductID,productName:getProductName}}];	
	digitalData.product=text;

	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:cart:remove from cart','products':digitalData.product});			
	});
}



function deliveryAddressNext(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.page', {'page_name':'mp:checkout:shipping'});			
	});
}

function getquote(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");

	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
	digitalData.product=text;
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link',{'link_name':'mp:get quote link','products':digitalData.product});			
	});
}

function completequote(productCode){
	var getQuoteProductID = productCode;
	var getQuoteProductName = "";
	
	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
	digitalData.product=text;
	
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link',{'link_name':'mp:submit quote','products':digitalData.product});			
	});
}

function customizeandbuy(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:recommendation:saveditems'});			
	});
}

function similarcustomizeandbuy(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");

	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
	digitalData.product=text;

	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:recommendation:similaritems','products':digitalData.product});			
	});
}

function dealofweekcustomizeandbuy(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");

	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
	digitalData.product=text;

	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:recommendation:dealofweek','products':digitalData.product});			
	});
}

function recommendedcustomizeandbuy(dataanalytics){
	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");

	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
	digitalData.product=text;

	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:recommendation:recommendedforyou','products':digitalData.product});			
	});
}

function topsellerscustomizeandbuy(dataanalytics){
 	var getQuoteProductID = dataanalytics.getAttribute("data-analytics-productID");
 	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");
 
  	var text =[{productInfo:{productID:getQuoteProductID,productName:getQuoteProductName}}];	
 	digitalData.product=text;
 
  	digitalData.promises.trackMetricsReady.then(function() {
 		trackMetrics('new.link', {'link_name':'mp:recommendation:topsellers','products':digitalData.product});			      
 	});
 }

function openvideo(dataanalytics){
	var getQuoteProductName = dataanalytics.getAttribute("data-analytics-productName");
	
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:video:play', 'video_name':getQuoteProductName});			
	});
}

function searchresult(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:search:click'});			
	});
}

function getcontactus(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.page', {'page_name':'mp:contact us'});			
	});
}

function submitcontactus(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:contactus:complete'});			
	});
}

function configureandbuy(dataanalytics){
	var productID = dataanalytics.getAttribute("data-analytics-productID");
	var productName = dataanalytics.getAttribute("data-analytics-productName");
	var text =[{productInfo:{productID:productID,productName:productName}}];	
	localStorage.setItem('productID',productID);
	localStorage.setItem('productName',productName);	
	digitalData.product=text;

	digitalData.promises !=undefined? digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:configuration:start','products':digitalData.product});			
	}):null;	
}

function searchfilter(dataanalytics){
	var filtername = dataanalytics.getAttribute("data-analytics-filtername");
	var filtervalue = dataanalytics.getAttribute("data-analytics-filtervalue");	
	var searchcriteria = filtername + '=' + filtervalue;  
	
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:search:filter','search_criteria':searchcriteria})		
	});	
}

$('body').on('hover','#hpehf-cart-item',function(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.page', {'page_name':'mp:minicart'});			
	});
});

$('body').on('click','.hpehf-flyout-header-link',function(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:minicart:view cart'});			
	});
});

$('body').on('click','.hpehf-cart-buttons .view-cart',function(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:minicart:view cart'});			
	});
});

$('body').on('click','.hpehf-cart-buttons .checkout',function(){
	digitalData.promises.trackMetricsReady.then(function() {
		trackMetrics('new.link', {'link_name':'mp:minicart:checkout'});			
	});
});

function setCustomerID(){
	var customerValue;
	if($('#customerId').text()){
		customerValue = $('#customerId').text();
	}else{
		customerValue = 'anonymous';
	}
	localStorage.setItem('hpeguid_hybris',customerValue);
}

$(document).ready(function() {
	scriptLoaded = loadScriptAsync();
});