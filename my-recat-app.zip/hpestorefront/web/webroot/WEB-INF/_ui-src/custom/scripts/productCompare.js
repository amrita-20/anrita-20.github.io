$('body').on('click','input.productToCompareCheckbox[type="checkbox"]',function() {
	var prodId = $(this).attr("productid");
	var flagValue = $(this).attr("compareflag");
	sessionStorage.setItem('flag', flagValue);
	if ($(this).prop("checked") == true) {
		addProductToCompare(prodId,flagValue);
	} else if ($(this).prop("checked") == false) {
		removeProductToCompare(prodId,flagValue);
	}
});

var compareUrl = currentUrl;
var substring = "/p/";

if(compareUrl.indexOf(substring) !== -1) {
	var baseProductCode = compareUrl.substring(
		compareUrl.lastIndexOf("/") + 1, 
		compareUrl.lastIndexOf("?") == -1?compareUrl.length:compareUrl.lastIndexOf("?")
	);
	if(!sessionStorage.hasOwnProperty('baseProductCode')){
		sessionStorage.setItem('baseProductCode', baseProductCode);
	}
	
	if(sessionStorage.getItem('baseProductCode') != baseProductCode){
		sessionStorage.setItem('baseProductCode', baseProductCode);
		var productCompareListModels = [];
		var productCompareListOptions = [];
		var productCompareListServices = [];
		sessionStorage.setItem('productCompareListModels', JSON.stringify(productCompareListModels));
		sessionStorage.setItem('productCompareListOptions', JSON.stringify(productCompareListOptions));
		sessionStorage.setItem('productCompareListServices', JSON.stringify(productCompareListServices));
	
	}
}


var plpURL = currentUrl;
var plpSubstring = "/c/";

if(plpURL.indexOf(plpSubstring) !== -1) {
	var categoryCode = plpURL.substring(
		plpURL.lastIndexOf("/") + 1, 
		plpURL.lastIndexOf("?") == -1?plpURL.length:plpURL.lastIndexOf("?")
	);

	// if(!categoryCode){
	// 	categoryCode = plpURL.split('/')[plpURL.split('/').length-1];
	// }

	if(!sessionStorage.hasOwnProperty('categoryProductCode')){
		sessionStorage.setItem('categoryProductCode', categoryCode);
	}
	
	if(sessionStorage.getItem('categoryProductCode') != categoryCode){
		sessionStorage.setItem('categoryProductCode', categoryCode);
		var productCompareListPLP = [];
		sessionStorage.setItem('productCompareListPLP', JSON.stringify(productCompareListPLP));
	}
}


// var compareUrl = currentUrl;
// var substring = "/c/"
// if(compareUrl.indexOf(substring) !== -1) 
// {
	
// var productCompareListModels = [];
// var productCompareListOptions = [];
// var productCompareListOptions = [];

var productCompareListPLP = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
var productCompareListModels = JSON.parse(sessionStorage.getItem('productCompareListModels'));
var productCompareListOptions = JSON.parse(sessionStorage.getItem('productCompareListOptions'));
var productCompareListServices = JSON.parse(sessionStorage.getItem('productCompareListServices'));



if(!productCompareListPLP){
    productCompareListPLP = [];
    sessionStorage.setItem('productCompareListPLP', JSON.stringify(productCompareListPLP));
}

if(!productCompareListModels){
    productCompareListModels = [];
    sessionStorage.setItem('productCompareListModels', JSON.stringify(productCompareListModels));
}


if(!productCompareListOptions){
    productCompareListOptions = [];
    sessionStorage.setItem('productCompareListOptions', JSON.stringify(productCompareListOptions));
}

if(!productCompareListServices){
    productCompareListServices = [];
    sessionStorage.setItem('productCompareListServices', JSON.stringify(productCompareListServices));
}


// sessionStorage.setItem('productCompareListModels', JSON.stringify(productCompareListModels));
// sessionStorage.setItem('productCompareListServices', JSON.stringify(productCompareListOptions));
// sessionStorage.setItem('productCompareListOptions', JSON.stringify(productCompareListServices));
// }



function closeProductToComparePLP(id,flag) {
	if($('input[productid="' + id + '"][compareflag="' + flag + '"]').length){
		// $('input[productid="' + chkboxValue + '"][compareflag="' + flag + '"]').prop('checked', true);
		$('input[productid="' + id + '"][compareflag="' + flag + '"]').trigger('click');
	}else{
		removeProductToCompare(id,flag);
	}
}


//Compare products js starts here
$(document).ready(function() {
	sessionStorage.removeItem('productsToCompareRemoved');
});
$('#backToListing').click(function() {
	location.href= document.referrer;
});


var compareDataList = [];
var flag = sessionStorage.getItem('flag');
var productsToCompare;



if(flag=="comparePLP"){
	productsToCompare = sessionStorage.getItem('productCompareListPLP'); 
}else if(flag=="compareModels"){
	productsToCompare = sessionStorage.getItem('productCompareListModels');
}else if (flag=="compareServices"){
	productsToCompare = sessionStorage.getItem('productCompareListServices');
}else{
	productsToCompare = sessionStorage.getItem('productCompareListOptions');
}


if (productsToCompare) {
	productsToCompare = productsToCompare.split(',');
}


function compareProducts(flag) 
{

	$('.compare-loading').show();

	
	if(flag=="comparePLP"){
		productsToCompare = sessionStorage.getItem('productCompareListPLP'); 
	}else if(flag=="compareModels"){
		productsToCompare = sessionStorage.getItem('productCompareListModels');
	}else if (flag=="compareServices"){
		productsToCompare = sessionStorage.getItem('productCompareListServices');
	}else{
		productsToCompare = sessionStorage.getItem('productCompareListOptions');
	}



	if (productsToCompare) {
		var flag = sessionStorage.getItem('compareTableFlag');

		$.ajax({
			type: 'POST',
			dataType: 'json',
			data: {
				prodIds: JSON.parse(productsToCompare).map(function(e) { return e.productID; }).join(','),
				compareflag:flag
			},
			url: BASE_URL+'/product/compare',
			async: false,
			success: function(data) {
				$('.compare-loading').hide();
				// if (data && data.length) {
				// 	compareDataList = data;
				// 	produceLayout(data);
                // }
                // redirect to other page\
                location.href = BASE_URL+"/product/compareProduct";
			},
			error: function(e) {
				$('.compare-loading').hide();
				$(".data-fetch-error").show();
				$(".data-fetch-error span").html(e.statusText);
			}
		});
	}
}





// compareUrl = currentUrl;
// substring = "/product/compareProduct"
// if(compareUrl.indexOf(substring) !== -1) 
// {
// 	compareProducts();	
// }



var closeProductsCompareId = [];

function closeProductToComparePage(id) {
	var indexOfProduct = productsToCompare.indexOf(id);
	if (indexOfProduct >= 0) {
		closeProductsCompareId.push(id);
		productsToCompare.splice(indexOfProduct, 1);
		//compareProducts();
	}
	for (var i = 0; i < compareDataList.length; i++) {
		if (compareDataList[i].code === id) {
			compareDataList.splice(i, 1);
			break;
		}
	}
	// produceLayout(compareDataList);
	sessionStorage.setItem('productsToCompareRemoved', closeProductsCompareId.join(','));
}
//Compare products js ends here


//Compare products list js starts here

var productsToCompareRemoved = [];
var removed = sessionStorage.getItem('productsToCompareRemoved');
if (removed) {
	productsToCompareRemoved = removed.split(',');
	sessionStorage.removeItem('productsToCompareRemoved');
	for (var i = 0; i < productsToCompareRemoved.length; i++) {
		closeProductToComparePLP(productsToCompareRemoved[i]);
	}
}

// var plpURLonRefresh = currentUrl;
// var substring = "/c/";

// if(plpURLonRefresh.indexOf(substring) !== -1) 
// {
	
// 	var getCheckedProducts = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
	
// 	getCheckedProducts.forEach(function(item){
// 		$('input[productid=' + item + '][compareflag="comparePLP"]').prop("checked","checked");
// 	});
	
// 	if (productCompareListPLP.length) {
// 		var id;
// 		prepareProductCompareList(id,sessionStorage.getItem('flag'),getCheckedProducts);
// 	}
// }


function setFlagInSessionStorage(flag,productCompareList){

	if(flag=="comparePLP"){
		sessionStorage.setItem('productCompareListPLP', JSON.stringify(productCompareList));
	}else if(flag=="compareModels"){
		sessionStorage.setItem('productCompareListModels', JSON.stringify(productCompareList));
	}else if (flag=="compareServices"){
		sessionStorage.setItem('productCompareListServices', JSON.stringify(productCompareList));
	}else{
		sessionStorage.setItem('productCompareListOptions', JSON.stringify(productCompareList));
	}
	return;
}

function compareLengthCheck(id,flag,productCompareList){
	if (productCompareList.length < 4 && productCompareList.indexOf(id) === -1) {
		var parent = $('input[productid="' + id + '"][compareflag="' + flag + '"]').closest('section');
		if($(parent).find('h4 a').text()){
			name = $(parent).find('h4 a').text();
		}else{
			name = $(parent).find('h4.hpe-product-list__name').text()
		}

		var price;
		if(flag=='comparePLP'){
			price = $(parent).find('.hpe-product-list__price span.hpe-font-weight').text();
		}else{
			price = $(parent).find('.hpe-product-list__price .priceTotal').text()
		}
		var content = {
			"name":name,
			"price":price,
			"imageURL":$(parent).find('img').attr('src'),
			"productID":id
		};

		productCompareList.push(content);
		setFlagInSessionStorage(flag,productCompareList);
		
		prepareProductCompareList(flag,productCompareList);
    } else if (productCompareList.length >= 4) {
        $('input[productid="' + id + '"]').prop('checked', false);
        $(".notificationMaxProduct").animate({
                bottom: '0'
            },
            "slow",
            function() {
                setTimeout(function() {
                    $(".notificationMaxProduct").animate({
                        bottom: '-35%'
                    })
                }, 5000);
            }
        );
    }
}

function addProductToCompare(id,flag) {
	
//	var productCompareList = [];
		
		if(flag=="comparePLP"){
			
			productCompareList = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
			compareLengthCheck(id,flag,productCompareList)
			
		}else if(flag=="compareModels"){
			
			productCompareList = JSON.parse(sessionStorage.getItem('productCompareListModels'));
			compareLengthCheck(id,flag,productCompareList)
		}else if (flag=="compareServices"){
			productCompareList = JSON.parse(sessionStorage.getItem('productCompareListServices'));
			compareLengthCheck(id,flag,productCompareList)
		}else{
			
			productCompareList = JSON.parse(sessionStorage.getItem('productCompareListOptions'));
			
			compareLengthCheck(id,flag,productCompareList)
		}
		
		
}

function removeCompareProduct(id,flag,productCompareList){
	var indexOfProduct = productCompareList.map(function(e) { return e.productID; }).indexOf(id);
	if (indexOfProduct >= 0) {
		productCompareList.splice(indexOfProduct, 1);
		setFlagInSessionStorage(flag,productCompareList);
		prepareProductCompareList( flag,productCompareList);
	}
}

function removeProductToCompare(id,flag) {
	
	if(flag=="comparePLP"){
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
		removeCompareProduct(id,flag,productCompareList)
		
	}else if(flag=="compareModels"){
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListModels'));
		removeCompareProduct(id,flag,productCompareList)
	}else if (flag=="compareServices"){
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListServices'));
		removeCompareProduct(id,flag,productCompareList)
	}else{
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListOptions'));
		
		removeCompareProduct(id,flag,productCompareList)
	}
	
			
	
	var indexOfProduct = productCompareList.indexOf(id);
	if (indexOfProduct >= 0) {
		productCompareList.splice(indexOfProduct, 1);
		prepareProductCompareList(flag,productCompareList);
	}
}

function prepareProductCompareList(flag,productCompareList) {
	
	var compareWindow;
	if(flag=="comparePLP"){
		$('#productCompareContainerPLP').html('');
		$('#noOfProductsToComparePLP').html(productCompareList.length);
		compareWindow = $('#noOfProductsToComparePLP').closest('.hpe-compare');
	}else if(flag=="compareModels"){
		$('#productCompareContainerModels').html('');
		$('#noOfProductsToCompareModels').html(productCompareList.length);
		compareWindow = $('#noOfProductsToCompareModels').closest('.hpe-compare');
	}else if (flag=="compareServices"){
		$('#productCompareContainerServices').html('');
		$('#noOfProductsToCompareServices').html(productCompareList.length);
		compareWindow = $('#noOfProductsToCompareServices').closest('.hpe-compare');
	}else{
		$('#productCompareContainerOptions').html('');
		$('#noOfProductsToCompareOptions').html(productCompareList.length);
		compareWindow = $('#noOfProductsToCompareOptions').closest('.hpe-compare');
	}
	
	
	
	
	if (productCompareList.length) {
		$(compareWindow).show();

		var finalValue = '';
		productCompareList.forEach(function(item) {
			var template;
			
			
			if(flag=="comparePLP"){
				template = $('#productCompareTemplatePLP').html();
			}else if(flag=="compareModels"){
				template = $('#productCompareTemplateModels').html();
			}else if (flag=="compareServices"){
				template = $('#productCompareTemplateServices').html();
			}else{
				template = $('#productCompareTemplateOptions').html();
			}
			
			
			if(!item.price.trim()){
			      template = template.replace('hideText', 'hidden');
			     }
			template = template.replace('ProductNameValue', item.name); 
			template = template.replace('ProductPriceValue', item.price); 
			template = template.replace('ProductIDValue', item.productID); 
			template = template.replace('ProductImageURL', item.imageURL);
			template = template.replace('flagValClose', flag);
			finalValue += $(template).prop('outerHTML');

		});
		
		if(flag=="comparePLP"){
			$('#productCompareContainerPLP').append(finalValue);
			}else if(flag=="compareModels"){
				$('#productCompareContainerModels').append(finalValue);
			}else if (flag=="compareServices"){
				$('#productCompareContainerServices').append(finalValue);
			}else{
				$('#productCompareContainerOptions').append(finalValue);
		}
		
		
		
		if (productCompareList.length == 1) {	
			$('.compareButton:visible').attr('disabled', true);
		} else {
			$('.compareButton:visible').removeAttr('disabled');
		}
	} else {
		$('.compareButton').removeAttr('disabled');
		$('.hpe-compare').hide();
	}
}

$('body').on('click','.compareButton:visible', function() {
    var compareTableFlagValue = $(this).attr('compareTableFlag');
    
     sessionStorage.setItem('compareTableFlag',compareTableFlagValue);
    compareProducts(compareTableFlagValue);
	
})



// Models tab compare tab


$(document).ready(function(){
	var flag ;
    var data;
    if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Models")').hasClass('active')){
        flag = 'compareModels';
        data = sessionStorage.getItem('productCompareListModels');
        if(JSON.parse(data).length){
            prepareProductCompareList( flag,JSON.parse(data));
        }
	}
	
	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Options")').hasClass('active')){
        flag = 'compareOptions';
        data = sessionStorage.getItem('productCompareListOptions');
        if(JSON.parse(data).length){
            prepareProductCompareList( flag,JSON.parse(data));
        }
	}

	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Services")').hasClass('active')){
        flag = 'compareServices';
        data = sessionStorage.getItem('productCompareListServices');
        if(JSON.parse(data).length){
            prepareProductCompareList( flag,JSON.parse(data));
        }
	}
	

});


function handleModels(){
	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Models")').hasClass('active')){
		flag = 'compareModels';
		data = JSON.parse(sessionStorage.getItem('productCompareListModels'));
		$('input[compareflag='+flag+']').prop('checked', false);
		$.each($('.modelSection .hpe-product-list__row.row'),function(index,eachEle){
			var checkbox = $(eachEle).find('.productToCompareCheckbox');
			var chkboxValue = checkbox.attr('productid')
			$.each(data,function(i,v){
				if(chkboxValue == v.productID){
					$('input[productid="' + chkboxValue + '"][compareflag="' + flag + '"]').prop('checked', true);
				}
				
			})

		});
		if(data.length){
			prepareProductCompareList( flag,data);
		}
	}
}

function handleOptions(){
	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Options")').hasClass('active')){
		flag = 'compareOptions';
		data = JSON.parse(sessionStorage.getItem('productCompareListOptions'));
		$('input[compareflag='+flag+']').prop('checked', false);
		$.each($('.optionsSection .hpe-product-list__row.row'),function(index,eachEle){
			var checkbox = $(eachEle).find('.productToCompareCheckbox');
			var chkboxValue = checkbox.attr('productid')
			$.each(data,function(i,v){
				if(chkboxValue == v.productID){
					$('input[productid="' + chkboxValue + '"][compareflag="' + flag + '"]').prop('checked', true);
				}
				
			})

		});
		if(data.length){
			prepareProductCompareList( flag,data);
		}
	}
}

function handleServices(){
	if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Services")').hasClass('active')){
		flag = 'compareServices';
		data = JSON.parse(sessionStorage.getItem('productCompareListServices'));
		$('input[compareflag='+flag+']').prop('checked', false);
		$.each($('.servicesSection .hpe-product-list__row.row'),function(index,eachEle){
			var checkbox = $(eachEle).find('.productToCompareCheckbox');
			var chkboxValue = checkbox.attr('productid')
			$.each(data,function(i,v){
				if(chkboxValue == v.productID){
					$('input[productid="' + chkboxValue + '"][compareflag="' + flag + '"]').prop('checked', true);
				}
				
			})

		});
		if(data.length){
			prepareProductCompareList( flag,data);
		}
	}
}

function handlePLP(){
	var flag = 'comparePLP';
	var	data = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
		$('input[compareflag='+flag+']').prop('checked', false);
		$.each($('.product__listing.product__list .hpe-product-list__row.row'),function(index,eachEle){
			var checkbox = $(eachEle).find('.productToCompareCheckbox');
			var chkboxValue = checkbox.attr('productid')
			$.each(data,function(i,v){
				if(chkboxValue == v.productID){
					$('input[productid="' + chkboxValue + '"][compareflag="' + flag + '"]').prop('checked', true);
				}
				
			})

		});
		if(data.length){
			prepareProductCompareList( flag,data);
		}
}

var compareUrl = currentUrl;
var substring = "/p/";

if(compareUrl.indexOf(substring) !== -1) {
	$(document).ajaxComplete(function() {
		if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Services")').hasClass('active')){
			handleServices();
		}
		if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Models")').hasClass('active')){
			handleModels();
		}
		if($('.tabs.js-tabs.tabs-responsive li[id*=accessibletabsnavigation]:contains("Options")').hasClass('active')){
			handleOptions();
		}
	});
}


if(plpURL.indexOf(plpSubstring) !== -1) {
	handlePLP();
}


var compareProductUrl = currentUrl;
var substring = "/product/compareProduct";

function productLengthCheck(){
	if($('.buttonClosingVisib:visible').length<=2){
		$('.buttonClosingVisib').hide();
	}
	return;
}

function removeProductfromsession(id,flag) {
	
	if(flag=="comparePLP"){
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListPLP'));
		removeProduct(id,flag,productCompareList)
		
	}else if(flag=="compareModels"){
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListModels'));
		removeProduct(id,flag,productCompareList)
	}else if (flag=="compareServices"){
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListServices'));
		removeProduct(id,flag,productCompareList)
	}else{
		
		productCompareList = JSON.parse(sessionStorage.getItem('productCompareListOptions'));
		
		removeProduct(id,flag,productCompareList)
	}
}


function setcomparelistinsessionstorage(flag,productCompareList){
	if(flag=="comparePLP"){
		sessionStorage.setItem('productCompareListPLP',JSON.stringify(productCompareList));
	}else if(flag=="compareModels"){
		sessionStorage.setItem('productCompareListModels',JSON.stringify(productCompareList));
	}else if (flag=="compareServices"){
		sessionStorage.setItem('productCompareListServices',JSON.stringify(productCompareList));
	}else{
		sessionStorage.setItem('productCompareListOptions',JSON.stringify(productCompareList));
	}
}


function removeProduct(id,flag,productCompareList){
	var indexOfProduct = productCompareList.map(function(e) { return e.productID; }).indexOf(id);
	if (indexOfProduct >= 0) {
		productCompareList.splice(indexOfProduct, 1);
	}
	setcomparelistinsessionstorage(flag,productCompareList)
}


if(compareProductUrl.indexOf(substring) !== -1) {

	$('.hpe-product-compare-card .buttonClosingVisib').on('click',function(){
		var getattrClass = $(this).attr('hideClass');
		var id = $(this).attr('id');
		var flag = sessionStorage.getItem('compareTableFlag');
		$(this).closest('.hpe-product-compare-card').hide();
		$(this).closest('thead').next().find('.'+getattrClass).hide();
		
		productLengthCheck(id,flag);
		removeProductfromsession(id,flag);
	});
	
	var referrerURL = document.referrer;
	var referrerURLsubstring = "/p/";
	if(referrerURL.indexOf(referrerURLsubstring) !== -1) {
		$('#pdpBackText').show();
	}else{
		$('#plpBackText').show();
	}
	
	$(document).ready(function(){
		if($('.buttonClosingVisib:visible').length<=2){
			$('.buttonClosingVisib').hide();
		}
	});
	
}
