var screenXs="480px";
var screenSm="640px";
var screenMd="1024px";
var screenLg="1400px";
  
var screenXsMin="480px";
var screenSmMin="640px";
var screenMdMin="1024px";
var screenLgMin="1400px";

var screenXsMax="639px";
var screenSmMax="1023px";
var screenMdMax="1399px";