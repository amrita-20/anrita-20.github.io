import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalStorageComponent } from './internal-storage.component';

describe('InternalStorageComponent', () => {
  let component: InternalStorageComponent;
  let fixture: ComponentFixture<InternalStorageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternalStorageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalStorageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
