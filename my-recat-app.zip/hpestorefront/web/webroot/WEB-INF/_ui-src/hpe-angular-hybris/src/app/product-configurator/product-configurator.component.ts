import { Component, ViewChild, OnInit, ElementRef, HostListener, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { CurrentConfigurationComponent } from '../current-configuration/current-configuration.component';
declare var jquery: any;
declare var $: any;
import { ProductServicesService } from '../product-services.service';
import { Options } from 'selenium-webdriver/edge';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'app-product-configurator',
  templateUrl: './product-configurator.component.html',
  styleUrls: ['./product-configurator.component.css']
})
export class ProductConfiguratorComponent implements OnInit, OnChanges {

  @ViewChild(CurrentConfigurationComponent) currComp: CurrentConfigurationComponent;
  channelJSON: any;
  realData: any;
  text: any;
  basePrice: any = 0.00;
  noData: Boolean = false;
  loading: Boolean = false;
  owlCounter: any = 3;
  archiveConfigurator: any = {};
  productConfigurator: any = {};
  variantcode: any;
  imageUrl:  any;
  countryCode:any;
  countryLang:  {[key: string]: string} ;

  constructor(private eRef: ElementRef, private route: ActivatedRoute,
    private productService: ProductServicesService,private translate: TranslateService) {
    this.setLanguage();
  }
  changeLang(lang: string) {
    this.translate.use(lang);
  }

  ngOnInit() {
    this.init();
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log('changes: ', changes);
  }   
  @HostListener('document:click', ['$event'])
  clickout(event) {
    let target_element = event.srcElement || event.target || event.option;
    // this.variantcode = target_element.getAttribute('variantcode');
    if (this.eRef.nativeElement.contains(event.target)) {
      this.text = "clicked inside";
    } else {

    if (target_element.className && typeof target_element.className === 'string' && target_element.className.indexOf("hpe-customize-link") >= 0) {
     // if (true) {
        //this.init();
        this.variantcode = target_element.getAttribute('variantcode');
        this.resetConfiguration();
        this.text = "clicked customize Link";
        /*   this.noData = false;
          this.loading = true;
          this.getProductChannelData(target_element.getAttribute("variantcode")); */
      }
      this.text = "clicked outside";
    }
  }
  checkData() {
    console.log('productConfigurator: ', this.productConfigurator);
  }

  init() {
    console.log('in init: ');
    this.channelJSON = [];
    this.archiveConfigurator = {};
    this.productConfigurator = {
      currentTab: '',
      tabs: {
        CPU_MEM: {
          exists: false,
          data: {},
          configured: []
        },
        MEM: {
          exists: false,
          data: {},
          configured: []
        },
        DRV: {
          exists: false,
          data: {},
          configured: []
        },
        XCVR: {
          exists: false,
          data: {},
          configured: []
        },
        CAB: {
          exists: false,
          data: {},
          configured: []
        },
        MOD: {
          exists: false,
          data: {},
          configured: []
        },
        ACC: {
          exists: false,
          data: {},
          configured: []
        },
        SOF: {
          exists: false,
          data: {},
          configured: []
        },
        OS: {
          exists: false,
          data: {},
          configured: []
        },
        SUP: {
          exists: false,
          data: {},
          configured: []
        },
        MAN: {
          exists: false,
          data: {},
          configured: []
        },
        PSU: {
          exists: false,
          data: {},
          configured: []
        },
        TAP: {
          exists: false,
          data: {},
          configured: []
        },
        MED: {
          exists: false,
          data: {},
          configured: []
        },
        CON: {
          exists: false,
          data: {},
          configured: []
        },
        OTH: {
          exists: false,
          data: {},
          configured: []
        }
      }
    };
  }

  getProductChannelData(variantcode) {
   // var query = $('.hpe-channelcentral' + variantcode).serialize();
    var query = 'variantCode='+variantcode;
    var shopName = $('.shopName' + variantcode + ' option:selected').attr('name');
    if (shopName) {
      query += '&shopName=' + shopName;
    }
    var basePrice = $('.variantPrice_' + variantcode + ' code').attr('price');
    if (basePrice) {
      this.basePrice = basePrice;
    }
    this.productService.getChannelData(query).subscribe(
      (data) => {
        this.loading = false;
        if (!data) {
          this.init();
          this.noData = true;
          //JSON.parse(JSON.stringify(this.productService.getSampleChannel().baseUnits[0].attachPattern.categories));
        }
        else {
          if (typeof data === 'string') {
            data = JSON.parse(data);
          }

          this.realData = data;
          this.imageUrl  =  this.realData.imageData  ?  this.realData.imageData.url  :  '';
          this.countryCode = this.realData.country;          

          console.log('finally:', data);
          if (!data["baseUnits"].length) {
            this.init();
            this.noData = true;
          }
          else {
            this.channelJSON = JSON.parse(JSON.stringify(data["baseUnits"][0].attachPattern.categories));
            this.configureChannels();
            this.owlTry();
          }
          if (data["baseUnits"].length > 0 && data["baseUnits"][0]["attachPattern"]["categories"].length > 0) {
            this.noData = true;
            for (let i = 0; i < data["baseUnits"][0]["attachPattern"]["categories"].length; i++) {
              let data_i = data["baseUnits"][0]["attachPattern"]["categories"][i];
              if (data_i["optionGroups"].length > 0 || data_i["options"].length > 0) {
                this.noData = false;
              }
            }
          }
        }
      },
      (error) => {
        console.log('error in testing: ', error);
        this.loading = false;
        this.noData = true;
      }
    );
  }

  owlTry() {
    var self = this;
    setTimeout(function () {
      $('.channel-central-tabs').owlCarousel('destroy').owlCarousel({
        loop: false,
        nav: true,
        dots: false,
        navText: ['\n    <svg class="hpe-icon">\n      <use xlink:href="#icon-previous" />\n    </svg>\n    ', '\n    <svg class="hpe-icon">\n      <use xlink:href="#icon-next" />\n    </svg>'],
        autoWidth: false,
        width:224,
        margin: 20,
        responsive: {
          0: {
            items: 2,
            nav: true
          },
          420: {
            items: 3,
            nav: true
          },
          1024: {
            items: 4
          },
          1100: {
            items: 5
          }
        }
      });
      self.owlCounter--;
      if (self.owlCounter > 0) {
        self.owlTry();
      }
    }, 1000);
  }

  hasOptions(category) {
    let optionsFound = 0;
    switch (category.code) {
      case "CPU_MEM":
        if (category.optionGroups && category.optionGroups.length) {
          for (var i = 0; i < category.optionGroups.length; i++) {
            if (category.optionGroups[i].groupMembers && category.optionGroups[i].groupMembers.length) {
              optionsFound++;
            }
          }
        }
        break;
      default:
        if (category.options && category.options.length) {
          optionsFound++;
        }

    }
    return optionsFound;
  }

  configureChannels() {
    let  self  =  this;
    let  tabIndexArr: any = [];
    let  tabIndex: number = 0;
    this.productConfigurator.currentTab  =  "";
    if  (this.channelJSON.length) {
      this.channelJSON.forEach(function  (item) {
        if  (self.productConfigurator.tabs[item.code]) {
          self.productConfigurator.tabs[item.code].exists  =  (item.code  &&  self.hasOptions(item));
          if (self.productConfigurator.tabs[item.code].exists) {
            tabIndexArr[tabIndex++] =
              self.productConfigurator.currentTab  =  item.code;
               // Data loaded for included configuration
           /*  for (var i = 0; i < item.options.length; i++) {
              item.quantity = 0;
              item.options[i].sortIndex = 1;
              item.options[i].memberQty = 0;
            } */
            item.quantity = 0;
            for (var i = 0; i < item.options.length; i++) {
              item.quantity += item.options[i].installedQty;
            }
            // 
          }
          self.productConfigurator.tabs[item.code].data  =  item;
        }
      }
      );
      self.productConfigurator.currentTab  =  tabIndexArr.length > 0 ? tabIndexArr[0] : "";
      $('.channel-central-tabs').owlCarousel('destroy').owlCarousel({
        loop: false,
        nav: true,
        dots: false,
        navText: ['\n    <svg class="hpe-icon">\n      <use xlink:href="#icon-previous" />\n    </svg>\n    ', '\n    <svg class="hpe-icon">\n      <use xlink:href="#icon-next" />\n    </svg>'],
        autoWidth: true
      });
    }

    //  for(var j = 0; j<self.channelJSON.length;j++){
    //      for(var i=0;i<self.productConfigurator.tabs;i++){
    //         if(self.productConfigurator.tabs[self.channelJSON[i].code] == self.channelJSON[j].code){
    //           console.log(self.channelJSON[i].code, self.productConfigurator.tabs[self.channelJSON[i].code], self.channelJSON[j].code);
    //           self.useTab(self.channelJSON[i].code);
    //           break;
    //         }
    //      }
    // }
    // for (var i = 0; i < self.channelJSON.length; i++) {
    //   console.log(self.channelJSON[i].code +"This is current");
    //   // if(self.productConfigurator.tabs[self.channelJSON[i].code].exists){
    //   if (self.productConfigurator.tabs[self.channelJSON[i].code]) {
    //     self.useTab(self.channelJSON[i].code);
    //     break;
    //  }
    //}
    this.archiveConfigurator = JSON.parse(JSON.stringify(this.productConfigurator));
  }
  cancelConfiguration() {
    //this.resetConfiguration();
    this.productConfigurator.currentTab = "";
    $('.hpe-card.hpe-card--details.variant-item-cr').removeClass('hpe-card--active');
  }
  resetConfiguration() {
    this.init();
    this.noData = false;
    this.loading = true;
    this.getProductChannelData(this.variantcode);
  }

  /*   resetConfiguration() {
      console.log('in resetConfiguration');
      this.productConfigurator.currentTab = "";
      this.productConfigurator = JSON.parse(JSON.stringify(this.archiveConfigurator));
      var self = this;
      for (var i = 0; i < self.channelJSON.length; i++) {
       // if (self.productConfigurator.tabs[self.channelJSON[i].code].exists) {
        if (self.productConfigurator.tabs[self.channelJSON[i].code]) {
          self.useTab(self.channelJSON[i].code);
          break;
        }
      }
      console.log('after reset ');
      setTimeout(function () { self.currComp.prepareDataToPost() }, 1000);
      this.ngOnInit();
    } */

  internalDataAdded(internalData: any) {
    this.productConfigurator.tabs.DRV.data = internalData;
    this.currComp.prepareDataToPost();
  }
  cpuMemoryAdded(cpuMemoryData: any) {
    console.log('in cpuMemoryAdded');
    this.productConfigurator.tabs.CPU_MEM.data = cpuMemoryData;
    this.currComp.prepareDataToPost();
  }
  osDataAdded(osData: any) {
    this.productConfigurator.tabs.OS.data = osData;
    this.currComp.prepareDataToPost();
  }
  manDataAdded(manData: any) {
    this.productConfigurator.tabs.MAN.data = manData;
    this.currComp.prepareDataToPost();
  }
  psDataAdded(psData: any) {
    this.productConfigurator.tabs.PSU.data = psData;
    this.currComp.prepareDataToPost();
  }
  supportDataAdded(supportData: any) {
    this.productConfigurator.tabs.SUP.data = supportData;
    this.currComp.prepareDataToPost();
  }

  transDataAdded(transData: any) {
    this.productConfigurator.tabs.XCVR.data = transData;
    this.currComp.prepareDataToPost();
  }

  cabDataAdded(cabData: any) {
    this.productConfigurator.tabs.CAB.data = cabData;
    this.currComp.prepareDataToPost();
  }

  tapDataAdded(tapData: any) {
    this.productConfigurator.tabs.TAP.data = tapData;
    this.currComp.prepareDataToPost();
  }

  medDataAdded(medData: any) {
    this.productConfigurator.tabs.MED.data = medData;
    this.currComp.prepareDataToPost();
  }

  accDataAdded(accData: any) {
    this.productConfigurator.tabs.ACC.data = accData;
    this.currComp.prepareDataToPost();
  }

  conDataAdded(conData: any) {
    this.productConfigurator.tabs.CON.data = conData;
    this.currComp.prepareDataToPost();
  }

  modDataAdded(modData: any) {
    this.productConfigurator.tabs.MOD.data = modData;
    this.currComp.prepareDataToPost();
  }

  memDataAdded(memData: any) {
    this.productConfigurator.tabs.MEM.data = memData;
    this.currComp.prepareDataToPost();
  }

  softDataAdded(softData: any) {
    this.productConfigurator.tabs.SOF.data = softData;
    this.currComp.prepareDataToPost();
  }

  othDataAdded(othData: any) {
    this.productConfigurator.tabs.OTH.data = othData;
    this.currComp.prepareDataToPost();
  }

  useTab(tab) {
    this.productConfigurator.currentTab = tab;
  }

  getTotalNumber(code) {
    var total = 0;

    if (this.productConfigurator.tabs.CPU_MEM.data.selectedIndex >= 0) {
      let attributes = this.productConfigurator.tabs.CPU_MEM.data.optionGroups[this.productConfigurator.tabs.CPU_MEM.data.selectedIndex].attributes;

      for (var i = 0; i < attributes.length; i++) {
        if (attributes[i].code === code) {
          total = attributes[i].value;
        }
      }
    }
    return total;
  }
  getInternalStorageSlots() {
    var slots = 0;
    var options = this.productConfigurator.tabs.DRV.data.options;
    if (options != undefined) {
      for (var i = 0; i < options.length; i++) {
        slots += options[i].installedQty;
      }
    }
    return slots;
  }
  getMaxInternalStorage() {
    if (this.productConfigurator.tabs.DRV.data.maxQty != undefined) {
      return this.productConfigurator.tabs.DRV.data.maxQty;
    }
  }

  getInternalStorageQuantity() {
    var storage = 0;
    var options = this.productConfigurator.tabs.DRV.data.options;
    if (options != undefined) {
      for (var i = 0; i < options.length; i++) {
        var qty = options[i].installedQty;
        if (qty) {
          storage += qty * options[i].attributes[0].value;
        }
      }
    }
    if (storage > 1024) {
      return (storage / 1024).toFixed(1) + ' TB';
    }
    else {
      return storage + 'GB';
    }
  }

  getMaxCPUMemoryProperty(keyAttribute) {
    var value = 0;
    var components = this.productConfigurator.tabs.CPU_MEM.data.components;
    for (var i = 0; i < components.length; i++) {
      if (components[i].keyAttribute === keyAttribute) {
        value = components[i].maxQty;
        break;
      }
    }
    return value;
  }

  getInstalledQty(component) {
    var qty = 0;
    if (!(this.productConfigurator.tabs.CPU_MEM.data.selectedIndex >= 0)) {
      this.productConfigurator.tabs.CPU_MEM.data.selectedIndex = 0;
    }
    if (this.productConfigurator.tabs.CPU_MEM.data.selectedIndex >= 0) {
      let members = this.productConfigurator.tabs.CPU_MEM.data.optionGroups[this.productConfigurator.tabs.CPU_MEM.data.selectedIndex].groupMembers;
      for (var i = 0; i < members.length; i++) {
        if (members[i].component === component) {
          qty += (members[i].installedQty + members[i].memberQty);
        }
      }
    }
    return qty;
  }

setLanguage(){
    this.countryLang = {US:'channelcentral_en', BE: 'channelcentral_fr', DE: 'channelcentral_de', AU:'channelcentral_en'};
    let langs:string[] = [];
    for(let key in this.countryLang){
      langs.push(this.countryLang[key]);  
    }
    this.translate.addLangs(langs);
    this.translate.setDefaultLang(this.countryLang['US']);
    this.translate.use(this.countryLang['US']);
}
}