import { Injectable, EventEmitter, OnInit } from "@angular/core";
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Router } from "@angular/router";
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductServicesService {

  httpOptions: any;
  constructor(private http: HttpClient, private router: Router) { }

  // configUrl = 'assets/data/44291_1008605458.json';

  gethttpHeaders() {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.httpOptions;
  }
  getChannelData(params) {
    // return this.http.get(this.configUrl);
    //return this.http.get(location.href + '/customizeItem?' + params);
    return this.http.get(location.origin + location.pathname + '/customizeItem?' + params);
      //return this.http.get('assets/data/memory_data.json');
    //return this.http.get('assets/data/master_data.json'); 
  }

  postChannelData(data) {
    let temp = JSON.parse(JSON.stringify(data));
    if (Array.isArray(temp["baseUnits"]) && temp["baseUnits"].length > 0 && temp["baseUnits"][0]["attachPattern"] && Array.isArray(temp["baseUnits"][0]["attachPattern"]["categories"]) && temp["baseUnits"][0]["attachPattern"]["categories"].length > 0) {
      for (let i = 0; i < temp["baseUnits"][0]["attachPattern"]["categories"].length; i++) {
        let temp_i = temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"];
        if (temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"] && Array.isArray(temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"]) && temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"].length > 0) {

          for (let current = 0; current < temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"].length; current++) {
            if (temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["memberQty"]) {
              temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["installedQty"] = temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["installedQty"] - temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["memberQty"];
              console.log("installedqty= " + temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["installedQty"], "memberQty= " + temp["baseUnits"][0]["attachPattern"]["categories"][i]["options"][current]["memberQty"])
            }
          }
        }
      }
    }
    // console.log('body: ', temp);
    const body = JSON.stringify(temp);
    console.log('Printing post data url here' + location.origin + location.pathname + 'customizeItem');
   // var ctxPath = ACC.config.encodedContextPath || '';
   //console.log('ctxpath prints here'+ ACC.config.encodedContextPath || '');
const BASE_URL = location.protocol+'//'+location.hostname+ (window.location.port ? ':' + window.location.port : '');
console.log('base url angular print' + BASE_URL);
    var getpath = location.pathname.split('/');
        getpath.length = 3;
    console.log('rinting post data url here');
    if(data.isQuotePage == true){
      //var productCodePostToString = JSON.stringify({ productCodePost: body, flag: 'channelCentral' });
      return this.http.post(location.origin + getpath.join('/') + '/getQuotePage/customizeItem', body , this.gethttpHeaders());
    }else{
      return this.http.post(location.origin + '/us/en/cart/add/customizeItem', body, this.gethttpHeaders());
    } 
  }
}
