import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { ProductConfiguratorComponent } from './product-configurator/product-configurator.component';
import { EmptyComponent } from './empty/empty.component';

import { OwlModule } from 'ngx-owl-carousel';
import { ProductServicesService } from './product-services.service';
import { OrderByPipe } from './order-by.pipe';
import { ProcessorMemoryComponent } from './processor-memory/processor-memory.component';
import { InternalStorageComponent } from './internal-storage/internal-storage.component';
import { OperatingSystemsComponent } from './operating-systems/operating-systems.component';
import { ManagementSoftwareComponent } from './management-software/management-software.component';
import { SupportComponent } from './support/support.component';
import { CurrentConfigurationComponent } from './current-configuration/current-configuration.component';
import { PowerSupplyComponent } from './power-supply/power-supply.component';
import { TransceiversComponent } from './transceivers/transceivers.component';
import { CablesComponent } from './cables/cables.component';
import { MediaComponent } from './media/media.component';
import { AdditionalDrivesComponent } from './additional-drives/additional-drives.component';
import { AccessoriesComponent } from './accessories/accessories.component';
import { ControllerComponent } from './controller/controller.component';
import { ExpansionModulesComponent } from './expansion-modules/expansion-modules.component';
import { SoftwareComponent } from './software/software.component';
import { MemoryComponent } from './memory/memory.component';
import { OtherComponent } from './other/other.component';
import {TranslateModule,TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';

const appRoutes: Routes = [
  { path: '**', component: ProductConfiguratorComponent }
];

export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, "_ui/custom/hpe-angular-hybris/dist/assets/i18n/", ".json");
}

@NgModule({
  declarations: [
    AppComponent,
    ProductConfiguratorComponent,
    EmptyComponent,
    ProcessorMemoryComponent,
    InternalStorageComponent,
    OperatingSystemsComponent,
    ManagementSoftwareComponent,
    SupportComponent,
    CurrentConfigurationComponent,
    PowerSupplyComponent,
	  TransceiversComponent,
    CablesComponent,
	  MediaComponent,
    AdditionalDrivesComponent,
    AccessoriesComponent,
    ControllerComponent,
    ExpansionModulesComponent,
  	OrderByPipe,
  	SoftwareComponent,
  	MemoryComponent,
  	OtherComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    OwlModule,
    RouterModule.forRoot(appRoutes),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [ProductServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
