import { Component, OnInit, EventEmitter, Input, Output, NgZone, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-processor-memory',
  templateUrl: './processor-memory.component.html',
  styleUrls: ['./processor-memory.component.css']
})
export class ProcessorMemoryComponent implements OnInit, OnChanges {
  @Input() componentData: any;
  @Input()  imageUrl: any;
  @Input() countryCode: any;
  @Input() currency:any;
  @Output() itemsAdded: EventEmitter<any> = new EventEmitter<any>();
  maxCoreSlot: any = 0;
  maxMemorySlot: any = 0;
  bundleIndex: any = 0;
  constructor() { }

  ngOnInit() {
    this.maxCoreSlot = this.getMaxProperty("COR");
    this.maxMemorySlot = this.getMaxProperty("MCAP");
    if (!(this.componentData.selectedIndex >= 0)) {
      this.bundleSelected(0);
    } else {
      this.bundleSelected(this.componentData.selectedIndex);
    }
  }
  ngOnChanges(changes: SimpleChanges) {
    this.ngOnInit();
  }

  getMaxProperty(keyAttribute) {
    var value = 0;
    for (var i = 0; i < this.componentData.components.length; i++) {
      if (this.componentData.components[i].keyAttribute === keyAttribute) {
        value = this.componentData.components[i].maxQty;
        break;
      }
    }
    return value;
  }

  getTotalPrice() {
    let price = 0;
    if (this.componentData.selectedIndex > 0) {
      let groupMembers = this.componentData.optionGroups[this.componentData.selectedIndex].groupMembers;
      for (var i = 0; i < groupMembers.length; i++) {
        price += groupMembers[i].price * groupMembers[i].memberQty;
      }
    }
    return price.toFixed(2);
  }

  getNumArray(n) {
    var ar = [];
    for (var i = 0; i < n; i++) {
      ar.push(i + 1);
    }
    return ar;
  }

  getTotalNumber(code) {
    var total = 0;
    if (this.componentData.selectedIndex >= 0) {
      let attributes = this.componentData.optionGroups[this.componentData.selectedIndex].attributes;
      for (var i = 0; i < attributes.length; i++) {
        if (attributes[i].code === code) {
          total = attributes[i].value;
        }
      }
    }
    return total;
  }

  getInstalledQty(component) {
    var qty = 0;
    if (this.componentData.selectedIndex >= 0) {
      let members = this.componentData.optionGroups[this.componentData.selectedIndex].groupMembers;
      for (var i = 0; i < members.length; i++) {
        if (members[i].component === component) {
          qty += (members[i].installedQty + members[i].memberQty);
        }
      }
    }
    return qty;
  }

  coreSlotRemaining() {
    return this.maxCoreSlot - this.getInstalledQty('CPU');
  }

  memorySlotRemaining() {
    return this.maxMemorySlot - this.getInstalledQty('MEM');
  }

  bundleSelected(index) {
    this.componentData.selectedIndex = index;
    this.itemsAdded.emit(this.componentData);
    this.bundleIndex = index;
  }

}
