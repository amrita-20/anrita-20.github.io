import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessorMemoryComponent } from './processor-memory.component';

describe('ProcessorMemoryComponent', () => {
  let component: ProcessorMemoryComponent;
  let fixture: ComponentFixture<ProcessorMemoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessorMemoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessorMemoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
