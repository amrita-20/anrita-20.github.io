import { Component, OnInit, EventEmitter, Input, Output, NgZone, OnChanges } from '@angular/core';
import { OrderByPipe } from '../order-by.pipe';

@Component({
  selector: 'app-internal-storage',
  templateUrl: './internal-storage.component.html',
  styleUrls: ['./internal-storage.component.css'],
  providers: [OrderByPipe]
})
export class InternalStorageComponent implements OnInit {
  @Input() componentData: any;
  @Input()  imageUrl: any;
  @Input() countryCode: any;
  @Input() currency:any;
  @Output() itemsAdded: EventEmitter<any> = new EventEmitter<any>();
  partNumber: any = "";
  partQty: any = 0;  
  partIndex: any = 1;
  selectedOption: any=null;
  reachedMaxQuantity: boolean = false;
  options;

  constructor(private zone: NgZone, public orderBy: OrderByPipe) { }

  ngOnInit() {
    this.initialize();
  }

  initialize(){
    this.componentData.quantity = 0;
    console.log("Inside memory ngOnInit()..." + this.componentData.quantity);
    for (var i = 0; i < this.componentData.options.length; i++) {
      this.componentData.quantity += this.componentData.options[i].installedQty;
     // console.log(this.componentData.options[i])
     this.componentData.options[i].sortIndex = 1;
    //  this.componentData.options[i].memberQty = 0;
    }
    /*if(!(this.componentData.selectedIndex>=0)){
      this.componentData.selectedIndex = this.partNumber = 0;
    }*/
    this.options = this.filterOptions();

    let index = this.getFirstNonZeroInstalledQuatityIndex();
    console.log("Index: " + index);
    this.componentData.selectedIndex = this.partNumber = index;

    this.selectedOption = this.componentData.options[this.componentData.selectedIndex];
    console.log(this.selectedOption);
    if (this.componentData.selectedIndex >=0) {
      this.selectedOption = this.componentData.options[this.componentData.selectedIndex];
      } else {
      this.selectedOption = "";
      } 
  }
  getFirstNonZeroInstalledQuatityIndex(){
    for (let index = 0; index < this.options.length; index++) {
      const element = this.options[index];
      if(element.installedQty > 0)
        return index;

    }
  }  
 isReachedmaxQuantity(){ 
    let remainingSlots = this.componentData.maxQty - this.componentData.quantity
	 if(remainingSlots == 0){
		 this.reachedMaxQuantity = true;
	 }else{
		 this.reachedMaxQuantity = false;
	 }
 }
  quantityRemaining() {
    if(this.componentData.quantity === undefined){
      console.log("Inside quantityRemaining()...UNDEFINED");
      this.initialize();
    }
    return this.componentData.maxQty - this.componentData.quantity;
  }

  getNumArray(n) {
    var ar = [];
    for (var i = 0; i < n; i++) {
      ar.push(i + 1);
    }
    return ar;
  }


 /*  getInstalledQty(component) {
    var qty = 0;
    if(this.componentData.selectedIndex>=0){
      let members = this.componentData.optionGroups[this.componentData.selectedIndex].groupMembers;    
      for(var i = 0; i<members.length;i++){
        if(members[i].component === component){
          qty+=(members[i].installedQty+members[i].memberQty);
        }
      }
    }
    return qty;
  } */
  getStorageQuantity(){
    var storage = 0;
    var options = this.componentData.options;
    for(var i = 0;i<options.length;i++){
      var qty = options[i].installedQty;
      if(qty){
        storage+=qty*options[i].attributes[0].value;
      }
    }
    if(storage>1024){
      return (storage/1024).toFixed(1)+' TB';
    }
    else{
      return storage+ 'GB';
    }
  }

  deductQty(part) {
    if (part.memberQty > 0) {
      part.installedQty--;
      part.memberQty--;
      this.componentData.quantity--;
      console.log("The value of  component minus quantity--" + this.componentData.quantity);
    }
   
    this.itemsAdded.emit(this.componentData);
    this.isReachedmaxQuantity();
    this.selectedOption="";
  }

  addQty(part) {
    if (this.componentData.quantity < this.componentData.maxQty) {
      part.installedQty++;
      this.partQty++;
      part.memberQty++;
      console.log("The value of part Qty--" + this.partQty, "The value of memberQty--" + part.memberQty,"The value of  mem Qty--" + part.memberQty);
      this.componentData.quantity++;
      this.itemsAdded.emit(this.componentData);
    }
    this.isReachedmaxQuantity();
  }

  addPartNumber(part, e) {
    if (part) {
      this.selectedOption = part;
      part.showInAdded = true;
      this.addQty(part);
      this.partIndex++;
      // part.sortIndex = this.partIndex;
      // this.orderBy.transform(this.componentData.options,'sortIndex');
      let index = this.componentData.options.findIndex(x => x.partNumber == part.partNumber);
      console.log("Added part index: " + index);
      this.componentData.selectedIndex= index;

      // this.itemsAdded.emit(this.componentData);
    }
    e.srcElement.selectedIndex = 0;
  }

  deletePart(part, e) {
    //e.stopPropagation();
    part.showInAdded = false;
    this.componentData.quantity -= part.installedQty;
    part.installedQty = 0;
    part.memberQty = 0;
    this.itemsAdded.emit(this.componentData);
    this.isReachedmaxQuantity();
	  this.ngOnInit();
    this.selectedOption="";
  }

  getTotalPrice() {
    let price = 0;
    var options = this.componentData.options;
    for (var i = 0; i < options.length; i++) {
      price += options[i].price * options[i].installedQty;
    }
    return price.toFixed(2);
  }

  filterOptions() {
   // return this.componentData.options.filter(x => x.installedQty > 0);
   return this.componentData.options.filter(x => this.componentData.maxQty > 0);
  }
  getPrice(option){
    console.log("Get Price: " + option);
    let price = "0.00";
    
    if(option && option.memberQty != 0){
        price = (option.memberQty * option.price).toFixed(2);
    }
     return price;
    }
}
