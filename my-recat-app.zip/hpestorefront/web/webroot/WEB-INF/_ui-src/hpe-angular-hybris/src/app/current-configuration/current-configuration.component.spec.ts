import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentConfigurationComponent } from './current-configuration.component';

describe('CurrentConfigurationComponent', () => {
  let component: CurrentConfigurationComponent;
  let fixture: ComponentFixture<CurrentConfigurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
