import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalDrivesComponent } from './additional-drives.component';

describe('AdditionalDrivesComponent', () => {
  let component: AdditionalDrivesComponent;
  let fixture: ComponentFixture<AdditionalDrivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalDrivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalDrivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
