import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpansionModulesComponent } from './expansion-modules.component';

describe('ExpansionModulesComponent', () => {
  let component: ExpansionModulesComponent;
  let fixture: ComponentFixture<ExpansionModulesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpansionModulesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpansionModulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
