import { HttpClient} from '@angular/common/http';
import {
  Component, OnInit, EventEmitter, Input, Output, NgZone,
  OnChanges, SimpleChanges, SimpleChange
} from '@angular/core';

import { ProductServicesService } from '../product-services.service';

@Component({
  selector: 'app-current-configuration',
  templateUrl: './current-configuration.component.html',
  styleUrls: ['./current-configuration.component.css']
})
export class CurrentConfigurationComponent implements OnInit, OnChanges {
  @Input() realData: any;
  @Input() productConfigData: any;
  @Input() basePrice: any;
  @Input() countryCode: any;
  @Input() currency:any;
  displaySpinner: Boolean = false;
  actualData: any;
  totalPrice: any = 0;
  assemblyPrice: any = 0.00;
  showbasePrice : Boolean = true;
  showAssemblyPrice : Boolean = true;
  showTotalPrice : Boolean = true;
  showConfiguredTotalPrice : Boolean = true;
  configuredTotalPrice: any = 0;
  isQuotePage : Boolean = false;
  constructor(private productService: ProductServicesService,
  private http: HttpClient) { }

  ngOnInit() {
    this.prepareDataToPost(); 
    this.checkPrices(); 
  }
  addToCart(el) {
    this.prepareDataToPost();
    this.postConfiguredData();    
  }
  getQuote(el) {  
   this.isQuotePage = true;
   this.prepareDataToPost();
   this.postConfiguredData();
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log('changes: ', changes);

  }

  prepareDataToPost() {
    console.log('in prepareDataToPost');
    this.actualData = JSON.parse(JSON.stringify(this.realData));
    this.basePrice = this.actualData.baseUnits[0].price;
    this.configuredTotalPrice = 0;
    let actualCategories = this.actualData.baseUnits[0].attachPattern.categories;
    for (var i = 0; i < actualCategories.length; i++) {
      actualCategories[i].optionGroups = [];
      actualCategories[i].options = [];
    }
    let op = {};
    let tabs = Object.keys(this.productConfigData.tabs);
    for (var i = 0; i < tabs.length; i++) {
      switch (tabs[i]) {
        case 'CPU_MEM':
          if (this.productConfigData.tabs.CPU_MEM.data.selectedIndex > 0) {
            for (var j = 0; j < actualCategories.length; j++) {
              if (actualCategories[j].code == tabs[i]) {
                let optionConfigured = this.productConfigData.tabs.CPU_MEM.data.optionGroups[this.productConfigData.tabs.CPU_MEM.data.selectedIndex];
                actualCategories[j].optionGroups.push(optionConfigured);
                let groupMembers = optionConfigured.groupMembers;
                for (var p = 0; p < groupMembers.length; p++) {
                  this.configuredTotalPrice += groupMembers[p].price * groupMembers[p].memberQty;
                  this.assemblyPrice = groupMembers[p].assemblyFee.toFixed(2);
                }
              }
            }
          } else {
            this.assemblyPrice = 0.00;
          }
          break;
        default:
          let options = this.productConfigData.tabs[tabs[i]].data.options;
          if (options) {
            for (var j = 0; j < options.length; j++) {
              if (options[j].installedQty) {
                for (var k = 0; k < actualCategories.length; k++) {
                  if (actualCategories[k].code == tabs[i]) {
                    actualCategories[k].options.push(options[j]);
                    if (tabs[i] == 'PSU') {
                      if (options[j].memberQty) {
                        this.configuredTotalPrice += options[j].price * options[j].memberQty;
                        if (options[j].assemblyFee) {
                          this.assemblyPrice = options[j].assemblyFee.toFixed(2);
                        }
                      }
                    } else if (tabs[i] == 'MEM'|| tabs[i] == 'DRV' || tabs[i] == 'MOD' || tabs[i] == 'TAP' || tabs[i] == 'XCVR' || tabs[i] == 'MED' || tabs[i] == 'ACC' || tabs[i] == 'CON' || tabs[i] == 'SOF' || tabs[i] == 'OTH' || tabs[i] == 'SUP' || tabs[i] == 'MAN' || tabs[i] == 'OS') {
                      if (options[j].memberQty) {
                        this.configuredTotalPrice += options[j].price * options[j].memberQty;
                        if (options[j].assemblyFee) {
                          this.assemblyPrice = options[j].assemblyFee.toFixed(2);
                        }
                      }
                    } else {
                      this.configuredTotalPrice += options[j].price * options[j].installedQty;
                    }

                    if (tabs[i] == 'CPU_MEM') {
                      if (options[j].assemblyFee) {
                        this.assemblyPrice = options[j].assemblyFee.toFixed(2);
                      }
                    } 
                  }
                }
              }
            }
          }
      }
    }
    console.log('finally this.actualData : ', this.actualData);
    console.log('this.basePrice : ', this.basePrice);
    console.log('this.configuredTotalPrice : ', this.configuredTotalPrice);
    console.log('this.assemblyPrice : ', this.assemblyPrice);
    this.totalPrice = (parseFloat(this.basePrice) + this.configuredTotalPrice + parseFloat(this.assemblyPrice)).toFixed(2);
    this.actualData.baseUnits[0].totalPrice = this.totalPrice;
    this.checkPrices();
  }
  
  checkPrices(){
    this.showbasePrice =  (isNaN( this.basePrice ) || this.basePrice  == null || this.basePrice  == 0) ? false : true ; 
    this.showAssemblyPrice =  (isNaN( this.assemblyPrice ) || this.assemblyPrice  == null || this.assemblyPrice  == 0) ? false : true ; 
    this.showTotalPrice =  (isNaN( this.totalPrice ) || this.totalPrice  == null || this.totalPrice  == 0) ? false : true ; 
    this.showConfiguredTotalPrice =  (isNaN( this.configuredTotalPrice ) || this.configuredTotalPrice  == null || this.configuredTotalPrice  == 0) ? false : true ; 
  } 

  postConfiguredData() {
    this.prepareDataToPost();
    this.displaySpinner = true;
    this.actualData.isQuotePage = false;
    if( this.isQuotePage === true){
      this.actualData.isQuotePage = this.isQuotePage;
    }
    this.productService.postChannelData(this.actualData).subscribe(
      data => {
        // console.log('data: ', data);
        var path = location.pathname.split('/');
        path.length = 3;
        this.displaySpinner = false;
        if( this.actualData.isQuotePage == true){
        location.href = location.origin + path.join('/') + '/getquotepage';
        }else{
          location.href = location.origin + path.join('/') + '/cart';
        }
      },
      error => {
        console.log('error:', error);
        this.displaySpinner = false;
      }
    );
  }
  
  getConfiguredTotalPrice() {
    return this.configuredTotalPrice.toFixed(2);
  }
}
