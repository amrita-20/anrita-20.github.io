/**
 *
 */
package com.hpe.storefront.controllers.occ;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import com.hpe.facades.occ.HPECartsFacade;
import com.hpe.storefront.security.cookie.CartRestoreCookieGenerator;


/**
 * @author chenna
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class HPECartsControllerTest
{
	@InjectMocks
	@Spy
	private HPECartsController hpeCartsController;
	@Mock
	private CartRestoreCookieGenerator cartRestoreCookieGenerator;
	@Mock
	private HPECartsFacade hpeCartsFacade;
	@Mock
	private HttpServletRequest httpServletRequest;
	@Mock
	private HttpServletResponse httpServletResponse;
	private static final String CART_NOT_FOUND = "Cart Not Found";

	@Before
	public void setUp() throws Exception
	{
	}

	@Test
	public void noCartResponse()
	{
		final String cartResponse = hpeCartsController.getCartDetails(httpServletRequest, httpServletResponse);

		Assert.assertEquals(CART_NOT_FOUND, cartResponse);
	}

	@Test(expected = Exception.class)
	public void noCartResponseWhenTheCookieSizeIsEmpty()
	{
		when(hpeCartsFacade.getCartDetails(anyString())).thenThrow(new Exception());

		final String cartResponse = hpeCartsController.getCartDetails(httpServletRequest, httpServletResponse);

		Assert.assertEquals(CART_NOT_FOUND, cartResponse);
	}

}