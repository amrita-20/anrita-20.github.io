package com.hpe.storefront.controllers.pages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.commercefacades.user.UserFacade;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class HPEUserLoginControllerTest
{
	@InjectMocks
	@Spy
	private HPEUserLoginController hpeUserLoginController;
	@Mock
	private UserFacade userFacade;
	@Mock
	private HttpServletRequest httpServletRequest;
	@Mock
	private HttpServletResponse httpServletResponse;

	@Before
	public void setUp() throws Exception
	{
	}

	@Test
	public void anonymousUser()
	{
		doReturn(true).when(userFacade).isAnonymousUser();
		final Map<String, Boolean> response = hpeUserLoginController.isUserLoggedIn(httpServletRequest, httpServletResponse);

		assertFalse(response.get("hybris-store-logged-in"));
	}

	@Test
	public void loggedInUser()
	{
		doReturn(false).when(userFacade).isAnonymousUser();
		final Map<String, Boolean> response = hpeUserLoginController.isUserLoggedIn(httpServletRequest, httpServletResponse);

		assertTrue(response.get("hybris-store-logged-in"));
	}
}
