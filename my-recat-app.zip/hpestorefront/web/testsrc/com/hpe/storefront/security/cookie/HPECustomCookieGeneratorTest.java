/**
 *
 */
package com.hpe.storefront.security.cookie;

import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;


/**
 * @author chenna
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class HPECustomCookieGeneratorTest
{
	@InjectMocks
	@Spy
	private HPECustomCookieGenerator hpeCustomCookieGenerator;
	@Mock
	private HttpServletRequest httpServletRequest;

	@Before
	public void setUp() throws Exception
	{
	}

	@Test
	public void getDomainForLocalhost()
	{
		when(httpServletRequest.getServerName()).thenReturn("localhost");

		final String domain = hpeCustomCookieGenerator.getDomainForCookie(httpServletRequest);

		Assert.assertEquals("localhost", domain);
	}

	@Test
	public void getDomainForIP()
	{
		when(httpServletRequest.getServerName()).thenReturn("123.192.162.11");

		final String domain = hpeCustomCookieGenerator.getDomainForCookie(httpServletRequest);

		Assert.assertEquals("123.192.162.11", domain);
	}

	@Test
	public void getDomainForDotNet()
	{
		when(httpServletRequest.getServerName()).thenReturn("test.itcs.hpecorp.net");

		final String domain = hpeCustomCookieGenerator.getDomainForCookie(httpServletRequest);

		Assert.assertEquals("hpecorp.net", domain);
	}

	@Test
	public void getDomainForDotCom()
	{
		when(httpServletRequest.getServerName()).thenReturn("test.buy.hpe.com");

		final String domain = hpeCustomCookieGenerator.getDomainForCookie(httpServletRequest);

		Assert.assertEquals("hpe.com", domain);
	}
}
