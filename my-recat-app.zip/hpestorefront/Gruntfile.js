module.exports = function(grunt) {
    // Project configuration.
    grunt.loadNpmTasks('grunt-contrib-uglify-es');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-clean');
  
    grunt.initConfig({
      pkg: grunt.file.readJSON('package.json'),
      clean: ['web/webroot/_ui/dist/'],
  
      uglify:{
        build: {
          files: {
            'web/webroot/_ui/dist/js/all.min.js': [
              'web/webroot/_ui/responsive/common/js/enquire.min.js',
              'web/webroot/_ui/responsive/common/js/Imager.min.js',
              'web/webroot/_ui/responsive/common/js/purify.min.js',
              'web/webroot/_ui/responsive/common/js/jquery.blockUI-2.66.js',
              'web/webroot/_ui/responsive/common/js/jquery.colorbox-min.js',
              'web/webroot/_ui/responsive/common/js/jquery.form.min.js',
              'web/webroot/_ui/responsive/common/js/jquery.hoverIntent.js',
              'web/webroot/_ui/responsive/common/js/jquery.pstrength.custom-1.2.0.js',
              'web/webroot/_ui/responsive/common/js/jquery.syncheight.custom.js',
              'web/webroot/_ui/responsive/common/js/jquery.tabs.custom.js',
              'web/webroot/_ui/responsive/common/js/jquery-ui-1.12.1.min.js',
              'web/webroot/_ui/responsive/common/js/jquery.zoom.custom.js',
              'web/webroot/_ui/responsive/common/js/owl.carousel.custom.js',
              'web/webroot/_ui/responsive/common/js/jquery.tmpl-1.0.0pre.min.js',
              'web/webroot/_ui/responsive/common/js/jquery.currencies.min.js',
              'web/webroot/_ui/responsive/common/js/acc.address.js',
              'web/webroot/_ui/responsive/common/js/acc.autocomplete.js',
              'web/webroot/_ui/responsive/common/js/acc.carousel.js',
              'web/webroot/_ui/responsive/common/js/acc.cart.js',
              'web/webroot/_ui/responsive/common/js/acc.cartitem.js',
              'web/webroot/_ui/responsive/common/js/acc.checkout.js',
              'web/webroot/_ui/responsive/common/js/acc.checkoutsteps.js',
              'web/webroot/_ui/responsive/common/js/acc.cms.js',
              'web/webroot/_ui/responsive/common/js/acc.colorbox.js',
              'web/webroot/_ui/responsive/common/js/acc.common.js',
              'web/webroot/_ui/responsive/common/js/acc.forgottenpassword.js',
              'web/webroot/_ui/responsive/common/js/acc.global.js',
              'web/webroot/_ui/responsive/common/js/acc.hopdebug.js',
              'web/webroot/_ui/responsive/common/js/acc.imagegallery.js',
              'web/webroot/_ui/responsive/common/js/acc.langcurrencyselector.js',
              'web/webroot/_ui/responsive/common/js/acc.minicart.js',
              'web/webroot/_ui/responsive/common/js/acc.navigation.js',
              'web/webroot/_ui/responsive/common/js/acc.order.js',
              'web/webroot/_ui/responsive/common/js/acc.paginationsort.js',
              'web/webroot/_ui/responsive/common/js/acc.payment.js',
              'web/webroot/_ui/responsive/common/js/acc.paymentDetails.js',
              'web/webroot/_ui/responsive/common/js/acc.pickupinstore.js',
              'web/webroot/_ui/responsive/common/js/acc.product.js',
              'web/webroot/_ui/responsive/common/js/acc.productDetail.js',
              'web/webroot/_ui/responsive/common/js/acc.quickview.js',
              'web/webroot/_ui/responsive/common/js/acc.quote.js',
              'web/webroot/_ui/responsive/common/js/acc.consent.js',
              'web/webroot/_ui/responsive/common/js/acc.cookienotification.js',
              'web/webroot/_ui/responsive/common/js/acc.closeaccount.js',
              'web/webroot/_ui/responsive/common/js/acc.ratingstars.js',
              'web/webroot/_ui/responsive/common/js/acc.refinements.js',
              'web/webroot/_ui/responsive/common/js/acc.sanitizer.js',
              'web/webroot/_ui/responsive/common/js/acc.silentorderpost.js',
              'web/webroot/_ui/responsive/common/js/acc.tabs.js',
              'web/webroot/_ui/responsive/common/js/acc.termsandconditions.js',
              'web/webroot/_ui/responsive/common/js/acc.track.js',
              'web/webroot/_ui/responsive/common/js/acc.storefinder.js',
              'web/webroot/_ui/responsive/common/js/acc.futurelink.js',
              'web/webroot/_ui/responsive/common/js/acc.productorderform.js',
              'web/webroot/_ui/responsive/common/js/acc.savedcarts.js',
              'web/webroot/_ui/responsive/common/js/acc.multidgrid.js',
              'web/webroot/_ui/responsive/common/js/acc.quickorder.js',
              'web/webroot/_ui/responsive/common/js/acc.csv-import.js',
              'web/webroot/_ui/responsive/common/js/_autoload.js',
              'web/webroot/_ui/responsive/common/js/cms/*.js',
              'web/webroot/_ui/addons/**/responsive/common/js/*.js'
          ],
          'web/webroot/_ui/dist/js/adobeanalytics.min.js': ['web/webroot/_ui/custom/scripts/adobeanalytics.js'],
          'web/webroot/_ui/dist/js/theme.min.js':[
            'web/webroot/_ui/custom/scripts/toolkit.js',
              'web/webroot/_ui/custom/scripts/zip-code-validation.js',
            'web/webroot/_ui/custom/scripts/custom.js',
            'web/webroot/_ui/custom/scripts/productCompare.js'
          ]
        }
      }
      },
      cssmin: {
          build: {
            files: {
              'web/webroot/_ui/dist/css/theme.min.css': [ 'web/webroot/_ui/custom/styles/toolkit.css', 'web/webroot/_ui/custom/styles/custom.css'],
              'web/webroot/_ui/dist/css/addon.min.css': ['web/webroot/_ui/addons/**/responsive/common/css/*.css']
            }
          }
        },
        copy: {
          files: {
            cwd: 'web/webroot/_ui/',  // set working folder / root to copy
            src: ['**/*.woff'],           // copy all files and subfolders
            dest:'web/webroot/_ui/dist/fonts',   // destination folder
                       // required when using cwd
            flatten:true,
            expand:true
          }
        },
  
    });
    grunt.registerTask('default', ['clean','uglify', 'cssmin','copy']);
  
  }
