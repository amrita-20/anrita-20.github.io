import React, { Component } from "react";

import AboutAndAgenda from "../../components/AboutAndAgenda/AboutAndAgenda";
import Rules from "../../components/Rules/Rules";
import Ideas from "../../components/Ideas/Ideas";
import Teams from "../../components/Teams/Teams";

import { navigationLabels, buttonLabels } from "../../labels";

import { NavLink, HashRouter, Redirect } from "react-router-dom";

import { Route } from "react-router-dom";

import group from "../../_assets/images/group-5.svg";

import { Button } from "react-bootstrap";

class NavigationMenu extends Component {
  constructor() {
    super();
    this.state = {
      showStickyHeader: false,
    };
  }
  componentDidMount = () => {
    window.addEventListener("scroll", this.handleScroll);
    // document
    //   .getElementById("s4-workspace")
    //   .addEventListener("scroll", this.handleScroll);
  };

  componentWillUnmount = () => {
    window.removeEventListener("scroll", this.handleScroll);
    // document
    //   .getElementById("s4-workspace")
    //   .removeEventListener("scroll", this.handleScroll);
  };

  handleScroll = () => {
    const element = document.getElementById("bg-img");
    const rect = element.getBoundingClientRect();

    const isInViewPort = rect.top <= 0 && rect.bottom <= 0;

    this.setState({
      showStickyHeader: isInViewPort,
    });
  };

  render() {
    return (
      <div className="content-nav-wrapper">
        <HashRouter>
          <div
            className={` main-nav-container  header-wrapper ${
              this.state.showStickyHeader
                ? "full-width-header"
                : "container short-width-header"
            } `}
          >
            <div
              className={` main-nav-container  header-wrapper ${
                this.state.showStickyHeader
                  ? "container full-width-header-border"
                  : "short-width-header-border"
              } `}
            >
              {this.state.showStickyHeader && (
                <img src={group} responsive className="logo-icon-header" />
              )}
              <ul className="nav">
                <li>
                  <NavLink to="/AboutAndAgenda">
                    {navigationLabels.aboutAndAgenda}
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/rules">{navigationLabels.rules}</NavLink>
                </li>
                <li>
                  <NavLink to="/ideas">{navigationLabels.ideas}</NavLink>
                </li>
                {/* <li>
                  <NavLink to="/teams">{navigationLabels.teams}</NavLink>
                </li> */}
              </ul>
              {this.state.showStickyHeader && (
                <Button
                  variant="btn btn-primary button"
                  id="register-btn"
                  className="reg-btn"
                  onClick={() => {
                    window.open(
                      "https://deloittesurvey.deloitte.com/Community/se/3FC11B26435CDD49"
                    );
                  }}
                >
                  {buttonLabels.register}
                </Button>
              )}
            </div>
          </div>

          <Route
            exact
            path="/"
            render={() => <Redirect to="/AboutAndAgenda" />}
          />
          <Route path="/AboutAndAgenda">
            <div className="container agenda-container">
              <AboutAndAgenda></AboutAndAgenda>
            </div>
          </Route>
          <Route path="/rules">
            <div className="container rules-container">
              <Rules></Rules>
            </div>
          </Route>
          <Route path="/ideas">
            <div className="container ideas-container">
              <Ideas></Ideas>
            </div>
          </Route>
          <Route path="/teams">
            <div className="container ideas-container">
              <Teams></Teams>
            </div>
          </Route>
        </HashRouter>
      </div>
    );
  }
}

export default NavigationMenu;
