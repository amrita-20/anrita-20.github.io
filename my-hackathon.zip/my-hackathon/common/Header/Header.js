import React, { Component } from "react";
import group from "../../_assets/images/group-5.svg";
import tmtLogo from "../../_assets/images/tmt-logo-black.svg";
import background from "../../_assets/images/header_img.svg";
import { Button } from "react-bootstrap";
import { Player, ControlBar, BigPlayButton } from "video-react";
import ReactPlayer from "react-player/youtube";
import "./Header.css";
import { buttonLabels, headerLabels } from "../../labels";
import { teams_list } from "../../components/Teams/Teams.config";
import hacxVideo from "../../_assets/videos/hacx1.mp4";
import unmute from "../../_assets/images/mute_off.png";
import mute from "../../_assets/images/mute_on.png";

class Header extends Component {
  // const totalTeams = 24;
  // const getTeamsCount = () => {
  //   return totalTeams - teams_list.length;
  // };

  componentDidMount = () => {
    const elem = document.getElementById('unmuteButton');
    elem.addEventListener('click', this.handleVideoMute);  
  };

  handleVideoMute = () => {
    const elem = document.getElementById('hacx-video');
    elem.muted = !elem.muted;

    const btnElem = document.getElementById('unmuteButton');
    btnElem.src = elem.muted ? mute : unmute; 
  }

  render() {
    return (
      <div id="bg-img">
        <div className="container header-container">
          <div className="row">
            <div className="col-lg-12 ">
              <div className="logo-container">
                <img
                  src={group}
                  responsive
                  className="hacx-logo"
                  alt="Hacx Logo"
                />
                <img
                  src={tmtLogo}
                  responsive
                  alt="TMT Logo"
                  className="tmt-logo"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="container header-container">
          <div className=" header-text-container clearfix">
            <div className="header-text-wrapper">
              <div className="header-video-container">
                <video loop autoPlay muted id="hacx-video">
                  <source src={hacxVideo} type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
                <img
                  id = "unmuteButton"
                  className="mute-btn"
                  src={mute}
                  alt="mute"
                />
              </div>

              <div className="reg-btn-container">
                <Button
                  variant="btn btn-primary button"
                  id="register-btn"
                  className="reg-btn"
                  onClick={() => {
                    window.open(
                      "https://deloittesurvey.deloitte.com/Community/se/3FC11B26435CDD49"
                    );
                  }}
                >
                  {buttonLabels.register}
                </Button>
                {/* <div class="slots-left">{`Only ${getTeamsCount()} slots left`}</div> */}
                <div class="slots-left">{`Only 9 slots left!`}</div>
              </div>

              <div className="reg-btn-container-on-video">
                {/* <div class="slots-left">{`Only ${getTeamsCount()} slots left`}</div> */}

                <Button
                  variant="btn btn-primary button"
                  id="register-btn"
                  className="reg-btn"
                  onClick={() => {
                    window.open(
                      "https://deloittesurvey.deloitte.com/Community/se/3FC11B26435CDD49"
                    );
                  }}
                >
                  {buttonLabels.register}
                </Button>
                {/* <div class="slots-left">{`Only 9 slots left!`}</div> */}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Header;
