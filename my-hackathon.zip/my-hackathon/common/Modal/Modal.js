/* eslint-disable no-unused-expressions */
import React, { Component } from "react";
import PropTypes from "prop-types";
import { ideaLabels, teamsLabels } from "../../labels";
import closeIcon from "../../_assets/images/close.png";
import circleIcon from "../../_assets/images/circle-file.png";
import "./Modal.css";

class Modal extends Component {
  componentDidMount() {
    const { showModal } = this.props;
    if (showModal) {
      document.addEventListener("click", this.outsideClick);
    }
  }

  componentWillReceiveProps(newProps) {
    const { showModal } = newProps;
    if (this.props.showModal !== newProps.showModal) {
      if (showModal) {
        document.addEventListener("click", this.outsideClick);
      } else {
        document.removeEventListener("click", this.outsideClick);
      }
    }
  }
  componentWillUnmount() {
    document.removeEventListener("click", this.outsideClick);
  }

  outsideClick = (event) => {
    const selectedClass = event.target.className;
    if (
      (selectedClass === "idea-modal" && this.props.closeOnOutsideClick) ||
      selectedClass.includes("close-modal")
    ) {
      this.props.outsideAndCloseClick(event);
    }
  };
  render() {
    const { showModal, data, hasCloseButton } = this.props;
    return (
      <div className="modal-main-wrapper">
        {showModal && (
          <div className="idea-modal" id="modal">
            <div className="idea-modal-body">
              {data.sector && (
                <div class="container">
                  <div class="row">
                    <div className="col-lg-11 col-10">
                      <h4 className="teams-title">{data.title}</h4>
                    </div>
                    <div className="col-lg-1 col-2">
                      {hasCloseButton && (
                        <img
                          className="close-modal"
                          src={closeIcon}
                          alt="close "
                          width="30px"
                          height="30px"
                        />
                      )}
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-12">
                      <div className="sector-label-value">
                        <span className="idea-sector">
                          {ideaLabels.sector} :{" "}
                        </span>
                        <span className="idea-sector-val">{data.sector}</span>
                      </div>
                      <p className="idea-description">{data.description}</p>
                    </div>
                  </div>
                  <div className="idea-sector">{ideaLabels.idea_owners}</div>
                  <div class="row idea-member-wrapper">
                    {data.teamMember.map((team) => {
                      return (
                        <div className="col-lg-4 col-sm-4  col-12">
                          <a
                            href={`mailto: ${team.email}`}
                            className="name-picture-link"
                          >
                            <div className="name-picture-wrapper">
                              <div className="image">
                                <img
                                  className="circular-image"
                                  src={team.source}
                                  alt={team.name}
                                />
                              </div>
                              <div class=" idea-team-name idea-sector-val">
                                {team.name} ({team.domain})
                              </div>
                            </div>
                          </a>
                        </div>
                      );
                    })}
                  </div>
                  {/* <hr className="associated-teams-divider"></hr>
              <div className="idea-sector">{ideaLabels.asso_team}</div>
              <div class="row idea-asso-wrapper">
                {data.associatedTem.map((assTeam) => {
                  return (
                    <div className="col-lg-4 col-xs-12 name-picture-wrapper">
                      <div class=" associated-team-name idea-sector-val">
                        {assTeam}
                      </div>
                    </div>
                  );
                })}
              </div> */}
                </div>
              )}
              {data.associatedIdea && (
                <div class="container">
                  <div class="row">
                    <div class="col-lg-2 col-sm-3">
                      <img
                        className="circle-image"
                        src={circleIcon}
                        alt="close "
                        width="100px"
                        height="100px"
                      />
                    </div>
                    <div class="col-lg-9 col-sm-8 team-content-wrapper">
                      <div clas="row">
                        <h4 className="teams-title">{data.title}</h4>

                        <p className="idea-description">{data.description}</p>
                      </div>
                      <div className="idea-sector">
                        {teamsLabels.team_members}
                      </div>
                      <div class="row idea-member-wrapper">
                        {data.teamMember.map((team) => {
                          return (
                            <div className="col-lg-6 col-sm-12 col-12">
                              <a
                                href={`mailto: ${team.email}`}
                                className="name-picture-link"
                              >
                                <div className="name-picture-wrapper">
                                  <div className="image">
                                    <img
                                      className="circular-image"
                                      src={team.source}
                                      alt={team.name}
                                    />
                                  </div>
                                  <div class=" idea-team-name idea-sector-val">
                                    {team.name} ({team.domain})
                                  </div>
                                </div>
                              </a>
                            </div>
                          );
                        })}
                      </div>
                      <hr className="associated-teams-divider"></hr>
                      <div className="idea-sector">{teamsLabels.idea_ass}</div>
                      <div class="row idea-asso-wrapper">
                        <div class="col-lg-6 col-sm-12 col-12">{data.associatedIdea}</div>
                      </div>
                    </div>
                    <div className="col-lg-1 col-sm-1 col-2">
                      {hasCloseButton && (
                        <img
                          className="close-modal"
                          src={closeIcon}
                          alt="close "
                          width="30px"
                          height="30px"
                        />
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }
}
Modal.propTypes = {
  showModal: PropTypes.bool,
  closeOnOutsideClick: PropTypes.bool,
  outsideAndCloseClick: PropTypes.func,
  hasCloseButton: PropTypes.bool,
};

Modal.defaultProps = {
  showModal: false,
  closeOnOutsideClick: true,
  outsideAndCloseClick: () => {},
  hasCloseButton: true,
};
export default Modal;
