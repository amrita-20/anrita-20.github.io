import React from "react";
import { footerLabels } from "../../labels";

const Footer = () => {
  return (
    <footer className="footer">
      {footerLabels.footerText}{" "}
      <a href="mailto: tmthackathon2020@deloitte.com">
        {footerLabels.footerEmail}
      </a>{" "}
      {footerLabels.footerCopyright}
    </footer>
  );
};

export default Footer;
