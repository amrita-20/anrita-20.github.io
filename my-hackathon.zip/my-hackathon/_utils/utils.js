/* methodName: getShortNames,
    param:name:String,
    return: First letter of first and last words
    Returns First letter of first and last words to form the initials
    */
const getShortNames = (name) => {
  if (name) {
    var initials = name.match(/\b\w/g) || [];
    initials = (
      (initials.shift() || "") + (initials.pop() || "")
    ).toUpperCase();
    return initials;
  }
};

export { getShortNames };
