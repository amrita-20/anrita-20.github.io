const navigationLabels = {
  aboutAndAgenda: "What, Why & When",
  ideas: "IDEAS",
  teams: "TEAMS",
  contact: "CONTACT",
  rules: "RULES",
};

const buttonLabels = {
  register: "Register",
};

const ideaLabels = {
  sector: "SECTOR",
  idea_owners: "IDEA OWNERS",
  asso_team: "ASSOCIATED HACX TEAMS",
};
const teamsLabels = {
  team_members: "TEAM MEMBERS",
  idea_ass: "IDEA ASSOCIATED",
};
const headerLabels = {
  areYouReady: "Are you ready",
  buildForTomo: "to build for tomorrow",
};

const footerLabels = {
  footerText:
    " If you are facing any challenges or have a query, reach out to us at",
  footerEmail: " tmthackathon2020@deloitte.com",
  footerCopyright:
    " Copyright © 2020. Deloitte Development LLC. All rights reserved.",
};

const comingSoon = {
  comingSoon: "To be announced shortly..",
};

export {
  navigationLabels,
  buttonLabels,
  ideaLabels,
  footerLabels,
  teamsLabels,
  comingSoon,
  headerLabels,
};
