import React from "react";
import ReactDOM from "react-dom";
import Main from "./_main";

import "bootstrap/dist/css/bootstrap.min.css";

import "../../TMTHackathonWebsite/node_modules/video-react/dist/video-react.css";

import "./_styles/index.css";

ReactDOM.render(<Main />, document.getElementById("root"));
