import React, { Component, Fragment } from "react";
import NavigationMenus from "./common/NavigationMenus/NavigationMenu";

import Header from "./common/Header/Header";
import Footer from "./common/Footer/Footer";

class Main extends Component {
  constructor() {
    super();
    document.title = "TMT HacX";
  }

  componentDidMount = () => {
    var linkNodes = document.getElementsByTagName("link");
    if (linkNodes.length)
      linkNodes[0].href = "/sites/squad/SiteAssets/tmthackathon/fav.ico";
  };

  render() {
    return (
      <div className="main-container">
        <Header></Header>
        <NavigationMenus></NavigationMenus>
        <Footer></Footer>
      </div>
    );
  }
}

export default Main;
