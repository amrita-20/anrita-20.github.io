//Xtreme_Bot
import Praneetha from "../../_assets/images/Xtreme_Bot/bpraneetha.jpg";
import Tejdeep from "../../_assets/images/Xtreme_Bot/kvntejdeep.jpg";
import Chitra from "../../_assets/images/Xtreme_Bot/cvenkatachalapath.jpg";
import Jital from "../../_assets/images/Xtreme_Bot/jijacob.jpg";
import Mandala from "../../_assets/images/Xtreme_Bot/magoud.jpg";
//Convergers
import Alwala from "../../_assets/images/Convergers/ralwala.jpg";
import Hrishikesh from "../../_assets/images/Convergers/shrishikesh.jpg";
import Amit from "../../_assets/images/Convergers/amnage.jpg";
import Manav from "../../_assets/images/Convergers/msharatmehra.jpg";
import Pramodh from "../../_assets/images/Convergers/pgarnepalli.jpg";
//GamePixel
import Satya from "../../_assets/images/GamePixel/smudivarthi.jpg";
import Bharat from "../../_assets/images/GamePixel/brammurthy.jpg";
import Girish from "../../_assets/images/GamePixel/gzalpure.jpg";
//Ideaotic
import Naman from "../../_assets/images/Ideaotic/namjain.jpg";
import Venkatesh from "../../_assets/images/Ideaotic/vchalla.jpg";
import Neel from "../../_assets/images/Ideaotic/ndastidar.jpg";
import Vidya from "../../_assets/images/Ideaotic/pvidyavani.jpg";
//S4
import Pallavi from "../../_assets/images/S4/pamarathe.jpg";
import Sachin from "../../_assets/images/S4/sachinksingh.jpg";
//LogHealers
import Pankaj from "../../_assets/images/LogHealers/panmittal.jpg";
import Sanyogita from "../../_assets/images/LogHealers/srathore.jpg";
import Suraj from "../../_assets/images/LogHealers/spaintola.jpg";
import Samvedna from "../../_assets/images/LogHealers/ssaklani.jpg";
//Starformers
import Arunima from "../../_assets/images/Starformers/arunrath.jpg";
import Chetan from "../../_assets/images/Starformers/cmaduri.jpg";
import Rahul from "../../_assets/images/Starformers/rahdatta.jpg";
import Sankalp from "../../_assets/images/Starformers/sankasharma.jpg";
//Tech Crunch
import Praveen from "../../_assets/images/Tech Crunch/pbobbi.jpg";
import Srikant from "../../_assets/images/Tech Crunch/dsrikant.jpg";
import Arti from "../../_assets/images/Tech Crunch/asanagar.jpg";

const ideasList = [
  {
    title: "Xtreme Bot - Cognitive engagement in a digital customer journey",
    sector: "Technology",
    description: `Build enhancement modules for Xtreme Bot ( SFDC Einstein ) or a new AI powered BOT that showcases how businesses can leverage intelligent AI in customer portals to replicate human actions in interactions, and emulate human sensing & judgement. Bots can be used through the customer lifecycle from trials, conversion from try to buy, purchase etc. to proactively engage with the client, without manual engagement​`,
    teamMember: [
      {
        name: "Chitra Venkatachalapathy",
        domain: "C&M AM&C",
        source: Chitra,
        email: "cvenkatachalapath@deloitte.com",
      },
      {
        name: "Mandala Praveen Goud",
        domain: "C&M",
        source: Mandala,
        email: "magoud@deloitte.com",
      },
      {
        name: "B R Praneetha",
        domain: "C&M",
        source: Praneetha,
        email: "bpraneetha@deloitte.com",
      },
      {
        name: "V N Tejdeep Karamalaputty",
        domain: "C&M",
        source: Tejdeep,
        email: "kvntejdeep@deloitte.com",
      },
      {
        name: "Jita Susan Jacob",
        domain: "C&M AM&C",
        source: Jital,
        email: "jijacob@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  {
    title: "Convergers - Analytics - Auditing Invoicing Errors ",
    sector: "Telecom",
    description: `Build an analytical dashboard which encapsulates an aggregated presentation of billing errors with predesigned KPI’s which can drill down to individual invoice level for accurate RCA. It will reconcile information related to key fields of all invoices and show exceptions on a mismatch across multiple systems.​`,
    teamMember: [
      {
        name: "Raghavendra Alwala",
        domain: "SAP",
        source: Alwala,
        email: "ralwala@deloitte.com",
      },
      {
        name: "Manav Sharat Mehra",
        domain: "SAP",
        source: Manav,
        email: "msharatmehra@deloitte.com",
      },
      {
        name: "Pramodh Garnepalli",
        domain: "SAP",
        source: Pramodh,
        email: "pgarnepalli@deloitte.com",
      },
      {
        name: "S Hrishikesh",
        domain: "SAP",
        source: Hrishikesh,
        email: "shrishikesh@deloitte.com",
      },
      {
        name: "Amit Nage",
        domain: "SAP",
        source: Amit,
        email: "amnage@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  {
    title: "GamePixel - NextGen Gaming Ecosystem​",
    sector: "Entertainment",
    description: `Build a next generation solution to Gaming Industry that provides OnDemand access to personalized games using a cloud platform, enhancing the user experience of Gaming as a Service and removing the cost of ownership of gaming consoles. This platform may also leverage gaming data analytics, dashboards and chatbots to enhance the user experience. The idea can be extended to building an ML model to provide personalization and recommendations.​`,
    teamMember: [
      {
        name: "Satya Bharat Mudivarthi",
        domain: "CLOUDENG",
        source: Satya,
        email: "smudivarthi@deloitte.com",
      },
      {
        name: "Girish Zalpure",
        domain: "CLOUDENG",
        source: Girish,
        email: "gzalpure@deloitte.com",
      },
      {
        name: "Bharat Ram Murthy",
        domain: "SYSENG",
        source: Bharat,
        email: "brammurthy@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  {
    title: "Ideaotic Champions - ChatOps & Slack help bot Automation​",
    sector: "Entertainment",
    description: `Conventional approach to chatbots is to assist end users to provide at the first level and if bot fails then live agents assist user. However, this delays the resolution time and causes poor user experience. The idea is to build a plug and play system that enables bot and agent monitoring at the first level itself empowered by emojis and additional options. Now user has options to interact with bot and live agent using emojis. Teams can use stub systems to mock integrations if needed​​`,
    teamMember: [
      {
        name: "Neel Dastidar",
        domain: "TSO",
        source: Neel,
        email: "ndastidar@deloitte.com",
      },
      {
        name: "Naman Jain",
        domain: "CLOUDENG",
        source: Naman,
        email: "namjain@deloitte.com",
      },
      {
        name: "Venkatesh Challa",
        domain: "SYSENG",
        source: Venkatesh,
        email: "vchalla@deloitte.com",
      },
      {
        name: "Palli Vidya Vani",
        domain: "A&C",
        source: Vidya,
        email: "pvidyavani@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
{
    title: "S4 for Retail Stores - Simply Smart Store IoT System",
    sector: "Technology",
    description:`Simple Smart Store System (S4) is a solution for physical stores to provide enhanced customer service in the store. It aims at building an intelligent virtual assistant and an ecosystem around it that can be plugged into IOT devices, to enable generating analytics, insights and targetted offers. The teams may use stubs if needed in place of the IOT devices​​​​`,
    teamMember: [
      {
        name: "Pallavi Marathe",
        domain: "A&C",
        source: Pallavi,
        email: "pamarathe@deloitte.com",
      },
      {
        name: "Sachin Kumar K Singh",
        domain: "A&C",
        source: Sachin,
        email: "sachinksingh@deloitte.com",
      }
    ],
    associatedTem : [
     "Dysfunctional Pixels",
     "Mojo Dojos",
     "Coexistance is bliss"
    ]
  },
  {
    title: "LogHealers - Self-Healing Data Platform",
    sector: "Technology",
    description: `Error troubleshooting and debugging across different applications is human intensive and time consuming process. Idea is to  enhance features or to create a self healing data platform serving as the unified collaboration mechanism for enabling log insights with intelligent capabilities to predict errors, recommend error remediation and resolutions.​​​​`,
    teamMember: [
      {
        name: "Pankaj Mittal",
        domain: "A&C",
        source: Pankaj,
        email: "panmittal@deloitte.com",
      },
      {
        name: "Sanyogita Rathore",
        domain: "A&C",
        source: Sanyogita,
        email: "srathore@deloitte.com",
      },
      {
        name: "Suraj Paintola",
        domain: "A&C",
        source: Suraj,
        email: "spaintola@deloitte.com",
      },
      {
        name: "Samvedna Saklani",
        domain: "A&C",
        source: Samvedna,
        email: "ssaklani@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  {
    title: "Starformers - AI based OTT solution",
    sector: "Entertainment",
    description: `Production houses are facing loss of revenue and lack of content generation for during the present pandemic. Build an AI powered solution for production houses and OTT platforms to enrich video quality of old classic movies that can be leveraged in the present times and enable auto subtitling to enhance movie viewing experience.​​​​`,
    teamMember: [
      {
        name: "Chetan Maduri",
        domain: "SAP",
        source: Chetan,
        email: "cmaduri@deloitte.com",
      },
      {
        name: "Arunima Rath",
        domain: "SAP",
        source: Arunima,
        email: "arunrath@deloitte.com",
      },
      {
        name: "Rahul Datta",
        domain: "SAP",
        source: Rahul,
        email: "rahdatta@deloitte.com",
      },
      {
        name: "Sankalp Sharma",
        domain: "SAP",
        source: Sankalp,
        email: "sankasharma@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  {
    title: "Tech Crunch - D2M Platform - AI & ML to identify Genuine News",
    sector: "Media",
    description: `Build aintelligent digital media platform which can be used globally to avoid the pseudo news impacts on all sectors, general public and other industries. With this platform, media companies can differentiate between genuine and pseudo news. This will help improve accountability and credibility of the digital media with respect to the public and organizations spanning across different sectors.​`,
    teamMember: [
      {
        name: "Praveen Bhaskar Bobbi",
        domain: "Oracle",
        source: Praveen,
        email: "pbobbi@deloitte.com",
      },
      {
        name: "Dasagi Venkata Ramakrishn Srikant",
        domain: "Oracle",
        source: Srikant,
        email: "dsrikant@deloitte.com",
      },
      {
        name: "Arti Ashok Sanagar",
        domain: "Oracle",
        source: Arti,
        email: "asanagar@deloitte.com",
      },
    ],
    associatedTem: [
      "Dysfunctional Pixels",
      "Mojo Dojos",
      "Coexistance is bliss",
    ],
  },
  ];

const idea_heading = {
  ideas_title: `Ideas to make real!`,
  idea_desc: `TMT HacX is a platform to enable teams to nurture, build and showcase products, prototypes or assets for ideas seeded from TMT Xceed. These ideas span across technology,
   telecom, media, and entertainment and present specific business issues, solutions, and opportunities aimed at creating opportunities for both Customers, and Deloitte.`,
};

export { ideasList, idea_heading };
