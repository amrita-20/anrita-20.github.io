
const globalVars= {
    heading_rules: `Rules, Terms and Conditions`,
    label_registration: `Registration`,
    label_idea: `Idea Selection `,
    desc_registration1: `The registration for the hackathon would open on 29th July 2020 during the TMT Industry week. TMT HacX is a team-based event and the registration is limited to the first 24 teams that register. 2 additional teams would be allowed to register for the waitlist.`,
    desc_registration2: `If you are an individual who wants to participate and is looking to join a team, you can register yourself and we would work with you to identify if we can pair you with other individuals / teams. Participation is not guaranteed in this option.`,
    desc_idea_selection1: `During the registration for the event, you would get an option to choose the idea that your team wants to build during the event.`,
    desc_idea_selection2: `Each idea has an upper limit of teams that can register for. Teams can choose to provide their order of preference for up to three ideas. This will be used in case the max limit of team per idea is reached for your first preference.`,
    desc_idea_selection3: `For practitioners registering as individuals, Idea selection is mandatory and would be used by us to pair you with other teams / individuals who would have selected the same idea.`,
    label_terms_cond: `Terms and Conditions`,
};

const termsCond = [{
    title: "Teams:",
    desc: [
        "Team Size 2 - 6.",
        "Team composition can include designer(s), developer(s), and tester(s) based on solutions needs and rulesets.",
        "Team composition/members cannot change once registered.",
        "Ideas once chosen, cannot be exchanged."
    ]},
    {
        title: "What is needed for HacX?",
        desc: [
            "Deloitte laptop.",
            "Your skills.",
            "Communication channel (preferably Zoom)."
        ]
    },
    {   title: "What will be provided?",
        desc: [
            "Tech support for queries related to technology based on ideas (Microsoft Teams).",
            "Hosting environment.",
        ]
    },
    {   title: "Tech-stack & Environment",
        desc: [
            "This is an open hackathon. You can use any open source software (with proper vulnerability and security checks) to build your solution.",
            "Only Github based private repositories should be used for storing the code for your solution.",
            "Only AWS cloud platform should be used for hosting the hackathon solutions.",
            "Entire solution/application should be hosted. There should be no dependency on your local machine for any services.",
            "All solutions should be Dockerized.",
            "There is no restriction in IDE.",
            "Web browser compatibility - Chrome (Latest).",
            "iOS version >= OS 12.",
            "Android OS version - API v23 or Android 6.0."
        ]
    },
    {   title: "Acceptance Criteria",
        desc: [
            "Only end-to-end working solution is eligible for evaluation.",
            "Broken features will lose points."
        ]
    },
    {   title: "Documentation",
        desc: [
            "Presentation deck with technical stack details, architecture diagram and solution for the use case.",
            "README file (preferably, in Git Markdown format) should highlight basic flow, project setup and other deployment / executable details necessary to execute the solution."
        ]
    },

    {   title: "Bonus Points",
        desc: [
            "Presentation.",
            "User Experience."
        ]
    },

    {   title: "Evaluation",
        desc: [
            "The solution of each team is evaluated based on point system and bonus points."
        ]
    },
    {
        title: "Strict No-No",
        desc: [
            "No client datasets or client data should be used for any use case.",
            "No Deloitte/client data to be uploaded on any platforms (Deloitte approved / external).",
            "No PII information should be collected / stored (Use mock data instead)."
        ]
    }
]

export {globalVars, termsCond};