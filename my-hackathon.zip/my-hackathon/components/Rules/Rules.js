import React, { Component } from "react";
import peepIcon from "../../_assets/images/peep-standing-16.svg";
import { globalVars, termsCond } from "./Rules.config.js";
import "./Rules.css";

class Rules extends Component {
  render() {
    return (
      <div className="rules-main-wrapper">
        <img
          src={peepIcon}
          responsive
          className="peep-standing-16"
          alt="peep-standing"
        />
        <div className="row">
          <div className="col-lg-8 col-md-8 col-sm-12 col-xs-12">
            <h4 className="rules-label">{globalVars.label_registration}</h4>
            <p className="rules-description">
              {globalVars.desc_registration1} <br /> <br />
              {globalVars.desc_registration2}
            </p>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-8 col-md-8 col-sm-12 col-xs-12">
            <h4 className="rules-label">{globalVars.label_idea}</h4>
            <p className="rules-description">
              {globalVars.desc_idea_selection1} <br /> <br />
              {globalVars.desc_idea_selection2} <br /> <br />
              {globalVars.desc_idea_selection3}
            </p>
            <div>
              {termsCond.map((value) => {
                return (
                  <>
                    <h6 className="rules-title">{value.title}</h6>
                    <ul>
                      {value.desc.map((desc) => {
                        return <li className="rules-description">{desc}</li>;
                      })}
                    </ul>
                  </>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Rules;
