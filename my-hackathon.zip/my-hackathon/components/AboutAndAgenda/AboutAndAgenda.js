import React, { Component } from "react";
import ladyIcon from "../../_assets/images/group-3.svg";
import "./AboutAndAgenda.css";
import { globalVars } from "./AboutAndAgenda.config.js";

const schedule = [
  {
    date: globalVars.date1,
    eventName: globalVars.event_name1,
  },
  {
    date: globalVars.date2,
    eventName: globalVars.event_name2,
  },
  {
    date: globalVars.date3,
    eventName: globalVars.event_name3,
    description: globalVars.description1,
  },
  {
    date: globalVars.date4,
    eventName: globalVars.event_name4,
    description: globalVars.description2,
  },
  {
    date: globalVars.date5,
    eventName: globalVars.event_name5,
  },
];

class AboutAndAgenda extends Component {
  render() {
    return (
      <div className="row">
        <div className="col-lg-4">
          <div className="agenda-schedule">
            {schedule.map((anObjectMapped) => (
              <div className="agenda-mini">
                <div class="dots">
                  <div class="oval"></div>
                  <p className="agenda-date">{anObjectMapped.date}</p>
                </div>
                <p className="agenda-event">{anObjectMapped.eventName}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="col-lg-8 ">
          <div className="agenda-content">
            <div className="content1">
              <h1 className="agenda-heading">{globalVars.whatIsHacx}</h1>
              <p className="agenda-description">{globalVars.hacx1}</p>
            </div>
            <div className="row">
              <div className="col-lg-7">
                <div className="content1 clearfix">
                  <div className="content2">
                    <h1 className="agenda-heading">
                      {globalVars.whyWouldYouParticipate}
                    </h1>
                    <p className="agenda-descript">{globalVars.hacx2}</p>
                  </div>
                </div>

                <div className="bragging-text">{globalVars.braggingRights}</div>
              </div>
              <div className="col-lg-5">
                <div className="agenda-lady-img">
                  <img
                    className="agenda-img"
                    src={ladyIcon}
                    alt="medal"
                    width="220"
                    height="250"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default AboutAndAgenda;
