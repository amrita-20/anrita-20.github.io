//Xtreme_Bot
import Praneetha from "../../_assets/images/Xtreme_Bot/bpraneetha.jpg";
import Tejdeep from "../../_assets/images/Xtreme_Bot/kvntejdeep.jpg";
import Chitra from "../../_assets/images/Xtreme_Bot/cvenkatachalapath.jpg";
import Jital from "../../_assets/images/Xtreme_Bot/jijacob.jpg";
import Mandala from "../../_assets/images/Xtreme_Bot/magoud.jpg";

const teams_list = [
  {
    title: "Xtreme Bot - Cognitive engagement in a digital customer journey",
    description: `Build enhancement modules for Xtreme Bot ( SFDC Einstein ) or a new AI powered BOT that showcases how businesses can leverage intelligent AI in customer portals to replicate human actions in interactions, and emulate human sensing & judgement. Bots can be used through the customer lifecycle from trials, conversion from try to buy, purchase etc. to proactively engage with the client, without manual engagement​`,
    teamMember: [
      {
        name: "Chitra Venkatachalapathy",
        domain: "C&M AM&C",
        source: Chitra,
        email: "cvenkatachalapath@deloitte.com",
      },
      {
        name: "Mandala Praveen Goud",
        domain: "C&M",
        source: Mandala,
        email: "magoud@deloitte.com",
      },
      {
        name: "B R Praneetha",
        domain: "C&M",
        source: Praneetha,
        email: "bpraneetha@deloitte.com",
      },
      {
        name: "V N Tejdeep Karamalaputty",
        domain: "C&M",
        source: Tejdeep,
        email: "kvntejdeep@deloitte.com",
      },
      {
        name: "Jita Susan Jacob",
        domain: "C&M AM&C",
        source: Jital,
        email: "jijacob@deloitte.com",
      },
    ],
    associatedIdea: "Accelerate TMT - mProtect - Media Protect Plan "
  },

  ];


  const teams_heading = {
    teams_title: `Meet our HacX Warriors.`,
  }

  export { teams_list , teams_heading};
