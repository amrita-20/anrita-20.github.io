import React, { Component } from "react";
import { teams_list, teams_heading } from "./Teams.config";
import { teamsLabels } from "../../labels";
import Accordion from "../../common/Accordian/Accordion";
import medal from "../../_assets/images/medal.svg";
import Modal from "../../common/Modal/Modal.js";
import { ideaLabels } from "../../labels";
import "./Teams.css";

class Ideas extends Component {
  state = {
    showModal: false,
    selectedTeam: {},
  };
  displayModal = (value) => {
    this.setState({
      showModal: !this.state.showModal,
      selectedTeam: value,
    });
  };
  render() {
    return (
      <div className="team-main-wrapper">
        <h4 className="idea-title">{teams_heading.teams_title}</h4>
        <Modal
          showModal={this.state.showModal}
          data={this.state.selectedTeam}
          hasCloseButton
          outsideAndCloseClick={() => {
            this.setState({ showModal: false });
          }}
        ></Modal>
        <div className="row idea-main">
          {teams_list.map((value, index) => {
            return (
              <div
                className="col-lg-4 col-sm-6 col-12 idea-container-wrapper"
                onClick={(e) => {
                  this.displayModal(value);
                }}
              >
                <div className="idea-container">
                  <p className="idea-head">{value.title}</p>
                  <div className="idea-person-wrapper">
                    <div className="idea-sectorContent">
                      <p className="idea-sector">{ideaLabels.sector} : </p>
                      <p className="idea-sectorValue">{value.sector}</p>
                    </div>
                    <p className="idea-owners">{ideaLabels.idea_owners}</p>
                    <div className="idea-person">
                      {value.teamMember.map((team) => {
                        return (
                          <div className="image">
                              <img className="circular-image" src={team.source} alt={team.name} />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          </div>
      </div>
    );
  }
}

export default Ideas;
